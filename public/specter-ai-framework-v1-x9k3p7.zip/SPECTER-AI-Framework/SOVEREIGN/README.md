# SOVEREIGN

**Sovereign Omniscient Virtual Executive Runtime for Enhanced Intelligence and Generative Navigation**

A sovereign, LocalAI-powered terminal assistant that surpasses Claude Code capabilities.

## Features

- **100% Local**: Uses LocalAI exclusively (qwen2.5-coder-7b, deepseek-coder-33b)
- **Multi-Agent**: LangGraph-style stateful workflows with parallel execution
- **Advanced Memory**: Graph + Vector with automatic pattern extraction
- **Smart Routing**: Predictive tier skipping with quality prediction
- **Voice Interface**: Wake word, Whisper STT, RVC voice conversion
- **Autonomous**: Enhanced Ralph loops with adaptive circuit breakers
- **Rich TUI**: Real-time monitoring dashboard
- **Self-Testing**: Automatic adversarial testing

## Quick Start

```bash
# Install
pip install -e .

# Run REPL
sovereign

# Run with TUI dashboard
sovereign --tui

# Run with voice
sovereign --voice
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         SOVEREIGN                                │
├─────────────────────────────────────────────────────────────────┤
│  CLI/TUI Interface     │    Voice Interface                     │
│  (click + textual)     │    (wake word + whisper + RVC)         │
├─────────────────────────────────────────────────────────────────┤
│                    Orchestration Layer                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ WorkflowGraph│  │ ParallelExec │  │ HandoffRouter│          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
├─────────────────────────────────────────────────────────────────┤
│                      Core Engine                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │  ReAct Loop  │  │ Smart Router │  │  Tool System │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
├─────────────────────────────────────────────────────────────────┤
│                    Memory System                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │KnowledgeGraph│  │ VectorStore  │  │PatternExtract│          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
├─────────────────────────────────────────────────────────────────┤
│                    Autonomy Layer                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │  Ralph Loop  │  │CircuitBreaker│  │  Adversarial │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
├─────────────────────────────────────────────────────────────────┤
│                       LocalAI                                    │
│               http://localhost:8080                              │
└─────────────────────────────────────────────────────────────────┘
```

## Requirements

- Python 3.11+
- LocalAI running at http://localhost:8080
- LocalRecall running at http://localhost:9090 (optional, for vector memory)
- CUDA-capable GPU (for voice features)

## Configuration

Edit `config/sovereign.yaml`:

```yaml
inference:
  engine: "localai"
  base_url: "http://localhost:8080"
  models:
    fast: "qwen2.5-coder-7b"
    large: "deepseek-coder-33b"
```

## Documentation

- [Architecture](docs/architecture.md)
- [Getting Started](docs/getting-started.md)
- [API Reference](docs/api-reference.md)

## License

MIT License - Copyright 2026

## Acknowledgments

- Inspired by Claude Code from Anthropic
- Built on LocalAI, LangGraph patterns, and SPECTER voice architecture
