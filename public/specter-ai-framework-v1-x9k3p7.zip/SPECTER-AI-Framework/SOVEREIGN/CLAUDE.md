# SOVEREIGN - Project AI Instructions

## Project Identity

SOVEREIGN (Sovereign Omniscient Virtual Executive Runtime for Enhanced Intelligence and Generative Navigation) is a LocalAI-powered terminal assistant that operates independently of cloud APIs.

**Location:** `/media/dxverm/Expansion/SOVEREIGN/`
**Language:** Python 3.11+
**LLM Backend:** LocalAI (http://localhost:8080)

---

## Code Style

### Python Standards
- **Type hints**: All functions must have complete type annotations
- **Formatting**: Black (line length 88)
- **Linting**: Ruff with all recommended rules
- **Docstrings**: Google style for all public APIs
- **Testing**: pytest with 80% minimum coverage

### File Organization
- Files under 500 lines
- Functions under 50 lines
- Cyclomatic complexity ≤ 15
- One class per file for major components

### Naming Conventions
- `snake_case` for functions and variables
- `PascalCase` for classes
- `SCREAMING_SNAKE_CASE` for constants
- `_private` prefix for internal functions

---

## Architecture Rules

### Async First
All I/O operations must be async:
```python
# ✅ Correct
async def read_file(path: str) -> str:
    async with aiofiles.open(path) as f:
        return await f.read()

# ❌ Wrong
def read_file(path: str) -> str:
    with open(path) as f:
        return f.read()
```

### Dependency Injection
Use constructor injection for dependencies:
```python
# ✅ Correct
class ReActLoop:
    def __init__(self, engine: InferenceEngine, tools: ToolRegistry):
        self.engine = engine
        self.tools = tools

# ❌ Wrong
class ReActLoop:
    def __init__(self):
        self.engine = LocalAIEngine()  # Hardcoded
```

### Error Handling
Use custom exceptions with context:
```python
# ✅ Correct
raise ToolExecutionError(
    tool="bash",
    message="Command failed",
    context={"command": cmd, "exit_code": code}
)

# ❌ Wrong
raise Exception("Command failed")
```

---

## Module Responsibilities

### `sovereign/core/`
- **engine.py**: LocalAI HTTP client, streaming, model switching
- **react.py**: Thought → Action → Observation loop
- **router.py**: Quality prediction, tier selection
- **streaming.py**: Token-by-token response handling

### `sovereign/tools/`
- **base.py**: Tool protocol definition
- **registry.py**: Tool discovery and registration
- **mcp_server.py**: MCP protocol implementation
- **builtins/**: Built-in tools (read, write, bash, etc.)

### `sovereign/memory/`
- **knowledge_graph.py**: NetworkX entity storage
- **vector_store.py**: LocalRecall integration
- **pattern_extractor.py**: Success/failure pattern mining
- **proactive.py**: Context injection before prompts

### `sovereign/orchestration/`
- **state.py**: Workflow state management
- **graph.py**: LangGraph-style workflow graphs
- **parallel.py**: Concurrent agent execution
- **handoff.py**: Agent-to-agent delegation

### `sovereign/autonomy/`
- **ralph_loop.py**: Enhanced autonomous loop
- **circuit_breaker.py**: Failure detection, recovery
- **quality_gate.py**: Type/lint/test enforcement
- **adversarial.py**: Security self-testing

### `sovereign/voice/`
- **pipeline.py**: Voice I/O coordinator
- **wake_word.py**: OpenWakeWord integration
- **stt.py**: faster-whisper STT
- **tts.py**: edge-tts synthesis
- **rvc.py**: Voice personality conversion

### `sovereign/tui/`
- **app.py**: Textual application
- **panels/**: Dashboard components

---

## Testing Requirements

### Unit Tests
- Every public function must have tests
- Mock external dependencies (LocalAI, LocalRecall)
- Test edge cases and error paths

### Integration Tests
- Test component interactions
- Use test fixtures for LocalAI responses
- Verify MCP protocol compliance

### E2E Tests
- Test complete user workflows
- Verify CLI commands work
- Test voice pipeline (if GPU available)

---

## Security Rules

### Input Validation
- Validate all tool parameters against JSON schemas
- Sanitize file paths (no `..` traversal)
- Escape shell commands

### Output Sanitization
- Filter sensitive data from logs
- Redact API keys, passwords
- Sanitize LLM responses before display

### Sandboxing
- Execute bash commands in bubblewrap when possible
- Limit file system access to project directory
- Rate limit external tool calls

---

## LocalAI Integration

### Endpoint Usage
```python
# Chat completions (primary)
POST http://localhost:8080/v1/chat/completions

# Streaming
POST http://localhost:8080/v1/chat/completions
{"stream": true}

# Models list
GET http://localhost:8080/v1/models
```

### Model Selection
| Task Type | Model | Rationale |
|-----------|-------|-----------|
| Simple | qwen2.5-coder-7b | Fast, good for basic tasks |
| Complex | deepseek-coder-33b | Better reasoning, slower |

### Token Limits
- Context: 8192 tokens default
- Max output: 4096 tokens
- Track usage for cost estimation

---

## Development Commands

```bash
# Run tests
pytest tests/ -v --cov=sovereign --cov-report=term-missing

# Type check
mypy sovereign/ --strict

# Lint
ruff check sovereign/ --fix

# Format
black sovereign/ tests/

# Security scan
bandit -r sovereign/

# All quality checks
./scripts/quality-check.sh
```

---

## Commit Messages

Follow conventional commits:
```
feat(core): add streaming support for LocalAI responses
fix(tools): handle file not found in read tool
test(memory): add unit tests for knowledge graph
docs(readme): update installation instructions
refactor(orchestration): simplify workflow graph
```

---

## Important Patterns

### ReAct Loop Pattern
```
Thought: [reasoning about the task]
Action: [tool_name]
Parameters: [JSON parameters]
Observation: [tool result]
... repeat until done ...
Final Answer: [response to user]
```

### Error Recovery
1. Log the error with context
2. Attempt retry with backoff (1s, 2s, 4s)
3. If retries exhausted, escalate or report
4. Never silently fail

### Memory Integration
1. Before responding, query memory for relevant context
2. After completing tasks, extract and store patterns
3. Use proactive injection for common contexts

---

## Quality Gates

All PRs must pass:
- [ ] `mypy sovereign/ --strict` (0 errors)
- [ ] `ruff check sovereign/` (0 errors)
- [ ] `pytest --cov=sovereign --cov-fail-under=80`
- [ ] `bandit -r sovereign/` (0 high/critical)

---

**Version**: 1.0.0
**Created**: January 2026
