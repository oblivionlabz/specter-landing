# SOVEREIGN Architecture

## Overview

SOVEREIGN is a modular, layered system designed for extensibility and local-first operation.

## Layers

### 1. Interface Layer

**CLI (click)**
- Interactive REPL with streaming responses
- Command history and auto-completion
- Rich output formatting

**TUI (textual)**
- Real-time monitoring dashboard
- Agent status panels
- Cost tracking visualization
- Memory usage graphs

**Voice (OpenWakeWord + Whisper + RVC)**
- Wake word detection: "Hey Sovereign"
- Local speech-to-text with faster-whisper
- Text-to-speech with edge-tts
- Voice personality via RVC conversion

### 2. Orchestration Layer

**WorkflowGraph**
- LangGraph-inspired stateful workflows
- Node-based execution graph
- Conditional branching
- State checkpointing

**ParallelExec**
- Concurrent agent execution
- Work stealing scheduler
- Resource limits

**HandoffRouter**
- Expert agent delegation
- Domain-based routing
- Quality-aware handoffs

### 3. Core Engine Layer

**ReAct Loop**
- Thought → Action → Observation cycle
- Tool calling with JSON schema
- Error recovery and retry

**Smart Router**
- Quality prediction for tier selection
- Task fingerprinting
- Cost optimization
- Auto-escalation

**Tool System**
- MCP protocol (JSON-RPC 2.0)
- Built-in tools: read, write, edit, glob, grep, bash
- External tool discovery
- Security sandboxing

### 4. Memory Layer

**Knowledge Graph (NetworkX)**
- Entity-relation storage
- Relationship inference
- Pattern storage

**Vector Store (LocalRecall)**
- Semantic similarity search
- Embedding generation (sentence-transformers)
- Automatic indexing

**Pattern Extractor**
- Success pattern mining
- Error pattern detection
- Automatic learning

### 5. Autonomy Layer

**Ralph Loop**
- Enhanced autonomous execution
- Completion promise tracking
- Iteration limits

**Circuit Breaker**
- Adaptive failure detection
- Stuck loop prevention
- Automatic recovery

**Quality Gates**
- Type checking (mypy)
- Linting (ruff)
- Test coverage
- Security scanning (bandit)

**Adversarial Tester**
- Input fuzzing
- Edge case generation
- Security probing

### 6. Inference Layer

**LocalAI Integration**
- HTTP client (httpx)
- Streaming support
- Model management
- Token tracking

## Data Flow

```
User Input
    │
    ▼
┌─────────────────┐
│  Interface      │ ◄── CLI/TUI/Voice
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Orchestration  │ ◄── WorkflowGraph, Parallel
└────────┬────────┘
         │
         ▼
┌─────────────────┐     ┌─────────────────┐
│   Core Engine   │ ◄──►│     Memory      │
│   (ReAct Loop)  │     │  (Graph+Vector) │
└────────┬────────┘     └─────────────────┘
         │
         ▼
┌─────────────────┐
│    LocalAI      │
└─────────────────┘
```

## Security Model

### Sandboxing
- Tool execution in bubblewrap containers
- File system restrictions
- Network isolation options

### Input Validation
- JSON schema validation for tools
- Path traversal prevention
- Command injection protection

### Output Sanitization
- Sensitive data filtering
- Log redaction
- Response sanitization

## Configuration

All configuration via `config/sovereign.yaml`:
- Inference settings
- Memory paths
- Autonomy limits
- Voice configuration
- Security policies

## Extensibility

### Custom Tools
Implement `sovereign.tools.base.Tool` protocol:
```python
class MyTool(Tool):
    name = "my_tool"
    description = "Does something useful"
    parameters = {...}  # JSON Schema

    async def execute(self, **params) -> ToolResult:
        ...
```

### Custom Hooks
Register via `sovereign.hooks.registry`:
```python
@hook("pre_tool_use")
async def my_hook(context: HookContext) -> HookResult:
    ...
```

### Custom Agents
Define in workflow graphs:
```python
graph = WorkflowGraph()
graph.add_node("researcher", ResearcherAgent())
graph.add_node("coder", CoderAgent())
graph.add_edge("researcher", "coder")
```
