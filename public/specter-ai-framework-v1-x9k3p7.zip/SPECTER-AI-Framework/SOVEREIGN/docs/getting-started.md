# Getting Started with SOVEREIGN

## Prerequisites

### Required
- Python 3.11 or higher
- LocalAI running at http://localhost:8080 with:
  - `qwen2.5-coder-7b` model loaded
  - `deepseek-coder-33b` model (optional, for complex tasks)

### Optional
- LocalRecall at http://localhost:9090 (for vector memory)
- CUDA-capable GPU (for voice features)
- microphone and speakers (for voice mode)

## Installation

### From Source

```bash
# Clone or navigate to the project
cd /media/dxverm/Expansion/SOVEREIGN

# Create virtual environment
python -m venv .venv
source .venv/bin/activate

# Install in development mode
pip install -e ".[dev]"

# Verify installation
sovereign --version
```

### Verify LocalAI

```bash
# Check LocalAI is running
curl http://localhost:8080/readyz

# List available models
curl http://localhost:8080/v1/models
```

## Configuration

### Basic Setup

Copy and edit the config file:

```bash
cp config/sovereign.yaml.example config/sovereign.yaml
```

Key settings:

```yaml
inference:
  base_url: "http://localhost:8080"
  models:
    fast: "qwen2.5-coder-7b"
    large: "deepseek-coder-33b"
  default_model: "fast"
```

### Memory Configuration

For persistent memory across sessions:

```yaml
memory:
  knowledge_graph_path: "./data/knowledge.db"
  vector_store_url: "http://localhost:9090"
```

## Usage

### Basic REPL

```bash
# Start interactive mode
sovereign

# You'll see:
# SOVEREIGN v1.0.0 - Sovereign AI Terminal Assistant
# Type /help for commands, /quit to exit
#
# >>>
```

### Example Session

```
>>> What files are in the current directory?

Thought: I need to list the files in the current directory.
Action: glob
Parameters: {"pattern": "*"}

Files found:
- README.md
- pyproject.toml
- sovereign/
- tests/
- docs/

>>> Create a Python function that calculates fibonacci numbers

Thought: I'll create an efficient fibonacci function using memoization.
Action: write
Parameters: {"path": "fibonacci.py", "content": "..."}

Created fibonacci.py with memoized fibonacci function.
```

### TUI Mode

```bash
# Launch with dashboard
sovereign --tui
```

Features:
- Real-time token usage
- Agent status panel
- Memory visualization
- Cost tracking

### Voice Mode

```bash
# Enable voice interface
sovereign --voice

# Say "Hey Sovereign" to activate
```

## Commands

| Command | Description |
|---------|-------------|
| `/help` | Show available commands |
| `/quit` | Exit SOVEREIGN |
| `/clear` | Clear conversation |
| `/model <name>` | Switch model |
| `/memory` | Show memory status |
| `/tools` | List available tools |
| `/loop <task>` | Start autonomous loop |
| `/cancel` | Cancel current operation |

## Autonomous Mode (Ralph Loop)

For hands-free task execution:

```
>>> /loop "Create a REST API with user authentication"

Starting Ralph loop...
Max iterations: 50
Quality gates: enabled

[Iteration 1] Planning architecture...
[Iteration 2] Creating project structure...
[Iteration 3] Implementing user model...
...
[Iteration 15] All tests passing. Task complete.

<DONE>
```

## Troubleshooting

### LocalAI Connection Failed

```bash
# Check if LocalAI is running
curl http://localhost:8080/readyz

# Start LocalAI if needed
docker run -p 8080:8080 localai/localai
```

### Model Not Found

```bash
# Pull the model
curl -X POST http://localhost:8080/models/apply \
  -d '{"id": "qwen2.5-coder-7b"}'
```

### Out of Memory

Reduce context size in config:

```yaml
inference:
  max_tokens: 2048  # Reduce from 4096
```

## Next Steps

- Read the [Architecture](architecture.md) docs
- Explore [API Reference](api-reference.md)
- Create custom tools in `sovereign/tools/builtins/`
- Define workflow graphs in `sovereign/orchestration/`
