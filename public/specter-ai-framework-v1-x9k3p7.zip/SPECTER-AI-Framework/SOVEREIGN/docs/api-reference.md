# SOVEREIGN API Reference

## Core Module

### `sovereign.core.engine.LocalAIEngine`

LocalAI inference client with streaming support.

```python
from sovereign.core.engine import LocalAIEngine
from sovereign.config import InferenceConfig

config = InferenceConfig(base_url="http://localhost:8080")
engine = LocalAIEngine(config)
```

#### Methods

##### `async health_check() -> bool`
Check if LocalAI is responding.

##### `async list_models() -> list[str]`
List available models on LocalAI.

##### `async generate(prompt, system=None, model=None, max_tokens=None, temperature=None, stream=False) -> str`
Generate a response from LocalAI.

**Parameters:**
- `prompt` (str): User prompt
- `system` (str, optional): System prompt
- `model` (str, optional): Model to use
- `max_tokens` (int, optional): Maximum tokens
- `temperature` (float, optional): Temperature
- `stream` (bool): Whether to stream

**Returns:** Generated text response

##### `async generate_stream(...) -> AsyncIterator[str]`
Stream a response token by token.

---

## Configuration Module

### `sovereign.config.Config`

Main application configuration.

```python
from sovereign.config import Config

# Load from file
config = Config.load("config/sovereign.yaml")

# Create with defaults
config = Config()

# Create from dict
config = Config.from_dict({"name": "SOVEREIGN"})
```

#### Attributes

- `version` (str): Configuration version
- `name` (str): Application name
- `data_dir` (Path): Data directory
- `log_level` (str): Logging level
- `inference` (InferenceConfig): Inference settings
- `memory` (MemoryConfig): Memory settings
- `autonomy` (AutonomyConfig): Autonomy settings
- `voice` (VoiceConfig): Voice settings

---

## Application Module

### `sovereign.app.SovereignApp`

Main SOVEREIGN application.

```python
from sovereign.app import SovereignApp
from sovereign.config import Config

config = Config.load("config/sovereign.yaml")
app = SovereignApp(config, tui=False, voice=False)
app.run()
```

#### Methods

##### `run() -> None`
Run the application (REPL, TUI, or voice mode).

---

## Tools Module (Phase 2)

### Base Tool Protocol

```python
from sovereign.tools.base import Tool, ToolResult

class MyTool(Tool):
    name = "my_tool"
    description = "Does something useful"
    parameters = {
        "type": "object",
        "properties": {
            "input": {"type": "string"}
        },
        "required": ["input"]
    }

    async def execute(self, **params) -> ToolResult:
        result = do_something(params["input"])
        return ToolResult(success=True, output=result)
```

### Built-in Tools

| Tool | Description |
|------|-------------|
| `read` | Read file contents |
| `write` | Write file contents |
| `edit` | Edit file with replacements |
| `glob` | Find files by pattern |
| `grep` | Search file contents |
| `bash` | Execute shell command |
| `python` | Execute Python code |

---

## Memory Module (Phase 3)

### Knowledge Graph

```python
from sovereign.memory.knowledge_graph import KnowledgeGraph

kg = KnowledgeGraph("./data/knowledge.db")
kg.add_entity("concept", "SOVEREIGN", {"type": "application"})
kg.add_relation("SOVEREIGN", "uses", "LocalAI")
results = kg.query("MATCH (n) RETURN n")
```

### Vector Store

```python
from sovereign.memory.vector_store import VectorStore

vs = VectorStore("http://localhost:9090")
vs.add("doc1", "This is a document", {"source": "user"})
results = vs.search("document", limit=5)
```

---

## Orchestration Module (Phase 5)

### Workflow Graph

```python
from sovereign.orchestration.graph import WorkflowGraph
from sovereign.orchestration.state import State

graph = WorkflowGraph()
graph.add_node("start", StartNode())
graph.add_node("process", ProcessNode())
graph.add_node("end", EndNode())
graph.add_edge("start", "process")
graph.add_edge("process", "end")

state = State()
result = await graph.execute(state)
```

---

## Autonomy Module (Phase 6)

### Ralph Loop

```python
from sovereign.autonomy.ralph_loop import RalphLoop

loop = RalphLoop(
    max_iterations=50,
    quality_gates=True,
    completion_promise="DONE"
)
result = await loop.execute("Build a REST API")
```

### Circuit Breaker

```python
from sovereign.autonomy.circuit_breaker import CircuitBreaker

breaker = CircuitBreaker(
    failure_threshold=3,
    recovery_timeout=30
)

@breaker.protect
async def risky_operation():
    ...
```

---

## Voice Module (Phase 7)

### Voice Pipeline

```python
from sovereign.voice.pipeline import VoicePipeline

pipeline = VoicePipeline(
    wake_word="hey sovereign",
    stt_model="base.en",
    tts_voice="en-US-GuyNeural"
)

# Start listening
await pipeline.start()

# Process voice input
text = await pipeline.listen()
await pipeline.speak("Hello!")
```

---

## TUI Module (Phase 8)

### Dashboard App

```python
from sovereign.tui.app import DashboardApp

app = DashboardApp()
app.run()
```

### Custom Panels

```python
from sovereign.tui.panels.base import Panel

class MyPanel(Panel):
    def compose(self):
        yield Label("My Panel")

    def update(self, data):
        ...
```
