"""Tests for memory module."""

from __future__ import annotations

import tempfile
from datetime import datetime
from pathlib import Path

import pytest

from sovereign.memory.knowledge_graph import (
    Entity,
    Relation,
    KnowledgeGraph,
)
from sovereign.memory.vector_store import (
    VectorStore,
    Document,
    SearchResult,
)
from sovereign.memory.pattern_extractor import (
    Pattern,
    PatternExtractor,
)


class TestEntity:
    """Tests for Entity."""

    def test_create_entity(self) -> None:
        entity = Entity(
            id="test-1",
            type="concept",
            name="Test Entity",
            properties={"key": "value"},
        )
        assert entity.id == "test-1"
        assert entity.type == "concept"
        assert entity.name == "Test Entity"

    def test_entity_with_timestamp(self) -> None:
        entity = Entity(
            id="test-2",
            type="code",
            name="Code Entity",
        )
        assert entity.created_at is not None


class TestRelation:
    """Tests for Relation."""

    def test_create_relation(self) -> None:
        rel = Relation(
            source_id="entity-1",
            target_id="entity-2",
            relation_type="contains",
            weight=0.8,
        )
        assert rel.source_id == "entity-1"
        assert rel.target_id == "entity-2"
        assert rel.weight == 0.8


class TestKnowledgeGraph:
    """Tests for KnowledgeGraph."""

    def test_create_graph(self) -> None:
        kg = KnowledgeGraph()
        assert kg is not None

    def test_add_entity_positional(self) -> None:
        kg = KnowledgeGraph()
        # add_entity takes (entity_type, name, properties, entity_id)
        kg.add_entity("concept", "Concept 1", {}, "e1")
        retrieved = kg.get_entity("e1")
        assert retrieved is not None
        assert retrieved.name == "Concept 1"

    def test_add_relation_positional(self) -> None:
        kg = KnowledgeGraph()
        kg.add_entity("code", "E1", {}, "e1")
        kg.add_entity("code", "E2", {}, "e2")
        # add_relation takes (source_id, target_id, relation_type, properties, weight)
        kg.add_relation("e1", "e2", "calls")
        relations = kg.get_relations("e1")
        assert len(relations) > 0

    def test_get_neighbors(self) -> None:
        kg = KnowledgeGraph()
        kg.add_entity("concept", "Center", {}, "center")
        kg.add_entity("concept", "Neighbor1", {}, "neighbor1")
        kg.add_entity("concept", "Neighbor2", {}, "neighbor2")
        kg.add_relation("center", "neighbor1", "related")
        kg.add_relation("center", "neighbor2", "related")
        neighbors = kg.get_neighbors("center")
        assert len(neighbors) == 2

    def test_remove_entity(self) -> None:
        kg = KnowledgeGraph()
        kg.add_entity("file", "ToRemove", {}, "remove-me")
        kg.remove_entity("remove-me")
        assert kg.get_entity("remove-me") is None

    def test_find_entities(self) -> None:
        kg = KnowledgeGraph()
        kg.add_entity("code", "UserAuthentication", {}, "e1")
        kg.add_entity("code", "UserProfile", {}, "e2")
        kg.add_entity("file", "config.yaml", {}, "e3")
        results = kg.find_entities(name_pattern="User")
        assert len(results) >= 2

    def test_stats(self) -> None:
        kg = KnowledgeGraph()
        kg.add_entity("concept", "Test", {}, "test")
        stats = kg.stats()
        assert isinstance(stats, dict)


class TestDocument:
    """Tests for Document."""

    def test_create_document(self) -> None:
        doc = Document(
            id="doc-1",
            content="Test content",
            metadata={"source": "test"},
        )
        assert doc.id == "doc-1"
        assert doc.content == "Test content"


class TestSearchResult:
    """Tests for SearchResult."""

    def test_create_result(self) -> None:
        doc = Document(id="r1", content="Result content")
        result = SearchResult(document=doc, score=0.95, distance=0.05)
        assert result.score == 0.95


class TestVectorStore:
    """Tests for VectorStore."""

    def test_create_store(self) -> None:
        store = VectorStore()
        assert store is not None

    def test_stats(self) -> None:
        store = VectorStore()
        stats = store.stats()
        assert isinstance(stats, dict)


class TestPattern:
    """Tests for Pattern."""

    def test_create_pattern(self) -> None:
        pattern = Pattern(
            id="p1",
            type="code_style",
            name="Test Pattern",
            description="A test pattern",
            trigger="function def",
            action="apply style",
            confidence=0.9,
        )
        assert pattern.id == "p1"
        assert pattern.confidence == 0.9


class TestPatternExtractor:
    """Tests for PatternExtractor."""

    def test_create_extractor(self) -> None:
        extractor = PatternExtractor()
        assert extractor is not None

    def test_stats(self) -> None:
        extractor = PatternExtractor()
        stats = extractor.stats()
        assert isinstance(stats, dict)
