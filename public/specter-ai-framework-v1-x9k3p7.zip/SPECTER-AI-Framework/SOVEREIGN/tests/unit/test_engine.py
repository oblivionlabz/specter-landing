"""Tests for LocalAI engine."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from sovereign.config import InferenceConfig
from sovereign.core.engine import LocalAIEngine


@pytest.fixture
def engine() -> LocalAIEngine:
    """Create a test engine instance."""
    config = InferenceConfig(
        base_url="http://localhost:8080",
        models={"fast": "test-model"},
        default_model="fast",
    )
    return LocalAIEngine(config)


class TestLocalAIEngine:
    """Tests for LocalAIEngine."""

    def test_init(self, engine: LocalAIEngine) -> None:
        """Test engine initialization."""
        assert engine.base_url == "http://localhost:8080"
        assert engine._client is None

    def test_client_property(self, engine: LocalAIEngine) -> None:
        """Test client lazy initialization."""
        client = engine.client
        assert client is not None
        assert engine._client is client

        # Should return same client
        assert engine.client is client

    @pytest.mark.asyncio
    async def test_close(self, engine: LocalAIEngine) -> None:
        """Test client closing."""
        _ = engine.client  # Initialize client
        await engine.close()
        assert engine._client is None

    @pytest.mark.asyncio
    async def test_health_check_success(self, engine: LocalAIEngine) -> None:
        """Test successful health check."""
        mock_response = MagicMock()
        mock_response.status_code = 200

        with patch.object(engine.client, "get", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = mock_response
            result = await engine.health_check()

        assert result is True
        mock_get.assert_called_once_with("/readyz")

    @pytest.mark.asyncio
    async def test_health_check_failure(self, engine: LocalAIEngine) -> None:
        """Test failed health check."""
        with patch.object(engine.client, "get", new_callable=AsyncMock) as mock_get:
            mock_get.side_effect = Exception("Connection failed")
            result = await engine.health_check()

        assert result is False

    @pytest.mark.asyncio
    async def test_list_models(self, engine: LocalAIEngine) -> None:
        """Test listing models."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "data": [
                {"id": "model1"},
                {"id": "model2"},
            ]
        }

        with patch.object(engine.client, "get", new_callable=AsyncMock) as mock_get:
            mock_get.return_value = mock_response
            models = await engine.list_models()

        assert models == ["model1", "model2"]

    @pytest.mark.asyncio
    async def test_generate_simple(self, engine: LocalAIEngine) -> None:
        """Test simple text generation."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "Hello, I am SOVEREIGN!"}}]
        }

        with patch.object(engine.client, "post", new_callable=AsyncMock) as mock_post:
            mock_post.return_value = mock_response
            result = await engine.generate(
                prompt="Say hello",
                system="You are helpful",
            )

        assert result == "Hello, I am SOVEREIGN!"
        mock_post.assert_called_once()

        # Verify request payload
        call_args = mock_post.call_args
        assert call_args[0][0] == "/v1/chat/completions"
        payload = call_args[1]["json"]
        assert payload["model"] == "test-model"
        assert len(payload["messages"]) == 2
        assert payload["messages"][0]["role"] == "system"
        assert payload["messages"][1]["role"] == "user"

    @pytest.mark.asyncio
    async def test_generate_no_system(self, engine: LocalAIEngine) -> None:
        """Test generation without system prompt."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "Response"}}]
        }

        with patch.object(engine.client, "post", new_callable=AsyncMock) as mock_post:
            mock_post.return_value = mock_response
            result = await engine.generate(prompt="Test")

        call_args = mock_post.call_args
        payload = call_args[1]["json"]
        assert len(payload["messages"]) == 1
        assert payload["messages"][0]["role"] == "user"
