"""Tests for router and cost tracker."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from sovereign.core.router import (
    SmartRouter,
    ModelTier,
    TierConfig,
    TaskFingerprint,
    RoutingDecision,
)
from sovereign.core.cost_tracker import (
    CostTracker,
    CostEntry,
    CostLimits,
)


class TestModelTier:
    """Tests for ModelTier."""

    def test_tiers_exist(self) -> None:
        assert ModelTier.FAST is not None
        assert ModelTier.LARGE is not None

    def test_tier_values(self) -> None:
        assert ModelTier.FAST.value == "fast"


class TestTierConfig:
    """Tests for TierConfig."""

    def test_create_config(self) -> None:
        config = TierConfig(
            tier=ModelTier.FAST,
            model_id="qwen2.5-coder-7b",
            cost_per_million_tokens=0.0,
            quality_score=70,
            max_tokens=4096,
        )
        assert config.tier == ModelTier.FAST

    def test_config_is_local(self) -> None:
        config = TierConfig(
            tier=ModelTier.FAST,
            model_id="test",
            cost_per_million_tokens=0.0,
            quality_score=70,
            max_tokens=4096,
            is_local=True,
        )
        assert config.is_local is True


class TestTaskFingerprint:
    """Tests for TaskFingerprint."""

    def test_create_fingerprint(self) -> None:
        fp = TaskFingerprint(
            task_type="coding",
            complexity=0.7,
            domain="backend",
        )
        assert fp.task_type == "coding"
        assert fp.complexity == 0.7

    def test_fingerprint_with_keywords(self) -> None:
        fp = TaskFingerprint(
            task_type="coding",
            complexity=0.5,
            domain="backend",
            keywords=["python", "api"],
        )
        assert "python" in fp.keywords


class TestRoutingDecision:
    """Tests for RoutingDecision."""

    def test_create_decision(self) -> None:
        decision = RoutingDecision(
            tier=ModelTier.LARGE,
            model_id="deepseek-coder-33b",
            confidence=0.9,
            reason="High complexity task",
            estimated_cost=0.0,
        )
        assert decision.tier == ModelTier.LARGE
        assert decision.confidence == 0.9


class TestSmartRouter:
    """Tests for SmartRouter."""

    def test_create_router(self) -> None:
        router = SmartRouter()
        assert router is not None

    def test_fingerprint_task(self) -> None:
        router = SmartRouter()
        fingerprint = router.fingerprint_task("Write a Python function to sort a list")
        assert fingerprint is not None
        assert isinstance(fingerprint, TaskFingerprint)

    def test_select_tier(self) -> None:
        router = SmartRouter()
        decision = router.select_tier("Print hello world")
        assert decision is not None
        assert isinstance(decision, RoutingDecision)

    def test_get_tier_config(self) -> None:
        router = SmartRouter()
        config = router.get_tier_config(ModelTier.FAST)
        assert config.tier == ModelTier.FAST

    def test_stats(self) -> None:
        router = SmartRouter()
        stats = router.stats()
        assert isinstance(stats, dict)


class TestCostEntry:
    """Tests for CostEntry."""

    def test_create_entry(self) -> None:
        entry = CostEntry(
            amount=0.001,
            tokens=150,
            model="qwen2.5-coder-7b",
            task_id="task-1",
            session_id="session-1",
        )
        assert entry.model == "qwen2.5-coder-7b"
        assert entry.tokens == 150
        assert entry.amount == 0.001


class TestCostLimits:
    """Tests for CostLimits."""

    def test_default_limits(self) -> None:
        limits = CostLimits()
        assert limits.per_task > 0
        assert limits.per_session > 0

    def test_custom_limits(self) -> None:
        limits = CostLimits(
            per_task=1.0,
            per_session=10.0,
            per_day=50.0,
        )
        assert limits.per_task == 1.0


class TestCostTracker:
    """Tests for CostTracker."""

    def test_create_tracker(self) -> None:
        tracker = CostTracker()
        assert tracker is not None

    def test_record_usage(self) -> None:
        tracker = CostTracker()
        tracker.record(
            amount=0.0,
            tokens=150,
            model="qwen2.5-coder-7b",
        )
        cost = tracker.get_session_cost()
        assert cost >= 0

    def test_get_session_cost(self) -> None:
        tracker = CostTracker()
        tracker.record(amount=0.001, tokens=1500, model="test-model")
        cost = tracker.get_session_cost()
        assert cost >= 0

    def test_get_daily_cost(self) -> None:
        tracker = CostTracker()
        tracker.record(amount=0.001, tokens=100, model="test")
        cost = tracker.get_daily_cost()
        assert cost >= 0

    def test_get_remaining(self) -> None:
        tracker = CostTracker()
        remaining = tracker.get_remaining()
        assert isinstance(remaining, dict)

    def test_stats(self) -> None:
        tracker = CostTracker()
        tracker.record(amount=0.0, tokens=100, model="model1")
        stats = tracker.stats()
        assert isinstance(stats, dict)
