"""Tests for proactive memory module."""

from __future__ import annotations

from datetime import datetime

import pytest

from sovereign.memory.proactive import (
    ProactiveMemory,
    InjectedContext,
)


class TestInjectedContext:
    """Tests for InjectedContext."""

    def test_create_context(self) -> None:
        context = InjectedContext(
            patterns=["pattern1", "pattern2"],
            knowledge=["fact1", "fact2"],
            memories=["mem1"],
            total_tokens=150,
        )
        assert "pattern1" in context.patterns
        assert "fact1" in context.knowledge
        assert context.total_tokens == 150

    def test_context_empty_lists(self) -> None:
        context = InjectedContext(
            patterns=[],
            knowledge=[],
            memories=[],
            total_tokens=0,
        )
        assert len(context.patterns) == 0
        assert context.total_tokens == 0

    def test_context_memories(self) -> None:
        context = InjectedContext(
            patterns=[],
            knowledge=[],
            memories=["memory1", "memory2", "memory3"],
            total_tokens=300,
        )
        assert len(context.memories) == 3


class TestProactiveMemory:
    """Tests for ProactiveMemory."""

    def test_create_memory(self) -> None:
        memory = ProactiveMemory()
        assert memory is not None

    def test_memory_config(self) -> None:
        memory = ProactiveMemory(
            relevance_threshold=0.8,
            max_tokens=3000,
        )
        assert memory.relevance_threshold == 0.8
        assert memory.max_tokens == 3000

    def test_memory_default_values(self) -> None:
        memory = ProactiveMemory()
        assert memory.max_tokens == 2000
        assert memory.relevance_threshold == 0.6

    def test_memory_components(self) -> None:
        memory = ProactiveMemory()
        # Components should be None by default
        assert memory.knowledge_graph is None
        assert memory.vector_store is None
        assert memory.pattern_extractor is None
