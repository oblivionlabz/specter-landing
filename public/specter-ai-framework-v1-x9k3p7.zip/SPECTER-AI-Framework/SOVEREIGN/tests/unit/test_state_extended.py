"""Extended tests for state and parallel orchestration modules."""

from __future__ import annotations

import asyncio
from datetime import datetime

import pytest

from sovereign.orchestration.state import (
    WorkflowState,
    StateManager,
    Checkpoint,
    WorkflowStatus,
)
from sovereign.orchestration.parallel import (
    ParallelExecutor,
    FanOutFanIn,
    TaskGroup,
    ParallelTask,
    TaskResult,
    TaskStatus,
)
from sovereign.orchestration.graph import (
    WorkflowGraph,
    Node,
    Edge,
)


class TestWorkflowStateExtended:
    """Extended tests for WorkflowState."""

    def test_state_with_all_fields(self) -> None:
        state = WorkflowState(
            workflow_id="wf-full",
            data={"input": "test", "result": None},
            status=WorkflowStatus.RUNNING,
        )
        assert state.workflow_id == "wf-full"
        assert state.status == WorkflowStatus.RUNNING
        assert state.data["input"] == "test"

    def test_state_data_modification(self) -> None:
        state = WorkflowState(workflow_id="wf-mod", data={"counter": 0})
        state.data["counter"] = 5
        assert state.data["counter"] == 5

    def test_state_timestamps(self) -> None:
        state = WorkflowState(workflow_id="wf-time", data={})
        assert state.created_at is not None

    def test_multiple_states(self) -> None:
        state1 = WorkflowState(workflow_id="wf-1", data={"v": 1})
        state2 = WorkflowState(workflow_id="wf-2", data={"v": 2})
        assert state1.workflow_id != state2.workflow_id
        assert state1.data["v"] != state2.data["v"]


class TestStateManagerExtended:
    """Extended tests for StateManager."""

    def test_create_and_get_state(self) -> None:
        manager = StateManager()
        assert manager is not None

    def test_manager_operations(self) -> None:
        manager = StateManager()
        stats = manager.stats()
        assert isinstance(stats, dict)


class TestCheckpointExtended:
    """Extended tests for Checkpoint."""

    def test_checkpoint_with_metadata(self) -> None:
        checkpoint = Checkpoint(
            checkpoint_id="cp-meta",
            workflow_id="wf-cp-meta",
            state_snapshot={"step": 3, "data": [1, 2, 3]},
            node="process_node",
        )
        assert checkpoint.checkpoint_id == "cp-meta"
        assert checkpoint.state_snapshot["step"] == 3
        assert len(checkpoint.state_snapshot["data"]) == 3

    def test_checkpoint_node(self) -> None:
        checkpoint = Checkpoint(
            checkpoint_id="cp-node",
            workflow_id="wf-node",
            state_snapshot={},
            node="start",
        )
        assert checkpoint.node == "start"


class TestTaskStatus:
    """Tests for TaskStatus enum."""

    def test_statuses_exist(self) -> None:
        assert TaskStatus.PENDING is not None
        assert TaskStatus.RUNNING is not None
        assert TaskStatus.COMPLETED is not None
        assert TaskStatus.FAILED is not None


class TestTaskResult:
    """Tests for TaskResult."""

    def test_create_success_result(self) -> None:
        result = TaskResult(
            task_id="task-1",
            status=TaskStatus.COMPLETED,
            result="completed",
        )
        assert result.task_id == "task-1"
        assert result.status == TaskStatus.COMPLETED
        assert result.result == "completed"

    def test_create_failure_result(self) -> None:
        result = TaskResult(
            task_id="task-fail",
            status=TaskStatus.FAILED,
            error="Something went wrong",
        )
        assert result.status == TaskStatus.FAILED
        assert result.error == "Something went wrong"

    def test_result_with_duration(self) -> None:
        result = TaskResult(
            task_id="task-dur",
            status=TaskStatus.COMPLETED,
            duration_seconds=1.5,
        )
        assert result.duration_seconds == 1.5


class TestParallelTask:
    """Tests for ParallelTask."""

    def test_create_task(self) -> None:
        async def dummy_fn(x):
            return x

        task = ParallelTask(
            task_id="pt-1",
            func=dummy_fn,
            input_data="test",
        )
        assert task.task_id == "pt-1"
        assert task.input_data == "test"

    def test_task_with_timeout(self) -> None:
        async def add_fn(x):
            return x + 1

        task = ParallelTask(
            task_id="pt-timeout",
            func=add_fn,
            input_data=5,
            timeout=10.0,
        )
        assert task.timeout == 10.0

    def test_task_with_retry(self) -> None:
        async def retry_fn(x):
            return x

        task = ParallelTask(
            task_id="pt-retry",
            func=retry_fn,
            input_data=None,
            retry_count=3,
        )
        assert task.retry_count == 3


class TestTaskGroup:
    """Tests for TaskGroup."""

    def test_create_group(self) -> None:
        group = TaskGroup(name="test-group")
        assert group.name == "test-group"

    def test_group_max_concurrent(self) -> None:
        group = TaskGroup(name="concurrent-group", max_concurrent=10)
        assert group.max_concurrent == 10

    def test_group_add_task(self) -> None:
        async def task_fn(x):
            return x

        group = TaskGroup(name="group-with-tasks")
        # add() takes (task_id, func, input_data, ...)
        group.add("t1", task_fn, "data")
        # Group should have the task
        assert group.name == "group-with-tasks"

    def test_group_stats(self) -> None:
        group = TaskGroup(name="stats-group")
        stats = group.stats()
        assert isinstance(stats, dict)


class TestParallelExecutorExtended:
    """Extended tests for ParallelExecutor."""

    def test_executor_max_concurrent(self) -> None:
        executor = ParallelExecutor(max_concurrent=4)
        assert executor is not None

    def test_executor_default(self) -> None:
        executor = ParallelExecutor()
        assert executor is not None

    def test_executor_with_timeout(self) -> None:
        executor = ParallelExecutor(default_timeout=60.0)
        assert executor is not None


class TestFanOutFanInExtended:
    """Extended tests for FanOutFanIn."""

    def test_create_with_all_functions(self) -> None:
        async def split(data):
            return [data[i:i+2] for i in range(0, len(data), 2)]

        async def process(chunk):
            return sum(chunk)

        async def aggregate(results):
            return sum(results)

        fofi = FanOutFanIn(
            name="sum-fofi",
            split_func=split,
            process_func=process,
            aggregate_func=aggregate,
        )
        assert fofi.name == "sum-fofi"

    def test_fofi_name(self) -> None:
        async def identity(x):
            return x

        fofi = FanOutFanIn(
            name="identity-fofi",
            split_func=identity,
            process_func=identity,
            aggregate_func=identity,
        )
        assert fofi.name == "identity-fofi"


class TestWorkflowGraphExtended:
    """Extended tests for WorkflowGraph."""

    def test_graph_with_edges(self) -> None:
        graph = WorkflowGraph(name="edge-test")

        async def node_a(state):
            return {**state, "a": True}

        async def node_b(state):
            return {**state, "b": True}

        graph.add_node("a", node_a, "Node A")
        graph.add_node("b", node_b, "Node B")
        graph.add_edge("a", "b")

        assert graph.name == "edge-test"

    def test_graph_entry_point(self) -> None:
        graph = WorkflowGraph(name="entry-test")

        async def start_node(state):
            return state

        graph.add_node("start", start_node, "Start")
        graph.set_entry_point("start")

        assert graph.name == "entry-test"

    def test_graph_finish_point(self) -> None:
        graph = WorkflowGraph(name="finish-test")

        async def end_node(state):
            return state

        graph.add_node("end", end_node, "End")
        graph.set_finish_point("end")

        assert graph.name == "finish-test"

    def test_graph_state_manager(self) -> None:
        graph = WorkflowGraph(name="state-test")
        # Graph should have a state manager
        assert graph.state_manager is not None


class TestNodeCreation:
    """Tests for Node creation."""

    def test_node_with_description(self) -> None:
        async def process(state):
            return state

        node = Node(
            name="Process Node",
            func=process,
            description="Processes the state",
        )
        assert node.name == "Process Node"
        assert node.description == "Processes the state"

    def test_node_with_timeout(self) -> None:
        async def analyze(state):
            return state

        node = Node(
            name="Analyzer",
            func=analyze,
            description="Analyzes data",
            timeout=30.0,
        )
        assert node.timeout == 30.0

    def test_node_with_retry(self) -> None:
        async def retry_node(state):
            return state

        node = Node(
            name="Retry Node",
            func=retry_node,
            retry_count=3,
        )
        assert node.retry_count == 3


class TestEdgeCreation:
    """Tests for Edge creation."""

    def test_edge_basic(self) -> None:
        edge = Edge(source="node1", target="node2")
        assert edge.source == "node1"
        assert edge.target == "node2"

    def test_edge_self_loop(self) -> None:
        edge = Edge(source="loop", target="loop")
        assert edge.source == edge.target
