"""Tests for orchestration module."""

from __future__ import annotations

import asyncio
from datetime import datetime

import pytest

from sovereign.orchestration.state import (
    WorkflowState,
    StateManager,
    Checkpoint,
    WorkflowStatus,
)
from sovereign.orchestration.graph import (
    WorkflowGraph,
    Node,
    Edge,
)
from sovereign.orchestration.parallel import (
    ParallelExecutor,
    FanOutFanIn,
)
from sovereign.orchestration.handoff import (
    HandoffRouter,
    ExpertAgent,
    HandoffDecision,
)


class TestWorkflowStatus:
    """Tests for WorkflowStatus."""

    def test_statuses_exist(self) -> None:
        assert WorkflowStatus.PENDING is not None
        assert WorkflowStatus.RUNNING is not None
        assert WorkflowStatus.COMPLETED is not None


class TestWorkflowState:
    """Tests for WorkflowState."""

    def test_create_state(self) -> None:
        state = WorkflowState(
            workflow_id="wf-1",
            data={"key": "value"},
        )
        assert state.workflow_id == "wf-1"
        assert state.data["key"] == "value"

    def test_state_status(self) -> None:
        state = WorkflowState(workflow_id="wf-2", data={})
        assert state.status == WorkflowStatus.PENDING


class TestCheckpoint:
    """Tests for Checkpoint."""

    def test_create_checkpoint(self) -> None:
        checkpoint = Checkpoint(
            checkpoint_id="cp-1",
            workflow_id="wf-cp",
            state_snapshot={"step": 1},
            node="start",
        )
        assert checkpoint.checkpoint_id == "cp-1"


class TestStateManager:
    """Tests for StateManager."""

    def test_create_manager(self) -> None:
        manager = StateManager()
        assert manager is not None

    def test_stats(self) -> None:
        manager = StateManager()
        stats = manager.stats()
        assert isinstance(stats, dict)


class TestNode:
    """Tests for Node."""

    def test_create_node(self) -> None:
        async def dummy_func(state):
            return state

        node = Node(
            name="Start Node",
            func=dummy_func,
            description="Start of workflow",
        )
        assert node.name == "Start Node"


class TestEdge:
    """Tests for Edge."""

    def test_create_edge(self) -> None:
        edge = Edge(
            source="node-1",
            target="node-2",
        )
        assert edge.source == "node-1"
        assert edge.target == "node-2"


class TestWorkflowGraph:
    """Tests for WorkflowGraph."""

    def test_create_graph(self) -> None:
        graph = WorkflowGraph(name="test-workflow")
        assert graph.name == "test-workflow"

    def test_add_node_positional(self) -> None:
        graph = WorkflowGraph(name="add-node-test")

        async def task_func(state):
            return state

        # add_node takes (name, func, description, ...)
        # Test that add_node completes without error
        graph.add_node("n1", task_func, "Node 1")
        # WorkflowGraph stores nodes internally - verify graph exists
        assert graph.name == "add-node-test"


class TestParallelExecutor:
    """Tests for ParallelExecutor."""

    def test_create_executor(self) -> None:
        executor = ParallelExecutor()
        assert executor is not None


class TestFanOutFanIn:
    """Tests for FanOutFanIn."""

    def test_create_fan_out_fan_in(self) -> None:
        async def split(data):
            return data

        async def process(item):
            return item * 2

        async def aggregate(results):
            return sum(results)

        fofi = FanOutFanIn(
            name="test-fofi",
            split_func=split,
            process_func=process,
            aggregate_func=aggregate,
        )
        assert fofi is not None


class TestExpertAgent:
    """Tests for ExpertAgent."""

    def test_create_expert(self) -> None:
        expert = ExpertAgent(
            name="Code Expert",
            description="Expert in coding",
            capabilities=["python", "javascript"],
            keywords=["code", "programming"],
        )
        assert expert.name == "Code Expert"

    def test_expert_capabilities(self) -> None:
        expert = ExpertAgent(
            name="Test",
            description="Test",
            capabilities=["search", "analyze"],
        )
        assert "search" in expert.capabilities


class TestHandoffDecision:
    """Tests for HandoffDecision."""

    def test_create_decision(self) -> None:
        expert = ExpertAgent(
            name="Expert",
            description="Test",
            capabilities=[],
        )
        decision = HandoffDecision(
            task="Test task",
            selected_agent=expert,
            confidence=0.95,
            reason="Best match for task",
        )
        assert decision.confidence == 0.95


class TestHandoffRouter:
    """Tests for HandoffRouter."""

    def test_create_router(self) -> None:
        router = HandoffRouter()
        assert router is not None

    def test_register_expert(self) -> None:
        router = HandoffRouter()
        expert = ExpertAgent(
            name="Test Expert",
            description="For testing",
            capabilities=["search"],
            keywords=["test"],
        )
        router.register_expert(expert)
        assert router.get_expert("Test Expert") is not None

    def test_list_experts(self) -> None:
        router = HandoffRouter()
        router.register_expert(ExpertAgent(
            name="Agent 1",
            description="Test",
            capabilities=[],
        ))
        experts = router.list_experts()
        assert len(experts) >= 1

    def test_stats(self) -> None:
        router = HandoffRouter()
        stats = router.stats()
        assert isinstance(stats, dict)
