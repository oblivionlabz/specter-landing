"""Tests for builtin tools."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from sovereign.tools.builtins.bash import BashTool
from sovereign.tools.builtins.file_ops import (
    ReadTool,
    WriteTool,
    EditTool,
    GlobTool,
    GrepTool,
)
from sovereign.tools.base import ToolResult


class TestBashTool:
    """Tests for BashTool."""

    def test_create_tool(self) -> None:
        tool = BashTool()
        assert tool is not None

    def test_name(self) -> None:
        tool = BashTool()
        assert tool.name == "bash"

    def test_description(self) -> None:
        tool = BashTool()
        assert "command" in tool.description.lower() or "shell" in tool.description.lower()

    def test_parameters(self) -> None:
        tool = BashTool()
        params = tool.parameters
        assert "type" in params
        assert params["type"] == "object"

    @pytest.mark.asyncio
    async def test_execute_echo(self) -> None:
        tool = BashTool()
        result = await tool.execute(command="echo hello")
        assert result.success is True
        assert "hello" in str(result.output)

    @pytest.mark.asyncio
    async def test_execute_pwd(self) -> None:
        tool = BashTool()
        result = await tool.execute(command="pwd")
        assert result.success is True
        assert result.output is not None

    def test_to_mcp_schema(self) -> None:
        tool = BashTool()
        schema = tool.to_mcp_schema()
        assert "name" in schema
        assert schema["name"] == "bash"


class TestReadTool:
    """Tests for ReadTool."""

    def test_create_tool(self) -> None:
        tool = ReadTool()
        assert tool is not None

    def test_name(self) -> None:
        tool = ReadTool()
        assert tool.name == "read" or tool.name == "read_file"

    def test_description(self) -> None:
        tool = ReadTool()
        assert len(tool.description) > 0

    def test_parameters(self) -> None:
        tool = ReadTool()
        params = tool.parameters
        assert "type" in params

    @pytest.mark.asyncio
    async def test_execute_read_file(self) -> None:
        tool = ReadTool()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("test content here")
            temp_path = f.name

        try:
            result = await tool.execute(path=temp_path)
            assert result.success is True
            assert "test content" in str(result.output)
        finally:
            Path(temp_path).unlink()

    @pytest.mark.asyncio
    async def test_execute_file_not_found(self) -> None:
        tool = ReadTool()
        result = await tool.execute(path="/nonexistent/path/file.txt")
        assert result.success is False

    def test_to_mcp_schema(self) -> None:
        tool = ReadTool()
        schema = tool.to_mcp_schema()
        assert "name" in schema


class TestWriteTool:
    """Tests for WriteTool."""

    def test_create_tool(self) -> None:
        tool = WriteTool()
        assert tool is not None

    def test_name(self) -> None:
        tool = WriteTool()
        assert tool.name == "write" or tool.name == "write_file"

    def test_description(self) -> None:
        tool = WriteTool()
        assert len(tool.description) > 0

    def test_parameters(self) -> None:
        tool = WriteTool()
        params = tool.parameters
        assert "type" in params

    @pytest.mark.asyncio
    async def test_execute_write_file(self) -> None:
        tool = WriteTool()
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir) / "test_write.txt"
            result = await tool.execute(path=str(temp_path), content="written content")
            assert result.success is True
            assert temp_path.exists()
            assert temp_path.read_text() == "written content"

    def test_to_mcp_schema(self) -> None:
        tool = WriteTool()
        schema = tool.to_mcp_schema()
        assert "name" in schema


class TestEditTool:
    """Tests for EditTool."""

    def test_create_tool(self) -> None:
        tool = EditTool()
        assert tool is not None

    def test_name(self) -> None:
        tool = EditTool()
        assert tool.name == "edit" or tool.name == "edit_file"

    def test_description(self) -> None:
        tool = EditTool()
        assert len(tool.description) > 0

    def test_parameters(self) -> None:
        tool = EditTool()
        params = tool.parameters
        assert "type" in params

    @pytest.mark.asyncio
    async def test_execute_edit_file(self) -> None:
        tool = EditTool()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("original text")
            temp_path = f.name

        try:
            result = await tool.execute(
                path=temp_path,
                old_string="original",
                new_string="modified"
            )
            assert result.success is True
            content = Path(temp_path).read_text()
            assert "modified" in content
        finally:
            Path(temp_path).unlink()

    def test_to_mcp_schema(self) -> None:
        tool = EditTool()
        schema = tool.to_mcp_schema()
        assert "name" in schema


class TestGlobTool:
    """Tests for GlobTool."""

    def test_create_tool(self) -> None:
        tool = GlobTool()
        assert tool is not None

    def test_name(self) -> None:
        tool = GlobTool()
        assert tool.name == "glob" or tool.name == "find_files"

    def test_description(self) -> None:
        tool = GlobTool()
        assert len(tool.description) > 0

    def test_parameters(self) -> None:
        tool = GlobTool()
        params = tool.parameters
        assert "type" in params

    @pytest.mark.asyncio
    async def test_execute_glob(self) -> None:
        tool = GlobTool()
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create test files
            (Path(temp_dir) / "test1.txt").write_text("content1")
            (Path(temp_dir) / "test2.txt").write_text("content2")
            (Path(temp_dir) / "other.py").write_text("content3")

            result = await tool.execute(pattern="*.txt", path=temp_dir)
            assert result.success is True
            output = str(result.output)
            assert "test1.txt" in output or len(result.output) >= 0

    def test_to_mcp_schema(self) -> None:
        tool = GlobTool()
        schema = tool.to_mcp_schema()
        assert "name" in schema


class TestGrepTool:
    """Tests for GrepTool."""

    def test_create_tool(self) -> None:
        tool = GrepTool()
        assert tool is not None

    def test_name(self) -> None:
        tool = GrepTool()
        assert tool.name == "grep" or tool.name == "search"

    def test_description(self) -> None:
        tool = GrepTool()
        assert len(tool.description) > 0

    def test_parameters(self) -> None:
        tool = GrepTool()
        params = tool.parameters
        assert "type" in params

    @pytest.mark.asyncio
    async def test_execute_grep(self) -> None:
        tool = GrepTool()
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create test file with searchable content
            test_file = Path(temp_dir) / "searchable.txt"
            test_file.write_text("line1 hello\nline2 world\nline3 hello world")

            result = await tool.execute(pattern="hello", path=temp_dir)
            assert result.success is True

    def test_to_mcp_schema(self) -> None:
        tool = GrepTool()
        schema = tool.to_mcp_schema()
        assert "name" in schema


class TestToolResultHelpers:
    """Tests for ToolResult helper methods."""

    def test_ok_method(self) -> None:
        result = ToolResult.ok("success output", duration=1.5)
        assert result.success is True
        assert result.output == "success output"
        assert result.metadata.get("duration") == 1.5

    def test_fail_method(self) -> None:
        from sovereign.tools.base import ToolErrorCode
        result = ToolResult.fail(
            ToolErrorCode.EXECUTION_FAILED,
            "Something went wrong",
            details={"file": "test.txt"}
        )
        assert result.success is False
        assert result.error is not None
        assert result.error.code == ToolErrorCode.EXECUTION_FAILED

    def test_to_dict(self) -> None:
        result = ToolResult(success=True, output="test", metadata={"key": "value"})
        d = result.to_dict()
        assert d["success"] is True
        assert d["output"] == "test"
