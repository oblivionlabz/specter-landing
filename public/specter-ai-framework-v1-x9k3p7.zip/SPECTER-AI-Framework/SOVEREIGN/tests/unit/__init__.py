"""Unit tests for SOVEREIGN."""
