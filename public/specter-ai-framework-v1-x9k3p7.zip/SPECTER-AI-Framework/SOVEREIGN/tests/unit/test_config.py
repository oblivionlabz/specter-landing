"""Tests for configuration module."""

import pytest
from pathlib import Path
from sovereign.config import Config, InferenceConfig, MemoryConfig


class TestInferenceConfig:
    """Tests for InferenceConfig."""

    def test_default_values(self) -> None:
        """Test default configuration values."""
        config = InferenceConfig()

        assert config.engine == "localai"
        assert config.base_url == "http://localhost:8080"
        assert config.timeout == 120
        assert config.default_model == "fast"
        assert config.max_tokens == 4096
        assert config.temperature == 0.7
        assert config.stream is True

    def test_models_dict(self) -> None:
        """Test models dictionary."""
        config = InferenceConfig()

        assert "fast" in config.models
        assert "large" in config.models
        assert config.models["fast"] == "qwen2.5-coder-7b"
        assert config.models["large"] == "deepseek-coder-33b"


class TestMemoryConfig:
    """Tests for MemoryConfig."""

    def test_default_values(self) -> None:
        """Test default configuration values."""
        config = MemoryConfig()

        assert config.knowledge_graph_path == "./data/knowledge.db"
        assert config.vector_store_url == "http://localhost:9090"
        assert config.vector_collection == "sovereign_memories"


class TestConfig:
    """Tests for main Config."""

    def test_default_config(self) -> None:
        """Test default configuration."""
        config = Config()

        assert config.version == "1.0.0"
        assert config.name == "SOVEREIGN"
        assert config.log_level == "INFO"
        assert isinstance(config.inference, InferenceConfig)
        assert isinstance(config.memory, MemoryConfig)

    def test_load_nonexistent_file(self) -> None:
        """Test loading from nonexistent file returns defaults."""
        config = Config.load("/nonexistent/path/config.yaml")

        assert config.name == "SOVEREIGN"
        assert config.version == "1.0.0"

    def test_from_dict(self) -> None:
        """Test creating config from dictionary."""
        data = {
            "version": "2.0.0",
            "name": "TEST",
            "core": {
                "data_dir": "/tmp/test",
                "log_level": "DEBUG",
            },
            "inference": {
                "base_url": "http://test:8080",
                "default_model": "large",
            },
        }

        config = Config.from_dict(data)

        assert config.version == "2.0.0"
        assert config.name == "TEST"
        assert config.log_level == "DEBUG"
        assert config.inference.base_url == "http://test:8080"
        assert config.inference.default_model == "large"
