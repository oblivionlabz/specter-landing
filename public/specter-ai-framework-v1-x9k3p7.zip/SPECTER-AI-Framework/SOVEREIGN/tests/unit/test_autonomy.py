"""Tests for autonomy module."""

from __future__ import annotations

import asyncio
from datetime import datetime

import pytest

from sovereign.autonomy.circuit_breaker import (
    CircuitBreaker,
    CircuitState,
    BreakerConfig,
    AdaptiveBreaker,
)
from sovereign.autonomy.quality_gate import (
    QualityGate,
    QualityResult,
)
from sovereign.autonomy.ralph_loop import (
    RalphLoop,
    LoopConfig,
    LoopStatus,
    IterationResult,
)


class TestCircuitState:
    """Tests for CircuitState."""

    def test_states_exist(self) -> None:
        assert CircuitState.CLOSED is not None
        assert CircuitState.OPEN is not None
        assert CircuitState.HALF_OPEN is not None


class TestBreakerConfig:
    """Tests for BreakerConfig."""

    def test_default_config(self) -> None:
        config = BreakerConfig()
        assert config.max_consecutive_failures > 0
        assert config.recovery_timeout > 0

    def test_custom_config(self) -> None:
        config = BreakerConfig(
            max_consecutive_failures=10,
            recovery_timeout=60.0,
        )
        assert config.max_consecutive_failures == 10


class TestCircuitBreaker:
    """Tests for CircuitBreaker."""

    def test_create_breaker(self) -> None:
        breaker = CircuitBreaker()
        assert breaker.state == CircuitState.CLOSED

    def test_initial_state(self) -> None:
        breaker = CircuitBreaker()
        assert breaker.is_closed
        assert not breaker.is_open

    def test_record_result_success(self) -> None:
        breaker = CircuitBreaker()
        breaker.record_result(success=True)
        assert breaker.state == CircuitState.CLOSED

    def test_record_result_failures_open(self) -> None:
        config = BreakerConfig(max_consecutive_failures=3)
        breaker = CircuitBreaker(config=config)

        for _ in range(3):
            breaker.record_result(success=False, error="Test failure")

        assert breaker.state == CircuitState.OPEN

    def test_allow_request_closed(self) -> None:
        breaker = CircuitBreaker()
        assert breaker.allow_request() is True

    def test_reset(self) -> None:
        config = BreakerConfig(max_consecutive_failures=1)
        breaker = CircuitBreaker(config=config)
        breaker.record_result(success=False, error="Error")
        breaker.reset()
        assert breaker.state == CircuitState.CLOSED

    def test_get_stats(self) -> None:
        breaker = CircuitBreaker()
        breaker.record_result(success=True)
        stats = breaker.get_stats()
        # stats is a BreakerStats object with state attribute
        assert hasattr(stats, "state")
        assert stats.state == CircuitState.CLOSED

    def test_force_open(self) -> None:
        breaker = CircuitBreaker()
        breaker.force_open()
        assert breaker.is_open

    def test_force_close(self) -> None:
        breaker = CircuitBreaker()
        breaker.force_open()
        breaker.force_close()
        assert breaker.is_closed

    def test_get_health(self) -> None:
        breaker = CircuitBreaker()
        health = breaker.get_health()
        assert health is not None


class TestAdaptiveBreaker:
    """Tests for AdaptiveBreaker."""

    def test_create_adaptive(self) -> None:
        breaker = AdaptiveBreaker()
        assert breaker is not None


class TestQualityResult:
    """Tests for QualityResult."""

    def test_create_result(self) -> None:
        result = QualityResult(
            check_name="lint",
            decision="pass",
            score=0.95,
            message="All checks passed",
        )
        assert result.check_name == "lint"
        assert result.score == 0.95


class TestQualityGate:
    """Tests for QualityGate."""

    def test_create_gate(self) -> None:
        gate = QualityGate()
        assert gate is not None

    def test_get_checks(self) -> None:
        gate = QualityGate()
        checks = gate.get_checks()
        assert isinstance(checks, list)


class TestLoopStatus:
    """Tests for LoopStatus."""

    def test_states_exist(self) -> None:
        assert LoopStatus.IDLE is not None
        assert LoopStatus.RUNNING is not None
        assert LoopStatus.PAUSED is not None
        assert LoopStatus.COMPLETED is not None


class TestIterationResult:
    """Tests for IterationResult."""

    def test_create_result(self) -> None:
        result = IterationResult(
            iteration=1,
            success=True,
            output="test result",
        )
        assert result.iteration == 1
        assert result.success is True


class TestLoopConfig:
    """Tests for LoopConfig."""

    def test_default_config(self) -> None:
        config = LoopConfig()
        assert config.max_iterations > 0

    def test_custom_config(self) -> None:
        config = LoopConfig(
            max_iterations=100,
            completion_promise="DONE",
        )
        assert config.max_iterations == 100


class TestRalphLoop:
    """Tests for RalphLoop."""

    def test_create_loop(self) -> None:
        config = LoopConfig(max_iterations=10)
        loop = RalphLoop(config=config)
        assert loop is not None
        assert loop.status == LoopStatus.IDLE

    def test_get_summary(self) -> None:
        loop = RalphLoop(config=LoopConfig())
        summary = loop.get_summary()
        assert summary is not None

    def test_pause(self) -> None:
        loop = RalphLoop(config=LoopConfig())
        # pause() method exists
        assert hasattr(loop, "pause")

    def test_cancel(self) -> None:
        loop = RalphLoop(config=LoopConfig())
        # cancel() method exists
        assert hasattr(loop, "cancel")

    def test_reset(self) -> None:
        loop = RalphLoop(config=LoopConfig())
        loop.reset()
        assert loop.status == LoopStatus.IDLE
