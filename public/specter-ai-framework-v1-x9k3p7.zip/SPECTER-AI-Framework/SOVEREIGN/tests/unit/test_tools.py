"""Tests for tools module."""

from __future__ import annotations

import pytest
from typing import Any

from sovereign.tools.base import (
    ToolResult,
    BaseTool,
    ToolError,
    ToolErrorCode,
)
from sovereign.tools.registry import ToolRegistry


class TestToolResult:
    """Tests for ToolResult."""

    def test_success_result(self) -> None:
        result = ToolResult(success=True, output={"data": "test"})
        assert result.success is True
        assert result.output == {"data": "test"}

    def test_error_result(self) -> None:
        result = ToolResult(success=False, error="Something went wrong")
        assert result.success is False
        assert result.error == "Something went wrong"

    def test_result_with_metadata(self) -> None:
        result = ToolResult(
            success=True,
            output="test",
            metadata={"duration": 0.5},
        )
        assert result.metadata["duration"] == 0.5


class TestToolError:
    """Tests for ToolError."""

    def test_create_error(self) -> None:
        error = ToolError(
            code=ToolErrorCode.EXECUTION_FAILED,
            message="Execution failed",
        )
        assert error.code == ToolErrorCode.EXECUTION_FAILED
        assert error.message == "Execution failed"

    def test_error_with_details(self) -> None:
        error = ToolError(
            code=ToolErrorCode.INVALID_PARAMS,
            message="Invalid parameters",
            details={"param": "value"},
        )
        assert error.details["param"] == "value"


class TestToolErrorCode:
    """Tests for ToolErrorCode."""

    def test_error_codes_exist(self) -> None:
        assert ToolErrorCode.INVALID_PARAMS is not None
        assert ToolErrorCode.EXECUTION_FAILED is not None
        assert ToolErrorCode.PERMISSION_DENIED is not None
        assert ToolErrorCode.NOT_FOUND is not None
        assert ToolErrorCode.TIMEOUT is not None
        assert ToolErrorCode.INTERNAL_ERROR is not None


class MockTool(BaseTool):
    """Mock tool for testing."""

    @property
    def name(self) -> str:
        return "mock"

    @property
    def description(self) -> str:
        return "Mock tool for testing"

    @property
    def parameters(self) -> dict[str, Any]:
        return {"type": "object", "properties": {}}

    async def execute(self, arguments: dict[str, Any]) -> ToolResult:
        return ToolResult(success=True, output="mocked")


class EchoTool(BaseTool):
    """Echo tool for testing."""

    @property
    def name(self) -> str:
        return "echo"

    @property
    def description(self) -> str:
        return "Echo input"

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {"message": {"type": "string"}},
        }

    async def execute(self, arguments: dict[str, Any]) -> ToolResult:
        return ToolResult(success=True, output=arguments.get("message", ""))


class TestToolRegistry:
    """Tests for ToolRegistry."""

    def test_create_registry(self) -> None:
        registry = ToolRegistry()
        assert registry is not None

    def test_register_tool(self) -> None:
        registry = ToolRegistry()
        tool = MockTool()
        registry.register(tool)
        assert "mock" in registry.list_tools()

    def test_get_tool(self) -> None:
        registry = ToolRegistry()
        tool = MockTool()
        registry.register(tool)
        retrieved = registry.get("mock")
        assert retrieved is not None

    def test_get_nonexistent_tool(self) -> None:
        registry = ToolRegistry()
        assert registry.get("nonexistent") is None

    def test_unregister_tool(self) -> None:
        registry = ToolRegistry()
        tool = MockTool()
        registry.register(tool)
        assert "mock" in registry.list_tools()
        registry.unregister("mock")
        assert "mock" not in registry.list_tools()

    def test_list_tools(self) -> None:
        registry = ToolRegistry()
        registry.register(MockTool())
        registry.register(EchoTool())
        tools = registry.list_tools()
        assert "mock" in tools
        assert "echo" in tools

    def test_get_all(self) -> None:
        registry = ToolRegistry()
        registry.register(MockTool())
        all_tools = registry.get_all()
        assert len(all_tools) >= 1
