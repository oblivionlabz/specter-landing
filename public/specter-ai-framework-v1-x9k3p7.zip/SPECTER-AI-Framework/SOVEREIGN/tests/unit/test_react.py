"""Tests for the ReAct (Reasoning + Acting) loop."""

from __future__ import annotations

import pytest

from sovereign.core.react import (
    ReActLoop,
    ReActResult,
    ReActState,
    ReActStep,
    THOUGHT_PATTERN,
    ACTION_PATTERN,
    ACTION_INPUT_PATTERN,
    FINAL_ANSWER_PATTERN,
)


class TestReActState:
    """Tests for ReActState enum."""

    def test_states_exist(self) -> None:
        assert ReActState.THINKING is not None
        assert ReActState.ACTING is not None
        assert ReActState.OBSERVING is not None
        assert ReActState.COMPLETE is not None
        assert ReActState.ERROR is not None


class TestReActStep:
    """Tests for ReActStep dataclass."""

    def test_create_step(self) -> None:
        step = ReActStep(thought="I need to read the file")
        assert step.thought == "I need to read the file"
        assert step.action is None
        assert step.action_input == {}
        assert step.observation is None
        assert step.is_final is False

    def test_step_with_action(self) -> None:
        step = ReActStep(
            thought="I should read the config file",
            action="read",
            action_input={"path": "config.yaml"},
        )
        assert step.action == "read"
        assert step.action_input["path"] == "config.yaml"

    def test_final_step(self) -> None:
        step = ReActStep(
            thought="I have the answer",
            is_final=True,
            observation="The result is 42",
        )
        assert step.is_final is True
        assert step.observation == "The result is 42"


class TestReActResult:
    """Tests for ReActResult dataclass."""

    def test_successful_result(self) -> None:
        result = ReActResult(
            success=True,
            answer="The file contains config settings",
            steps=[ReActStep(thought="Reading file", action="read")],
        )
        assert result.success is True
        assert result.answer == "The file contains config settings"
        assert len(result.steps) == 1
        assert result.error is None
        assert result.total_tokens == 0

    def test_failed_result(self) -> None:
        result = ReActResult(
            success=False,
            answer="",
            error="LLM connection failed",
        )
        assert result.success is False
        assert result.error == "LLM connection failed"

    def test_result_with_multiple_steps(self) -> None:
        steps = [
            ReActStep(thought="Step 1", action="read"),
            ReActStep(thought="Step 2", action="write"),
            ReActStep(thought="Done", is_final=True),
        ]
        result = ReActResult(success=True, answer="Complete", steps=steps)
        assert len(result.steps) == 3

    def test_result_with_tokens(self) -> None:
        result = ReActResult(
            success=True,
            answer="Answer",
            total_tokens=1500,
        )
        assert result.total_tokens == 1500


class TestReActPatterns:
    """Tests for ReAct response parsing patterns."""

    def test_thought_pattern(self) -> None:
        response = "THOUGHT: I need to read the file first\nACTION: read"
        match = THOUGHT_PATTERN.search(response)
        assert match is not None
        assert "I need to read the file first" in match.group(1)

    def test_action_pattern(self) -> None:
        response = "THOUGHT: Let me check\nACTION: bash"
        match = ACTION_PATTERN.search(response)
        assert match is not None
        assert match.group(1) == "bash"

    def test_action_input_pattern(self) -> None:
        response = 'ACTION: write\nACTION_INPUT: {"path": "test.py", "content": "print(1)"}'
        match = ACTION_INPUT_PATTERN.search(response)
        assert match is not None
        assert '"path": "test.py"' in match.group(1)

    def test_final_answer_pattern(self) -> None:
        response = "THOUGHT: I have completed the task\nFINAL_ANSWER: The file was created successfully"
        match = FINAL_ANSWER_PATTERN.search(response)
        assert match is not None
        assert "The file was created successfully" in match.group(1)

    def test_multiline_thought(self) -> None:
        response = """THOUGHT: I need to:
1. Read the file
2. Parse the contents
3. Make changes
ACTION: read"""
        match = THOUGHT_PATTERN.search(response)
        assert match is not None
        assert "I need to:" in match.group(1)

    def test_complex_action_input(self) -> None:
        response = '''ACTION: write
ACTION_INPUT: {"path": "main.py", "content": "def hello(): pass"}'''
        match = ACTION_INPUT_PATTERN.search(response)
        assert match is not None
        # The JSON should be parseable
        import json
        json_str = match.group(1)
        parsed = json.loads(json_str)
        assert parsed["path"] == "main.py"
        assert "hello" in parsed["content"]


class TestReActLoopCreation:
    """Tests for ReActLoop initialization."""

    def test_create_loop_with_mocks(self) -> None:
        """Test creating a ReAct loop with mock engine and registry."""
        from unittest.mock import MagicMock

        engine = MagicMock()
        registry = MagicMock()

        loop = ReActLoop(
            engine=engine,
            registry=registry,
            max_iterations=5,
            verbose=False,
        )

        assert loop.engine is engine
        assert loop.registry is registry
        assert loop.max_iterations == 5
        assert loop.verbose is False

    def test_default_max_iterations(self) -> None:
        from unittest.mock import MagicMock

        engine = MagicMock()
        registry = MagicMock()

        loop = ReActLoop(engine=engine, registry=registry)
        assert loop.max_iterations == 10

    def test_default_verbose(self) -> None:
        from unittest.mock import MagicMock

        engine = MagicMock()
        registry = MagicMock()

        loop = ReActLoop(engine=engine, registry=registry)
        assert loop.verbose is True


class TestReActLoopParsing:
    """Tests for ReActLoop response parsing."""

    def test_parse_thought_and_action(self) -> None:
        from unittest.mock import MagicMock

        engine = MagicMock()
        registry = MagicMock()
        registry.get_all.return_value = {}

        loop = ReActLoop(engine=engine, registry=registry)

        response = """THOUGHT: I need to list the files in the directory
ACTION: glob
ACTION_INPUT: {"pattern": "*.py"}"""

        step = loop._parse_response(response)
        assert "list the files" in step.thought
        assert step.action == "glob"
        assert step.action_input.get("pattern") == "*.py"
        assert step.is_final is False

    def test_parse_final_answer(self) -> None:
        from unittest.mock import MagicMock

        engine = MagicMock()
        registry = MagicMock()
        registry.get_all.return_value = {}

        loop = ReActLoop(engine=engine, registry=registry)

        response = """THOUGHT: I have completed the analysis
FINAL_ANSWER: There are 5 Python files in the directory."""

        step = loop._parse_response(response)
        assert "completed the analysis" in step.thought
        assert step.is_final is True
        assert "5 Python files" in step.observation

    def test_parse_empty_response(self) -> None:
        from unittest.mock import MagicMock

        engine = MagicMock()
        registry = MagicMock()
        registry.get_all.return_value = {}

        loop = ReActLoop(engine=engine, registry=registry)

        response = ""
        step = loop._parse_response(response)
        assert step.thought == ""
        assert step.action is None
        assert step.is_final is False

    def test_parse_malformed_json(self) -> None:
        from unittest.mock import MagicMock

        engine = MagicMock()
        registry = MagicMock()
        registry.get_all.return_value = {}

        loop = ReActLoop(engine=engine, registry=registry)

        response = """THOUGHT: Testing
ACTION: test
ACTION_INPUT: {not valid json}"""

        step = loop._parse_response(response)
        assert step.action == "test"
        # Should default to empty dict on parse error
        assert step.action_input == {}


class TestReActLoopFormatTools:
    """Tests for tool formatting."""

    def test_format_no_tools(self) -> None:
        from unittest.mock import MagicMock

        engine = MagicMock()
        registry = MagicMock()
        registry.get_all.return_value = {}

        loop = ReActLoop(engine=engine, registry=registry)
        formatted = loop._format_tools()
        assert formatted == "No tools available."

    def test_format_with_tools(self) -> None:
        from unittest.mock import MagicMock

        engine = MagicMock()

        # Create mock tool
        mock_tool = MagicMock()
        mock_tool.description = "Read a file from disk"
        mock_tool.parameters = {
            "properties": {
                "path": {"type": "string", "description": "File path to read"}
            }
        }

        registry = MagicMock()
        registry.get_all.return_value = {"read": mock_tool}

        loop = ReActLoop(engine=engine, registry=registry)
        formatted = loop._format_tools()

        assert "read" in formatted
        assert "Read a file from disk" in formatted
        assert "path" in formatted


class TestReActLoopPromptBuilding:
    """Tests for prompt building."""

    def test_build_initial_prompt(self) -> None:
        from unittest.mock import MagicMock

        engine = MagicMock()
        registry = MagicMock()
        registry.get_all.return_value = {}

        loop = ReActLoop(engine=engine, registry=registry)
        prompt = loop._build_prompt("List Python files", [])

        assert "List Python files" in prompt
        assert "User request:" in prompt

    def test_build_prompt_with_history(self) -> None:
        from unittest.mock import MagicMock

        engine = MagicMock()
        registry = MagicMock()
        registry.get_all.return_value = {}

        loop = ReActLoop(engine=engine, registry=registry)

        steps = [
            ReActStep(
                thought="First step",
                action="read",
                action_input={"path": "test.py"},
                observation="File contents here",
            )
        ]

        prompt = loop._build_prompt("Read file", steps)

        assert "Read file" in prompt
        assert "Step 1" in prompt
        assert "THOUGHT: First step" in prompt
        assert "ACTION: read" in prompt
        assert "OBSERVATION: File contents here" in prompt
