"""Tests for file operation tools validation."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from sovereign.tools.builtins.file_ops import (
    EditTool,
    WriteTool,
    ReadTool,
    GlobTool,
    GrepTool,
)
from sovereign.tools.base import ToolErrorCode


class TestEditToolValidation:
    """Tests for EditTool input validation."""

    @pytest.fixture
    def edit_tool(self) -> EditTool:
        return EditTool()

    @pytest.fixture
    def temp_file(self) -> str:
        """Create a temporary file with content."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("Hello World\nThis is a test file\nWith multiple lines\n")
            return f.name

    @pytest.mark.asyncio
    async def test_reject_empty_old_string(self, edit_tool: EditTool) -> None:
        """Test that empty old_string is rejected.

        This is CRITICAL - empty string replacement causes catastrophic corruption:
        >>> "hello".replace("", "X")
        'XhXeXlXlXoX'
        """
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("test content")
            temp_path = f.name

        try:
            result = await edit_tool.execute(
                path=temp_path,
                old_string="",  # Empty - should be rejected
                new_string="replacement",
            )

            assert result.success is False
            assert result.error is not None
            assert result.error.code == ToolErrorCode.INVALID_PARAMS
            assert "empty" in result.error.message.lower()
        finally:
            Path(temp_path).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_reject_identical_strings(self, edit_tool: EditTool) -> None:
        """Test that identical old_string and new_string are rejected."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("test content")
            temp_path = f.name

        try:
            result = await edit_tool.execute(
                path=temp_path,
                old_string="test",
                new_string="test",  # Same as old_string - should be rejected
            )

            assert result.success is False
            assert result.error is not None
            assert result.error.code == ToolErrorCode.INVALID_PARAMS
            assert "identical" in result.error.message.lower()
        finally:
            Path(temp_path).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_successful_edit(self, edit_tool: EditTool, temp_file: str) -> None:
        """Test that valid edits succeed."""
        try:
            result = await edit_tool.execute(
                path=temp_file,
                old_string="Hello World",
                new_string="Goodbye World",
            )

            assert result.success is True
            assert Path(temp_file).read_text().startswith("Goodbye World")
        finally:
            Path(temp_file).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_text_not_found(self, edit_tool: EditTool, temp_file: str) -> None:
        """Test that non-existent text returns NOT_FOUND error."""
        try:
            result = await edit_tool.execute(
                path=temp_file,
                old_string="nonexistent text that doesn't exist",
                new_string="replacement",
            )

            assert result.success is False
            assert result.error is not None
            assert result.error.code == ToolErrorCode.NOT_FOUND
        finally:
            Path(temp_file).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_multiple_occurrences_without_replace_all(
        self, edit_tool: EditTool
    ) -> None:
        """Test that multiple occurrences require replace_all=True."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("test test test")  # 3 occurrences
            temp_path = f.name

        try:
            result = await edit_tool.execute(
                path=temp_path,
                old_string="test",
                new_string="replaced",
                replace_all=False,
            )

            assert result.success is False
            assert result.error is not None
            assert result.error.code == ToolErrorCode.INVALID_PARAMS
            assert "3 occurrences" in result.error.message
        finally:
            Path(temp_path).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_replace_all_succeeds(self, edit_tool: EditTool) -> None:
        """Test that replace_all=True replaces all occurrences."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("test test test")
            temp_path = f.name

        try:
            result = await edit_tool.execute(
                path=temp_path,
                old_string="test",
                new_string="replaced",
                replace_all=True,
            )

            assert result.success is True
            assert Path(temp_path).read_text() == "replaced replaced replaced"
        finally:
            Path(temp_path).unlink(missing_ok=True)


class TestWriteToolValidation:
    """Tests for WriteTool input validation."""

    @pytest.fixture
    def write_tool(self) -> WriteTool:
        return WriteTool()

    @pytest.mark.asyncio
    async def test_successful_write(self, write_tool: WriteTool) -> None:
        """Test that valid writes succeed."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test_output.txt"

            result = await write_tool.execute(
                path=str(test_file),
                content="Test content",
            )

            assert result.success is True
            assert test_file.exists()
            assert test_file.read_text() == "Test content"

    @pytest.mark.asyncio
    async def test_looks_corrupted_detection(self, write_tool: WriteTool) -> None:
        """Test that repetitive content is detected as corrupted."""
        # Test the internal _looks_corrupted method

        # Short content - should not be flagged
        assert write_tool._looks_corrupted("short content") is False

        # Highly repetitive content - should be flagged
        repetitive = ("same line\n" * 200)  # 200 identical lines
        assert write_tool._looks_corrupted(repetitive) is True

        # Normal content with some repetition - should not be flagged
        normal = "\n".join([f"line {i} with unique content" for i in range(200)])
        assert write_tool._looks_corrupted(normal) is False

    @pytest.mark.asyncio
    async def test_reject_corrupted_content(self, write_tool: WriteTool) -> None:
        """Test that writing corrupted content is rejected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test_output.txt"

            # Create highly repetitive content (simulates corruption)
            corrupted = ("same line\n" * 200)

            result = await write_tool.execute(
                path=str(test_file),
                content=corrupted,
            )

            assert result.success is False
            assert result.error is not None
            assert result.error.code == ToolErrorCode.EXECUTION_FAILED
            assert "corrupted" in result.error.message.lower()

    @pytest.mark.asyncio
    async def test_creates_parent_directories(self, write_tool: WriteTool) -> None:
        """Test that parent directories are created automatically."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "nested" / "deep" / "file.txt"

            result = await write_tool.execute(
                path=str(test_file),
                content="Nested content",
            )

            assert result.success is True
            assert test_file.exists()
            assert test_file.read_text() == "Nested content"

    @pytest.mark.asyncio
    async def test_reject_missing_content(self, write_tool: WriteTool) -> None:
        """Test that None content is rejected."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test_output.txt"

            result = await write_tool.execute(
                path=str(test_file),
                content=None,
            )

            assert result.success is False
            assert result.error is not None
            assert result.error.code == ToolErrorCode.INVALID_PARAMS


class TestReadTool:
    """Tests for ReadTool."""

    @pytest.fixture
    def read_tool(self) -> ReadTool:
        return ReadTool()

    @pytest.mark.asyncio
    async def test_read_file(self, read_tool: ReadTool) -> None:
        """Test reading a file."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("Line 1\nLine 2\nLine 3\n")
            temp_path = f.name

        try:
            result = await read_tool.execute(path=temp_path)

            assert result.success is True
            assert "Line 1" in result.output
            assert "Line 2" in result.output
        finally:
            Path(temp_path).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_read_nonexistent_file(self, read_tool: ReadTool) -> None:
        """Test reading a non-existent file."""
        result = await read_tool.execute(path="/nonexistent/path/file.txt")

        assert result.success is False
        assert result.error is not None
        assert result.error.code == ToolErrorCode.NOT_FOUND

    @pytest.mark.asyncio
    async def test_read_with_offset_and_limit(self, read_tool: ReadTool) -> None:
        """Test reading with offset and limit."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            for i in range(100):
                f.write(f"Line {i}\n")
            temp_path = f.name

        try:
            result = await read_tool.execute(
                path=temp_path,
                offset=10,
                limit=5,
            )

            assert result.success is True
            assert "Line 10" in result.output
            assert "Line 14" in result.output
            assert result.metadata["returned_lines"] == 5
        finally:
            Path(temp_path).unlink(missing_ok=True)


class TestGlobTool:
    """Tests for GlobTool."""

    @pytest.fixture
    def glob_tool(self) -> GlobTool:
        return GlobTool()

    @pytest.mark.asyncio
    async def test_glob_pattern(self, glob_tool: GlobTool) -> None:
        """Test glob pattern matching."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create test files
            (Path(tmpdir) / "test1.py").write_text("pass")
            (Path(tmpdir) / "test2.py").write_text("pass")
            (Path(tmpdir) / "test.txt").write_text("text")

            result = await glob_tool.execute(
                pattern="*.py",
                path=tmpdir,
            )

            assert result.success is True
            files = result.output
            assert len(files) == 2
            assert any("test1.py" in f for f in files)
            assert any("test2.py" in f for f in files)

    @pytest.mark.asyncio
    async def test_glob_nonexistent_dir(self, glob_tool: GlobTool) -> None:
        """Test glob on non-existent directory."""
        result = await glob_tool.execute(
            pattern="*.py",
            path="/nonexistent/directory",
        )

        assert result.success is False
        assert result.error is not None
        assert result.error.code == ToolErrorCode.NOT_FOUND


class TestGrepTool:
    """Tests for GrepTool."""

    @pytest.fixture
    def grep_tool(self) -> GrepTool:
        return GrepTool()

    @pytest.mark.asyncio
    async def test_grep_pattern(self, grep_tool: GrepTool) -> None:
        """Test grep pattern matching."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("Hello World\nFoo Bar\nHello Again\n")
            temp_path = f.name

        try:
            result = await grep_tool.execute(
                pattern="Hello",
                path=temp_path,
            )

            assert result.success is True
            matches = result.output
            assert len(matches) == 2
        finally:
            Path(temp_path).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_grep_invalid_regex(self, grep_tool: GrepTool) -> None:
        """Test grep with invalid regex."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("test content")
            temp_path = f.name

        try:
            result = await grep_tool.execute(
                pattern="[invalid regex",  # Unclosed bracket
                path=temp_path,
            )

            assert result.success is False
            assert result.error is not None
            assert result.error.code == ToolErrorCode.INVALID_PARAMS
        finally:
            Path(temp_path).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_grep_with_context(self, grep_tool: GrepTool) -> None:
        """Test grep with context lines."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("Line 1\nLine 2\nMATCH\nLine 4\nLine 5\n")
            temp_path = f.name

        try:
            result = await grep_tool.execute(
                pattern="MATCH",
                path=temp_path,
                context=1,
            )

            assert result.success is True
            matches = result.output
            assert len(matches) == 1
            assert "context" in matches[0]
            assert len(matches[0]["context"]) == 3  # 1 before + match + 1 after
        finally:
            Path(temp_path).unlink(missing_ok=True)
