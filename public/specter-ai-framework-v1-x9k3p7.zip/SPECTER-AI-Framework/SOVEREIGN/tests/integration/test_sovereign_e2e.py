"""End-to-end integration tests for SOVEREIGN.

These tests verify that SOVEREIGN can:
1. Connect to LocalAI
2. Use the ReAct loop for tool-augmented reasoning
3. Execute tools (file ops, bash, etc.)
4. Track costs and routing decisions
"""

from __future__ import annotations

import tempfile
import urllib.request
from pathlib import Path

import pytest


# Config path for tests
CONFIG_PATH = Path(__file__).parent.parent.parent / "config" / "sovereign.yaml"


def _check_localai_available() -> bool:
    """Check if LocalAI is running."""
    try:
        with urllib.request.urlopen("http://localhost:8080/readyz", timeout=2):
            return True
    except Exception:
        return False


# Skip all tests if LocalAI is not available
pytestmark = pytest.mark.skipif(
    not _check_localai_available(),
    reason="LocalAI not available at localhost:8080",
)


class TestSovereignStartup:
    """Tests for SOVEREIGN startup and initialization."""

    def test_app_creation(self) -> None:
        """Test creating the SovereignApp."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        assert app is not None
        assert app.config is config
        assert app.running is False

    def test_lazy_engine_creation(self) -> None:
        """Test that engine is created lazily."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        # Engine not created yet
        assert app._engine is None

        # Access property creates engine
        engine = app.engine
        assert engine is not None
        assert app._engine is engine

    def test_lazy_registry_creation(self) -> None:
        """Test that registry is created lazily."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        # Registry not created yet
        assert app._registry is None

        # Access property creates registry
        registry = app.registry
        assert registry is not None
        assert app._registry is registry

        # Verify tools are registered
        tools = registry.list_tools()
        assert len(tools) > 0
        assert "read" in tools
        assert "write" in tools
        assert "bash" in tools

    def test_lazy_router_creation(self) -> None:
        """Test that router is created lazily."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        # Router not created yet
        assert app._router is None

        # Access property creates router
        router = app.router
        assert router is not None
        assert app._router is router
        assert router.prefer_local is True

    def test_lazy_cost_tracker_creation(self) -> None:
        """Test that cost tracker is created lazily."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        # Cost tracker not created yet
        assert app._cost_tracker is None

        # Access property creates tracker
        tracker = app.cost_tracker
        assert tracker is not None
        assert app._cost_tracker is tracker
        assert tracker.limits.per_task == 0.50
        assert tracker.limits.per_session == 5.00


class TestLocalAIConnection:
    """Tests for LocalAI connectivity."""

    @pytest.mark.asyncio
    async def test_health_check(self) -> None:
        """Test LocalAI health check."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        healthy = await app.engine.health_check()
        assert healthy is True

    @pytest.mark.asyncio
    async def test_list_models(self) -> None:
        """Test listing available models."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        models = await app.engine.list_models()
        assert len(models) > 0


class TestSmartRouter:
    """Tests for smart routing decisions."""

    def test_route_simple_task(self) -> None:
        """Test routing a simple task."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config
        from sovereign.core.router import ModelTier

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        decision = app.router.select_tier("List files in the current directory")
        assert decision is not None
        # Simple tasks should prefer cheaper tiers (local or basic cloud)
        assert decision.tier in (ModelTier.FAST, ModelTier.LARGE, ModelTier.HAIKU)
        assert decision.estimated_cost >= 0

    def test_route_complex_task(self) -> None:
        """Test routing a complex task."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        decision = app.router.select_tier(
            "Build a complex multi-file REST API with authentication, "
            "database integration, and comprehensive test coverage"
        )
        assert decision is not None
        # Complex tasks may escalate to higher tiers
        assert decision.fingerprint is not None
        assert decision.fingerprint.complexity > 0.5


class TestToolExecution:
    """Tests for tool execution via ReAct loop."""

    @pytest.mark.asyncio
    async def test_glob_tool(self) -> None:
        """Test glob tool execution."""
        from sovereign.tools.registry import create_default_registry

        registry = create_default_registry()
        result = await registry.execute("glob", pattern="*.py", path="/tmp")

        assert result.success is True

    @pytest.mark.asyncio
    async def test_read_tool(self) -> None:
        """Test read tool execution."""
        from sovereign.tools.registry import create_default_registry

        # Create a temp file to read
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("Hello SOVEREIGN!")
            temp_path = f.name

        try:
            registry = create_default_registry()
            result = await registry.execute("read", path=temp_path)

            assert result.success is True
            assert "Hello SOVEREIGN" in result.output
        finally:
            Path(temp_path).unlink()

    @pytest.mark.asyncio
    async def test_write_tool(self) -> None:
        """Test write tool execution."""
        from sovereign.tools.registry import create_default_registry

        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test_output.txt"

            registry = create_default_registry()
            result = await registry.execute(
                "write",
                path=str(test_file),
                content="Written by SOVEREIGN",
            )

            assert result.success is True
            assert test_file.exists()
            assert test_file.read_text() == "Written by SOVEREIGN"

    @pytest.mark.asyncio
    async def test_bash_tool(self) -> None:
        """Test bash tool execution."""
        from sovereign.tools.registry import create_default_registry

        registry = create_default_registry()
        result = await registry.execute("bash", command="echo 'Hello from bash'")

        assert result.success is True
        assert "Hello from bash" in result.output


class TestReActLoop:
    """Tests for the ReAct reasoning loop."""

    @pytest.mark.asyncio
    async def test_react_loop_creation(self) -> None:
        """Test creating a ReAct loop."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        react_loop = app.react_loop
        assert react_loop is not None
        assert react_loop.max_iterations == 25  # Increased for complex tasks
        assert react_loop.verbose is False

    @pytest.mark.asyncio
    async def test_simple_query(self) -> None:
        """Test a simple query through the ReAct loop."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        # Simple query that should complete quickly
        result = await app.react_loop.run("What is 2 + 2?")

        assert result is not None
        # Either successfully ran steps OR properly caught an LLM error
        if result.success:
            assert len(result.steps) > 0
        else:
            # Error case - should have error message
            assert result.error is not None or len(result.steps) == 0


class TestCostTracking:
    """Tests for cost tracking."""

    def test_initial_costs(self) -> None:
        """Test that costs start at zero."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        stats = app.cost_tracker.stats()
        assert stats["session_cost"] == 0
        # Note: daily cost might not be 0 if previous tests ran today

    def test_cost_limits(self) -> None:
        """Test that cost limits are configured."""
        from sovereign.app import SovereignApp
        from sovereign.config import Config

        config = Config.load(CONFIG_PATH)
        app = SovereignApp(config)

        limits = app.cost_tracker.limits
        assert limits.per_task == 0.50
        assert limits.per_session == 5.00
        assert limits.per_day == 25.00


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
