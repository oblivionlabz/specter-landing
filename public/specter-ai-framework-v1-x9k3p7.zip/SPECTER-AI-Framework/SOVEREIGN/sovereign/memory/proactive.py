"""Proactive memory injection for context augmentation."""

from __future__ import annotations

import contextlib
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sovereign.memory.knowledge_graph import KnowledgeGraph
    from sovereign.memory.pattern_extractor import PatternExtractor
    from sovereign.memory.vector_store import VectorStore


@dataclass
class InjectedContext:
    """Context to be injected into prompts."""

    patterns: list[str]
    knowledge: list[str]
    memories: list[str]
    total_tokens: int

    def to_prompt_section(self) -> str:
        """Convert to a prompt section string."""
        sections = []

        if self.patterns:
            sections.append("## Relevant Patterns\n" + "\n".join(f"- {p}" for p in self.patterns))

        if self.knowledge:
            sections.append("## Related Knowledge\n" + "\n".join(f"- {k}" for k in self.knowledge))

        if self.memories:
            sections.append("## Previous Context\n" + "\n".join(f"- {m}" for m in self.memories))

        return "\n\n".join(sections)


class ProactiveMemory:
    """Proactively injects relevant context into prompts."""

    def __init__(
        self,
        knowledge_graph: KnowledgeGraph | None = None,
        vector_store: VectorStore | None = None,
        pattern_extractor: PatternExtractor | None = None,
        max_tokens: int = 2000,
        relevance_threshold: float = 0.6,
    ) -> None:
        """Initialize proactive memory.

        Args:
            knowledge_graph: Knowledge graph for entity lookup
            vector_store: Vector store for similarity search
            pattern_extractor: Pattern extractor for learned patterns
            max_tokens: Maximum tokens for injected context
            relevance_threshold: Minimum relevance score
        """
        self.knowledge_graph = knowledge_graph
        self.vector_store = vector_store
        self.pattern_extractor = pattern_extractor
        self.max_tokens = max_tokens
        self.relevance_threshold = relevance_threshold

    async def get_context(
        self,
        query: str,
        task_type: str | None = None,
    ) -> InjectedContext:
        """Get context to inject for a query.

        Args:
            query: User query or task description
            task_type: Optional task type hint

        Returns:
            InjectedContext with relevant information
        """
        patterns: list[str] = []
        knowledge: list[str] = []
        memories: list[str] = []
        estimated_tokens = 0

        # Get patterns from extractor
        if self.pattern_extractor:
            matching_patterns = self.pattern_extractor.find_matching_patterns(
                query, limit=5
            )
            for p in matching_patterns:
                if estimated_tokens >= self.max_tokens:
                    break
                pattern_str = f"{p.name}: {p.description}"
                patterns.append(pattern_str)
                estimated_tokens += len(pattern_str.split()) * 1.3

        # Get knowledge from graph
        if self.knowledge_graph:
            # Extract key terms from query
            terms = self._extract_key_terms(query)
            for term in terms[:3]:
                if estimated_tokens >= self.max_tokens:
                    break
                entities = self.knowledge_graph.find_entities(
                    name_pattern=term, limit=2
                )
                for entity in entities:
                    knowledge_str = f"{entity.name} ({entity.type})"
                    if entity.properties:
                        props = ", ".join(
                            f"{k}={v}" for k, v in list(entity.properties.items())[:3]
                        )
                        knowledge_str += f": {props}"
                    knowledge.append(knowledge_str)
                    estimated_tokens += len(knowledge_str.split()) * 1.3

        # Get memories from vector store
        if self.vector_store:
            try:
                results = await self.vector_store.search(
                    query,
                    limit=5,
                    min_score=self.relevance_threshold,
                )
                for result in results:
                    if estimated_tokens >= self.max_tokens:
                        break
                    # Truncate long content
                    content = result.document.content
                    if len(content) > 200:
                        content = content[:200] + "..."
                    memories.append(content)
                    estimated_tokens += len(content.split()) * 1.3
            except Exception:
                pass  # Vector store unavailable

        return InjectedContext(
            patterns=patterns,
            knowledge=knowledge,
            memories=memories,
            total_tokens=int(estimated_tokens),
        )

    def _extract_key_terms(self, text: str) -> list[str]:
        """Extract key terms from text.

        Args:
            text: Input text

        Returns:
            List of key terms
        """
        # Simple implementation - can be enhanced with NLP
        words = text.lower().split()
        # Filter common words
        stopwords = {
            "the", "a", "an", "is", "are", "was", "were",
            "be", "been", "being", "have", "has", "had",
            "do", "does", "did", "will", "would", "could",
            "should", "may", "might", "can", "to", "of",
            "in", "for", "on", "with", "at", "by", "from",
            "this", "that", "these", "those", "it", "its",
            "and", "or", "but", "if", "then", "else",
            "i", "you", "we", "they", "he", "she", "me",
            "my", "your", "our", "their", "his", "her",
        }
        terms = [w for w in words if w not in stopwords and len(w) > 2]
        # Return unique terms
        seen: set[str] = set()
        unique = []
        for t in terms:
            if t not in seen:
                seen.add(t)
                unique.append(t)
        return unique[:10]

    async def augment_prompt(
        self,
        prompt: str,
        system_prompt: str | None = None,
    ) -> tuple[str, str | None]:
        """Augment a prompt with injected context.

        Args:
            prompt: User prompt
            system_prompt: Optional system prompt

        Returns:
            Tuple of (augmented_prompt, augmented_system)
        """
        context = await self.get_context(prompt)

        if not any([context.patterns, context.knowledge, context.memories]):
            return prompt, system_prompt

        context_section = context.to_prompt_section()

        # Inject into system prompt if available
        if system_prompt:
            augmented_system = f"{system_prompt}\n\n{context_section}"
            return prompt, augmented_system

        # Otherwise prepend to user prompt
        augmented_prompt = f"{context_section}\n\n---\n\n{prompt}"
        return augmented_prompt, system_prompt

    def record_interaction(
        self,
        query: str,
        response: str,
        success: bool,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Record an interaction for future learning.

        Args:
            query: User query
            response: Assistant response
            success: Whether interaction was successful
            metadata: Additional metadata
        """
        # Store in vector store for future retrieval
        if self.vector_store and success:
            import asyncio

            content = f"Q: {query[:200]}\nA: {response[:500]}"
            with contextlib.suppress(Exception):
                asyncio.create_task(
                    self.vector_store.add(
                        content=content,
                        metadata={
                            "type": "interaction",
                            "success": success,
                            **(metadata or {}),
                        },
                    )
                )

        # Extract patterns from successful interactions
        if self.pattern_extractor and success:
            self.pattern_extractor.extract_from_tool_use(
                tool_name="conversation",
                params={"query": query[:100]},
                result={"success": True, "output": response[:200]},
                context=query[:200],
            )
