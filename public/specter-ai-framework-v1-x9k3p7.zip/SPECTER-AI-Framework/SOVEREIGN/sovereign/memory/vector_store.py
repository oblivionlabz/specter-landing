"""Vector Store for semantic similarity search via LocalRecall."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import httpx


@dataclass
class Document:
    """A document in the vector store."""

    id: str
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)
    embedding: list[float] | None = None
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "content": self.content,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
        }


@dataclass
class SearchResult:
    """Result from a similarity search."""

    document: Document
    score: float
    distance: float


class VectorStore:
    """Vector store client for LocalRecall or compatible API."""

    def __init__(
        self,
        url: str = "http://localhost:9090",
        collection: str = "sovereign_memories",
        embedding_model: str = "all-MiniLM-L6-v2",
    ) -> None:
        """Initialize vector store.

        Args:
            url: LocalRecall API URL
            collection: Collection name
            embedding_model: Model for embeddings
        """
        self.url = url.rstrip("/")
        self.collection = collection
        self.embedding_model = embedding_model
        self._client: httpx.AsyncClient | None = None

        # In-memory fallback when LocalRecall is unavailable
        self._fallback_store: dict[str, Document] = {}
        self._use_fallback = False

    @property
    def client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.url,
                timeout=30.0,
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def health_check(self) -> bool:
        """Check if LocalRecall is available.

        Returns:
            True if available, False otherwise
        """
        try:
            response = await self.client.get("/health")
            return response.status_code == 200
        except Exception:
            self._use_fallback = True
            return False

    async def create_collection(self) -> bool:
        """Create the collection if it doesn't exist.

        Returns:
            True if created or exists
        """
        if self._use_fallback:
            return True

        try:
            response = await self.client.post(
                "/collections",
                json={
                    "name": self.collection,
                    "embedding_model": self.embedding_model,
                },
            )
            return response.status_code in (200, 201, 409)  # 409 = already exists
        except Exception:
            self._use_fallback = True
            return True

    async def add(
        self,
        content: str,
        metadata: dict[str, Any] | None = None,
        doc_id: str | None = None,
    ) -> Document:
        """Add a document to the store.

        Args:
            content: Document content
            metadata: Optional metadata
            doc_id: Optional custom ID

        Returns:
            Created Document
        """
        if doc_id is None:
            doc_id = hashlib.sha256(content.encode()).hexdigest()[:16]

        doc = Document(
            id=doc_id,
            content=content,
            metadata=metadata or {},
        )

        if self._use_fallback:
            self._fallback_store[doc_id] = doc
            return doc

        try:
            response = await self.client.post(
                f"/collections/{self.collection}/documents",
                json={
                    "id": doc_id,
                    "content": content,
                    "metadata": metadata or {},
                },
            )
            response.raise_for_status()
        except Exception:
            # Fall back to in-memory
            self._use_fallback = True
            self._fallback_store[doc_id] = doc

        return doc

    async def add_batch(
        self,
        documents: list[tuple[str, dict[str, Any] | None]],
    ) -> list[Document]:
        """Add multiple documents.

        Args:
            documents: List of (content, metadata) tuples

        Returns:
            List of created Documents
        """
        results = []
        for content, metadata in documents:
            doc = await self.add(content, metadata)
            results.append(doc)
        return results

    async def search(
        self,
        query: str,
        limit: int = 10,
        min_score: float = 0.0,
        filter_metadata: dict[str, Any] | None = None,
    ) -> list[SearchResult]:
        """Search for similar documents.

        Args:
            query: Search query
            limit: Maximum results
            min_score: Minimum similarity score
            filter_metadata: Metadata filters

        Returns:
            List of SearchResults
        """
        if self._use_fallback:
            return self._fallback_search(query, limit)

        try:
            payload: dict[str, Any] = {
                "query": query,
                "limit": limit,
                "min_score": min_score,
            }
            if filter_metadata:
                payload["filter"] = filter_metadata

            response = await self.client.post(
                f"/collections/{self.collection}/search",
                json=payload,
            )
            response.raise_for_status()
            data = response.json()

            results = []
            for item in data.get("results", []):
                doc = Document(
                    id=item["id"],
                    content=item["content"],
                    metadata=item.get("metadata", {}),
                )
                results.append(
                    SearchResult(
                        document=doc,
                        score=item.get("score", 0.0),
                        distance=item.get("distance", 0.0),
                    )
                )
            return results

        except Exception:
            self._use_fallback = True
            return self._fallback_search(query, limit)

    def _fallback_search(
        self,
        query: str,
        limit: int,
    ) -> list[SearchResult]:
        """Simple keyword-based fallback search.

        Args:
            query: Search query
            limit: Maximum results

        Returns:
            List of SearchResults
        """
        query_words = set(query.lower().split())
        scored: list[tuple[Document, float]] = []

        for doc in self._fallback_store.values():
            doc_words = set(doc.content.lower().split())
            overlap = len(query_words & doc_words)
            if overlap > 0:
                score = overlap / max(len(query_words), 1)
                scored.append((doc, score))

        scored.sort(key=lambda x: x[1], reverse=True)

        return [
            SearchResult(document=doc, score=score, distance=1 - score)
            for doc, score in scored[:limit]
        ]

    async def get(self, doc_id: str) -> Document | None:
        """Get a document by ID.

        Args:
            doc_id: Document ID

        Returns:
            Document or None
        """
        if self._use_fallback:
            return self._fallback_store.get(doc_id)

        try:
            response = await self.client.get(
                f"/collections/{self.collection}/documents/{doc_id}"
            )
            if response.status_code == 404:
                return None
            response.raise_for_status()
            data = response.json()
            return Document(
                id=data["id"],
                content=data["content"],
                metadata=data.get("metadata", {}),
            )
        except Exception:
            self._use_fallback = True
            return self._fallback_store.get(doc_id)

    async def delete(self, doc_id: str) -> bool:
        """Delete a document.

        Args:
            doc_id: Document ID

        Returns:
            True if deleted
        """
        if self._use_fallback:
            if doc_id in self._fallback_store:
                del self._fallback_store[doc_id]
                return True
            return False

        try:
            response = await self.client.delete(
                f"/collections/{self.collection}/documents/{doc_id}"
            )
            return response.status_code in (200, 204)
        except Exception:
            self._use_fallback = True
            return False

    async def count(self) -> int:
        """Get document count.

        Returns:
            Number of documents
        """
        if self._use_fallback:
            return len(self._fallback_store)

        try:
            response = await self.client.get(
                f"/collections/{self.collection}/stats"
            )
            response.raise_for_status()
            return response.json().get("document_count", 0)
        except Exception:
            self._use_fallback = True
            return len(self._fallback_store)

    async def clear(self) -> bool:
        """Clear all documents in collection.

        Returns:
            True if cleared
        """
        if self._use_fallback:
            self._fallback_store.clear()
            return True

        try:
            response = await self.client.delete(
                f"/collections/{self.collection}/documents"
            )
            return response.status_code in (200, 204)
        except Exception:
            self._use_fallback = True
            self._fallback_store.clear()
            return True

    def stats(self) -> dict[str, Any]:
        """Get store statistics.

        Returns:
            Dictionary of statistics
        """
        return {
            "url": self.url,
            "collection": self.collection,
            "using_fallback": self._use_fallback,
            "fallback_count": len(self._fallback_store),
        }
