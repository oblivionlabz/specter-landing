"""Pattern Extractor for automatic learning from successful operations."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any


class PatternType(Enum):
    """Types of patterns that can be extracted."""

    SUCCESS = "success"
    ERROR = "error"
    TOOL_USAGE = "tool_usage"
    CODE_PATTERN = "code_pattern"
    WORKFLOW = "workflow"


@dataclass
class Pattern:
    """A learned pattern from operations."""

    id: str
    type: PatternType
    name: str
    description: str
    trigger: str  # What triggers this pattern
    action: str  # What action to take
    confidence: float = 0.5
    occurrences: int = 1
    examples: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "type": self.type.value,
            "name": self.name,
            "description": self.description,
            "trigger": self.trigger,
            "action": self.action,
            "confidence": self.confidence,
            "occurrences": self.occurrences,
            "examples": self.examples,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Pattern:
        """Create from dictionary."""
        return cls(
            id=data["id"],
            type=PatternType(data["type"]),
            name=data["name"],
            description=data["description"],
            trigger=data["trigger"],
            action=data["action"],
            confidence=data.get("confidence", 0.5),
            occurrences=data.get("occurrences", 1),
            examples=data.get("examples", []),
            metadata=data.get("metadata", {}),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
        )


class PatternExtractor:
    """Extracts and manages learned patterns from operations."""

    def __init__(
        self,
        storage_path: str | Path | None = None,
        min_occurrences: int = 3,
        confidence_threshold: float = 0.7,
    ) -> None:
        """Initialize pattern extractor.

        Args:
            storage_path: Path to persist patterns
            min_occurrences: Minimum occurrences to consider a pattern
            confidence_threshold: Minimum confidence to use a pattern
        """
        self.storage_path = Path(storage_path) if storage_path else None
        self.min_occurrences = min_occurrences
        self.confidence_threshold = confidence_threshold
        self._patterns: dict[str, Pattern] = {}

        if self.storage_path and self.storage_path.exists():
            self.load()

    def extract_from_tool_use(
        self,
        tool_name: str,
        params: dict[str, Any],
        result: dict[str, Any],
        context: str | None = None,
    ) -> Pattern | None:
        """Extract pattern from a tool usage.

        Args:
            tool_name: Name of the tool used
            params: Tool parameters
            result: Tool result
            context: Optional context (e.g., task description)

        Returns:
            Extracted or updated Pattern, or None
        """
        # Generate pattern ID from tool and key params
        key_parts = [tool_name]
        for k, v in sorted(params.items()):
            if isinstance(v, str) and len(v) < 50:
                key_parts.append(f"{k}:{v}")
        pattern_id = hashlib.sha256(
            ":".join(key_parts).encode()
        ).hexdigest()[:12]

        # Check if successful
        success = result.get("success", False)
        if not success:
            return self._extract_error_pattern(
                tool_name, params, result, context
            )

        # Create or update success pattern
        existing = self._patterns.get(pattern_id)
        if existing:
            existing.occurrences += 1
            existing.confidence = min(
                0.95,
                existing.confidence + 0.05,
            )
            existing.updated_at = datetime.now()
            if context and context not in existing.examples:
                existing.examples.append(context)
                existing.examples = existing.examples[-5:]  # Keep last 5
            return existing

        pattern = Pattern(
            id=pattern_id,
            type=PatternType.TOOL_USAGE,
            name=f"{tool_name}_success",
            description=f"Successful {tool_name} pattern",
            trigger=f"Using {tool_name} tool",
            action=json.dumps(params),
            confidence=0.5,
            examples=[context] if context else [],
            metadata={"tool": tool_name},
        )
        self._patterns[pattern_id] = pattern
        return pattern

    def _extract_error_pattern(
        self,
        tool_name: str,
        params: dict[str, Any],
        result: dict[str, Any],
        context: str | None = None,
    ) -> Pattern | None:
        """Extract pattern from an error.

        Args:
            tool_name: Name of the tool
            params: Tool parameters
            result: Error result
            context: Optional context

        Returns:
            Error pattern or None
        """
        error = result.get("error", {})
        error_code = error.get("code", "unknown")
        error_msg = error.get("message", "")

        # Generate ID from error signature
        pattern_id = hashlib.sha256(
            f"{tool_name}:{error_code}:{error_msg[:50]}".encode()
        ).hexdigest()[:12]

        existing = self._patterns.get(pattern_id)
        if existing:
            existing.occurrences += 1
            existing.confidence = min(0.95, existing.confidence + 0.05)
            existing.updated_at = datetime.now()
            return existing

        pattern = Pattern(
            id=pattern_id,
            type=PatternType.ERROR,
            name=f"{tool_name}_error_{error_code}",
            description=f"Error pattern: {error_msg[:100]}",
            trigger=f"Error in {tool_name}: {error_code}",
            action=f"Avoid: {error_msg[:200]}",
            confidence=0.3,
            examples=[context] if context else [],
            metadata={
                "tool": tool_name,
                "error_code": error_code,
                "error_message": error_msg,
            },
        )
        self._patterns[pattern_id] = pattern
        return pattern

    def extract_from_code(self, code: str, language: str = "python") -> list[Pattern]:
        """Extract patterns from code.

        Args:
            code: Source code
            language: Programming language

        Returns:
            List of extracted patterns
        """
        patterns: list[Pattern] = []

        if language == "python":
            patterns.extend(self._extract_python_patterns(code))

        return patterns

    def _extract_python_patterns(self, code: str) -> list[Pattern]:
        """Extract patterns from Python code.

        Args:
            code: Python source code

        Returns:
            List of patterns
        """
        patterns: list[Pattern] = []

        # Extract import patterns
        imports = re.findall(r"^(?:from|import)\s+[\w.]+", code, re.MULTILINE)
        for imp in imports:
            pattern_id = hashlib.sha256(imp.encode()).hexdigest()[:12]
            if pattern_id not in self._patterns:
                patterns.append(
                    Pattern(
                        id=pattern_id,
                        type=PatternType.CODE_PATTERN,
                        name="import_pattern",
                        description=f"Import: {imp}",
                        trigger="Importing module",
                        action=imp,
                        confidence=0.6,
                    )
                )

        # Extract function signatures
        funcs = re.findall(
            r"(?:async\s+)?def\s+(\w+)\s*\([^)]*\)",
            code,
        )
        for func in funcs:
            pattern_id = hashlib.sha256(f"func:{func}".encode()).hexdigest()[:12]
            if pattern_id not in self._patterns:
                patterns.append(
                    Pattern(
                        id=pattern_id,
                        type=PatternType.CODE_PATTERN,
                        name="function_pattern",
                        description=f"Function: {func}",
                        trigger=f"Defining {func}",
                        action=f"def {func}(...)",
                        confidence=0.5,
                    )
                )

        # Add new patterns to store
        for p in patterns:
            self._patterns[p.id] = p

        return patterns

    def extract_workflow(
        self,
        steps: list[dict[str, Any]],
        outcome: str,
    ) -> Pattern | None:
        """Extract a workflow pattern from a sequence of steps.

        Args:
            steps: List of step descriptions
            outcome: Final outcome

        Returns:
            Workflow pattern or None
        """
        if len(steps) < 2:
            return None

        # Create workflow signature
        step_names = [s.get("name", str(i)) for i, s in enumerate(steps)]
        workflow_sig = "->".join(step_names)
        pattern_id = hashlib.sha256(workflow_sig.encode()).hexdigest()[:12]

        existing = self._patterns.get(pattern_id)
        if existing:
            existing.occurrences += 1
            existing.confidence = min(0.95, existing.confidence + 0.1)
            existing.updated_at = datetime.now()
            return existing

        pattern = Pattern(
            id=pattern_id,
            type=PatternType.WORKFLOW,
            name=f"workflow_{len(steps)}_steps",
            description=f"Workflow: {workflow_sig}",
            trigger=f"Starting {step_names[0]}",
            action=workflow_sig,
            confidence=0.4,
            metadata={
                "steps": steps,
                "outcome": outcome,
            },
        )
        self._patterns[pattern_id] = pattern
        return pattern

    def find_matching_patterns(
        self,
        context: str,
        pattern_type: PatternType | None = None,
        limit: int = 5,
    ) -> list[Pattern]:
        """Find patterns matching a context.

        Args:
            context: Context to match against
            pattern_type: Filter by type
            limit: Maximum results

        Returns:
            List of matching patterns
        """
        context_words = set(context.lower().split())
        scored: list[tuple[Pattern, float]] = []

        for pattern in self._patterns.values():
            if pattern_type and pattern.type != pattern_type:
                continue
            if pattern.confidence < self.confidence_threshold:
                continue
            if pattern.occurrences < self.min_occurrences:
                continue

            # Score based on word overlap
            pattern_words = set(
                (pattern.trigger + " " + pattern.description).lower().split()
            )
            overlap = len(context_words & pattern_words)
            if overlap > 0:
                score = (overlap / max(len(context_words), 1)) * pattern.confidence
                scored.append((pattern, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return [p for p, _ in scored[:limit]]

    def get_high_confidence_patterns(
        self,
        pattern_type: PatternType | None = None,
    ) -> list[Pattern]:
        """Get all high-confidence patterns.

        Args:
            pattern_type: Filter by type

        Returns:
            List of high-confidence patterns
        """
        return [
            p
            for p in self._patterns.values()
            if p.confidence >= self.confidence_threshold
            and p.occurrences >= self.min_occurrences
            and (pattern_type is None or p.type == pattern_type)
        ]

    def save(self) -> None:
        """Save patterns to file."""
        if self.storage_path is None:
            return

        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            pid: p.to_dict()
            for pid, p in self._patterns.items()
        }
        with open(self.storage_path, "w") as f:
            json.dump(data, f, indent=2)

    def load(self) -> None:
        """Load patterns from file."""
        if self.storage_path is None or not self.storage_path.exists():
            return

        with open(self.storage_path) as f:
            data = json.load(f)
            self._patterns = {
                pid: Pattern.from_dict(pdata)
                for pid, pdata in data.items()
            }

    def stats(self) -> dict[str, Any]:
        """Get extractor statistics.

        Returns:
            Dictionary of statistics
        """
        by_type: dict[str, int] = {}
        high_confidence = 0
        total_occurrences = 0

        for p in self._patterns.values():
            by_type[p.type.value] = by_type.get(p.type.value, 0) + 1
            if p.confidence >= self.confidence_threshold:
                high_confidence += 1
            total_occurrences += p.occurrences

        return {
            "total_patterns": len(self._patterns),
            "by_type": by_type,
            "high_confidence": high_confidence,
            "total_occurrences": total_occurrences,
        }
