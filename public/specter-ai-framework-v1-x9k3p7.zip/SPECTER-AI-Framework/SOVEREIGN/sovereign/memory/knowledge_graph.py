"""Knowledge Graph using NetworkX for entity-relation storage."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import networkx as nx
from networkx.readwrite import json_graph


@dataclass
class Entity:
    """An entity in the knowledge graph."""

    id: str
    type: str
    name: str
    properties: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "type": self.type,
            "name": self.name,
            "properties": self.properties,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Entity:
        """Create from dictionary."""
        return cls(
            id=data["id"],
            type=data["type"],
            name=data["name"],
            properties=data.get("properties", {}),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
        )


@dataclass
class Relation:
    """A relation between entities."""

    source_id: str
    target_id: str
    relation_type: str
    properties: dict[str, Any] = field(default_factory=dict)
    weight: float = 1.0
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "relation_type": self.relation_type,
            "properties": self.properties,
            "weight": self.weight,
            "created_at": self.created_at.isoformat(),
        }


class KnowledgeGraph:
    """NetworkX-based knowledge graph for entity-relation storage."""

    def __init__(self, path: str | Path | None = None) -> None:
        """Initialize knowledge graph.

        Args:
            path: Optional path to persist the graph (JSON format)
        """
        self.path = Path(path) if path else None
        self._graph = nx.MultiDiGraph()
        self._entity_index: dict[str, Entity] = {}

        # Load from file if exists
        if self.path and self.path.exists():
            self.load()

    @property
    def entity_count(self) -> int:
        """Number of entities in the graph."""
        return self._graph.number_of_nodes()

    @property
    def relation_count(self) -> int:
        """Number of relations in the graph."""
        return self._graph.number_of_edges()

    def add_entity(
        self,
        entity_type: str,
        name: str,
        properties: dict[str, Any] | None = None,
        entity_id: str | None = None,
    ) -> Entity:
        """Add an entity to the graph.

        Args:
            entity_type: Type of entity (e.g., 'concept', 'file', 'function')
            name: Name of the entity
            properties: Optional additional properties
            entity_id: Optional custom ID (auto-generated if not provided)

        Returns:
            Created Entity
        """
        if entity_id is None:
            entity_id = f"{entity_type}:{name}:{datetime.now().timestamp()}"

        entity = Entity(
            id=entity_id,
            type=entity_type,
            name=name,
            properties=properties or {},
        )

        self._graph.add_node(
            entity_id,
            **entity.to_dict(),
        )
        self._entity_index[entity_id] = entity

        return entity

    def get_entity(self, entity_id: str) -> Entity | None:
        """Get an entity by ID.

        Args:
            entity_id: Entity ID

        Returns:
            Entity or None if not found
        """
        return self._entity_index.get(entity_id)

    def find_entities(
        self,
        entity_type: str | None = None,
        name_pattern: str | None = None,
        limit: int = 100,
    ) -> list[Entity]:
        """Find entities matching criteria.

        Args:
            entity_type: Filter by type
            name_pattern: Filter by name (substring match)
            limit: Maximum results

        Returns:
            List of matching entities
        """
        results: list[Entity] = []

        for entity in self._entity_index.values():
            if entity_type and entity.type != entity_type:
                continue
            if name_pattern and name_pattern.lower() not in entity.name.lower():
                continue

            results.append(entity)
            if len(results) >= limit:
                break

        return results

    def update_entity(
        self,
        entity_id: str,
        properties: dict[str, Any] | None = None,
        name: str | None = None,
    ) -> Entity | None:
        """Update an entity.

        Args:
            entity_id: Entity ID
            properties: New properties to merge
            name: New name

        Returns:
            Updated Entity or None if not found
        """
        entity = self._entity_index.get(entity_id)
        if entity is None:
            return None

        if properties:
            entity.properties.update(properties)
        if name:
            entity.name = name
        entity.updated_at = datetime.now()

        # Update graph node
        self._graph.nodes[entity_id].update(entity.to_dict())

        return entity

    def remove_entity(self, entity_id: str) -> bool:
        """Remove an entity and its relations.

        Args:
            entity_id: Entity ID

        Returns:
            True if removed, False if not found
        """
        if entity_id not in self._entity_index:
            return False

        self._graph.remove_node(entity_id)
        del self._entity_index[entity_id]
        return True

    def add_relation(
        self,
        source_id: str,
        target_id: str,
        relation_type: str,
        properties: dict[str, Any] | None = None,
        weight: float = 1.0,
    ) -> Relation | None:
        """Add a relation between entities.

        Args:
            source_id: Source entity ID
            target_id: Target entity ID
            relation_type: Type of relation (e.g., 'uses', 'imports', 'calls')
            properties: Optional relation properties
            weight: Relation weight

        Returns:
            Created Relation or None if entities don't exist
        """
        if source_id not in self._entity_index:
            return None
        if target_id not in self._entity_index:
            return None

        relation = Relation(
            source_id=source_id,
            target_id=target_id,
            relation_type=relation_type,
            properties=properties or {},
            weight=weight,
        )

        self._graph.add_edge(
            source_id,
            target_id,
            key=relation_type,
            **relation.to_dict(),
        )

        return relation

    def get_relations(
        self,
        entity_id: str,
        direction: str = "both",
        relation_type: str | None = None,
    ) -> list[Relation]:
        """Get relations for an entity.

        Args:
            entity_id: Entity ID
            direction: 'outgoing', 'incoming', or 'both'
            relation_type: Filter by relation type

        Returns:
            List of relations
        """
        relations: list[Relation] = []

        if direction in ("outgoing", "both"):
            for _, target, data in self._graph.out_edges(entity_id, data=True):
                if relation_type and data.get("relation_type") != relation_type:
                    continue
                relations.append(
                    Relation(
                        source_id=entity_id,
                        target_id=target,
                        relation_type=data.get("relation_type", ""),
                        properties=data.get("properties", {}),
                        weight=data.get("weight", 1.0),
                    )
                )

        if direction in ("incoming", "both"):
            for source, _, data in self._graph.in_edges(entity_id, data=True):
                if relation_type and data.get("relation_type") != relation_type:
                    continue
                relations.append(
                    Relation(
                        source_id=source,
                        target_id=entity_id,
                        relation_type=data.get("relation_type", ""),
                        properties=data.get("properties", {}),
                        weight=data.get("weight", 1.0),
                    )
                )

        return relations

    def find_path(
        self,
        source_id: str,
        target_id: str,
        max_length: int = 5,
    ) -> list[str] | None:
        """Find shortest path between entities.

        Args:
            source_id: Source entity ID
            target_id: Target entity ID
            max_length: Maximum path length

        Returns:
            List of entity IDs in path, or None if no path exists
        """
        try:
            path = nx.shortest_path(
                self._graph,
                source_id,
                target_id,
            )
            if len(path) > max_length:
                return None
            return list(path)
        except nx.NetworkXNoPath:
            return None
        except nx.NodeNotFound:
            return None

    def get_neighbors(
        self,
        entity_id: str,
        depth: int = 1,
    ) -> list[Entity]:
        """Get neighboring entities.

        Args:
            entity_id: Entity ID
            depth: How many hops to traverse

        Returns:
            List of neighboring entities
        """
        if entity_id not in self._entity_index:
            return []

        neighbors: set[str] = set()
        current = {entity_id}

        for _ in range(depth):
            next_level: set[str] = set()
            for node in current:
                next_level.update(self._graph.successors(node))
                next_level.update(self._graph.predecessors(node))
            next_level -= neighbors
            next_level.discard(entity_id)
            neighbors.update(next_level)
            current = next_level

        return [
            self._entity_index[n]
            for n in neighbors
            if n in self._entity_index
        ]

    def query(self, cypher_like: str) -> list[dict[str, Any]]:
        """Execute a simple Cypher-like query.

        Supported patterns:
        - MATCH (n:Type) RETURN n
        - MATCH (n)-[r:REL]->(m) RETURN n, r, m

        Args:
            cypher_like: Query string

        Returns:
            Query results
        """
        # Simple implementation - can be extended
        query_lower = cypher_like.lower()

        if "match (n)" in query_lower or "match (n:" in query_lower:
            # Extract type if specified
            entity_type = None
            if ":" in cypher_like:
                import re
                match = re.search(r"\(n:(\w+)\)", cypher_like)
                if match:
                    entity_type = match.group(1)

            entities = self.find_entities(entity_type=entity_type)
            return [e.to_dict() for e in entities]

        return []

    def save(self) -> None:
        """Save graph to JSON file."""
        if self.path is None:
            return

        self.path.parent.mkdir(parents=True, exist_ok=True)

        # Use NetworkX JSON serialization for the graph
        graph_data = json_graph.node_link_data(self._graph)

        # Save entities index separately for quick reconstruction
        entities_data = {
            eid: e.to_dict()
            for eid, e in self._entity_index.items()
        }

        data = {
            "graph": graph_data,
            "entities": entities_data,
            "version": "1.0",
        }

        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)

    def load(self) -> None:
        """Load graph from JSON file."""
        if self.path is None or not self.path.exists():
            return

        with open(self.path, encoding="utf-8") as f:
            data = json.load(f)

        # Reconstruct graph from JSON
        self._graph = json_graph.node_link_graph(data["graph"])

        # Reconstruct entity index
        self._entity_index = {
            eid: Entity.from_dict(edata)
            for eid, edata in data.get("entities", {}).items()
        }

    def export_json(self) -> str:
        """Export graph to JSON string.

        Returns:
            JSON string representation
        """
        data = {
            "entities": [e.to_dict() for e in self._entity_index.values()],
            "relations": [
                {
                    "source": u,
                    "target": v,
                    "type": d.get("relation_type"),
                    "properties": d.get("properties", {}),
                }
                for u, v, d in self._graph.edges(data=True)
            ],
        }
        return json.dumps(data, indent=2, default=str)

    def stats(self) -> dict[str, Any]:
        """Get graph statistics.

        Returns:
            Dictionary of statistics
        """
        entity_types: dict[str, int] = {}
        for entity in self._entity_index.values():
            entity_types[entity.type] = entity_types.get(entity.type, 0) + 1

        return {
            "entity_count": self.entity_count,
            "relation_count": self.relation_count,
            "entity_types": entity_types,
            "is_connected": nx.is_weakly_connected(self._graph)
            if self.entity_count > 0
            else True,
        }
