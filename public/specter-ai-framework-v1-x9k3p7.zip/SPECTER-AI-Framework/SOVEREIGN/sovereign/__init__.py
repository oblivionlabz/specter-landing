"""SOVEREIGN - Sovereign AI Terminal Assistant.

A sovereign, LocalAI-powered terminal assistant that surpasses Claude Code capabilities.
"""

__version__ = "1.0.0"
__author__ = "SOVEREIGN Team"

from sovereign.app import SovereignApp
from sovereign.config import Config

__all__ = ["Config", "SovereignApp", "__version__"]
