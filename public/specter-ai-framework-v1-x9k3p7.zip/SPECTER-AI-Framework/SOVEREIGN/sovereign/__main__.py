"""SOVEREIGN CLI entry point."""

import sys

import click
from rich.console import Console

from sovereign import __version__
from sovereign.app import SovereignApp
from sovereign.config import Config

console = Console()


@click.group(invoke_without_command=True)
@click.option("--version", is_flag=True, help="Show version and exit")
@click.option("--tui", is_flag=True, help="Launch with TUI dashboard")
@click.option("--voice", is_flag=True, help="Enable voice interface")
@click.option(
    "--config",
    "-c",
    type=click.Path(exists=True),
    help="Path to config file",
    default="config/sovereign.yaml",
)
@click.pass_context
def main(ctx: click.Context, version: bool, tui: bool, voice: bool, config: str) -> None:
    """SOVEREIGN - Sovereign AI Terminal Assistant.

    LocalAI-powered terminal assistant with multi-agent orchestration,
    advanced memory, voice interface, and autonomous execution.
    """
    if version:
        console.print(f"[bold blue]SOVEREIGN[/bold blue] v{__version__}")
        sys.exit(0)

    if ctx.invoked_subcommand is None:
        # Run the main app
        try:
            cfg = Config.load(config)
            app = SovereignApp(cfg, tui=tui, voice=voice)
            app.run()
        except KeyboardInterrupt:
            console.print("\n[yellow]Interrupted. Goodbye![/yellow]")
            sys.exit(0)
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            sys.exit(1)


@main.command()
@click.argument("task")
@click.option("--max-iterations", "-n", default=30, help="Maximum iterations")
@click.option("--quality-gate/--no-quality-gate", default=True, help="Enable quality gates")
@click.option(
    "--config",
    "-c",
    type=click.Path(exists=True),
    help="Path to config file",
    default="config/sovereign.yaml",
)
def loop(task: str, max_iterations: int, quality_gate: bool, config: str) -> None:
    """Run autonomous Ralph loop on a task."""
    import asyncio

    console.print(f"[bold blue]Starting Ralph Loop[/bold blue]")
    console.print(f"Task: {task}")
    console.print(f"Max iterations: {max_iterations}, Quality gates: {quality_gate}")
    console.print("[dim]Press Ctrl+C to pause[/dim]\n")

    try:
        cfg = Config.load(config)
        app = SovereignApp(cfg)

        # Run the Ralph loop
        asyncio.run(app._run_ralph_loop(task))

    except KeyboardInterrupt:
        console.print("\n[yellow]Ralph loop interrupted[/yellow]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


@main.command()
def tools() -> None:
    """List available tools."""
    console.print("[bold]Available Tools:[/bold]")
    tools_list = ["read", "write", "edit", "glob", "grep", "bash", "python"]
    for tool in tools_list:
        console.print(f"  - {tool}")


@main.command()
def memory() -> None:
    """Show memory status."""
    console.print("[bold]Memory Status:[/bold]")
    console.print("  Knowledge Graph: [yellow]Not initialized[/yellow]")
    console.print("  Vector Store: [yellow]Not connected[/yellow]")
    # TODO: Implement in Phase 3


if __name__ == "__main__":
    main()
