"""Bash execution tool with security controls."""

from __future__ import annotations

import asyncio
import os
from typing import Any

from sovereign.tools.base import BaseTool, ToolErrorCode, ToolResult


class BashTool(BaseTool):
    """Execute bash commands with security controls."""

    # Commands that are always blocked
    BLOCKED_COMMANDS = {
        "rm -rf /",
        "rm -rf /*",
        "dd if=",
        "mkfs",
        ":(){:|:&};:",  # Fork bomb
        "chmod -R 777 /",
        "chown -R",
    }

    # Command prefixes that are blocked
    BLOCKED_PREFIXES = {
        "sudo ",
        "su ",
        "passwd",
        "shutdown",
        "reboot",
        "init ",
        "systemctl",
    }

    # Default timeout in seconds
    DEFAULT_TIMEOUT = 60

    @property
    def name(self) -> str:
        return "bash"

    @property
    def description(self) -> str:
        return "Execute a bash command and return the output"

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The bash command to execute",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds",
                    "default": 60,
                },
                "cwd": {
                    "type": "string",
                    "description": "Working directory",
                },
            },
            "required": ["command"],
        }

    async def execute(self, **params: Any) -> ToolResult:
        command = params["command"]
        timeout = params.get("timeout", self.DEFAULT_TIMEOUT)
        cwd = params.get("cwd")

        # Security checks
        security_result = self._check_security(command)
        if security_result is not None:
            return security_result

        try:
            # Create subprocess
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
                env=self._get_safe_env(),
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout,
                )
            except TimeoutError:
                process.kill()
                await process.wait()
                return ToolResult.fail(
                    code=ToolErrorCode.TIMEOUT,
                    message=f"Command timed out after {timeout}s",
                    details={"command": command},
                )

            stdout_str = stdout.decode("utf-8", errors="replace")
            stderr_str = stderr.decode("utf-8", errors="replace")

            # Truncate output if too long
            max_output = 50000
            if len(stdout_str) > max_output:
                stdout_str = stdout_str[:max_output] + "\n... (truncated)"
            if len(stderr_str) > max_output:
                stderr_str = stderr_str[:max_output] + "\n... (truncated)"

            output = stdout_str
            if stderr_str:
                output += f"\n[stderr]\n{stderr_str}"

            return ToolResult.ok(
                output,
                command=command,
                exit_code=process.returncode,
                success=process.returncode == 0,
            )

        except Exception as e:
            return ToolResult.fail(
                code=ToolErrorCode.EXECUTION_FAILED,
                message=f"Command execution failed: {e}",
                details={"command": command},
            )

    def _check_security(self, command: str) -> ToolResult | None:
        """Check if command is safe to execute.

        Args:
            command: Command to check

        Returns:
            ToolResult with error if blocked, None if safe
        """
        command_lower = command.lower().strip()

        # Check exact blocked commands
        for blocked in self.BLOCKED_COMMANDS:
            if blocked in command_lower:
                return ToolResult.fail(
                    code=ToolErrorCode.PERMISSION_DENIED,
                    message=f"Blocked dangerous command: {blocked}",
                )

        # Check blocked prefixes
        for prefix in self.BLOCKED_PREFIXES:
            if command_lower.startswith(prefix):
                return ToolResult.fail(
                    code=ToolErrorCode.PERMISSION_DENIED,
                    message=f"Blocked command type: {prefix.strip()}",
                )

        return None

    def _get_safe_env(self) -> dict[str, str]:
        """Get a safe environment for command execution.

        Returns:
            Environment dictionary with sensitive vars removed
        """
        env = dict(os.environ)

        # Remove potentially sensitive environment variables
        sensitive_vars = {
            "AWS_SECRET_ACCESS_KEY",
            "AWS_SESSION_TOKEN",
            "GITHUB_TOKEN",
            "ANTHROPIC_API_KEY",
            "OPENAI_API_KEY",
            "DATABASE_PASSWORD",
            "DB_PASSWORD",
            "SECRET_KEY",
            "PRIVATE_KEY",
        }

        for var in sensitive_vars:
            env.pop(var, None)

        return env
