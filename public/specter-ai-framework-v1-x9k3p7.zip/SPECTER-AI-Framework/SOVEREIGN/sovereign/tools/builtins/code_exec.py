"""Code execution tools with sandboxing."""

from __future__ import annotations

import asyncio
import sys
import tempfile
from pathlib import Path
from typing import Any

from sovereign.tools.base import BaseTool, ToolErrorCode, ToolResult


class PythonTool(BaseTool):
    """Run Python code in a subprocess."""

    DEFAULT_TIMEOUT = 30

    @property
    def name(self) -> str:
        return "python"

    @property
    def description(self) -> str:
        return "Run Python code and return the output"

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "Python code to run",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds",
                    "default": 30,
                },
            },
            "required": ["code"],
        }

    async def run_code(self, **params: Any) -> ToolResult:
        """Alias for execute to avoid naming conflicts."""
        return await self.execute(**params)

    async def execute(self, **params: Any) -> ToolResult:
        code = params["code"]
        timeout = params.get("timeout", self.DEFAULT_TIMEOUT)

        # Security check
        security_result = self._check_security(code)
        if security_result is not None:
            return security_result

        try:
            # Write code to temp file
            with tempfile.NamedTemporaryFile(
                mode="w",
                suffix=".py",
                delete=False,
            ) as f:
                f.write(code)
                temp_path = Path(f.name)

            try:
                # Run in subprocess using create_subprocess with explicit args
                # This is safe - uses execve internally, not shell
                process = await asyncio.create_subprocess_exec(
                    sys.executable,
                    str(temp_path),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )

                try:
                    stdout, stderr = await asyncio.wait_for(
                        process.communicate(),
                        timeout=timeout,
                    )
                except TimeoutError:
                    process.kill()
                    await process.wait()
                    return ToolResult.fail(
                        code=ToolErrorCode.TIMEOUT,
                        message=f"Code timed out after {timeout}s",
                    )

                stdout_str = stdout.decode("utf-8", errors="replace")
                stderr_str = stderr.decode("utf-8", errors="replace")

                output = stdout_str
                if stderr_str:
                    output += f"\n[stderr]\n{stderr_str}"

                return ToolResult.ok(
                    output,
                    exit_code=process.returncode,
                    success=process.returncode == 0,
                )

            finally:
                # Clean up temp file
                temp_path.unlink(missing_ok=True)

        except Exception as e:
            return ToolResult.fail(
                code=ToolErrorCode.EXECUTION_FAILED,
                message=f"Code run failed: {e}",
            )

    def _check_security(self, code: str) -> ToolResult | None:
        """Check if code is safe to run.

        Args:
            code: Python code to check

        Returns:
            ToolResult with error if blocked, None if safe
        """
        code_lower = code.lower()

        # Block dangerous operations
        blocked_patterns = [
            "os.system(",
            "subprocess.call(",
            "subprocess.run(",
            "__import__(",
            "open('/etc",
            "open('/proc",
            "shutil.rmtree('/'",
        ]

        for pattern in blocked_patterns:
            if pattern in code_lower:
                return ToolResult.fail(
                    code=ToolErrorCode.PERMISSION_DENIED,
                    message=f"Blocked dangerous operation: {pattern}",
                )

        return None
