"""File operation tools: read, write, edit, glob, grep."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import aiofiles

from sovereign.tools.base import BaseTool, ToolErrorCode, ToolResult


class ReadTool(BaseTool):
    """Read file contents."""

    @property
    def name(self) -> str:
        return "read"

    @property
    def description(self) -> str:
        return "Read the contents of a file at the specified path"

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to read",
                },
                "offset": {
                    "type": "integer",
                    "description": "Line number to start reading from (0-indexed)",
                    "default": 0,
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of lines to read",
                    "default": 2000,
                },
            },
            "required": ["path"],
        }

    async def execute(self, **params: Any) -> ToolResult:
        path = Path(params["path"]).expanduser().resolve()
        offset = params.get("offset", 0)
        limit = params.get("limit", 2000)

        # Security check
        if not self._is_safe_path(path):
            return ToolResult.fail(
                code=ToolErrorCode.PERMISSION_DENIED,
                message=f"Access denied: {path}",
            )

        if not path.exists():
            return ToolResult.fail(
                code=ToolErrorCode.NOT_FOUND,
                message=f"File not found: {path}",
            )

        if not path.is_file():
            return ToolResult.fail(
                code=ToolErrorCode.INVALID_PARAMS,
                message=f"Not a file: {path}",
            )

        try:
            async with aiofiles.open(path, encoding="utf-8") as f:
                lines = await f.readlines()

            # Apply offset and limit
            total_lines = len(lines)
            selected = lines[offset : offset + limit]

            # Format with line numbers
            result_lines = []
            for i, line in enumerate(selected, start=offset + 1):
                result_lines.append(f"{i:6d}│{line.rstrip()}")

            content = "\n".join(result_lines)

            return ToolResult.ok(
                content,
                path=str(path),
                total_lines=total_lines,
                returned_lines=len(selected),
                offset=offset,
            )

        except UnicodeDecodeError:
            return ToolResult.fail(
                code=ToolErrorCode.EXECUTION_FAILED,
                message=f"Cannot read binary file: {path}",
            )
        except Exception as e:
            return ToolResult.fail(
                code=ToolErrorCode.EXECUTION_FAILED,
                message=f"Error reading file: {e}",
            )

    def _is_safe_path(self, path: Path) -> bool:
        """Check if path is safe to access."""
        # Block sensitive paths
        blocked = [".env", ".key", ".pem", "secrets/", "credentials"]
        path_str = str(path).lower()
        return not any(b in path_str for b in blocked)


class WriteTool(BaseTool):
    """Write content to a file."""

    @property
    def name(self) -> str:
        return "write"

    @property
    def description(self) -> str:
        return "Write content to a file, creating it if it doesn't exist"

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to write",
                },
                "content": {
                    "type": "string",
                    "description": "Content to write to the file",
                },
            },
            "required": ["path", "content"],
        }

    # Maximum file size to write (10MB)
    MAX_WRITE_SIZE = 10 * 1024 * 1024

    async def execute(self, **params: Any) -> ToolResult:
        path = Path(params["path"]).expanduser().resolve()
        content = params.get("content", "")

        # Validate content is provided
        if content is None:
            return ToolResult.fail(
                code=ToolErrorCode.INVALID_PARAMS,
                message="content parameter is required",
            )

        # Convert to string if needed
        if not isinstance(content, str):
            content = str(content)

        # Security check
        if not self._is_safe_path(path):
            return ToolResult.fail(
                code=ToolErrorCode.PERMISSION_DENIED,
                message=f"Access denied: {path}",
            )

        # Validate content size
        content_bytes = len(content.encode("utf-8"))
        if content_bytes > self.MAX_WRITE_SIZE:
            return ToolResult.fail(
                code=ToolErrorCode.INVALID_PARAMS,
                message=f"Content too large: {content_bytes:,} bytes exceeds {self.MAX_WRITE_SIZE:,} byte limit",
            )

        # Check for suspicious patterns that indicate corruption
        if self._looks_corrupted(content):
            return ToolResult.fail(
                code=ToolErrorCode.EXECUTION_FAILED,
                message="Content appears corrupted (excessive repetition detected). Aborting write.",
            )

        try:
            # Create parent directories if needed
            path.parent.mkdir(parents=True, exist_ok=True)

            async with aiofiles.open(path, "w", encoding="utf-8") as f:
                await f.write(content)

            return ToolResult.ok(
                f"Successfully wrote to {path}",
                path=str(path),
                bytes_written=content_bytes,
                lines=content.count("\n") + 1,
            )

        except Exception as e:
            return ToolResult.fail(
                code=ToolErrorCode.EXECUTION_FAILED,
                message=f"Error writing file: {e}",
            )

    def _is_safe_path(self, path: Path) -> bool:
        """Check if path is safe to write."""
        blocked = [".env", ".key", ".pem", "secrets/"]
        path_str = str(path).lower()
        return not any(b in path_str for b in blocked)

    def _looks_corrupted(self, content: str) -> bool:
        """Check if content looks corrupted (excessive repetition)."""
        if len(content) < 1000:
            return False

        # Check for suspiciously repetitive content
        # Sample lines and look for excessive duplication
        lines = content.split("\n")
        if len(lines) > 100:
            sample = lines[:100]
            unique_lines = set(sample)
            # If more than 80% of lines are duplicates, it's suspicious
            if len(unique_lines) < len(sample) * 0.2:
                return True

        return False


class EditTool(BaseTool):
    """Edit a file by replacing text."""

    @property
    def name(self) -> str:
        return "edit"

    @property
    def description(self) -> str:
        return "Edit a file by replacing old text with new text"

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to the file to edit",
                },
                "old_string": {
                    "type": "string",
                    "description": "Text to replace",
                },
                "new_string": {
                    "type": "string",
                    "description": "Replacement text",
                },
                "replace_all": {
                    "type": "boolean",
                    "description": "Replace all occurrences",
                    "default": False,
                },
            },
            "required": ["path", "old_string", "new_string"],
        }

    async def execute(self, **params: Any) -> ToolResult:
        path = Path(params["path"]).expanduser().resolve()
        old_string = params.get("old_string", "")
        new_string = params.get("new_string", "")
        replace_all = params.get("replace_all", False)

        # CRITICAL: Validate old_string is not empty
        # Empty string replace inserts new_string before EVERY character!
        if not old_string:
            return ToolResult.fail(
                code=ToolErrorCode.INVALID_PARAMS,
                message="old_string cannot be empty. Provide the exact text to replace.",
            )

        # Validate old_string and new_string are different
        if old_string == new_string:
            return ToolResult.fail(
                code=ToolErrorCode.INVALID_PARAMS,
                message="old_string and new_string are identical. No changes needed.",
            )

        if not path.exists():
            return ToolResult.fail(
                code=ToolErrorCode.NOT_FOUND,
                message=f"File not found: {path}",
            )

        try:
            async with aiofiles.open(path, encoding="utf-8") as f:
                content = await f.read()

            original_size = len(content)

            # Check if old_string exists
            if old_string not in content:
                return ToolResult.fail(
                    code=ToolErrorCode.NOT_FOUND,
                    message=f"Text not found in file: {old_string[:50]}{'...' if len(old_string) > 50 else ''}",
                )

            # Count occurrences
            count = content.count(old_string)
            if count > 1 and not replace_all:
                return ToolResult.fail(
                    code=ToolErrorCode.INVALID_PARAMS,
                    message=f"Found {count} occurrences. Use replace_all=true to replace all.",
                )

            # Replace
            if replace_all:
                new_content = content.replace(old_string, new_string)
                replaced = count
            else:
                new_content = content.replace(old_string, new_string, 1)
                replaced = 1

            # Validate output - check for suspicious size changes
            new_size = len(new_content)
            size_ratio = new_size / max(original_size, 1)

            # If file grew more than 10x, something is wrong
            if size_ratio > 10 and new_size > 10000:
                return ToolResult.fail(
                    code=ToolErrorCode.EXECUTION_FAILED,
                    message=f"Suspicious file growth detected: {original_size} -> {new_size} bytes. "
                    f"Aborting to prevent corruption.",
                )

            async with aiofiles.open(path, "w", encoding="utf-8") as f:
                await f.write(new_content)

            return ToolResult.ok(
                f"Replaced {replaced} occurrence(s) in {path}",
                path=str(path),
                replacements=replaced,
                original_size=original_size,
                new_size=new_size,
            )

        except Exception as e:
            return ToolResult.fail(
                code=ToolErrorCode.EXECUTION_FAILED,
                message=f"Error editing file: {e}",
            )


class GlobTool(BaseTool):
    """Find files matching a pattern."""

    @property
    def name(self) -> str:
        return "glob"

    @property
    def description(self) -> str:
        return "Find files matching a glob pattern"

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern (e.g., '**/*.py')",
                },
                "path": {
                    "type": "string",
                    "description": "Directory to search in",
                    "default": ".",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of results",
                    "default": 100,
                },
            },
            "required": ["pattern"],
        }

    async def execute(self, **params: Any) -> ToolResult:
        pattern = params["pattern"]
        base_path = Path(params.get("path", ".")).expanduser().resolve()
        limit = params.get("limit", 100)

        if not base_path.exists():
            return ToolResult.fail(
                code=ToolErrorCode.NOT_FOUND,
                message=f"Directory not found: {base_path}",
            )

        try:
            matches = list(base_path.glob(pattern))[:limit]
            files = [str(m.relative_to(base_path)) for m in matches if m.is_file()]

            return ToolResult.ok(
                files,
                pattern=pattern,
                base_path=str(base_path),
                count=len(files),
                limited=len(matches) >= limit,
            )

        except Exception as e:
            return ToolResult.fail(
                code=ToolErrorCode.EXECUTION_FAILED,
                message=f"Error searching: {e}",
            )


class GrepTool(BaseTool):
    """Search for patterns in files."""

    @property
    def name(self) -> str:
        return "grep"

    @property
    def description(self) -> str:
        return "Search for a pattern in files"

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Regex pattern to search for",
                },
                "path": {
                    "type": "string",
                    "description": "File or directory to search",
                    "default": ".",
                },
                "include": {
                    "type": "string",
                    "description": "File pattern to include (e.g., '*.py')",
                },
                "context": {
                    "type": "integer",
                    "description": "Lines of context around matches",
                    "default": 0,
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of matches",
                    "default": 50,
                },
            },
            "required": ["pattern"],
        }

    async def execute(self, **params: Any) -> ToolResult:
        pattern = params["pattern"]
        search_path = Path(params.get("path", ".")).expanduser().resolve()
        include = params.get("include", "*")
        context = params.get("context", 0)
        limit = params.get("limit", 50)

        try:
            regex = re.compile(pattern)
        except re.error as e:
            return ToolResult.fail(
                code=ToolErrorCode.INVALID_PARAMS,
                message=f"Invalid regex: {e}",
            )

        matches: list[dict[str, Any]] = []

        try:
            # Collect files to search
            if search_path.is_file():
                files = [search_path]
            else:
                files = list(search_path.rglob(include))

            for file_path in files:
                if not file_path.is_file():
                    continue
                if len(matches) >= limit:
                    break

                try:
                    async with aiofiles.open(file_path, encoding="utf-8") as f:
                        lines = await f.readlines()

                    for i, line in enumerate(lines):
                        if regex.search(line):
                            match_info: dict[str, Any] = {
                                "file": str(file_path.relative_to(search_path.parent)),
                                "line": i + 1,
                                "content": line.rstrip(),
                            }

                            # Add context if requested
                            if context > 0:
                                start = max(0, i - context)
                                end = min(len(lines), i + context + 1)
                                match_info["context"] = [
                                    l.rstrip() for l in lines[start:end]
                                ]

                            matches.append(match_info)

                            if len(matches) >= limit:
                                break

                except (UnicodeDecodeError, PermissionError):
                    continue

            return ToolResult.ok(
                matches,
                pattern=pattern,
                search_path=str(search_path),
                count=len(matches),
                limited=len(matches) >= limit,
            )

        except Exception as e:
            return ToolResult.fail(
                code=ToolErrorCode.EXECUTION_FAILED,
                message=f"Error searching: {e}",
            )
