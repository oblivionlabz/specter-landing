"""Tool registry for discovering and managing tools."""

from __future__ import annotations

from typing import Any

from sovereign.tools.base import BaseTool, Tool, ToolError, ToolErrorCode, ToolResult


class ToolRegistry:
    """Registry for managing and discovering tools."""

    def __init__(self) -> None:
        """Initialize the tool registry."""
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        """Register a tool.

        Args:
            tool: Tool instance to register

        Raises:
            ValueError: If tool with same name already exists
        """
        if tool.name in self._tools:
            raise ValueError(f"Tool '{tool.name}' is already registered")
        self._tools[tool.name] = tool

    def unregister(self, name: str) -> None:
        """Unregister a tool by name.

        Args:
            name: Tool name to unregister
        """
        self._tools.pop(name, None)

    def get(self, name: str) -> Tool | None:
        """Get a tool by name.

        Args:
            name: Tool name

        Returns:
            Tool instance or None if not found
        """
        return self._tools.get(name)

    def list_tools(self) -> list[str]:
        """List all registered tool names.

        Returns:
            List of tool names
        """
        return list(self._tools.keys())

    def get_all(self) -> dict[str, Tool]:
        """Get all registered tools.

        Returns:
            Dictionary of tool name to tool instance
        """
        return dict(self._tools)

    async def execute(self, name: str, **params: Any) -> ToolResult:
        """Execute a tool by name.

        Args:
            name: Tool name
            **params: Tool parameters

        Returns:
            ToolResult from execution
        """
        tool = self.get(name)
        if tool is None:
            return ToolResult.fail(
                code=ToolErrorCode.NOT_FOUND,
                message=f"Tool '{name}' not found",
            )

        try:
            # Validate parameters if tool has validation
            if isinstance(tool, BaseTool):
                errors = tool.validate_params(params)
                if errors:
                    return ToolResult.fail(
                        code=ToolErrorCode.INVALID_PARAMS,
                        message="Parameter validation failed",
                        details={"errors": errors},
                    )

            return await tool.execute(**params)

        except ToolError as e:
            return ToolResult.fail(
                code=e.code,
                message=e.message,
                details=e.details,
            )
        except Exception as e:
            return ToolResult.fail(
                code=ToolErrorCode.EXECUTION_FAILED,
                message=str(e),
                details={"exception_type": type(e).__name__},
            )

    def to_mcp_tools(self) -> list[dict[str, Any]]:
        """Convert all tools to MCP format.

        Returns:
            List of tool schemas in MCP format
        """
        tools = []
        for tool in self._tools.values():
            if isinstance(tool, BaseTool):
                tools.append(tool.to_mcp_schema())
            else:
                # Generic conversion for protocol-based tools
                tools.append({
                    "name": tool.name,
                    "description": tool.description,
                    "inputSchema": tool.parameters,
                })
        return tools

    def load_builtins(self) -> None:
        """Load all built-in tools from sovereign.tools.builtins."""
        from sovereign.tools.builtins import (
            bash,
            code_exec,
            file_ops,
        )

        # Register file operations
        self.register(file_ops.ReadTool())
        self.register(file_ops.WriteTool())
        self.register(file_ops.EditTool())
        self.register(file_ops.GlobTool())
        self.register(file_ops.GrepTool())

        # Register bash
        self.register(bash.BashTool())

        # Register code execution
        self.register(code_exec.PythonTool())


def create_default_registry() -> ToolRegistry:
    """Create a registry with all built-in tools loaded.

    Returns:
        ToolRegistry with built-in tools
    """
    registry = ToolRegistry()
    registry.load_builtins()
    return registry
