"""Base tool protocol and types."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol, runtime_checkable


class ToolErrorCode(Enum):
    """Standard tool error codes."""

    INVALID_PARAMS = "invalid_params"
    EXECUTION_FAILED = "execution_failed"
    PERMISSION_DENIED = "permission_denied"
    NOT_FOUND = "not_found"
    TIMEOUT = "timeout"
    INTERNAL_ERROR = "internal_error"


@dataclass
class ToolError(Exception):
    """Tool execution error."""

    code: ToolErrorCode
    message: str
    details: dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        return f"[{self.code.value}] {self.message}"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "code": self.code.value,
            "message": self.message,
            "details": self.details,
        }


@dataclass
class ToolResult:
    """Result of a tool execution."""

    success: bool
    output: Any = None
    error: ToolError | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result: dict[str, Any] = {"success": self.success}
        if self.output is not None:
            result["output"] = self.output
        if self.error is not None:
            result["error"] = self.error.to_dict()
        if self.metadata:
            result["metadata"] = self.metadata
        return result

    @classmethod
    def ok(cls, output: Any, **metadata: Any) -> ToolResult:
        """Create a successful result."""
        return cls(success=True, output=output, metadata=metadata)

    @classmethod
    def fail(
        cls,
        code: ToolErrorCode,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> ToolResult:
        """Create a failed result."""
        error = ToolError(code=code, message=message, details=details or {})
        return cls(success=False, error=error)


@runtime_checkable
class Tool(Protocol):
    """Protocol for SOVEREIGN tools.

    All tools must implement this protocol to be registered.
    """

    @property
    def name(self) -> str:
        """Tool name (unique identifier)."""
        ...

    @property
    def description(self) -> str:
        """Human-readable description."""
        ...

    @property
    def parameters(self) -> dict[str, Any]:
        """JSON Schema for parameters."""
        ...

    async def execute(self, **params: Any) -> ToolResult:
        """Execute the tool with given parameters.

        Args:
            **params: Tool parameters matching the JSON schema

        Returns:
            ToolResult with success/failure and output
        """
        ...


class BaseTool(ABC):
    """Abstract base class for tools with common functionality."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Tool name."""
        ...

    @property
    @abstractmethod
    def description(self) -> str:
        """Tool description."""
        ...

    @property
    @abstractmethod
    def parameters(self) -> dict[str, Any]:
        """JSON Schema for parameters."""
        ...

    @abstractmethod
    async def execute(self, **params: Any) -> ToolResult:
        """Execute the tool."""
        ...

    def validate_params(self, params: dict[str, Any]) -> list[str]:
        """Validate parameters against schema.

        Args:
            params: Parameters to validate

        Returns:
            List of validation errors (empty if valid)
        """
        errors: list[str] = []
        schema = self.parameters

        # Check required parameters
        required = schema.get("required", [])
        for req in required:
            if req not in params:
                errors.append(f"Missing required parameter: {req}")

        # Check parameter types
        properties = schema.get("properties", {})
        for key, value in params.items():
            if key not in properties:
                continue

            prop_schema = properties[key]
            expected_type = prop_schema.get("type")

            if expected_type == "string" and not isinstance(value, str):
                errors.append(f"Parameter '{key}' must be a string")
            elif expected_type == "integer" and not isinstance(value, int):
                errors.append(f"Parameter '{key}' must be an integer")
            elif expected_type == "boolean" and not isinstance(value, bool):
                errors.append(f"Parameter '{key}' must be a boolean")
            elif expected_type == "array" and not isinstance(value, list):
                errors.append(f"Parameter '{key}' must be an array")
            elif expected_type == "object" and not isinstance(value, dict):
                errors.append(f"Parameter '{key}' must be an object")

        return errors

    def to_mcp_schema(self) -> dict[str, Any]:
        """Convert to MCP tool schema format."""
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.parameters,
        }
