"""SOVEREIGN Tool System.

MCP-compatible tool system with built-in file operations and bash execution.
"""

from sovereign.tools.base import Tool, ToolError, ToolResult
from sovereign.tools.registry import ToolRegistry

__all__ = ["Tool", "ToolError", "ToolRegistry", "ToolResult"]
