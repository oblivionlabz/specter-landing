"""Workflow State Management with checkpointing."""

from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Generic, TypeVar


class WorkflowStatus(Enum):
    """Status of a workflow execution."""

    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


T = TypeVar("T", bound=dict[str, Any])


@dataclass
class WorkflowState(Generic[T]):
    """State container for workflow execution.

    Stores all data that flows through the workflow graph.
    """

    workflow_id: str
    data: T
    status: WorkflowStatus = WorkflowStatus.PENDING
    current_node: str | None = None
    history: list[str] = field(default_factory=list)
    errors: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    def update(self, updates: dict[str, Any]) -> None:
        """Update state data.

        Args:
            updates: Dictionary of updates to merge
        """
        if isinstance(self.data, dict):
            self.data.update(updates)
        self.updated_at = datetime.now()

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value from state data.

        Args:
            key: Key to retrieve
            default: Default value if not found

        Returns:
            Value or default
        """
        if isinstance(self.data, dict):
            return self.data.get(key, default)
        return default

    def set(self, key: str, value: Any) -> None:
        """Set a value in state data.

        Args:
            key: Key to set
            value: Value to set
        """
        if isinstance(self.data, dict):
            self.data[key] = value
            self.updated_at = datetime.now()

    def add_error(self, error: str, node: str | None = None) -> None:
        """Record an error.

        Args:
            error: Error message
            node: Node where error occurred
        """
        self.errors.append({
            "error": error,
            "node": node or self.current_node,
            "timestamp": datetime.now().isoformat(),
        })

    def record_node(self, node: str) -> None:
        """Record a node visit.

        Args:
            node: Node name
        """
        self.current_node = node
        self.history.append(node)
        self.updated_at = datetime.now()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "workflow_id": self.workflow_id,
            "data": self.data,
            "status": self.status.value,
            "current_node": self.current_node,
            "history": self.history,
            "errors": self.errors,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WorkflowState[dict[str, Any]]:
        """Create from dictionary."""
        return cls(
            workflow_id=data["workflow_id"],
            data=data["data"],
            status=WorkflowStatus(data["status"]),
            current_node=data.get("current_node"),
            history=data.get("history", []),
            errors=data.get("errors", []),
            metadata=data.get("metadata", {}),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
        )


@dataclass
class Checkpoint:
    """A checkpoint of workflow state."""

    checkpoint_id: str
    workflow_id: str
    state_snapshot: dict[str, Any]
    node: str
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "checkpoint_id": self.checkpoint_id,
            "workflow_id": self.workflow_id,
            "state_snapshot": self.state_snapshot,
            "node": self.node,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Checkpoint:
        """Create from dictionary."""
        return cls(
            checkpoint_id=data["checkpoint_id"],
            workflow_id=data["workflow_id"],
            state_snapshot=data["state_snapshot"],
            node=data["node"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
        )


class StateManager:
    """Manages workflow state with checkpointing and persistence."""

    def __init__(
        self,
        storage_path: str | Path | None = None,
        max_checkpoints: int = 10,
    ) -> None:
        """Initialize state manager.

        Args:
            storage_path: Path to persist state
            max_checkpoints: Maximum checkpoints to keep per workflow
        """
        self.storage_path = Path(storage_path) if storage_path else None
        self.max_checkpoints = max_checkpoints

        self._states: dict[str, WorkflowState[Any]] = {}
        self._checkpoints: dict[str, list[Checkpoint]] = {}

        if self.storage_path and self.storage_path.exists():
            self._load()

    def create_state(
        self,
        workflow_id: str,
        initial_data: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> WorkflowState[dict[str, Any]]:
        """Create a new workflow state.

        Args:
            workflow_id: Unique workflow identifier
            initial_data: Initial state data
            metadata: Workflow metadata

        Returns:
            Created WorkflowState
        """
        state: WorkflowState[dict[str, Any]] = WorkflowState(
            workflow_id=workflow_id,
            data=initial_data or {},
            metadata=metadata or {},
        )
        self._states[workflow_id] = state
        self._checkpoints[workflow_id] = []
        return state

    def get_state(self, workflow_id: str) -> WorkflowState[Any] | None:
        """Get workflow state.

        Args:
            workflow_id: Workflow identifier

        Returns:
            WorkflowState or None
        """
        return self._states.get(workflow_id)

    def update_state(
        self,
        workflow_id: str,
        updates: dict[str, Any],
        node: str | None = None,
    ) -> WorkflowState[Any] | None:
        """Update workflow state.

        Args:
            workflow_id: Workflow identifier
            updates: State updates
            node: Current node name

        Returns:
            Updated WorkflowState or None
        """
        state = self._states.get(workflow_id)
        if state is None:
            return None

        state.update(updates)
        if node:
            state.record_node(node)

        return state

    def checkpoint(
        self,
        workflow_id: str,
        checkpoint_id: str | None = None,
    ) -> Checkpoint | None:
        """Create a checkpoint of current state.

        Args:
            workflow_id: Workflow identifier
            checkpoint_id: Optional checkpoint ID

        Returns:
            Created Checkpoint or None
        """
        state = self._states.get(workflow_id)
        if state is None:
            return None

        cp_id = checkpoint_id or f"cp_{datetime.now().timestamp()}"
        checkpoint = Checkpoint(
            checkpoint_id=cp_id,
            workflow_id=workflow_id,
            state_snapshot=copy.deepcopy(state.to_dict()),
            node=state.current_node or "unknown",
        )

        if workflow_id not in self._checkpoints:
            self._checkpoints[workflow_id] = []

        self._checkpoints[workflow_id].append(checkpoint)

        # Prune old checkpoints
        if len(self._checkpoints[workflow_id]) > self.max_checkpoints:
            self._checkpoints[workflow_id] = self._checkpoints[workflow_id][
                -self.max_checkpoints:
            ]

        return checkpoint

    def restore_checkpoint(
        self,
        workflow_id: str,
        checkpoint_id: str | None = None,
    ) -> WorkflowState[Any] | None:
        """Restore state from a checkpoint.

        Args:
            workflow_id: Workflow identifier
            checkpoint_id: Checkpoint to restore (latest if None)

        Returns:
            Restored WorkflowState or None
        """
        checkpoints = self._checkpoints.get(workflow_id, [])
        if not checkpoints:
            return None

        # Find the checkpoint
        checkpoint = None
        if checkpoint_id:
            for cp in checkpoints:
                if cp.checkpoint_id == checkpoint_id:
                    checkpoint = cp
                    break
        else:
            checkpoint = checkpoints[-1]  # Latest

        if checkpoint is None:
            return None

        # Restore state
        state = WorkflowState.from_dict(checkpoint.state_snapshot)
        self._states[workflow_id] = state
        return state

    def list_checkpoints(self, workflow_id: str) -> list[Checkpoint]:
        """List checkpoints for a workflow.

        Args:
            workflow_id: Workflow identifier

        Returns:
            List of checkpoints
        """
        return self._checkpoints.get(workflow_id, [])

    def delete_workflow(self, workflow_id: str) -> bool:
        """Delete a workflow and its checkpoints.

        Args:
            workflow_id: Workflow identifier

        Returns:
            True if deleted
        """
        deleted = False
        if workflow_id in self._states:
            del self._states[workflow_id]
            deleted = True
        if workflow_id in self._checkpoints:
            del self._checkpoints[workflow_id]
            deleted = True
        return deleted

    def save(self) -> None:
        """Save all states to storage."""
        if self.storage_path is None:
            return

        self.storage_path.parent.mkdir(parents=True, exist_ok=True)

        data = {
            "states": {
                wid: state.to_dict() for wid, state in self._states.items()
            },
            "checkpoints": {
                wid: [cp.to_dict() for cp in cps]
                for wid, cps in self._checkpoints.items()
            },
        }

        with open(self.storage_path, "w") as f:
            json.dump(data, f, indent=2)

    def _load(self) -> None:
        """Load states from storage."""
        if self.storage_path is None or not self.storage_path.exists():
            return

        with open(self.storage_path) as f:
            data = json.load(f)

        self._states = {
            wid: WorkflowState.from_dict(sdata)
            for wid, sdata in data.get("states", {}).items()
        }

        self._checkpoints = {
            wid: [Checkpoint.from_dict(cpd) for cpd in cps]
            for wid, cps in data.get("checkpoints", {}).items()
        }

    def stats(self) -> dict[str, Any]:
        """Get manager statistics.

        Returns:
            Dictionary of statistics
        """
        status_counts: dict[str, int] = {}
        for state in self._states.values():
            status_counts[state.status.value] = (
                status_counts.get(state.status.value, 0) + 1
            )

        return {
            "total_workflows": len(self._states),
            "status_counts": status_counts,
            "total_checkpoints": sum(
                len(cps) for cps in self._checkpoints.values()
            ),
        }
