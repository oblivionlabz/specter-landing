"""Handoff Router for expert agent routing."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable


@dataclass
class ExpertAgent:
    """Definition of an expert agent."""

    name: str
    description: str
    capabilities: list[str]
    keywords: list[str] = field(default_factory=list)
    priority: int = 0  # Higher = more preferred
    max_concurrent: int = 1
    handler: Callable[[str, dict[str, Any]], Awaitable[dict[str, Any]]] | None = None

    def matches(self, task: str) -> float:
        """Calculate match score for a task.

        Args:
            task: Task description

        Returns:
            Match score (0-1)
        """
        task_lower = task.lower()
        score = 0.0
        matches = 0

        # Check capability matches
        for cap in self.capabilities:
            if cap.lower() in task_lower:
                score += 0.3
                matches += 1

        # Check keyword matches
        for kw in self.keywords:
            if kw.lower() in task_lower:
                score += 0.2
                matches += 1

        # Normalize by number of possible matches
        total_possible = len(self.capabilities) + len(self.keywords)
        if total_possible > 0:
            score = min(1.0, score)

        return score


@dataclass
class HandoffDecision:
    """Decision from the handoff router."""

    task: str
    selected_agent: ExpertAgent | None
    confidence: float
    reason: str
    alternatives: list[tuple[ExpertAgent, float]] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class HandoffResult:
    """Result of a handoff execution."""

    decision: HandoffDecision
    success: bool
    result: dict[str, Any] | None
    error: str | None = None
    duration_seconds: float = 0.0


class HandoffRouter:
    """Routes tasks to appropriate expert agents."""

    # Built-in expert definitions
    BUILTIN_EXPERTS: list[ExpertAgent] = [
        ExpertAgent(
            name="code_expert",
            description="Expert in code generation and modification",
            capabilities=["code", "programming", "implementation", "function", "class"],
            keywords=["write", "create", "implement", "build", "generate", "code"],
            priority=5,
        ),
        ExpertAgent(
            name="debug_expert",
            description="Expert in debugging and error resolution",
            capabilities=["debug", "error", "fix", "issue", "bug"],
            keywords=["fix", "debug", "error", "broken", "failing", "crash"],
            priority=4,
        ),
        ExpertAgent(
            name="test_expert",
            description="Expert in testing and quality assurance",
            capabilities=["test", "testing", "quality", "coverage", "assertion"],
            keywords=["test", "spec", "coverage", "assert", "mock", "pytest"],
            priority=3,
        ),
        ExpertAgent(
            name="refactor_expert",
            description="Expert in code refactoring and improvement",
            capabilities=["refactor", "improve", "optimize", "clean", "restructure"],
            keywords=["refactor", "improve", "optimize", "clean", "extract", "rename"],
            priority=3,
        ),
        ExpertAgent(
            name="docs_expert",
            description="Expert in documentation and explanation",
            capabilities=["documentation", "explain", "describe", "readme", "docstring"],
            keywords=["document", "explain", "describe", "readme", "comment", "docstring"],
            priority=2,
        ),
        ExpertAgent(
            name="security_expert",
            description="Expert in security and vulnerability analysis",
            capabilities=["security", "vulnerability", "auth", "encryption", "sanitize"],
            keywords=["security", "vulnerable", "auth", "encrypt", "safe", "sanitize"],
            priority=4,
        ),
        ExpertAgent(
            name="architecture_expert",
            description="Expert in system design and architecture",
            capabilities=["architecture", "design", "pattern", "structure", "system"],
            keywords=["architecture", "design", "pattern", "structure", "scale", "system"],
            priority=3,
        ),
    ]

    def __init__(
        self,
        confidence_threshold: float = 0.3,
        use_builtins: bool = True,
    ) -> None:
        """Initialize handoff router.

        Args:
            confidence_threshold: Minimum confidence to select an agent
            use_builtins: Include built-in expert definitions
        """
        self.confidence_threshold = confidence_threshold
        self._experts: dict[str, ExpertAgent] = {}

        if use_builtins:
            for expert in self.BUILTIN_EXPERTS:
                self._experts[expert.name] = expert

    def register_expert(self, expert: ExpertAgent) -> None:
        """Register a new expert agent.

        Args:
            expert: Expert agent definition
        """
        self._experts[expert.name] = expert

    def unregister_expert(self, name: str) -> bool:
        """Unregister an expert agent.

        Args:
            name: Expert name

        Returns:
            True if removed
        """
        if name in self._experts:
            del self._experts[name]
            return True
        return False

    def get_expert(self, name: str) -> ExpertAgent | None:
        """Get an expert by name.

        Args:
            name: Expert name

        Returns:
            ExpertAgent or None
        """
        return self._experts.get(name)

    def route(self, task: str) -> HandoffDecision:
        """Route a task to the best expert.

        Args:
            task: Task description

        Returns:
            HandoffDecision with selected agent
        """
        scored: list[tuple[ExpertAgent, float]] = []

        for expert in self._experts.values():
            score = expert.matches(task)
            if score > 0:
                # Factor in priority
                adjusted_score = score + (expert.priority * 0.05)
                scored.append((expert, min(1.0, adjusted_score)))

        # Sort by score descending
        scored.sort(key=lambda x: x[1], reverse=True)

        if not scored or scored[0][1] < self.confidence_threshold:
            return HandoffDecision(
                task=task,
                selected_agent=None,
                confidence=scored[0][1] if scored else 0.0,
                reason="No expert met confidence threshold",
                alternatives=scored[:3],
            )

        best_expert, best_score = scored[0]
        return HandoffDecision(
            task=task,
            selected_agent=best_expert,
            confidence=best_score,
            reason=f"Best match: {best_expert.name} ({best_expert.description})",
            alternatives=scored[1:4],  # Top 3 alternatives
        )

    async def execute_handoff(
        self,
        task: str,
        context: dict[str, Any] | None = None,
    ) -> HandoffResult:
        """Route and execute a task.

        Args:
            task: Task description
            context: Additional context for execution

        Returns:
            HandoffResult
        """
        start_time = datetime.now()
        decision = self.route(task)

        if decision.selected_agent is None:
            return HandoffResult(
                decision=decision,
                success=False,
                result=None,
                error="No suitable expert found",
                duration_seconds=(datetime.now() - start_time).total_seconds(),
            )

        agent = decision.selected_agent
        if agent.handler is None:
            return HandoffResult(
                decision=decision,
                success=False,
                result=None,
                error=f"Expert {agent.name} has no handler",
                duration_seconds=(datetime.now() - start_time).total_seconds(),
            )

        try:
            result = await agent.handler(task, context or {})
            return HandoffResult(
                decision=decision,
                success=True,
                result=result,
                duration_seconds=(datetime.now() - start_time).total_seconds(),
            )
        except Exception as e:
            return HandoffResult(
                decision=decision,
                success=False,
                result=None,
                error=str(e),
                duration_seconds=(datetime.now() - start_time).total_seconds(),
            )

    def route_multi(
        self,
        task: str,
        max_experts: int = 3,
    ) -> list[HandoffDecision]:
        """Route a task to multiple experts (for parallel processing).

        Args:
            task: Task description
            max_experts: Maximum experts to select

        Returns:
            List of HandoffDecisions
        """
        scored: list[tuple[ExpertAgent, float]] = []

        for expert in self._experts.values():
            score = expert.matches(task)
            if score >= self.confidence_threshold:
                adjusted_score = score + (expert.priority * 0.05)
                scored.append((expert, min(1.0, adjusted_score)))

        scored.sort(key=lambda x: x[1], reverse=True)
        selected = scored[:max_experts]

        return [
            HandoffDecision(
                task=task,
                selected_agent=expert,
                confidence=score,
                reason=f"Selected for multi-expert: {expert.name}",
            )
            for expert, score in selected
        ]

    def list_experts(self) -> list[ExpertAgent]:
        """List all registered experts.

        Returns:
            List of expert agents
        """
        return list(self._experts.values())

    def analyze_task(self, task: str) -> dict[str, Any]:
        """Analyze a task without routing.

        Args:
            task: Task description

        Returns:
            Analysis dictionary
        """
        task_lower = task.lower()

        # Detect task type
        task_types: dict[str, list[str]] = {
            "creation": ["create", "build", "implement", "add", "new", "write"],
            "modification": ["update", "change", "modify", "edit", "refactor"],
            "debugging": ["fix", "debug", "solve", "resolve", "error"],
            "analysis": ["analyze", "explain", "describe", "understand", "review"],
            "testing": ["test", "verify", "validate", "check", "assert"],
        }

        detected_types: list[str] = []
        for task_type, keywords in task_types.items():
            if any(kw in task_lower for kw in keywords):
                detected_types.append(task_type)

        # Calculate expert scores
        expert_scores = {
            expert.name: expert.matches(task)
            for expert in self._experts.values()
        }

        return {
            "task": task,
            "detected_types": detected_types,
            "expert_scores": expert_scores,
            "recommended_expert": max(expert_scores, key=expert_scores.get)
            if expert_scores else None,
            "complexity_estimate": self._estimate_complexity(task),
        }

    def _estimate_complexity(self, task: str) -> str:
        """Estimate task complexity.

        Args:
            task: Task description

        Returns:
            Complexity level
        """
        task_lower = task.lower()

        # High complexity indicators
        high_indicators = [
            "architecture", "system", "design", "multi", "complex",
            "integration", "security", "performance", "scale",
        ]
        high_count = sum(1 for ind in high_indicators if ind in task_lower)

        # Low complexity indicators
        low_indicators = [
            "simple", "basic", "small", "quick", "minor",
            "typo", "rename", "comment",
        ]
        low_count = sum(1 for ind in low_indicators if ind in task_lower)

        if high_count >= 2 or len(task) > 500:
            return "high"
        elif low_count >= 2 or len(task) < 50:
            return "low"
        return "medium"

    def stats(self) -> dict[str, Any]:
        """Get router statistics.

        Returns:
            Statistics dictionary
        """
        capabilities_count: dict[str, int] = {}
        for expert in self._experts.values():
            for cap in expert.capabilities:
                capabilities_count[cap] = capabilities_count.get(cap, 0) + 1

        return {
            "total_experts": len(self._experts),
            "expert_names": list(self._experts.keys()),
            "capabilities_coverage": capabilities_count,
            "confidence_threshold": self.confidence_threshold,
        }
