"""LangGraph-style Workflow Graph for multi-agent orchestration."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Generic, TypeVar

from sovereign.orchestration.state import StateManager, WorkflowState, WorkflowStatus

T = TypeVar("T", bound=dict[str, Any])

# Type aliases for node and edge functions
NodeFunc = Callable[[WorkflowState[T]], Awaitable[dict[str, Any]]]
ConditionFunc = Callable[[WorkflowState[T]], str]


@dataclass
class Node(Generic[T]):
    """A node in the workflow graph."""

    name: str
    func: NodeFunc[T]
    description: str = ""
    retry_count: int = 0
    timeout: float | None = None

    async def execute(self, state: WorkflowState[T]) -> dict[str, Any]:
        """Execute the node function.

        Args:
            state: Current workflow state

        Returns:
            State updates from node execution
        """
        if self.timeout:
            return await asyncio.wait_for(
                self.func(state),
                timeout=self.timeout,
            )
        return await self.func(state)


@dataclass
class Edge:
    """A simple edge between nodes."""

    source: str
    target: str


@dataclass
class ConditionalEdge:
    """A conditional edge that routes based on state."""

    source: str
    condition: ConditionFunc[Any]
    mapping: dict[str, str]  # condition_result -> target_node
    default: str | None = None


@dataclass
class ExecutionResult:
    """Result of workflow execution."""

    workflow_id: str
    status: WorkflowStatus
    final_state: dict[str, Any]
    nodes_executed: list[str]
    duration_seconds: float
    errors: list[dict[str, Any]]


class WorkflowGraph(Generic[T]):
    """LangGraph-style directed workflow graph.

    Supports:
    - Sequential execution
    - Conditional branching
    - Cycles (for iterative workflows)
    - State checkpointing
    """

    END = "__end__"
    START = "__start__"

    def __init__(
        self,
        name: str = "workflow",
        state_manager: StateManager | None = None,
    ) -> None:
        """Initialize workflow graph.

        Args:
            name: Workflow name
            state_manager: Optional state manager for persistence
        """
        self.name = name
        self.state_manager = state_manager or StateManager()

        self._nodes: dict[str, Node[T]] = {}
        self._edges: dict[str, list[Edge | ConditionalEdge]] = {}
        self._entry_point: str | None = None

    def add_node(
        self,
        name: str,
        func: NodeFunc[T],
        description: str = "",
        retry_count: int = 0,
        timeout: float | None = None,
    ) -> WorkflowGraph[T]:
        """Add a node to the graph.

        Args:
            name: Node name
            func: Async function that takes state and returns updates
            description: Node description
            retry_count: Number of retries on failure
            timeout: Execution timeout in seconds

        Returns:
            Self for chaining
        """
        self._nodes[name] = Node(
            name=name,
            func=func,
            description=description,
            retry_count=retry_count,
            timeout=timeout,
        )
        return self

    def add_edge(self, source: str, target: str) -> WorkflowGraph[T]:
        """Add a simple edge between nodes.

        Args:
            source: Source node name
            target: Target node name

        Returns:
            Self for chaining
        """
        if source not in self._edges:
            self._edges[source] = []
        self._edges[source].append(Edge(source=source, target=target))
        return self

    def add_conditional_edges(
        self,
        source: str,
        condition: ConditionFunc[T],
        mapping: dict[str, str],
        default: str | None = None,
    ) -> WorkflowGraph[T]:
        """Add conditional edges from a node.

        Args:
            source: Source node name
            condition: Function that returns routing key
            mapping: Mapping from routing key to target node
            default: Default target if key not in mapping

        Returns:
            Self for chaining
        """
        if source not in self._edges:
            self._edges[source] = []
        self._edges[source].append(
            ConditionalEdge(
                source=source,
                condition=condition,
                mapping=mapping,
                default=default,
            )
        )
        return self

    def set_entry_point(self, node: str) -> WorkflowGraph[T]:
        """Set the entry point node.

        Args:
            node: Entry point node name

        Returns:
            Self for chaining
        """
        self._entry_point = node
        return self

    def set_finish_point(self, node: str) -> WorkflowGraph[T]:
        """Set a node as a finish point.

        Args:
            node: Node that leads to END

        Returns:
            Self for chaining
        """
        return self.add_edge(node, self.END)

    def _get_next_node(
        self,
        current: str,
        state: WorkflowState[T],
    ) -> str | None:
        """Determine next node based on edges.

        Args:
            current: Current node name
            state: Current state

        Returns:
            Next node name or None
        """
        edges = self._edges.get(current, [])
        if not edges:
            return None

        for edge in edges:
            if isinstance(edge, Edge):
                return edge.target
            elif isinstance(edge, ConditionalEdge):
                result = edge.condition(state)
                target = edge.mapping.get(result, edge.default)
                if target:
                    return target

        return None

    async def _execute_node(
        self,
        node: Node[T],
        state: WorkflowState[T],
    ) -> dict[str, Any]:
        """Execute a node with retry logic.

        Args:
            node: Node to execute
            state: Current state

        Returns:
            State updates
        """
        last_error: Exception | None = None

        for attempt in range(node.retry_count + 1):
            try:
                return await node.execute(state)
            except TimeoutError as e:
                last_error = e
                if attempt < node.retry_count:
                    await asyncio.sleep(0.5 * (attempt + 1))  # Backoff
            except Exception as e:
                last_error = e
                if attempt < node.retry_count:
                    await asyncio.sleep(0.5 * (attempt + 1))

        # All retries failed
        raise last_error or RuntimeError(f"Node {node.name} failed")

    async def run(
        self,
        initial_state: dict[str, Any],
        workflow_id: str | None = None,
        checkpoint_interval: int = 5,
    ) -> ExecutionResult:
        """Execute the workflow.

        Args:
            initial_state: Initial state data
            workflow_id: Optional workflow ID
            checkpoint_interval: Checkpoint every N nodes

        Returns:
            ExecutionResult with final state
        """
        if self._entry_point is None:
            raise ValueError("No entry point set for workflow")

        # Create workflow state
        wf_id = workflow_id or f"{self.name}_{datetime.now().timestamp()}"
        state = self.state_manager.create_state(
            workflow_id=wf_id,
            initial_data=initial_state,
            metadata={"graph_name": self.name},
        )
        state.status = WorkflowStatus.RUNNING

        start_time = datetime.now()
        current_node = self._entry_point
        nodes_executed: list[str] = []
        node_count = 0

        try:
            while current_node and current_node != self.END:
                # Check if node exists
                if current_node not in self._nodes:
                    raise ValueError(f"Unknown node: {current_node}")

                node = self._nodes[current_node]
                state.record_node(current_node)
                nodes_executed.append(current_node)

                # Execute node
                try:
                    updates = await self._execute_node(node, state)
                    state.update(updates)
                except Exception as e:
                    state.add_error(str(e), current_node)
                    raise

                node_count += 1

                # Checkpoint periodically
                if checkpoint_interval > 0 and node_count % checkpoint_interval == 0:
                    self.state_manager.checkpoint(wf_id)

                # Get next node
                current_node = self._get_next_node(current_node, state)

            state.status = WorkflowStatus.COMPLETED

        except Exception as e:
            state.status = WorkflowStatus.FAILED
            state.add_error(str(e))

        finally:
            # Final checkpoint
            self.state_manager.checkpoint(wf_id)
            self.state_manager.save()

        duration = (datetime.now() - start_time).total_seconds()

        return ExecutionResult(
            workflow_id=wf_id,
            status=state.status,
            final_state=state.data if isinstance(state.data, dict) else {},
            nodes_executed=nodes_executed,
            duration_seconds=duration,
            errors=state.errors,
        )

    async def resume(
        self,
        workflow_id: str,
        checkpoint_id: str | None = None,
    ) -> ExecutionResult:
        """Resume a workflow from a checkpoint.

        Args:
            workflow_id: Workflow to resume
            checkpoint_id: Specific checkpoint (latest if None)

        Returns:
            ExecutionResult
        """
        state = self.state_manager.restore_checkpoint(workflow_id, checkpoint_id)
        if state is None:
            raise ValueError(f"Cannot restore workflow {workflow_id}")

        # Resume from last node's next
        if state.current_node:
            next_node = self._get_next_node(state.current_node, state)
        else:
            next_node = self._entry_point

        if next_node is None or next_node == self.END:
            return ExecutionResult(
                workflow_id=workflow_id,
                status=WorkflowStatus.COMPLETED,
                final_state=state.data if isinstance(state.data, dict) else {},
                nodes_executed=state.history,
                duration_seconds=0,
                errors=state.errors,
            )

        # Continue execution
        start_time = datetime.now()
        state.status = WorkflowStatus.RUNNING
        current_node = next_node

        try:
            while current_node and current_node != self.END:
                if current_node not in self._nodes:
                    raise ValueError(f"Unknown node: {current_node}")

                node = self._nodes[current_node]
                state.record_node(current_node)

                try:
                    updates = await self._execute_node(node, state)
                    state.update(updates)
                except Exception as e:
                    state.add_error(str(e), current_node)
                    raise

                current_node = self._get_next_node(current_node, state)

            state.status = WorkflowStatus.COMPLETED

        except Exception as e:
            state.status = WorkflowStatus.FAILED
            state.add_error(str(e))

        finally:
            self.state_manager.checkpoint(workflow_id)
            self.state_manager.save()

        duration = (datetime.now() - start_time).total_seconds()

        return ExecutionResult(
            workflow_id=workflow_id,
            status=state.status,
            final_state=state.data if isinstance(state.data, dict) else {},
            nodes_executed=state.history,
            duration_seconds=duration,
            errors=state.errors,
        )

    def visualize(self) -> str:
        """Generate a simple text visualization of the graph.

        Returns:
            Text representation
        """
        lines = [f"Workflow: {self.name}", "=" * 40]

        # Entry point
        if self._entry_point:
            lines.append(f"Entry: {self._entry_point}")
        lines.append("")

        # Nodes
        lines.append("Nodes:")
        for name, node in self._nodes.items():
            desc = f" - {node.description}" if node.description else ""
            lines.append(f"  [{name}]{desc}")
        lines.append("")

        # Edges
        lines.append("Edges:")
        for source, edges in self._edges.items():
            for edge in edges:
                if isinstance(edge, Edge):
                    lines.append(f"  {source} -> {edge.target}")
                elif isinstance(edge, ConditionalEdge):
                    targets = ", ".join(
                        f"{k}:{v}" for k, v in edge.mapping.items()
                    )
                    lines.append(f"  {source} -?-> [{targets}]")

        return "\n".join(lines)
