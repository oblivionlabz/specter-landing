"""Parallel Task Execution with fan-out/fan-in patterns."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Any, Generic, TypeVar

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

T = TypeVar("T")
R = TypeVar("R")


class TaskStatus(Enum):
    """Status of a parallel task."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


@dataclass
class TaskResult(Generic[R]):
    """Result of a parallel task."""

    task_id: str
    status: TaskStatus
    result: R | None = None
    error: str | None = None
    duration_seconds: float = 0.0
    started_at: datetime | None = None
    completed_at: datetime | None = None


@dataclass
class ParallelTask(Generic[T, R]):
    """A task for parallel execution."""

    task_id: str
    func: Callable[[T], Awaitable[R]]
    input_data: T
    timeout: float | None = None
    retry_count: int = 0


class ParallelExecutor:
    """Executes multiple tasks in parallel with concurrency control."""

    def __init__(
        self,
        max_concurrent: int = 10,
        default_timeout: float | None = 30.0,
    ) -> None:
        """Initialize parallel executor.

        Args:
            max_concurrent: Maximum concurrent tasks
            default_timeout: Default timeout per task in seconds
        """
        self.max_concurrent = max_concurrent
        self.default_timeout = default_timeout
        self._semaphore = asyncio.Semaphore(max_concurrent)

    async def _execute_task(
        self,
        task: ParallelTask[T, R],
    ) -> TaskResult[R]:
        """Execute a single task with retry logic.

        Args:
            task: Task to execute

        Returns:
            TaskResult
        """
        started_at = datetime.now()
        timeout = task.timeout or self.default_timeout
        last_error: str | None = None

        async with self._semaphore:
            for attempt in range(task.retry_count + 1):
                try:
                    if timeout:
                        result = await asyncio.wait_for(
                            task.func(task.input_data),
                            timeout=timeout,
                        )
                    else:
                        result = await task.func(task.input_data)

                    completed_at = datetime.now()
                    return TaskResult(
                        task_id=task.task_id,
                        status=TaskStatus.COMPLETED,
                        result=result,
                        duration_seconds=(completed_at - started_at).total_seconds(),
                        started_at=started_at,
                        completed_at=completed_at,
                    )

                except TimeoutError:
                    last_error = f"Task timed out after {timeout}s"
                    if attempt < task.retry_count:
                        await asyncio.sleep(0.5 * (attempt + 1))

                except asyncio.CancelledError:
                    return TaskResult(
                        task_id=task.task_id,
                        status=TaskStatus.CANCELLED,
                        error="Task was cancelled",
                        duration_seconds=(datetime.now() - started_at).total_seconds(),
                        started_at=started_at,
                        completed_at=datetime.now(),
                    )

                except Exception as e:
                    last_error = str(e)
                    if attempt < task.retry_count:
                        await asyncio.sleep(0.5 * (attempt + 1))

        # All retries exhausted
        completed_at = datetime.now()
        status = TaskStatus.TIMEOUT if "timed out" in (last_error or "") else TaskStatus.FAILED
        return TaskResult(
            task_id=task.task_id,
            status=status,
            error=last_error,
            duration_seconds=(completed_at - started_at).total_seconds(),
            started_at=started_at,
            completed_at=completed_at,
        )

    async def execute_all(
        self,
        tasks: list[ParallelTask[Any, Any]],
        fail_fast: bool = False,
    ) -> list[TaskResult[Any]]:
        """Execute all tasks in parallel.

        Args:
            tasks: List of tasks to execute
            fail_fast: Stop all tasks on first failure

        Returns:
            List of TaskResults in same order as input
        """
        if not tasks:
            return []

        if fail_fast:
            return await self._execute_fail_fast(tasks)

        # Execute all tasks, collecting results
        coroutines = [self._execute_task(task) for task in tasks]
        results = await asyncio.gather(*coroutines, return_exceptions=False)
        return list(results)

    async def _execute_fail_fast(
        self,
        tasks: list[ParallelTask[Any, Any]],
    ) -> list[TaskResult[Any]]:
        """Execute tasks, cancelling remaining on first failure.

        Args:
            tasks: Tasks to execute

        Returns:
            List of TaskResults
        """
        results: dict[str, TaskResult[Any]] = {}
        pending: set[asyncio.Task[TaskResult[Any]]] = set()

        for task in tasks:
            async_task = asyncio.create_task(
                self._execute_task(task),
                name=task.task_id,
            )
            pending.add(async_task)

        first_failure: TaskResult[Any] | None = None

        while pending:
            done, pending = await asyncio.wait(
                pending,
                return_when=asyncio.FIRST_COMPLETED,
            )

            for completed_task in done:
                result = completed_task.result()
                results[result.task_id] = result

                if result.status == TaskStatus.FAILED and first_failure is None:
                    first_failure = result
                    # Cancel remaining tasks
                    for p in pending:
                        p.cancel()

        # Return in original order
        return [
            results.get(
                task.task_id,
                TaskResult(
                    task_id=task.task_id,
                    status=TaskStatus.CANCELLED,
                    error="Cancelled due to fail-fast",
                ),
            )
            for task in tasks
        ]

    async def map(
        self,
        func: Callable[[T], Awaitable[R]],
        items: list[T],
        timeout: float | None = None,
    ) -> list[TaskResult[R]]:
        """Map a function over items in parallel.

        Args:
            func: Async function to apply
            items: Items to process
            timeout: Timeout per item

        Returns:
            List of TaskResults
        """
        tasks = [
            ParallelTask(
                task_id=f"map_{i}",
                func=func,
                input_data=item,
                timeout=timeout or self.default_timeout,
            )
            for i, item in enumerate(items)
        ]
        return await self.execute_all(tasks)


@dataclass
class FanOutFanIn(Generic[T, R]):
    """Fan-out/fan-in pattern for splitting and aggregating work."""

    name: str
    split_func: Callable[[T], list[Any]]
    process_func: Callable[[Any], Awaitable[Any]]
    aggregate_func: Callable[[list[Any]], R]
    max_concurrent: int = 10
    timeout_per_item: float | None = 30.0

    async def execute(self, input_data: T) -> R:
        """Execute the fan-out/fan-in pattern.

        Args:
            input_data: Input data to split

        Returns:
            Aggregated result
        """
        # Fan-out: split input
        items = self.split_func(input_data)

        # Process in parallel
        executor = ParallelExecutor(
            max_concurrent=self.max_concurrent,
            default_timeout=self.timeout_per_item,
        )

        results = await executor.map(self.process_func, items)

        # Collect successful results
        processed = [
            r.result for r in results
            if r.status == TaskStatus.COMPLETED and r.result is not None
        ]

        # Fan-in: aggregate
        return self.aggregate_func(processed)


class TaskGroup:
    """Group of related tasks that can be managed together."""

    def __init__(self, name: str, max_concurrent: int = 5) -> None:
        """Initialize task group.

        Args:
            name: Group name
            max_concurrent: Max concurrent tasks
        """
        self.name = name
        self.max_concurrent = max_concurrent
        self._tasks: list[ParallelTask[Any, Any]] = []
        self._results: list[TaskResult[Any]] = []
        self._executor = ParallelExecutor(max_concurrent=max_concurrent)

    def add(
        self,
        task_id: str,
        func: Callable[[Any], Awaitable[Any]],
        input_data: Any,
        timeout: float | None = None,
        retry_count: int = 0,
    ) -> TaskGroup:
        """Add a task to the group.

        Args:
            task_id: Unique task identifier
            func: Async function
            input_data: Input for function
            timeout: Task timeout
            retry_count: Retry attempts

        Returns:
            Self for chaining
        """
        self._tasks.append(
            ParallelTask(
                task_id=task_id,
                func=func,
                input_data=input_data,
                timeout=timeout,
                retry_count=retry_count,
            )
        )
        return self

    async def run(self, fail_fast: bool = False) -> list[TaskResult[Any]]:
        """Run all tasks in the group.

        Args:
            fail_fast: Stop on first failure

        Returns:
            List of TaskResults
        """
        self._results = await self._executor.execute_all(
            self._tasks,
            fail_fast=fail_fast,
        )
        return self._results

    @property
    def results(self) -> list[TaskResult[Any]]:
        """Get results from last run."""
        return self._results

    @property
    def success_count(self) -> int:
        """Count of successful tasks."""
        return sum(1 for r in self._results if r.status == TaskStatus.COMPLETED)

    @property
    def failure_count(self) -> int:
        """Count of failed tasks."""
        return sum(1 for r in self._results if r.status == TaskStatus.FAILED)

    def get_result(self, task_id: str) -> TaskResult[Any] | None:
        """Get result for a specific task.

        Args:
            task_id: Task identifier

        Returns:
            TaskResult or None
        """
        for result in self._results:
            if result.task_id == task_id:
                return result
        return None

    def stats(self) -> dict[str, Any]:
        """Get group statistics.

        Returns:
            Statistics dictionary
        """
        status_counts: dict[str, int] = {}
        total_duration = 0.0

        for result in self._results:
            status_counts[result.status.value] = (
                status_counts.get(result.status.value, 0) + 1
            )
            total_duration += result.duration_seconds

        return {
            "name": self.name,
            "total_tasks": len(self._tasks),
            "status_counts": status_counts,
            "total_duration_seconds": total_duration,
            "average_duration_seconds": (
                total_duration / len(self._results) if self._results else 0
            ),
        }
