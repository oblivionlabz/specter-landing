"""SOVEREIGN Configuration management."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field


class InferenceConfig(BaseModel):
    """LocalAI inference configuration."""

    engine: str = "localai"
    base_url: str = "http://localhost:8080"
    timeout: int = 120
    models: dict[str, str] = Field(
        default_factory=lambda: {
            "fast": "qwen2.5-coder-7b",
            "large": "deepseek-coder-33b",
        }
    )
    default_model: str = "fast"
    max_tokens: int = 4096
    temperature: float = 0.7
    top_p: float = 0.95
    stream: bool = True


class MemoryConfig(BaseModel):
    """Memory system configuration."""

    knowledge_graph_path: str = "./data/knowledge.db"
    vector_store_url: str = "http://localhost:9090"
    vector_collection: str = "sovereign_memories"


class AutonomyConfig(BaseModel):
    """Autonomy system configuration."""

    max_iterations: int = 50
    max_no_change: int = 5
    max_same_error: int = 3
    quality_gates_enabled: bool = True


class VoiceConfig(BaseModel):
    """Voice interface configuration."""

    enabled: bool = False
    wake_word: str = "hey sovereign"
    stt_model: str = "base.en"
    tts_voice: str = "en-US-GuyNeural"


class Config(BaseModel):
    """Main SOVEREIGN configuration."""

    version: str = "1.0.0"
    name: str = "SOVEREIGN"
    data_dir: Path = Path("./data")
    log_level: str = "INFO"

    inference: InferenceConfig = Field(default_factory=InferenceConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    autonomy: AutonomyConfig = Field(default_factory=AutonomyConfig)
    voice: VoiceConfig = Field(default_factory=VoiceConfig)

    @classmethod
    def load(cls, path: str | Path) -> Config:
        """Load configuration from YAML file."""
        path = Path(path)
        if not path.exists():
            # Return default config if file doesn't exist
            return cls()

        with open(path) as f:
            data = yaml.safe_load(f)

        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Config:
        """Create config from dictionary."""
        # Map YAML structure to pydantic models
        inference_data = data.get("inference", {})
        memory_data = data.get("memory", {})
        autonomy_data = data.get("autonomy", {})
        voice_data = data.get("voice", {})

        return cls(
            version=data.get("version", "1.0.0"),
            name=data.get("name", "SOVEREIGN"),
            data_dir=Path(data.get("core", {}).get("data_dir", "./data")),
            log_level=data.get("core", {}).get("log_level", "INFO"),
            inference=InferenceConfig(
                engine=inference_data.get("engine", "localai"),
                base_url=inference_data.get("base_url", "http://localhost:8080"),
                timeout=inference_data.get("timeout", 120),
                models=inference_data.get(
                    "models",
                    {"fast": "qwen2.5-coder-7b", "large": "deepseek-coder-33b"},
                ),
                default_model=inference_data.get("default_model", "fast"),
                max_tokens=inference_data.get("max_tokens", 4096),
                temperature=inference_data.get("temperature", 0.7),
                stream=inference_data.get("stream", True),
            ),
            memory=MemoryConfig(
                knowledge_graph_path=memory_data.get(
                    "knowledge_graph", {}
                ).get("path", "./data/knowledge.db"),
                vector_store_url=memory_data.get(
                    "vector_store", {}
                ).get("url", "http://localhost:9090"),
            ),
            autonomy=AutonomyConfig(
                max_iterations=autonomy_data.get(
                    "ralph_loop", {}
                ).get("max_iterations", 50),
                quality_gates_enabled=autonomy_data.get(
                    "quality_gates", {}
                ).get("enabled", True),
            ),
            voice=VoiceConfig(
                enabled=voice_data.get("enabled", False),
                wake_word=voice_data.get("wake_word", {}).get("phrase", "hey sovereign"),
            ),
        )

    def save(self, path: str | Path) -> None:
        """Save configuration to YAML file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        # Use dict() for pydantic v1/v2 compatibility
        def to_dict(model: BaseModel) -> dict[str, Any]:
            return model.model_dump() if hasattr(model, "model_dump") else model.dict()

        data = {
            "version": self.version,
            "name": self.name,
            "core": {
                "data_dir": str(self.data_dir),
                "log_level": self.log_level,
            },
            "inference": to_dict(self.inference),
            "memory": to_dict(self.memory),
            "autonomy": to_dict(self.autonomy),
            "voice": to_dict(self.voice),
        }

        with open(path, "w") as f:
            yaml.safe_dump(data, f, default_flow_style=False)
