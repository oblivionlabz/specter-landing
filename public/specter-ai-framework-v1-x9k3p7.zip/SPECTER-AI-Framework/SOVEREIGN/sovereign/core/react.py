"""ReAct (Reasoning + Acting) Loop for SOVEREIGN.

This module implements the core reasoning loop that enables SOVEREIGN to:
1. Think about user requests
2. Choose and execute tools
3. Observe results
4. Iterate until task completion
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sovereign.core.engine import LocalAIEngine
    from sovereign.tools.registry import ToolRegistry


class ReActState(Enum):
    """State of the ReAct loop."""

    THINKING = "thinking"
    ACTING = "acting"
    OBSERVING = "observing"
    COMPLETE = "complete"
    ERROR = "error"


@dataclass
class ReActStep:
    """A single step in the ReAct loop."""

    thought: str
    action: str | None = None
    action_input: dict[str, Any] = field(default_factory=dict)
    observation: str | None = None
    is_final: bool = False


@dataclass
class ReActResult:
    """Result of a ReAct loop execution."""

    success: bool
    answer: str
    steps: list[ReActStep] = field(default_factory=list)
    error: str | None = None
    total_tokens: int = 0


# System prompt that instructs the LLM to use ReAct format
REACT_SYSTEM_PROMPT = """You are SOVEREIGN, an intelligent AI assistant with access to tools.

You MUST respond in the following format for EVERY response:

THOUGHT: [Your reasoning about what to do next]
ACTION: [tool_name]
ACTION_INPUT: {{"param1": "value1", "param2": "value2"}}

OR if you have the final answer:

THOUGHT: [Your reasoning]
FINAL_ANSWER: [Your complete answer to the user]

Available tools:
{tools}

Rules:
1. ALWAYS start with THOUGHT
2. Use tools when you need to read files, write code, run commands, etc.
3. After each tool use, you will receive an OBSERVATION with the result
4. Keep reasoning until you can provide FINAL_ANSWER
5. Be concise but complete in your answers
6. If a tool fails, try a different approach
"""

# Regex patterns for parsing LLM output
THOUGHT_PATTERN = re.compile(r"THOUGHT:\s*(.+?)(?=ACTION:|FINAL_ANSWER:|$)", re.DOTALL)
ACTION_PATTERN = re.compile(r"ACTION:\s*(\w+)")
ACTION_INPUT_PATTERN = re.compile(r"ACTION_INPUT:\s*(\{.+?\})", re.DOTALL)
FINAL_ANSWER_PATTERN = re.compile(r"FINAL_ANSWER:\s*(.+?)$", re.DOTALL)


class ReActLoop:
    """ReAct loop implementation for tool-augmented reasoning."""

    def __init__(
        self,
        engine: LocalAIEngine,
        registry: ToolRegistry,
        max_iterations: int = 10,
        verbose: bool = True,
    ) -> None:
        """Initialize the ReAct loop.

        Args:
            engine: LocalAI inference engine
            registry: Tool registry for executing tools
            max_iterations: Maximum reasoning iterations
            verbose: Whether to print intermediate steps
        """
        self.engine = engine
        self.registry = registry
        self.max_iterations = max_iterations
        self.verbose = verbose

    def _format_tools(self) -> str:
        """Format available tools for the system prompt."""
        tools = self.registry.get_all()
        if not tools:
            return "No tools available."

        lines = []
        for name, tool in tools.items():
            desc = tool.description
            params = tool.parameters
            # Format parameters as simple list
            param_list = []
            if "properties" in params:
                for pname, pinfo in params["properties"].items():
                    ptype = pinfo.get("type", "any")
                    pdesc = pinfo.get("description", "")
                    param_list.append(f"    - {pname} ({ptype}): {pdesc}")

            param_str = "\n".join(param_list) if param_list else "    (no parameters)"
            lines.append(f"- {name}: {desc}\n  Parameters:\n{param_str}")

        return "\n\n".join(lines)

    def _parse_response(self, response: str) -> ReActStep:
        """Parse LLM response into a ReAct step.

        Args:
            response: Raw LLM response text

        Returns:
            Parsed ReActStep
        """
        step = ReActStep(thought="")

        # Extract thought
        thought_match = THOUGHT_PATTERN.search(response)
        if thought_match:
            step.thought = thought_match.group(1).strip()

        # Check for final answer
        final_match = FINAL_ANSWER_PATTERN.search(response)
        if final_match:
            step.is_final = True
            step.observation = final_match.group(1).strip()
            return step

        # Extract action
        action_match = ACTION_PATTERN.search(response)
        if action_match:
            step.action = action_match.group(1).strip()

        # Extract action input
        input_match = ACTION_INPUT_PATTERN.search(response)
        if input_match:
            try:
                step.action_input = json.loads(input_match.group(1))
            except json.JSONDecodeError:
                step.action_input = {}

        return step

    async def _execute_tool(self, action: str, action_input: dict[str, Any]) -> str:
        """Execute a tool and return the observation.

        Args:
            action: Tool name
            action_input: Tool parameters

        Returns:
            Observation string (tool output or error)
        """
        # Validate tool exists
        available_tools = self.registry.list_tools()
        if action not in available_tools:
            return f"Error: Unknown tool '{action}'. Available tools: {', '.join(available_tools)}"

        # Validate action_input is a dict
        if not isinstance(action_input, dict):
            return f"Error: ACTION_INPUT must be a JSON object, got {type(action_input).__name__}"

        try:
            result = await self.registry.execute(action, **action_input)
        except TypeError as e:
            # Missing or invalid parameters
            return f"Error: Invalid parameters for tool '{action}': {e}"
        except Exception as e:
            # Unexpected error during execution
            return f"Error: Tool '{action}' failed unexpectedly: {e}"

        if result.success:
            output = result.output
            if isinstance(output, (dict, list)):
                return json.dumps(output, indent=2)
            return str(output)
        else:
            error = result.error
            if error:
                # Provide actionable error message
                error_msg = f"Error: {error.message}"
                if error.code:
                    error_msg += f" (code: {error.code.value})"
                # Add hints for common errors
                if "not found" in error.message.lower():
                    error_msg += "\nHint: Check the file path or search pattern."
                elif "permission" in error.message.lower():
                    error_msg += "\nHint: This path may be restricted for security."
                elif "empty" in error.message.lower():
                    error_msg += "\nHint: Ensure you provide valid, non-empty values."
                return error_msg
            return "Error: Tool execution failed with unknown error"

    def _build_prompt(
        self,
        user_input: str,
        steps: list[ReActStep],
    ) -> str:
        """Build the prompt with conversation history.

        Args:
            user_input: Original user request
            steps: Previous ReAct steps

        Returns:
            Full prompt for the LLM
        """
        parts = [f"User request: {user_input}\n"]

        for i, step in enumerate(steps):
            parts.append(f"--- Step {i + 1} ---")
            parts.append(f"THOUGHT: {step.thought}")

            if step.action:
                parts.append(f"ACTION: {step.action}")
                parts.append(f"ACTION_INPUT: {json.dumps(step.action_input)}")

            if step.observation and not step.is_final:
                parts.append(f"OBSERVATION: {step.observation}")

        parts.append("\n--- Continue from here ---")
        return "\n".join(parts)

    async def run(self, user_input: str) -> ReActResult:
        """Run the ReAct loop on user input.

        Args:
            user_input: The user's request

        Returns:
            ReActResult with answer and step history
        """
        steps: list[ReActStep] = []
        system_prompt = REACT_SYSTEM_PROMPT.format(tools=self._format_tools())

        for iteration in range(self.max_iterations):
            # Build prompt with history
            prompt = self._build_prompt(user_input, steps)

            # Get LLM response
            try:
                response = await self.engine.generate(
                    prompt=prompt,
                    system=system_prompt,
                )
            except Exception as e:
                return ReActResult(
                    success=False,
                    answer="",
                    steps=steps,
                    error=f"LLM error: {e}",
                )

            # Parse response
            step = self._parse_response(response)
            steps.append(step)

            if self.verbose:
                print(f"\n[Iteration {iteration + 1}]")
                print(f"Thought: {step.thought}")

            # Check for final answer
            if step.is_final:
                return ReActResult(
                    success=True,
                    answer=step.observation or step.thought,
                    steps=steps,
                )

            # Execute tool if action specified
            if step.action:
                if self.verbose:
                    print(f"Action: {step.action}")
                    print(f"Input: {step.action_input}")

                observation = await self._execute_tool(step.action, step.action_input)
                step.observation = observation

                if self.verbose:
                    # Truncate long observations
                    display_obs = observation[:500] + "..." if len(observation) > 500 else observation
                    print(f"Observation: {display_obs}")
            else:
                # No action and no final answer - something went wrong
                step.observation = "Error: No action specified. Please provide an ACTION or FINAL_ANSWER."

        # Max iterations reached
        return ReActResult(
            success=False,
            answer="Maximum iterations reached without completing the task.",
            steps=steps,
            error="max_iterations_exceeded",
        )


async def test_react() -> None:
    """Test the ReAct loop."""
    from sovereign.config import Config
    from sovereign.core.engine import LocalAIEngine
    from sovereign.tools.registry import create_default_registry

    config = Config.load()
    engine = LocalAIEngine(config.inference)
    registry = create_default_registry()

    react = ReActLoop(engine, registry, verbose=True)

    print("Testing ReAct loop...")
    print("=" * 50)

    result = await react.run("List all Python files in the current directory")

    print("\n" + "=" * 50)
    print(f"Success: {result.success}")
    print(f"Answer: {result.answer}")
    print(f"Steps: {len(result.steps)}")

    await engine.close()


if __name__ == "__main__":
    import asyncio

    asyncio.run(test_react())
