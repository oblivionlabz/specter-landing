"""Smart Economic Router with quality prediction and tier skipping."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sovereign.config import SovereignConfig


class ModelTier(Enum):
    """Model tiers ordered by capability and cost."""

    FAST = "fast"  # qwen2.5-coder-7b - $0
    LARGE = "large"  # deepseek-coder-33b - $0
    HAIKU = "haiku"  # Claude Haiku - $0.25/1M
    SONNET = "sonnet"  # Claude Sonnet - $3/1M
    OPUS = "opus"  # Claude Opus - $15/1M


@dataclass
class TierConfig:
    """Configuration for a model tier."""

    tier: ModelTier
    model_id: str
    cost_per_million_tokens: float
    quality_score: float  # 0-1 expected quality
    max_tokens: int
    is_local: bool = False


@dataclass
class TaskFingerprint:
    """Fingerprint for categorizing tasks."""

    task_type: str  # e.g., 'code_generation', 'refactoring', 'explanation'
    complexity: float  # 0-1 estimated complexity
    domain: str  # e.g., 'python', 'javascript', 'general'
    keywords: list[str] = field(default_factory=list)
    token_estimate: int = 0

    def to_hash(self) -> str:
        """Generate hash for this fingerprint."""
        key = f"{self.task_type}:{self.complexity:.1f}:{self.domain}"
        return hashlib.sha256(key.encode()).hexdigest()[:12]


@dataclass
class RoutingDecision:
    """Decision from the router."""

    tier: ModelTier
    model_id: str
    confidence: float
    reason: str
    estimated_cost: float
    fingerprint: TaskFingerprint | None = None


@dataclass
class RoutingHistory:
    """History entry for learning."""

    fingerprint_hash: str
    tier_used: ModelTier
    success: bool
    quality_score: float
    actual_tokens: int
    actual_cost: float
    timestamp: datetime = field(default_factory=datetime.now)


class SmartRouter:
    """Economic router with predictive tier selection."""

    # Default tier configurations
    DEFAULT_TIERS: list[TierConfig] = [
        TierConfig(
            tier=ModelTier.FAST,
            model_id="qwen2.5-coder-7b",
            cost_per_million_tokens=0.0,
            quality_score=0.70,
            max_tokens=8192,
            is_local=True,
        ),
        TierConfig(
            tier=ModelTier.LARGE,
            model_id="deepseek-coder-33b",
            cost_per_million_tokens=0.0,
            quality_score=0.80,
            max_tokens=16384,
            is_local=True,
        ),
        TierConfig(
            tier=ModelTier.HAIKU,
            model_id="claude-3-haiku-20240307",
            cost_per_million_tokens=0.25,
            quality_score=0.85,
            max_tokens=200000,
            is_local=False,
        ),
        TierConfig(
            tier=ModelTier.SONNET,
            model_id="claude-3-5-sonnet-20241022",
            cost_per_million_tokens=3.0,
            quality_score=0.95,
            max_tokens=200000,
            is_local=False,
        ),
        TierConfig(
            tier=ModelTier.OPUS,
            model_id="claude-3-opus-20240229",
            cost_per_million_tokens=15.0,
            quality_score=0.99,
            max_tokens=200000,
            is_local=False,
        ),
    ]

    # Task type patterns for fingerprinting
    TASK_PATTERNS: dict[str, list[str]] = {
        "code_generation": [
            r"\b(write|create|implement|build|generate)\b.*\b(function|class|code|script)\b",
            r"\b(add|new)\b.*\b(feature|endpoint|component)\b",
        ],
        "refactoring": [
            r"\b(refactor|improve|optimize|clean)\b",
            r"\b(extract|rename|move|split)\b.*\b(method|function|class)\b",
        ],
        "debugging": [
            r"\b(fix|debug|solve|resolve)\b.*\b(bug|error|issue|problem)\b",
            r"\b(why|doesn't|not working|broken)\b",
        ],
        "explanation": [
            r"\b(explain|describe|what|how|why)\b",
            r"\b(understand|documentation|docs)\b",
        ],
        "testing": [
            r"\b(test|spec|unittest|pytest)\b",
            r"\b(coverage|assertion|mock)\b",
        ],
    }

    # Complexity indicators
    COMPLEXITY_INDICATORS: dict[str, float] = {
        "simple": -0.2,
        "basic": -0.2,
        "trivial": -0.3,
        "complex": 0.3,
        "advanced": 0.3,
        "difficult": 0.2,
        "multi-file": 0.2,
        "architecture": 0.3,
        "security": 0.2,
        "performance": 0.2,
    }

    def __init__(
        self,
        config: SovereignConfig | None = None,
        history_path: str | Path | None = None,
        prefer_local: bool = True,
        quality_threshold: float = 0.8,
    ) -> None:
        """Initialize the smart router.

        Args:
            config: Sovereign configuration
            history_path: Path to persist routing history
            prefer_local: Prefer local models when quality is sufficient
            quality_threshold: Minimum quality required for task success
        """
        self.config = config
        self.history_path = Path(history_path) if history_path else None
        self.prefer_local = prefer_local
        self.quality_threshold = quality_threshold

        self._tiers = {t.tier: t for t in self.DEFAULT_TIERS}
        self._history: dict[str, list[RoutingHistory]] = {}
        self._fingerprint_success_rates: dict[str, dict[ModelTier, float]] = {}

        if self.history_path and self.history_path.exists():
            self._load_history()

    def fingerprint_task(self, task: str) -> TaskFingerprint:
        """Create a fingerprint for a task.

        Args:
            task: Task description

        Returns:
            TaskFingerprint for the task
        """
        task_lower = task.lower()

        # Detect task type
        task_type = "general"
        for type_name, patterns in self.TASK_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, task_lower, re.IGNORECASE):
                    task_type = type_name
                    break
            if task_type != "general":
                break

        # Estimate complexity (0.5 baseline)
        complexity = 0.5
        for indicator, adjustment in self.COMPLEXITY_INDICATORS.items():
            if indicator in task_lower:
                complexity += adjustment
        complexity = max(0.0, min(1.0, complexity))

        # Detect domain
        domain = "general"
        domain_keywords = {
            "python": ["python", ".py", "pip", "pytest", "django", "flask"],
            "javascript": ["javascript", "js", "node", "npm", "react", "vue"],
            "typescript": ["typescript", "ts", "tsx"],
            "rust": ["rust", "cargo", "crate"],
            "go": ["golang", "go mod", "go build"],
        }
        for domain_name, keywords in domain_keywords.items():
            if any(kw in task_lower for kw in keywords):
                domain = domain_name
                break

        # Extract significant keywords
        words = re.findall(r"\b\w{4,}\b", task_lower)
        keywords = list(set(words))[:10]

        # Estimate tokens (rough: 4 chars per token, task + expected response)
        token_estimate = len(task) // 4 + 500  # Base response estimate

        return TaskFingerprint(
            task_type=task_type,
            complexity=complexity,
            domain=domain,
            keywords=keywords,
            token_estimate=token_estimate,
        )

    def predict_quality(
        self,
        fingerprint: TaskFingerprint,
        tier: ModelTier,
    ) -> float:
        """Predict quality score for a tier on this task.

        Args:
            fingerprint: Task fingerprint
            tier: Model tier to evaluate

        Returns:
            Predicted quality score (0-1)
        """
        base_quality = self._tiers[tier].quality_score

        # Check historical success for this fingerprint type
        fp_hash = fingerprint.to_hash()
        if fp_hash in self._fingerprint_success_rates:
            tier_rates = self._fingerprint_success_rates[fp_hash]
            if tier in tier_rates:
                # Blend historical and base quality
                historical = tier_rates[tier]
                return 0.7 * historical + 0.3 * base_quality

        # Adjust base quality by complexity
        complexity_penalty = fingerprint.complexity * 0.2
        adjusted = base_quality - complexity_penalty

        # Domain-specific adjustments for local models
        if self._tiers[tier].is_local and fingerprint.domain in ["python", "javascript"]:
            adjusted += 0.05  # Local coding models excel at common languages

        return max(0.0, min(1.0, adjusted))

    def select_tier(
        self,
        task: str,
        required_quality: float | None = None,
        max_cost: float | None = None,
    ) -> RoutingDecision:
        """Select the optimal tier for a task.

        Args:
            task: Task description
            required_quality: Minimum required quality (default: self.quality_threshold)
            max_cost: Maximum allowed cost per million tokens

        Returns:
            RoutingDecision with selected tier
        """
        required_quality = required_quality or self.quality_threshold
        fingerprint = self.fingerprint_task(task)

        # Evaluate each tier
        candidates: list[tuple[TierConfig, float, float]] = []

        for tier_config in self.DEFAULT_TIERS:
            # Check cost constraint
            if max_cost is not None and tier_config.cost_per_million_tokens > max_cost:
                continue

            # Predict quality
            predicted_quality = self.predict_quality(fingerprint, tier_config.tier)

            # Calculate cost estimate
            estimated_cost = (
                fingerprint.token_estimate / 1_000_000
            ) * tier_config.cost_per_million_tokens

            if predicted_quality >= required_quality:
                candidates.append((tier_config, predicted_quality, estimated_cost))

        if not candidates:
            # Fall back to highest tier if none meet requirements
            tier_config = self._tiers[ModelTier.OPUS]
            predicted_quality = self.predict_quality(fingerprint, ModelTier.OPUS)
            estimated_cost = (
                fingerprint.token_estimate / 1_000_000
            ) * tier_config.cost_per_million_tokens

            return RoutingDecision(
                tier=ModelTier.OPUS,
                model_id=tier_config.model_id,
                confidence=predicted_quality,
                reason="No tier met quality requirements, using highest tier",
                estimated_cost=estimated_cost,
                fingerprint=fingerprint,
            )

        # Sort by preference: local first (if prefer_local), then by cost
        def sort_key(item: tuple[TierConfig, float, float]) -> tuple[int, float]:
            config, _quality, cost = item
            local_priority = 0 if (self.prefer_local and config.is_local) else 1
            return (local_priority, cost)

        candidates.sort(key=sort_key)
        selected, quality, cost = candidates[0]

        # Determine reason
        if selected.is_local and self.prefer_local:
            reason = f"Local model meets quality threshold ({quality:.2f} >= {required_quality:.2f})"
        else:
            reason = f"Selected for optimal cost/quality ratio ({quality:.2f} quality, ${cost:.4f} estimated)"

        return RoutingDecision(
            tier=selected.tier,
            model_id=selected.model_id,
            confidence=quality,
            reason=reason,
            estimated_cost=cost,
            fingerprint=fingerprint,
        )

    def record_result(
        self,
        decision: RoutingDecision,
        success: bool,
        actual_quality: float,
        actual_tokens: int,
    ) -> None:
        """Record the result of a routing decision for learning.

        Args:
            decision: The routing decision that was made
            success: Whether the task was successful
            actual_quality: Actual quality achieved (0-1)
            actual_tokens: Actual tokens used
        """
        if decision.fingerprint is None:
            return

        fp_hash = decision.fingerprint.to_hash()
        tier_config = self._tiers[decision.tier]
        actual_cost = (actual_tokens / 1_000_000) * tier_config.cost_per_million_tokens

        history_entry = RoutingHistory(
            fingerprint_hash=fp_hash,
            tier_used=decision.tier,
            success=success,
            quality_score=actual_quality,
            actual_tokens=actual_tokens,
            actual_cost=actual_cost,
        )

        # Update history
        if fp_hash not in self._history:
            self._history[fp_hash] = []
        self._history[fp_hash].append(history_entry)

        # Update success rates
        self._update_success_rates(fp_hash)

        # Save if configured
        if self.history_path:
            self._save_history()

    def _update_success_rates(self, fp_hash: str) -> None:
        """Update success rates for a fingerprint hash.

        Args:
            fp_hash: Fingerprint hash to update
        """
        if fp_hash not in self._history:
            return

        if fp_hash not in self._fingerprint_success_rates:
            self._fingerprint_success_rates[fp_hash] = {}

        tier_results: dict[ModelTier, list[float]] = {}
        for entry in self._history[fp_hash]:
            if entry.tier_used not in tier_results:
                tier_results[entry.tier_used] = []
            tier_results[entry.tier_used].append(entry.quality_score if entry.success else 0.0)

        for tier, scores in tier_results.items():
            self._fingerprint_success_rates[fp_hash][tier] = sum(scores) / len(scores)

    def get_tier_config(self, tier: ModelTier) -> TierConfig:
        """Get configuration for a tier.

        Args:
            tier: Model tier

        Returns:
            TierConfig for the tier
        """
        return self._tiers[tier]

    def _save_history(self) -> None:
        """Save routing history to file."""
        if self.history_path is None:
            return

        self.history_path.parent.mkdir(parents=True, exist_ok=True)

        data = {
            "history": {
                fp_hash: [
                    {
                        "fingerprint_hash": e.fingerprint_hash,
                        "tier_used": e.tier_used.value,
                        "success": e.success,
                        "quality_score": e.quality_score,
                        "actual_tokens": e.actual_tokens,
                        "actual_cost": e.actual_cost,
                        "timestamp": e.timestamp.isoformat(),
                    }
                    for e in entries
                ]
                for fp_hash, entries in self._history.items()
            },
            "success_rates": {
                fp_hash: {tier.value: rate for tier, rate in rates.items()}
                for fp_hash, rates in self._fingerprint_success_rates.items()
            },
        }

        with open(self.history_path, "w") as f:
            json.dump(data, f, indent=2)

    def _load_history(self) -> None:
        """Load routing history from file."""
        if self.history_path is None or not self.history_path.exists():
            return

        with open(self.history_path) as f:
            data = json.load(f)

        # Reconstruct history
        for fp_hash, entries in data.get("history", {}).items():
            self._history[fp_hash] = [
                RoutingHistory(
                    fingerprint_hash=e["fingerprint_hash"],
                    tier_used=ModelTier(e["tier_used"]),
                    success=e["success"],
                    quality_score=e["quality_score"],
                    actual_tokens=e["actual_tokens"],
                    actual_cost=e["actual_cost"],
                    timestamp=datetime.fromisoformat(e["timestamp"]),
                )
                for e in entries
            ]

        # Reconstruct success rates
        for fp_hash, rates in data.get("success_rates", {}).items():
            self._fingerprint_success_rates[fp_hash] = {
                ModelTier(tier): rate for tier, rate in rates.items()
            }

    def stats(self) -> dict[str, Any]:
        """Get router statistics.

        Returns:
            Dictionary of statistics
        """
        total_entries = sum(len(entries) for entries in self._history.values())
        tier_usage: dict[str, int] = {}
        total_cost = 0.0
        total_tokens = 0

        for entries in self._history.values():
            for entry in entries:
                tier_usage[entry.tier_used.value] = (
                    tier_usage.get(entry.tier_used.value, 0) + 1
                )
                total_cost += entry.actual_cost
                total_tokens += entry.actual_tokens

        return {
            "total_decisions": total_entries,
            "unique_fingerprints": len(self._history),
            "tier_usage": tier_usage,
            "total_cost": total_cost,
            "total_tokens": total_tokens,
            "average_cost_per_decision": total_cost / total_entries if total_entries > 0 else 0,
        }
