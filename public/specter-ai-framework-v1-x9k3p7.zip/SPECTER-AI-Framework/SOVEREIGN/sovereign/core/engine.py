"""LocalAI Inference Engine."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from sovereign.config import InferenceConfig


class LocalAIEngine:
    """LocalAI inference client with streaming support."""

    def __init__(self, config: InferenceConfig) -> None:
        """Initialize LocalAI engine.

        Args:
            config: Inference configuration
        """
        self.config = config
        self.base_url = config.base_url.rstrip("/")
        self._client: httpx.AsyncClient | None = None

    @property
    def client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=httpx.Timeout(self.config.timeout),
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def health_check(self) -> bool:
        """Check if LocalAI is healthy.

        Returns:
            True if LocalAI is responding, False otherwise
        """
        try:
            response = await self.client.get("/readyz")
            return response.status_code == 200
        except Exception:
            return False

    async def list_models(self) -> list[str]:
        """List available models.

        Returns:
            List of model names
        """
        try:
            response = await self.client.get("/v1/models")
            response.raise_for_status()
            data = response.json()
            return [m["id"] for m in data.get("data", [])]
        except Exception as e:
            raise RuntimeError(f"Failed to list models: {e}") from e

    async def generate(
        self,
        prompt: str,
        system: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        stream: bool = False,
    ) -> str:
        """Generate a response from LocalAI.

        Args:
            prompt: User prompt
            system: System prompt
            model: Model to use (defaults to config)
            max_tokens: Maximum tokens (defaults to config)
            temperature: Temperature (defaults to config)
            stream: Whether to stream the response

        Returns:
            Generated text response
        """
        model = model or self.config.models.get(self.config.default_model)
        max_tokens = max_tokens or self.config.max_tokens
        temperature = temperature or self.config.temperature

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": stream,
        }

        if stream:
            chunks = []
            async for chunk in self.generate_stream(
                prompt=prompt,
                system=system,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
            ):
                chunks.append(chunk)
            return "".join(chunks)

        try:
            response = await self.client.post(
                "/v1/chat/completions",
                json=payload,
            )
            response.raise_for_status()
            data = response.json()
            return data["choices"][0]["message"]["content"]
        except httpx.HTTPStatusError as e:
            raise RuntimeError(f"LocalAI request failed: {e.response.text}") from e
        except Exception as e:
            raise RuntimeError(f"LocalAI request failed: {e}") from e

    async def generate_stream(
        self,
        prompt: str,
        system: str | None = None,
        model: str | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> AsyncIterator[str]:
        """Stream a response from LocalAI.

        Args:
            prompt: User prompt
            system: System prompt
            model: Model to use
            max_tokens: Maximum tokens
            temperature: Temperature

        Yields:
            Text chunks as they arrive
        """
        model = model or self.config.models.get(self.config.default_model)
        max_tokens = max_tokens or self.config.max_tokens
        temperature = temperature or self.config.temperature

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }

        try:
            async with self.client.stream(
                "POST",
                "/v1/chat/completions",
                json=payload,
            ) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        data_str = line[6:]
                        if data_str.strip() == "[DONE]":
                            break
                        try:
                            import json

                            data = json.loads(data_str)
                            delta = data["choices"][0].get("delta", {})
                            content = delta.get("content", "")
                            if content:
                                yield content
                        except Exception:
                            continue
        except Exception as e:
            raise RuntimeError(f"LocalAI streaming failed: {e}") from e


async def test_engine() -> None:
    """Test the LocalAI engine."""
    from sovereign.config import InferenceConfig

    config = InferenceConfig()
    engine = LocalAIEngine(config)

    print("Testing LocalAI connection...")
    healthy = await engine.health_check()
    print(f"Health check: {'OK' if healthy else 'FAILED'}")

    if healthy:
        print("\nListing models...")
        models = await engine.list_models()
        print(f"Available models: {models}")

        print("\nGenerating response...")
        response = await engine.generate(
            prompt="Say 'Hello, I am SOVEREIGN!' in exactly those words.",
            system="You are SOVEREIGN, a helpful AI assistant. Follow instructions exactly.",
        )
        print(f"Response: {response}")

    await engine.close()


if __name__ == "__main__":
    asyncio.run(test_engine())
