"""Cost Tracker for enforcing spending limits."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any


@dataclass
class CostEntry:
    """A single cost entry."""

    amount: float
    tokens: int
    model: str
    task_id: str | None
    session_id: str
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "amount": self.amount,
            "tokens": self.tokens,
            "model": self.model,
            "task_id": self.task_id,
            "session_id": self.session_id,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CostEntry:
        """Create from dictionary."""
        return cls(
            amount=data["amount"],
            tokens=data["tokens"],
            model=data["model"],
            task_id=data.get("task_id"),
            session_id=data["session_id"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
        )


@dataclass
class CostLimits:
    """Cost limits configuration."""

    per_task: float = 0.50  # Max cost per individual task
    per_session: float = 5.00  # Max cost per session
    per_day: float = 25.00  # Max cost per 24 hours
    warning_threshold: float = 0.8  # Warn at 80% of limit


class CostLimitExceeded(Exception):
    """Raised when a cost limit would be exceeded."""

    def __init__(self, limit_type: str, current: float, limit: float) -> None:
        self.limit_type = limit_type
        self.current = current
        self.limit = limit
        super().__init__(
            f"Cost limit exceeded: {limit_type} (${current:.2f} >= ${limit:.2f})"
        )


class CostWarning(Exception):
    """Raised when approaching a cost limit."""

    def __init__(self, limit_type: str, current: float, limit: float) -> None:
        self.limit_type = limit_type
        self.current = current
        self.limit = limit
        super().__init__(
            f"Approaching cost limit: {limit_type} (${current:.2f} / ${limit:.2f})"
        )


class CostTracker:
    """Tracks and enforces cost limits."""

    def __init__(
        self,
        limits: CostLimits | None = None,
        storage_path: str | Path | None = None,
        session_id: str | None = None,
    ) -> None:
        """Initialize cost tracker.

        Args:
            limits: Cost limits configuration
            storage_path: Path to persist cost history
            session_id: Current session identifier
        """
        self.limits = limits or CostLimits()
        self.storage_path = Path(storage_path) if storage_path else None
        self.session_id = session_id or datetime.now().strftime("%Y%m%d_%H%M%S")

        self._entries: list[CostEntry] = []
        self._task_costs: dict[str, float] = {}

        if self.storage_path and self.storage_path.exists():
            self._load()

    def check_limits(
        self,
        estimated_cost: float,
        task_id: str | None = None,
    ) -> tuple[bool, str | None]:
        """Check if a cost would exceed limits.

        Args:
            estimated_cost: Estimated cost of operation
            task_id: Optional task identifier

        Returns:
            Tuple of (allowed, warning_message)
        """
        warnings: list[str] = []

        # Check task limit
        if task_id:
            task_total = self._task_costs.get(task_id, 0.0) + estimated_cost
            if task_total > self.limits.per_task:
                raise CostLimitExceeded("per_task", task_total, self.limits.per_task)
            if task_total > self.limits.per_task * self.limits.warning_threshold:
                warnings.append(
                    f"Task approaching limit: ${task_total:.2f} / ${self.limits.per_task:.2f}"
                )

        # Check session limit
        session_total = self.get_session_cost() + estimated_cost
        if session_total > self.limits.per_session:
            raise CostLimitExceeded("per_session", session_total, self.limits.per_session)
        if session_total > self.limits.per_session * self.limits.warning_threshold:
            warnings.append(
                f"Session approaching limit: ${session_total:.2f} / ${self.limits.per_session:.2f}"
            )

        # Check daily limit
        daily_total = self.get_daily_cost() + estimated_cost
        if daily_total > self.limits.per_day:
            raise CostLimitExceeded("per_day", daily_total, self.limits.per_day)
        if daily_total > self.limits.per_day * self.limits.warning_threshold:
            warnings.append(
                f"Daily approaching limit: ${daily_total:.2f} / ${self.limits.per_day:.2f}"
            )

        warning_msg = "; ".join(warnings) if warnings else None
        return True, warning_msg

    def record(
        self,
        amount: float,
        tokens: int,
        model: str,
        task_id: str | None = None,
    ) -> CostEntry:
        """Record a cost entry.

        Args:
            amount: Cost amount in dollars
            tokens: Number of tokens used
            model: Model identifier
            task_id: Optional task identifier

        Returns:
            Created CostEntry
        """
        entry = CostEntry(
            amount=amount,
            tokens=tokens,
            model=model,
            task_id=task_id,
            session_id=self.session_id,
        )

        self._entries.append(entry)

        if task_id:
            self._task_costs[task_id] = self._task_costs.get(task_id, 0.0) + amount

        if self.storage_path:
            self._save()

        return entry

    def get_session_cost(self) -> float:
        """Get total cost for current session.

        Returns:
            Total cost in dollars
        """
        return sum(e.amount for e in self._entries if e.session_id == self.session_id)

    def get_daily_cost(self) -> float:
        """Get total cost for last 24 hours.

        Returns:
            Total cost in dollars
        """
        cutoff = datetime.now() - timedelta(hours=24)
        return sum(e.amount for e in self._entries if e.timestamp > cutoff)

    def get_task_cost(self, task_id: str) -> float:
        """Get total cost for a specific task.

        Args:
            task_id: Task identifier

        Returns:
            Total cost in dollars
        """
        return self._task_costs.get(task_id, 0.0)

    def get_remaining(self) -> dict[str, float]:
        """Get remaining budget for each limit type.

        Returns:
            Dictionary of remaining budgets
        """
        return {
            "per_session": max(0, self.limits.per_session - self.get_session_cost()),
            "per_day": max(0, self.limits.per_day - self.get_daily_cost()),
        }

    def reset_session(self, new_session_id: str | None = None) -> None:
        """Start a new session.

        Args:
            new_session_id: Optional new session ID
        """
        self.session_id = new_session_id or datetime.now().strftime("%Y%m%d_%H%M%S")
        self._task_costs.clear()

    def _save(self) -> None:
        """Save cost history to file."""
        if self.storage_path is None:
            return

        self.storage_path.parent.mkdir(parents=True, exist_ok=True)

        data = {
            "entries": [e.to_dict() for e in self._entries],
            "session_id": self.session_id,
        }

        with open(self.storage_path, "w") as f:
            json.dump(data, f, indent=2)

    def _load(self) -> None:
        """Load cost history from file."""
        if self.storage_path is None or not self.storage_path.exists():
            return

        with open(self.storage_path) as f:
            data = json.load(f)

        self._entries = [CostEntry.from_dict(e) for e in data.get("entries", [])]

        # Rebuild task costs for current session
        for entry in self._entries:
            if entry.session_id == self.session_id and entry.task_id:
                self._task_costs[entry.task_id] = (
                    self._task_costs.get(entry.task_id, 0.0) + entry.amount
                )

    def cleanup_old_entries(self, days: int = 30) -> int:
        """Remove entries older than specified days.

        Args:
            days: Number of days to keep

        Returns:
            Number of entries removed
        """
        cutoff = datetime.now() - timedelta(days=days)
        original_count = len(self._entries)
        self._entries = [e for e in self._entries if e.timestamp > cutoff]
        removed = original_count - len(self._entries)

        if removed > 0 and self.storage_path:
            self._save()

        return removed

    def stats(self) -> dict[str, Any]:
        """Get tracker statistics.

        Returns:
            Dictionary of statistics
        """
        session_cost = self.get_session_cost()
        daily_cost = self.get_daily_cost()

        # Group by model
        model_costs: dict[str, float] = {}
        model_tokens: dict[str, int] = {}
        for entry in self._entries:
            model_costs[entry.model] = model_costs.get(entry.model, 0.0) + entry.amount
            model_tokens[entry.model] = model_tokens.get(entry.model, 0) + entry.tokens

        return {
            "session_id": self.session_id,
            "session_cost": session_cost,
            "session_remaining": self.limits.per_session - session_cost,
            "daily_cost": daily_cost,
            "daily_remaining": self.limits.per_day - daily_cost,
            "total_entries": len(self._entries),
            "model_costs": model_costs,
            "model_tokens": model_tokens,
            "limits": {
                "per_task": self.limits.per_task,
                "per_session": self.limits.per_session,
                "per_day": self.limits.per_day,
            },
        }


def create_tracker_with_config(
    config_dict: dict[str, Any],
    storage_path: str | Path | None = None,
) -> CostTracker:
    """Create a cost tracker from configuration dictionary.

    Args:
        config_dict: Configuration with 'cost_limits' key
        storage_path: Optional storage path

    Returns:
        Configured CostTracker
    """
    limits_config = config_dict.get("cost_limits", {})
    limits = CostLimits(
        per_task=limits_config.get("per_task", 0.50),
        per_session=limits_config.get("per_session", 5.00),
        per_day=limits_config.get("per_day", 25.00),
    )
    return CostTracker(limits=limits, storage_path=storage_path)
