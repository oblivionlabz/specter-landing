"""SOVEREIGN TUI Dashboard.

Rich terminal UI using Textual for real-time monitoring.
"""

from sovereign.tui.app import SovereignApp, run_dashboard

__all__ = ["SovereignApp", "run_dashboard"]
