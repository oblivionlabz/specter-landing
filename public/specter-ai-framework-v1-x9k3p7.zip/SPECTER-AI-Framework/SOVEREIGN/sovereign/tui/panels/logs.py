"""Logs Panel showing recent activity."""

from __future__ import annotations

from collections import deque
from datetime import datetime
from typing import Any

try:
    from textual.app import ComposeResult
    from textual.reactive import reactive
    from textual.widgets import Label, RichLog, Static
    TEXTUAL_AVAILABLE = True
except ImportError:
    TEXTUAL_AVAILABLE = False
    class ComposeResult:
        pass
    class Static:
        pass
    class Label:
        pass
    class RichLog:
        pass


class LogEntry:
    """A single log entry."""

    def __init__(
        self,
        level: str,
        message: str,
        source: str = "",
        timestamp: datetime | None = None,
    ) -> None:
        self.level = level
        self.message = message
        self.source = source
        self.timestamp = timestamp or datetime.now()

    def format(self) -> str:
        """Format the log entry."""
        time_str = self.timestamp.strftime("%H:%M:%S")
        color = self._get_level_color()
        source_str = f"[{self.source}] " if self.source else ""
        return f"[dim]{time_str}[/] [{color}]{self.level:5}[/] {source_str}{self.message}"

    def _get_level_color(self) -> str:
        """Get color for log level."""
        colors = {
            "DEBUG": "dim white",
            "INFO": "blue",
            "WARN": "yellow",
            "ERROR": "red",
            "FATAL": "bold red",
        }
        return colors.get(self.level.upper(), "white")


class LogPanel(Static if TEXTUAL_AVAILABLE else object):
    """Panel showing recent log messages."""

    log_count: int = 0 if not TEXTUAL_AVAILABLE else reactive(0)

    DEFAULT_CSS = """
    LogPanel {
        height: auto;
        min-height: 10;
        max-height: 20;
        padding: 1;
        border: solid cyan;
    }

    LogPanel .title {
        text-style: bold;
        color: cyan;
    }

    LogPanel #log-content {
        height: auto;
        min-height: 8;
        max-height: 15;
        overflow-y: auto;
    }
    """

    def __init__(self, max_logs: int = 100, **kwargs: Any) -> None:
        """Initialize log panel.

        Args:
            max_logs: Maximum log entries to keep
        """
        if TEXTUAL_AVAILABLE:
            super().__init__(**kwargs)
        self._logs: deque[LogEntry] = deque(maxlen=max_logs)

    def compose(self) -> ComposeResult:
        """Compose the panel layout."""
        if not TEXTUAL_AVAILABLE:
            return

        yield Label("[bold cyan]Activity Log[/]", classes="title")
        yield Label(id="log-content")

    def on_mount(self) -> None:
        """Handle mount event."""
        if not TEXTUAL_AVAILABLE:
            return
        self._update_display()

    def watch_log_count(self, value: int) -> None:
        """Watch log count changes."""
        if not TEXTUAL_AVAILABLE:
            return
        self._update_display()

    def _update_display(self) -> None:
        """Update the log display."""
        if not TEXTUAL_AVAILABLE:
            return

        try:
            content_label = self.query_one("#log-content", Label)

            if self._logs:
                # Show most recent logs
                lines = [entry.format() for entry in list(self._logs)[-10:]]
                content_label.update("\n".join(lines))
            else:
                content_label.update("  No log entries")

        except Exception:
            pass

    def add_log(
        self,
        message: str,
        level: str = "INFO",
        source: str = "",
    ) -> None:
        """Add a log entry.

        Args:
            message: Log message
            level: Log level (DEBUG, INFO, WARN, ERROR)
            source: Source of the log
        """
        entry = LogEntry(level=level, message=message, source=source)
        self._logs.append(entry)

        if TEXTUAL_AVAILABLE:
            self.log_count = len(self._logs)

    def info(self, message: str, source: str = "") -> None:
        """Add an INFO log."""
        self.add_log(message, "INFO", source)

    def warn(self, message: str, source: str = "") -> None:
        """Add a WARN log."""
        self.add_log(message, "WARN", source)

    def error(self, message: str, source: str = "") -> None:
        """Add an ERROR log."""
        self.add_log(message, "ERROR", source)

    def debug(self, message: str, source: str = "") -> None:
        """Add a DEBUG log."""
        self.add_log(message, "DEBUG", source)

    def clear(self) -> None:
        """Clear all logs."""
        self._logs.clear()
        if TEXTUAL_AVAILABLE:
            self.log_count = 0
