"""Agents Panel showing active agent status."""

from __future__ import annotations

from typing import Any

try:
    from textual.app import ComposeResult
    from textual.reactive import reactive
    from textual.widgets import DataTable, Label, Static
    TEXTUAL_AVAILABLE = True
except ImportError:
    TEXTUAL_AVAILABLE = False
    class ComposeResult:
        pass
    class Static:
        pass
    class Label:
        pass
    class DataTable:
        pass


class AgentPanel(Static if TEXTUAL_AVAILABLE else object):
    """Panel showing active agents and their status."""

    agent_count: int = 0 if not TEXTUAL_AVAILABLE else reactive(0)

    DEFAULT_CSS = """
    AgentPanel {
        height: auto;
        min-height: 10;
        padding: 1;
        border: solid magenta;
    }

    AgentPanel .title {
        text-style: bold;
        color: magenta;
    }

    AgentPanel DataTable {
        height: auto;
        max-height: 10;
    }

    AgentPanel .status-running {
        color: green;
    }

    AgentPanel .status-idle {
        color: yellow;
    }

    AgentPanel .status-error {
        color: red;
    }
    """

    def __init__(self, **kwargs: Any) -> None:
        """Initialize agent panel."""
        if TEXTUAL_AVAILABLE:
            super().__init__(**kwargs)
        self._agents: list[dict[str, Any]] = []

    def compose(self) -> ComposeResult:
        """Compose the panel layout."""
        if not TEXTUAL_AVAILABLE:
            return

        yield Label("[bold magenta]Active Agents[/]", classes="title")
        yield Label(id="agent-count")
        yield Label(id="agent-list")

    def on_mount(self) -> None:
        """Handle mount event."""
        if not TEXTUAL_AVAILABLE:
            return
        self._update_display()

    def watch_agent_count(self, value: int) -> None:
        """Watch agent count changes."""
        if not TEXTUAL_AVAILABLE:
            return
        self._update_display()

    def _update_display(self) -> None:
        """Update the agent display."""
        if not TEXTUAL_AVAILABLE:
            return

        try:
            # Update count
            count_label = self.query_one("#agent-count", Label)
            count_label.update(f"Total: {self.agent_count} agents")

            # Update agent list
            list_label = self.query_one("#agent-list", Label)
            if self._agents:
                lines = []
                for agent in self._agents[:5]:  # Show max 5
                    name = agent.get("name", "Unknown")
                    status = agent.get("status", "idle")
                    task = agent.get("task", "")[:30]
                    color = self._get_status_color(status)
                    lines.append(f"  [{color}]●[/] {name}: {task}")
                list_label.update("\n".join(lines))
            else:
                list_label.update("  No active agents")

        except Exception:
            pass

    def _get_status_color(self, status: str) -> str:
        """Get color for agent status."""
        if status == "running":
            return "green"
        elif status == "idle":
            return "yellow"
        elif status == "error":
            return "red"
        return "white"

    def update_agents(self, agents: list[dict[str, Any]]) -> None:
        """Update agent list.

        Args:
            agents: List of agent status dictionaries
        """
        self._agents = agents

        if TEXTUAL_AVAILABLE:
            self.agent_count = len(agents)
