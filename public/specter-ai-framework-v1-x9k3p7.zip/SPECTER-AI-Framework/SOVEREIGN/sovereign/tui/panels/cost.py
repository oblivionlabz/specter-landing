"""Cost Panel showing spending and budget tracking."""

from __future__ import annotations

from typing import Any

try:
    from textual.app import ComposeResult
    from textual.reactive import reactive
    from textual.widgets import Label, ProgressBar, Static
    TEXTUAL_AVAILABLE = True
except ImportError:
    TEXTUAL_AVAILABLE = False
    class ComposeResult:
        pass
    class Static:
        pass
    class Label:
        pass
    class ProgressBar:
        pass


class CostPanel(Static if TEXTUAL_AVAILABLE else object):
    """Panel showing cost tracking and budget."""

    session_cost: float = 0.0 if not TEXTUAL_AVAILABLE else reactive(0.0)
    daily_cost: float = 0.0 if not TEXTUAL_AVAILABLE else reactive(0.0)
    session_limit: float = 5.0 if not TEXTUAL_AVAILABLE else reactive(5.0)
    daily_limit: float = 25.0 if not TEXTUAL_AVAILABLE else reactive(25.0)

    DEFAULT_CSS = """
    CostPanel {
        height: auto;
        padding: 1;
        border: solid blue;
    }

    CostPanel .title {
        text-style: bold;
        color: blue;
    }

    CostPanel .cost-low {
        color: green;
    }

    CostPanel .cost-medium {
        color: yellow;
    }

    CostPanel .cost-high {
        color: red;
    }

    CostPanel ProgressBar {
        margin-top: 1;
    }
    """

    def __init__(self, **kwargs: Any) -> None:
        """Initialize cost panel."""
        if TEXTUAL_AVAILABLE:
            super().__init__(**kwargs)
        self._cost_data: dict[str, Any] = {}

    def compose(self) -> ComposeResult:
        """Compose the panel layout."""
        if not TEXTUAL_AVAILABLE:
            return

        yield Label("[bold blue]Cost Tracker[/]", classes="title")
        yield Label(id="session-cost")
        yield Label(id="daily-cost")
        yield Label(id="session-bar-label")
        # Note: ProgressBar would be added if Textual is available
        yield Label(id="daily-bar-label")

    def on_mount(self) -> None:
        """Handle mount event."""
        if not TEXTUAL_AVAILABLE:
            return
        self._update_display()

    def watch_session_cost(self, value: float) -> None:
        """Watch session cost changes."""
        if not TEXTUAL_AVAILABLE:
            return
        self._update_display()

    def watch_daily_cost(self, value: float) -> None:
        """Watch daily cost changes."""
        if not TEXTUAL_AVAILABLE:
            return
        self._update_display()

    def _update_display(self) -> None:
        """Update the cost display."""
        if not TEXTUAL_AVAILABLE:
            return

        try:
            # Session cost
            session_label = self.query_one("#session-cost", Label)
            session_pct = (self.session_cost / self.session_limit * 100) if self.session_limit > 0 else 0
            session_class = self._get_cost_class(session_pct)
            session_label.update(
                f"Session: [{session_class}]${self.session_cost:.2f}[/] / ${self.session_limit:.2f}"
            )

            # Daily cost
            daily_label = self.query_one("#daily-cost", Label)
            daily_pct = (self.daily_cost / self.daily_limit * 100) if self.daily_limit > 0 else 0
            daily_class = self._get_cost_class(daily_pct)
            daily_label.update(
                f"Daily: [{daily_class}]${self.daily_cost:.2f}[/] / ${self.daily_limit:.2f}"
            )

            # Progress bars as text
            session_bar = self.query_one("#session-bar-label", Label)
            session_bar.update(self._make_progress_bar(session_pct))

            daily_bar = self.query_one("#daily-bar-label", Label)
            daily_bar.update(self._make_progress_bar(daily_pct))

        except Exception:
            pass

    def _get_cost_class(self, percentage: float) -> str:
        """Get color class based on percentage."""
        if percentage >= 80:
            return "red"
        elif percentage >= 50:
            return "yellow"
        return "green"

    def _make_progress_bar(self, percentage: float) -> str:
        """Create a text progress bar.

        Args:
            percentage: Completion percentage

        Returns:
            Progress bar string
        """
        width = 20
        filled = int(percentage / 100 * width)
        filled = min(filled, width)
        empty = width - filled

        color = self._get_cost_class(percentage)
        bar = f"[{color}]{'█' * filled}{'░' * empty}[/] {percentage:.0f}%"
        return bar

    def update_costs(self, data: dict[str, Any]) -> None:
        """Update costs from data dictionary.

        Args:
            data: Cost data dictionary
        """
        self._cost_data = data

        if TEXTUAL_AVAILABLE:
            self.session_cost = data.get("session_cost", 0.0)
            self.daily_cost = data.get("daily_cost", 0.0)
            self.session_limit = data.get("session_limit", 5.0)
            self.daily_limit = data.get("daily_limit", 25.0)
