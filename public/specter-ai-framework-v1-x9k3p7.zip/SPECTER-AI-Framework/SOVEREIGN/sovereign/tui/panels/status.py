"""Status Panel showing system health and state."""

from __future__ import annotations

from typing import Any

try:
    from textual.app import ComposeResult
    from textual.containers import Vertical
    from textual.reactive import reactive
    from textual.widgets import Label, Static
    TEXTUAL_AVAILABLE = True
except ImportError:
    TEXTUAL_AVAILABLE = False
    # Provide fallbacks
    class ComposeResult:
        pass
    class Vertical:
        pass
    class Static:
        pass
    class Label:
        pass


class StatusPanel(Static if TEXTUAL_AVAILABLE else object):
    """Panel showing system status and health."""

    # Reactive properties
    status: str = "Initializing..." if not TEXTUAL_AVAILABLE else reactive("Initializing...")
    health_score: int = 100 if not TEXTUAL_AVAILABLE else reactive(100)
    active_agents: int = 0 if not TEXTUAL_AVAILABLE else reactive(0)
    memory_usage: float = 0.0 if not TEXTUAL_AVAILABLE else reactive(0.0)

    DEFAULT_CSS = """
    StatusPanel {
        height: auto;
        padding: 1;
        border: solid green;
    }

    StatusPanel .title {
        text-style: bold;
        color: green;
    }

    StatusPanel .metric {
        color: white;
    }

    StatusPanel .metric-value {
        color: cyan;
    }

    StatusPanel .health-good {
        color: green;
    }

    StatusPanel .health-warn {
        color: yellow;
    }

    StatusPanel .health-bad {
        color: red;
    }
    """

    def __init__(self, **kwargs: Any) -> None:
        """Initialize status panel."""
        if TEXTUAL_AVAILABLE:
            super().__init__(**kwargs)
        self._status_data: dict[str, Any] = {}

    def compose(self) -> ComposeResult:
        """Compose the panel layout."""
        if not TEXTUAL_AVAILABLE:
            return

        yield Label("[bold green]SOVEREIGN Status[/]", classes="title")
        yield Label(id="status-line")
        yield Label(id="health-line")
        yield Label(id="agents-line")
        yield Label(id="memory-line")

    def on_mount(self) -> None:
        """Handle mount event."""
        if not TEXTUAL_AVAILABLE:
            return
        self._update_display()

    def watch_status(self, status: str) -> None:
        """Watch for status changes."""
        if not TEXTUAL_AVAILABLE:
            return
        self._update_display()

    def watch_health_score(self, health_score: int) -> None:
        """Watch for health score changes."""
        if not TEXTUAL_AVAILABLE:
            return
        self._update_display()

    def _update_display(self) -> None:
        """Update the display with current values."""
        if not TEXTUAL_AVAILABLE:
            return

        try:
            # Update status
            status_label = self.query_one("#status-line", Label)
            status_label.update(f"Status: {self.status}")

            # Update health with color
            health_label = self.query_one("#health-line", Label)
            health_class = self._get_health_class()
            health_label.update(f"Health: [{health_class}]{self.health_score}%[/]")

            # Update agents
            agents_label = self.query_one("#agents-line", Label)
            agents_label.update(f"Active Agents: {self.active_agents}")

            # Update memory
            memory_label = self.query_one("#memory-line", Label)
            memory_label.update(f"Memory: {self.memory_usage:.1f} MB")
        except Exception:
            pass  # Panel not yet mounted

    def _get_health_class(self) -> str:
        """Get CSS class for health color."""
        if self.health_score >= 80:
            return "green"
        elif self.health_score >= 50:
            return "yellow"
        return "red"

    def update_status(self, data: dict[str, Any]) -> None:
        """Update status from data dictionary.

        Args:
            data: Status data dictionary
        """
        self._status_data = data

        if TEXTUAL_AVAILABLE:
            self.status = data.get("status", "Unknown")
            self.health_score = data.get("health_score", 100)
            self.active_agents = data.get("active_agents", 0)
            self.memory_usage = data.get("memory_usage", 0.0)
