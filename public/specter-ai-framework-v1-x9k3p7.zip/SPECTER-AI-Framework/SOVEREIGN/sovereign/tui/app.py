"""SOVEREIGN TUI Dashboard Application."""

from __future__ import annotations

import asyncio
from typing import Any

try:
    from textual.app import App, ComposeResult
    from textual.binding import Binding
    from textual.containers import Container, Horizontal, Vertical
    from textual.screen import Screen
    from textual.widgets import Footer, Header, Input, Label, Static
    TEXTUAL_AVAILABLE = True
except ImportError:
    TEXTUAL_AVAILABLE = False
    # Fallback definitions
    class App:
        pass
    class ComposeResult:
        pass
    class Binding:
        pass
    class Container:
        pass
    class Horizontal:
        pass
    class Vertical:
        pass
    class Footer:
        pass
    class Header:
        pass
    class Static:
        pass
    class Input:
        pass
    class Label:
        pass
    class Screen:
        pass

from sovereign.tui.panels.agents import AgentPanel
from sovereign.tui.panels.cost import CostPanel
from sovereign.tui.panels.logs import LogPanel
from sovereign.tui.panels.status import StatusPanel


class SovereignApp(App if TEXTUAL_AVAILABLE else object):
    """SOVEREIGN Terminal User Interface Dashboard.

    A real-time monitoring dashboard for SOVEREIGN showing:
    - System status and health
    - Cost tracking and budget
    - Active agents and tasks
    - Activity logs
    """

    TITLE = "SOVEREIGN Dashboard"
    SUB_TITLE = "Sovereign AI Terminal Assistant"

    CSS = """
    Screen {
        layout: grid;
        grid-size: 2 2;
        grid-gutter: 1;
    }

    #status-panel {
        column-span: 1;
        row-span: 1;
    }

    #cost-panel {
        column-span: 1;
        row-span: 1;
    }

    #agents-panel {
        column-span: 1;
        row-span: 1;
    }

    #logs-panel {
        column-span: 1;
        row-span: 1;
    }

    #input-container {
        dock: bottom;
        height: 3;
        padding: 0 1;
    }

    #command-input {
        width: 100%;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit", show=True),
        Binding("r", "refresh", "Refresh", show=True),
        Binding("c", "clear_logs", "Clear Logs", show=True),
        Binding("h", "toggle_help", "Help", show=True),
    ] if TEXTUAL_AVAILABLE else []

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the dashboard."""
        if TEXTUAL_AVAILABLE:
            super().__init__(**kwargs)

        self._status_panel: StatusPanel | None = None
        self._cost_panel: CostPanel | None = None
        self._agents_panel: AgentPanel | None = None
        self._logs_panel: LogPanel | None = None
        self._update_task: asyncio.Task[None] | None = None

    def compose(self) -> ComposeResult:
        """Compose the dashboard layout."""
        if not TEXTUAL_AVAILABLE:
            return

        yield Header()

        yield Container(
            StatusPanel(id="status-panel"),
            CostPanel(id="cost-panel"),
            AgentPanel(id="agents-panel"),
            LogPanel(id="logs-panel"),
        )

        yield Container(
            Input(placeholder="Enter command...", id="command-input"),
            id="input-container",
        )

        yield Footer()

    def on_mount(self) -> None:
        """Handle app mount."""
        if not TEXTUAL_AVAILABLE:
            return

        # Get panel references
        try:
            self._status_panel = self.query_one("#status-panel", StatusPanel)
            self._cost_panel = self.query_one("#cost-panel", CostPanel)
            self._agents_panel = self.query_one("#agents-panel", AgentPanel)
            self._logs_panel = self.query_one("#logs-panel", LogPanel)

            # Log startup
            if self._logs_panel:
                self._logs_panel.info("SOVEREIGN Dashboard started", "TUI")

            # Start update loop
            self._update_task = asyncio.create_task(self._update_loop())

        except Exception as e:
            self.notify(f"Mount error: {e}", severity="error")

    async def _update_loop(self) -> None:
        """Periodic update loop for dashboard."""
        while True:
            try:
                await self._refresh_data()
                await asyncio.sleep(2.0)  # Update every 2 seconds
            except asyncio.CancelledError:
                break
            except Exception:
                await asyncio.sleep(5.0)

    async def _refresh_data(self) -> None:
        """Refresh all dashboard data."""
        # This would normally fetch from actual SOVEREIGN components
        # For now, use placeholder data

        if self._status_panel:
            self._status_panel.update_status({
                "status": "Running",
                "health_score": 95,
                "active_agents": 2,
                "memory_usage": 128.5,
            })

        if self._cost_panel:
            self._cost_panel.update_costs({
                "session_cost": 0.00,
                "daily_cost": 0.00,
                "session_limit": 5.00,
                "daily_limit": 25.00,
            })

        if self._agents_panel:
            self._agents_panel.update_agents([
                {"name": "ReAct Loop", "status": "idle", "task": "Waiting for input"},
                {"name": "Router", "status": "running", "task": "Processing request"},
            ])

    async def on_input_submitted(self, event: Any) -> None:
        """Handle command input."""
        if not TEXTUAL_AVAILABLE:
            return

        command = event.value.strip()
        if command:
            if self._logs_panel:
                self._logs_panel.info(f"Command: {command}", "User")

            # Process command
            await self._process_command(command)

            # Clear input
            input_widget = self.query_one("#command-input", Input)
            input_widget.value = ""

    async def _process_command(self, command: str) -> None:
        """Process a user command.

        Args:
            command: Command string
        """
        if self._logs_panel:
            if command.lower() == "status":
                self._logs_panel.info("Status: System operational", "SOVEREIGN")
            elif command.lower() == "help":
                self._logs_panel.info("Commands: status, help, quit", "SOVEREIGN")
            else:
                self._logs_panel.info(f"Processing: {command}", "SOVEREIGN")

    def action_quit(self) -> None:
        """Quit the application."""
        if self._update_task:
            self._update_task.cancel()
        if TEXTUAL_AVAILABLE:
            self.exit()

    def action_refresh(self) -> None:
        """Refresh dashboard data."""
        if TEXTUAL_AVAILABLE:
            asyncio.create_task(self._refresh_data())
            self.notify("Dashboard refreshed")

    def action_clear_logs(self) -> None:
        """Clear the logs panel."""
        if self._logs_panel:
            self._logs_panel.clear()
            self._logs_panel.info("Logs cleared", "TUI")

    def action_toggle_help(self) -> None:
        """Toggle help display."""
        if TEXTUAL_AVAILABLE:
            self.notify(
                "q=Quit r=Refresh c=Clear h=Help",
                title="Keyboard Shortcuts",
            )


def run_dashboard() -> None:
    """Run the SOVEREIGN dashboard."""
    if not TEXTUAL_AVAILABLE:
        print("Textual is not installed. Install with: pip install textual")
        print("Running in fallback mode...")

        # Simple fallback display
        print("\n" + "=" * 50)
        print("SOVEREIGN Dashboard (Fallback Mode)")
        print("=" * 50)
        print("\nStatus: Running")
        print("Health: 100%")
        print("Active Agents: 0")
        print("\nInstall textual for the full TUI experience:")
        print("  pip install textual")
        return

    app = SovereignApp()
    app.run()


if __name__ == "__main__":
    run_dashboard()
