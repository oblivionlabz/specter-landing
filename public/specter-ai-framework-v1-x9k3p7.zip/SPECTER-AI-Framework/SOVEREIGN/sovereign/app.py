"""SOVEREIGN Main Application."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt

if TYPE_CHECKING:
    from sovereign.config import Config
    from sovereign.core.cost_tracker import CostTracker
    from sovereign.core.react import ReActLoop
    from sovereign.core.router import SmartRouter
    from sovereign.tools.registry import ToolRegistry

console = Console()


class SovereignApp:
    """Main SOVEREIGN application."""

    def __init__(self, config: Config, tui: bool = False, voice: bool = False) -> None:
        """Initialize SOVEREIGN application.

        Args:
            config: Application configuration
            tui: Enable TUI dashboard mode
            voice: Enable voice interface
        """
        self.config = config
        self.tui_enabled = tui
        self.voice_enabled = voice
        self.running = False

        # Components (initialized lazily)
        self._engine = None
        self._react_loop: ReActLoop | None = None
        self._memory = None
        self._registry: ToolRegistry | None = None
        self._router: SmartRouter | None = None
        self._cost_tracker: CostTracker | None = None

    @property
    def engine(self):
        """Get or create inference engine."""
        if self._engine is None:
            from sovereign.core.engine import LocalAIEngine

            self._engine = LocalAIEngine(self.config.inference)
        return self._engine

    @property
    def registry(self) -> ToolRegistry:
        """Get or create tool registry with built-in tools."""
        if self._registry is None:
            from sovereign.tools.registry import create_default_registry

            self._registry = create_default_registry()
        return self._registry

    @property
    def react_loop(self) -> ReActLoop:
        """Get or create ReAct loop."""
        if self._react_loop is None:
            from sovereign.core.react import ReActLoop

            self._react_loop = ReActLoop(
                engine=self.engine,
                registry=self.registry,
                max_iterations=25,  # Increased for complex multi-step tasks
                verbose=False,  # We handle output ourselves
            )
        return self._react_loop

    @property
    def router(self) -> SmartRouter:
        """Get or create smart router for economic model selection."""
        if self._router is None:
            from pathlib import Path

            from sovereign.core.router import SmartRouter

            # Store routing history for learning
            history_path = Path.home() / ".sovereign" / "routing_history.json"
            self._router = SmartRouter(
                prefer_local=True,  # Use LocalAI models first
                quality_threshold=0.75,
                history_path=history_path,
            )
        return self._router

    @property
    def cost_tracker(self) -> CostTracker:
        """Get or create cost tracker for spending limits."""
        if self._cost_tracker is None:
            from pathlib import Path

            from sovereign.core.cost_tracker import CostLimits, CostTracker

            # Store cost history
            storage_path = Path.home() / ".sovereign" / "cost_history.json"
            limits = CostLimits(
                per_task=0.50,
                per_session=5.00,
                per_day=25.00,
            )
            self._cost_tracker = CostTracker(
                limits=limits,
                storage_path=storage_path,
            )
        return self._cost_tracker

    def run(self) -> None:
        """Run the application."""
        if self.tui_enabled:
            self._run_tui()
        elif self.voice_enabled:
            self._run_voice()
        else:
            self._run_repl()

    def _run_repl(self) -> None:
        """Run interactive REPL mode."""
        self._print_banner()
        self._startup_check()
        self.running = True

        while self.running:
            try:
                user_input = Prompt.ask("\n[bold blue]>>>[/bold blue]")

                if not user_input.strip():
                    continue

                # Handle commands
                if user_input.startswith("/"):
                    self._handle_command(user_input)
                    continue

                # Process with ReAct loop
                asyncio.run(self._process_input(user_input))

            except KeyboardInterrupt:
                console.print("\n[yellow]Use /quit to exit[/yellow]")
            except EOFError:
                break

        console.print("[bold green]Goodbye![/bold green]")

    def _startup_check(self) -> None:
        """Perform startup health checks."""
        console.print("[dim]Checking LocalAI connection...[/dim]")

        async def check():
            return await self.engine.health_check()

        try:
            healthy = asyncio.run(check())
            if healthy:
                console.print("[green]✓ LocalAI connected[/green]")
                # Pre-initialize registry
                tools = self.registry.list_tools()
                console.print(f"[green]✓ {len(tools)} tools loaded[/green]\n")
            else:
                console.print("[yellow]⚠ LocalAI not responding[/yellow]")
                console.print(f"[dim]  Expected at: {self.config.inference.base_url}[/dim]\n")
        except Exception as e:
            console.print(f"[yellow]⚠ LocalAI check failed: {e}[/yellow]\n")

    def _run_tui(self) -> None:
        """Run TUI dashboard mode."""
        console.print("[yellow]TUI mode not yet implemented. Coming in Phase 8.[/yellow]")
        console.print("Falling back to REPL mode...\n")
        self._run_repl()

    def _run_voice(self) -> None:
        """Run voice interface mode."""
        console.print("[yellow]Voice mode not yet implemented. Coming in Phase 7.[/yellow]")
        console.print("Falling back to REPL mode...\n")
        self._run_repl()

    def _print_banner(self) -> None:
        """Print welcome banner."""
        banner = """
[bold blue]╔═══════════════════════════════════════════════════════════╗
║                      SOVEREIGN                              ║
║     Sovereign Omniscient Virtual Executive Runtime for      ║
║     Enhanced Intelligence and Generative Navigation         ║
╚═══════════════════════════════════════════════════════════╝[/bold blue]

[dim]Version 1.0.0 • LocalAI Backend • Type /help for commands[/dim]
"""
        console.print(banner)

    def _handle_command(self, command: str) -> None:
        """Handle slash commands."""
        cmd = command.lower().strip()

        if cmd in ("/quit", "/exit", "/q"):
            self.running = False

        elif cmd in ("/help", "/h", "/?"):
            self._print_help()

        elif cmd == "/clear":
            console.clear()
            self._print_banner()

        elif cmd == "/model":
            console.print(f"Current model: [bold]{self.config.inference.default_model}[/bold]")
            console.print(f"Available: {list(self.config.inference.models.keys())}")

        elif cmd.startswith("/model "):
            model_name = cmd.split(" ", 1)[1]
            if model_name in self.config.inference.models:
                self.config.inference.default_model = model_name
                console.print(f"[green]Switched to model: {model_name}[/green]")
            else:
                console.print(f"[red]Unknown model: {model_name}[/red]")

        elif cmd == "/tools":
            console.print("[bold]Available Tools:[/bold]")
            tools = self.registry.get_all()
            for name, tool in tools.items():
                desc = tool.description[:60] + "..." if len(tool.description) > 60 else tool.description
                console.print(f"  • [cyan]{name}[/cyan]: {desc}")

        elif cmd == "/memory":
            console.print("[bold]Memory Status:[/bold]")
            console.print("  Knowledge Graph: [yellow]Not initialized[/yellow]")
            console.print("  Vector Store: [yellow]Not connected[/yellow]")

        elif cmd == "/costs":
            self._print_costs()

        elif cmd == "/router":
            self._print_router_stats()

        elif cmd == "/status":
            self._print_status()

        elif cmd.startswith("/loop "):
            task = cmd.split(" ", 1)[1] if " " in cmd else ""
            if task:
                asyncio.run(self._run_ralph_loop(task))
            else:
                console.print("[yellow]Usage: /loop <task description>[/yellow]")

        elif cmd == "/loop":
            console.print("[yellow]Usage: /loop <task description>[/yellow]")
            console.print("[dim]Example: /loop Build a REST API with user authentication[/dim]")

        else:
            console.print(f"[red]Unknown command: {cmd}[/red]")
            console.print("Type /help for available commands")

    def _print_help(self) -> None:
        """Print help message."""
        help_text = """
## Commands

| Command | Description |
|---------|-------------|
| `/help` | Show this help |
| `/quit` | Exit SOVEREIGN |
| `/clear` | Clear screen |
| `/model` | Show/change model |
| `/tools` | List available tools |
| `/memory` | Show memory status |
| `/costs` | Show cost tracking |
| `/router` | Show routing stats |
| `/status` | Show system status |
| `/loop <task>` | Start autonomous loop |

## Usage

Just type your request and press Enter. SOVEREIGN will:
1. Think about your request
2. Choose appropriate tools
3. Execute actions
4. Provide results

## Examples

- "List all Python files in the current directory"
- "Create a function that calculates fibonacci numbers"
- "Explain what this code does: <paste code>"
"""
        console.print(Markdown(help_text))

    def _print_status(self) -> None:
        """Print system status."""
        # Check LocalAI health
        async def check_health():
            return await self.engine.health_check()

        try:
            healthy = asyncio.run(check_health())
            localai_status = "[green]Connected[/green]" if healthy else "[red]Offline[/red]"
        except Exception:
            localai_status = "[red]Error[/red]"

        # Get tool count
        tool_count = len(self.registry.list_tools())

        # Get cost info
        cost_stats = self.cost_tracker.stats()
        session_cost = cost_stats["session_cost"]
        daily_cost = cost_stats["daily_cost"]

        status = f"""
[bold]System Status[/bold]

• LocalAI: {localai_status}
• Model: {self.config.inference.default_model}
• Tools: [cyan]{tool_count} registered[/cyan]
• Router: [green]FrugalGPT (prefer local)[/green]
• Costs: [cyan]${session_cost:.4f}[/cyan] session / [cyan]${daily_cost:.4f}[/cyan] daily
• Memory: [yellow]Not initialized[/yellow]
• Voice: {"[green]Enabled[/green]" if self.voice_enabled else "[dim]Disabled[/dim]"}
• TUI: {"[green]Enabled[/green]" if self.tui_enabled else "[dim]Disabled[/dim]"}
"""
        console.print(Panel(status, title="SOVEREIGN Status"))

    def _print_costs(self) -> None:
        """Print cost tracking information."""
        stats = self.cost_tracker.stats()

        costs = f"""
[bold]Cost Tracking[/bold]

Session: [cyan]${stats['session_cost']:.4f}[/cyan] / ${stats['limits']['per_session']:.2f}
Daily:   [cyan]${stats['daily_cost']:.4f}[/cyan] / ${stats['limits']['per_day']:.2f}

[bold]Remaining Budget:[/bold]
• Session: [green]${stats['session_remaining']:.2f}[/green]
• Daily:   [green]${stats['daily_remaining']:.2f}[/green]

[bold]Usage by Model:[/bold]"""

        console.print(Panel(costs, title="Cost Tracker"))

        model_costs = stats.get("model_costs", {})
        model_tokens = stats.get("model_tokens", {})
        if model_costs:
            for model, cost in model_costs.items():
                tokens = model_tokens.get(model, 0)
                console.print(f"  • [cyan]{model}[/cyan]: ${cost:.4f} ({tokens:,} tokens)")
        else:
            console.print("  [dim]No usage recorded yet[/dim]")

    def _print_router_stats(self) -> None:
        """Print smart router statistics."""
        stats = self.router.stats()

        router_info = f"""
[bold]Smart Router (FrugalGPT)[/bold]

Strategy: [green]Prefer local models, escalate on quality[/green]
Quality Threshold: {self.router.quality_threshold * 100:.0f}%

[bold]Routing History:[/bold]
• Total Decisions: {stats['total_decisions']}
• Unique Task Types: {stats['unique_fingerprints']}
• Total Cost: [cyan]${stats['total_cost']:.4f}[/cyan]
• Total Tokens: {stats['total_tokens']:,}

[bold]Tier Usage:[/bold]"""

        console.print(Panel(router_info, title="Smart Router"))

        tier_usage = stats.get("tier_usage", {})
        if tier_usage:
            for tier, count in tier_usage.items():
                console.print(f"  • [cyan]{tier}[/cyan]: {count} calls")
        else:
            console.print("  [dim]No routing history yet[/dim]")

    async def _process_input(self, user_input: str) -> None:
        """Process user input through the ReAct loop.

        Args:
            user_input: The user's input text
        """
        # Use router to select optimal model tier
        routing_decision = self.router.select_tier(user_input)
        console.print(f"\n[dim]Routing: {routing_decision.tier.value} ({routing_decision.reason})[/dim]")

        # Check cost limits before proceeding
        try:
            allowed, warning = self.cost_tracker.check_limits(routing_decision.estimated_cost)
            if warning:
                console.print(f"[yellow]⚠ {warning}[/yellow]")
        except Exception as cost_error:
            console.print(f"[red]Cost limit exceeded: {cost_error}[/red]")
            return

        console.print("[dim]Thinking...[/dim]")

        try:
            # Run through the ReAct loop with tool support
            result = await self.react_loop.run(user_input)

            # Record cost (estimate tokens from result)
            estimated_tokens = result.total_tokens if result.total_tokens > 0 else 500
            tier_config = self.router.get_tier_config(routing_decision.tier)
            actual_cost = (estimated_tokens / 1_000_000) * tier_config.cost_per_million_tokens

            self.cost_tracker.record(
                amount=actual_cost,
                tokens=estimated_tokens,
                model=routing_decision.model_id,
            )

            # Record routing result for learning
            self.router.record_result(
                decision=routing_decision,
                success=result.success,
                actual_quality=1.0 if result.success else 0.5,
                actual_tokens=estimated_tokens,
            )

            # Display steps if any tools were used
            if len(result.steps) > 1:
                console.print(f"\n[dim]({len(result.steps)} reasoning steps)[/dim]")

            # Display the final answer
            if result.success:
                console.print(f"\n[green]{result.answer}[/green]")
            else:
                error_msg = result.error or "Unknown error"
                console.print(f"\n[yellow]Incomplete: {error_msg}[/yellow]")
                if result.answer:
                    console.print(f"[dim]Partial result: {result.answer}[/dim]")

        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]")
            console.print(f"[dim]Ensure LocalAI is running at {self.config.inference.base_url}[/dim]")

    async def _run_ralph_loop(self, task: str) -> None:
        """Run autonomous Ralph loop on a task.

        Args:
            task: Task description
        """
        from pathlib import Path

        from sovereign.autonomy.ralph_loop import LoopConfig, LoopStatus, RalphLoop

        console.print(f"\n[bold blue]Starting Ralph Loop[/bold blue]")
        console.print(f"[dim]Task: {task}[/dim]")
        console.print("[dim]Press Ctrl+C to pause[/dim]\n")

        # Configure the loop
        metrics_path = Path.home() / ".sovereign" / "ralph_metrics.json"
        config = LoopConfig(
            max_iterations=30,
            quality_gate_enabled=True,
            circuit_breaker_enabled=True,
            max_no_change_iterations=5,
            max_same_error_count=3,
            iteration_delay=0.5,
            metrics_path=str(metrics_path),
        )

        loop = RalphLoop(config=config)

        # Define iteration handler using ReAct loop
        async def iteration_handler(
            iteration: int, context: dict
        ) -> tuple[str, bool, bool]:
            """Handle a single Ralph iteration."""
            console.print(f"\n[cyan]{'─' * 50}[/cyan]")
            console.print(f"[bold cyan]Iteration {iteration}[/bold cyan]")
            console.print(f"[cyan]{'─' * 50}[/cyan]")

            # Build prompt with task and iteration context
            prompt = f"""Task: {context.get('task', task)}

Iteration {iteration} of autonomous development.
Previous iterations summary: {context.get('summary', 'None yet')}

Please make progress on this task. When you have fully completed all requirements, respond with TASK_COMPLETE.
If you cannot complete more work, explain why.
"""
            # Run through ReAct loop
            result = await self.react_loop.run(prompt)

            # Display verbose ReAct steps
            if result.steps:
                console.print(f"\n[dim]ReAct Steps ({len(result.steps)}):[/dim]")
                for i, step in enumerate(result.steps, 1):
                    thought_preview = step.thought[:80] + "..." if len(step.thought) > 80 else step.thought
                    console.print(f"  [dim]{i}. {thought_preview}[/dim]")
                    if step.action:
                        console.print(f"     [cyan]→ {step.action}[/cyan]")

            # Update context with summary
            if result.success:
                context["summary"] = result.answer[:200] + "..." if len(result.answer) > 200 else result.answer

            # Determine if changes were made (heuristic)
            changes_made = any(
                step.action in ("write", "edit", "bash")
                for step in result.steps
                if step.action
            )

            # IMPROVED: Only allow completion if ReAct loop succeeded AND didn't hit max iterations
            is_complete = False
            if result.success and result.error != "max_iterations_exceeded":
                # Check for explicit completion signal in answer
                is_complete = "TASK_COMPLETE" in (result.answer or "").upper()

                # Also check if the last step indicates completion
                if result.steps and result.steps[-1].is_final:
                    answer_text = result.steps[-1].observation or ""
                    if "TASK_COMPLETE" in answer_text.upper():
                        is_complete = True

            # Display iteration result with more context
            console.print("")
            if result.success:
                if is_complete:
                    console.print("[bold green]✓ TASK COMPLETED[/bold green]")
                else:
                    console.print("[green]✓ Iteration successful[/green]")
                answer_preview = result.answer[:150] + "..." if len(result.answer) > 150 else result.answer
                console.print(f"[dim]{answer_preview}[/dim]")
            else:
                console.print(f"[yellow]✗ {result.error or 'Failed'}[/yellow]")
                if result.answer:
                    console.print(f"[dim]Partial: {result.answer[:100]}...[/dim]")

            if changes_made:
                console.print("[cyan]  ↳ Files modified[/cyan]")

            return result.answer or "", changes_made, is_complete

        try:
            # Run the loop
            metrics = await loop.run(task, iteration_handler)

            # Display results
            console.print(f"\n[bold]Ralph Loop Complete[/bold]")
            console.print(f"Status: [cyan]{metrics.status.value}[/cyan]")
            console.print(f"Iterations: {metrics.iterations_completed}")
            console.print(f"Successful: [green]{metrics.successful_iterations}[/green]")
            console.print(f"Failed: [red]{metrics.failed_iterations}[/red]")
            console.print(f"Changes Made: {metrics.changes_made}")
            console.print(f"Duration: {metrics.total_duration_seconds:.1f}s")

            if metrics.breaker_trips > 0:
                console.print(f"[yellow]Circuit Breaker Trips: {metrics.breaker_trips}[/yellow]")
            if metrics.quality_blocks > 0:
                console.print(f"[yellow]Quality Gate Blocks: {metrics.quality_blocks}[/yellow]")

        except KeyboardInterrupt:
            loop.cancel()
            summary = loop.get_summary()
            console.print("\n[yellow]Ralph loop paused[/yellow]")
            console.print(f"Completed {summary['iterations']} iterations")
        except Exception as e:
            console.print(f"\n[red]Ralph loop error: {e}[/red]")
