"""Enhanced Ralph Loop for autonomous task execution."""

from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from sovereign.autonomy.circuit_breaker import BreakerConfig, CircuitBreaker
from sovereign.autonomy.quality_gate import QualityCheck, QualityGate


class LoopStatus(Enum):
    """Status of the Ralph loop."""

    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    BREAKER_OPEN = "breaker_open"
    QUALITY_BLOCKED = "quality_blocked"


@dataclass
class LoopConfig:
    """Configuration for Ralph loop."""

    max_iterations: int = 50
    completion_promise: str | None = None
    quality_gate_enabled: bool = True
    circuit_breaker_enabled: bool = True
    max_no_change_iterations: int = 5
    max_same_error_count: int = 3
    iteration_delay: float = 1.0
    checkpoint_interval: int = 10
    metrics_path: str | None = None


@dataclass
class IterationResult:
    """Result of a single iteration."""

    iteration: int
    success: bool
    output: Any
    error: str | None = None
    changes_made: bool = False
    quality_passed: bool = True
    duration_seconds: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class LoopMetrics:
    """Metrics from loop execution."""

    loop_id: str
    task: str
    status: LoopStatus
    iterations_completed: int
    successful_iterations: int
    failed_iterations: int
    total_duration_seconds: float
    breaker_trips: int
    quality_blocks: int
    changes_made: int
    started_at: datetime
    completed_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "loop_id": self.loop_id,
            "task": self.task,
            "status": self.status.value,
            "iterations_completed": self.iterations_completed,
            "successful_iterations": self.successful_iterations,
            "failed_iterations": self.failed_iterations,
            "total_duration_seconds": self.total_duration_seconds,
            "breaker_trips": self.breaker_trips,
            "quality_blocks": self.quality_blocks,
            "changes_made": self.changes_made,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


# Type for iteration handler
IterationHandler = Callable[
    [int, dict[str, Any]],  # iteration number, context
    Awaitable[tuple[Any, bool, bool]],  # output, changes_made, is_complete
]


class RalphLoop:
    """Enhanced autonomous loop with quality gates and circuit breakers.

    The "Ralph Wiggum" technique: Keep iterating until done, but with
    safety rails to prevent runaway execution.
    """

    def __init__(
        self,
        config: LoopConfig | None = None,
        quality_checks: list[QualityCheck] | None = None,
    ) -> None:
        """Initialize Ralph loop.

        Args:
            config: Loop configuration
            quality_checks: Quality checks to run
        """
        self.config = config or LoopConfig()

        # Initialize circuit breaker
        breaker_config = BreakerConfig(
            max_no_change=self.config.max_no_change_iterations,
            max_same_error=self.config.max_same_error_count,
        )
        self.circuit_breaker = CircuitBreaker(breaker_config)

        # Initialize quality gate
        self.quality_gate = QualityGate(checks=quality_checks or [])

        # State
        self._status = LoopStatus.IDLE
        self._results: list[IterationResult] = []
        self._context: dict[str, Any] = {}
        self._current_iteration = 0
        self._cancel_requested = False

    @property
    def status(self) -> LoopStatus:
        """Current loop status."""
        return self._status

    @property
    def results(self) -> list[IterationResult]:
        """Results from all iterations."""
        return self._results

    def add_quality_check(self, check: QualityCheck) -> None:
        """Add a quality check.

        Args:
            check: Quality check to add
        """
        self.quality_gate.add_check(check)

    async def run(
        self,
        task: str,
        handler: IterationHandler,
        initial_context: dict[str, Any] | None = None,
    ) -> LoopMetrics:
        """Run the autonomous loop.

        Args:
            task: Task description
            handler: Async function called each iteration
            initial_context: Initial context data

        Returns:
            LoopMetrics with execution statistics
        """
        loop_id = f"ralph_{datetime.now().timestamp()}"
        self._status = LoopStatus.RUNNING
        self._results = []
        self._context = initial_context or {}
        self._context["task"] = task
        self._cancel_requested = False

        metrics = LoopMetrics(
            loop_id=loop_id,
            task=task,
            status=LoopStatus.RUNNING,
            iterations_completed=0,
            successful_iterations=0,
            failed_iterations=0,
            total_duration_seconds=0,
            breaker_trips=0,
            quality_blocks=0,
            changes_made=0,
            started_at=datetime.now(),
        )

        start_time = datetime.now()

        try:
            for iteration in range(1, self.config.max_iterations + 1):
                self._current_iteration = iteration

                # Check for cancellation
                if self._cancel_requested:
                    self._status = LoopStatus.PAUSED
                    break

                # Check circuit breaker
                if self.config.circuit_breaker_enabled:
                    if not self.circuit_breaker.allow_request():
                        self._status = LoopStatus.BREAKER_OPEN
                        metrics.breaker_trips += 1
                        break

                # Execute iteration
                iter_start = datetime.now()
                try:
                    output, changes_made, is_complete = await handler(
                        iteration,
                        self._context,
                    )
                    success = True
                    error = None
                except Exception as e:
                    output = None
                    changes_made = False
                    is_complete = False
                    success = False
                    error = str(e)

                iter_duration = (datetime.now() - iter_start).total_seconds()

                # Run quality gate if enabled
                quality_passed = True
                if self.config.quality_gate_enabled and success:
                    gate_result = await self.quality_gate.evaluate(
                        output,
                        self._context,
                    )
                    quality_passed = gate_result.passed
                    if not quality_passed:
                        metrics.quality_blocks += 1

                # Record result
                result = IterationResult(
                    iteration=iteration,
                    success=success,
                    output=output,
                    error=error,
                    changes_made=changes_made,
                    quality_passed=quality_passed,
                    duration_seconds=iter_duration,
                )
                self._results.append(result)

                # Update metrics
                metrics.iterations_completed = iteration
                if success:
                    metrics.successful_iterations += 1
                else:
                    metrics.failed_iterations += 1
                if changes_made:
                    metrics.changes_made += 1

                # Record for circuit breaker
                self.circuit_breaker.record_result(
                    success=success,
                    changes_made=changes_made,
                    error=error,
                )

                # Check completion
                if is_complete and success and quality_passed:
                    if self._check_promise(output):
                        self._status = LoopStatus.COMPLETED
                        break

                # Delay between iterations
                if self.config.iteration_delay > 0:
                    await asyncio.sleep(self.config.iteration_delay)

            # Check if we exhausted iterations
            if self._status == LoopStatus.RUNNING:
                self._status = LoopStatus.FAILED

        except Exception as e:
            self._status = LoopStatus.FAILED
            # Record the exception
            self._results.append(
                IterationResult(
                    iteration=self._current_iteration,
                    success=False,
                    output=None,
                    error=str(e),
                )
            )

        # Finalize metrics
        metrics.status = self._status
        metrics.completed_at = datetime.now()
        metrics.total_duration_seconds = (
            metrics.completed_at - start_time
        ).total_seconds()

        # Save metrics if configured
        if self.config.metrics_path:
            self._save_metrics(metrics)

        return metrics

    def _check_promise(self, output: Any) -> bool:
        """Check if completion promise is satisfied.

        Args:
            output: Output from iteration

        Returns:
            True if promise satisfied
        """
        if self.config.completion_promise is None:
            return True

        # Check if promise string appears in output
        if isinstance(output, str):
            return self.config.completion_promise in output
        if isinstance(output, dict):
            output_str = json.dumps(output)
            return self.config.completion_promise in output_str

        return False

    def cancel(self) -> None:
        """Request cancellation of the loop."""
        self._cancel_requested = True

    def pause(self) -> None:
        """Pause the loop (alias for cancel)."""
        self.cancel()

    def reset(self) -> None:
        """Reset loop state for reuse."""
        self._status = LoopStatus.IDLE
        self._results = []
        self._context = {}
        self._current_iteration = 0
        self._cancel_requested = False
        self.circuit_breaker.reset()

    def _save_metrics(self, metrics: LoopMetrics) -> None:
        """Save metrics to file.

        Args:
            metrics: Metrics to save
        """
        if self.config.metrics_path is None:
            return

        path = Path(self.config.metrics_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        # Append to existing metrics file
        existing: list[dict[str, Any]] = []
        if path.exists():
            with open(path) as f:
                existing = json.load(f)

        existing.append(metrics.to_dict())

        with open(path, "w") as f:
            json.dump(existing, f, indent=2)

    def get_summary(self) -> dict[str, Any]:
        """Get a summary of the loop execution.

        Returns:
            Summary dictionary
        """
        if not self._results:
            return {
                "status": self._status.value,
                "iterations": 0,
                "message": "No iterations completed",
            }

        return {
            "status": self._status.value,
            "iterations": len(self._results),
            "successful": sum(1 for r in self._results if r.success),
            "failed": sum(1 for r in self._results if not r.success),
            "changes_made": sum(1 for r in self._results if r.changes_made),
            "quality_passed": sum(1 for r in self._results if r.quality_passed),
            "total_duration": sum(r.duration_seconds for r in self._results),
            "last_output": self._results[-1].output if self._results else None,
            "last_error": self._results[-1].error if self._results else None,
        }


async def run_ralph_enhanced(
    task: str,
    handler: IterationHandler,
    max_iterations: int = 50,
    completion_promise: str | None = None,
    quality_checks: list[QualityCheck] | None = None,
    quality_gate_enabled: bool = True,
    initial_context: dict[str, Any] | None = None,
) -> LoopMetrics:
    """Convenience function to run Ralph Enhanced loop.

    Args:
        task: Task description
        handler: Iteration handler function
        max_iterations: Maximum iterations
        completion_promise: String that must appear in output for completion
        quality_checks: Quality checks to run
        quality_gate_enabled: Whether to run quality checks
        initial_context: Initial context data

    Returns:
        LoopMetrics with execution statistics
    """
    config = LoopConfig(
        max_iterations=max_iterations,
        completion_promise=completion_promise,
        quality_gate_enabled=quality_gate_enabled,
    )

    loop = RalphLoop(config=config, quality_checks=quality_checks)
    return await loop.run(task, handler, initial_context)
