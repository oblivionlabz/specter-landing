"""Adaptive Circuit Breaker for autonomous loop safety."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any


class CircuitState(Enum):
    """State of the circuit breaker."""

    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Blocking requests
    HALF_OPEN = "half_open"  # Testing if recovery possible


@dataclass
class BreakerConfig:
    """Configuration for circuit breaker."""

    max_no_change: int = 5  # Open after N iterations with no changes
    max_same_error: int = 3  # Open after N same errors
    max_consecutive_failures: int = 5  # Open after N consecutive failures
    recovery_timeout: float = 30.0  # Seconds before trying half-open
    half_open_max_calls: int = 3  # Calls allowed in half-open state
    cooldown_multiplier: float = 2.0  # Increase recovery timeout on repeated trips


@dataclass
class BreakerStats:
    """Statistics for circuit breaker."""

    state: CircuitState
    total_calls: int
    successful_calls: int
    failed_calls: int
    no_change_streak: int
    same_error_streak: int
    consecutive_failures: int
    times_opened: int
    last_failure_time: datetime | None
    last_error: str | None


class CircuitBreaker:
    """Adaptive circuit breaker that detects stuck states.

    Prevents infinite loops by detecting patterns:
    - No changes being made (stuck in same state)
    - Same error repeating (unable to fix)
    - Consecutive failures (systemic issue)
    """

    def __init__(self, config: BreakerConfig | None = None) -> None:
        """Initialize circuit breaker.

        Args:
            config: Breaker configuration
        """
        self.config = config or BreakerConfig()

        # State
        self._state = CircuitState.CLOSED
        self._total_calls = 0
        self._successful_calls = 0
        self._failed_calls = 0

        # Streak tracking
        self._no_change_streak = 0
        self._same_error_streak = 0
        self._consecutive_failures = 0
        self._last_error: str | None = None

        # Timing
        self._last_failure_time: datetime | None = None
        self._last_state_change: datetime = datetime.now()
        self._times_opened = 0
        self._current_recovery_timeout = self.config.recovery_timeout

        # Half-open tracking
        self._half_open_calls = 0

    @property
    def state(self) -> CircuitState:
        """Current circuit state."""
        self._check_recovery()
        return self._state

    @property
    def is_open(self) -> bool:
        """Check if circuit is open (blocking)."""
        return self.state == CircuitState.OPEN

    @property
    def is_closed(self) -> bool:
        """Check if circuit is closed (allowing)."""
        return self.state == CircuitState.CLOSED

    def allow_request(self) -> bool:
        """Check if a request should be allowed.

        Returns:
            True if request allowed
        """
        current_state = self.state

        if current_state == CircuitState.CLOSED:
            return True

        if current_state == CircuitState.HALF_OPEN:
            if self._half_open_calls < self.config.half_open_max_calls:
                self._half_open_calls += 1
                return True
            return False

        # State is OPEN
        return False

    def record_result(
        self,
        success: bool,
        changes_made: bool = True,
        error: str | None = None,
    ) -> None:
        """Record the result of an operation.

        Args:
            success: Whether operation succeeded
            changes_made: Whether any changes were made
            error: Error message if failed
        """
        self._total_calls += 1

        if success:
            self._successful_calls += 1
            self._consecutive_failures = 0

            if changes_made:
                self._no_change_streak = 0
            else:
                self._no_change_streak += 1

            # Reset same error streak on success
            self._same_error_streak = 0
            self._last_error = None

            # If in half-open and successful, close the circuit
            if self._state == CircuitState.HALF_OPEN:
                self._close_circuit()

        else:
            self._failed_calls += 1
            self._consecutive_failures += 1
            self._last_failure_time = datetime.now()
            self._no_change_streak += 1  # Failures don't make changes

            # Track same error
            if error:
                if error == self._last_error:
                    self._same_error_streak += 1
                else:
                    self._same_error_streak = 1
                    self._last_error = error

        # Check if we should open the circuit
        self._check_thresholds()

    def _check_thresholds(self) -> None:
        """Check if any threshold exceeded to open circuit."""
        should_open = False
        reason = ""

        if self._no_change_streak >= self.config.max_no_change:
            should_open = True
            reason = f"No changes for {self._no_change_streak} iterations"

        elif self._same_error_streak >= self.config.max_same_error:
            should_open = True
            reason = f"Same error repeated {self._same_error_streak} times"

        elif self._consecutive_failures >= self.config.max_consecutive_failures:
            should_open = True
            reason = f"{self._consecutive_failures} consecutive failures"

        if should_open and self._state != CircuitState.OPEN:
            self._open_circuit(reason)

    def _check_recovery(self) -> None:
        """Check if circuit should transition to half-open."""
        if self._state != CircuitState.OPEN:
            return

        elapsed = (datetime.now() - self._last_state_change).total_seconds()
        if elapsed >= self._current_recovery_timeout:
            self._half_open_circuit()

    def _open_circuit(self, reason: str = "") -> None:
        """Open the circuit (start blocking)."""
        self._state = CircuitState.OPEN
        self._last_state_change = datetime.now()
        self._times_opened += 1

        # Increase recovery timeout on repeated trips
        if self._times_opened > 1:
            self._current_recovery_timeout = min(
                self._current_recovery_timeout * self.config.cooldown_multiplier,
                300.0,  # Max 5 minutes
            )

    def _half_open_circuit(self) -> None:
        """Transition to half-open (testing recovery)."""
        self._state = CircuitState.HALF_OPEN
        self._last_state_change = datetime.now()
        self._half_open_calls = 0

    def _close_circuit(self) -> None:
        """Close the circuit (resume normal operation)."""
        self._state = CircuitState.CLOSED
        self._last_state_change = datetime.now()
        self._no_change_streak = 0
        self._same_error_streak = 0
        self._consecutive_failures = 0

        # Reset recovery timeout on successful recovery
        self._current_recovery_timeout = self.config.recovery_timeout

    def reset(self) -> None:
        """Reset the circuit breaker to initial state."""
        self._state = CircuitState.CLOSED
        self._total_calls = 0
        self._successful_calls = 0
        self._failed_calls = 0
        self._no_change_streak = 0
        self._same_error_streak = 0
        self._consecutive_failures = 0
        self._last_error = None
        self._last_failure_time = None
        self._last_state_change = datetime.now()
        self._times_opened = 0
        self._current_recovery_timeout = self.config.recovery_timeout
        self._half_open_calls = 0

    def force_open(self) -> None:
        """Force the circuit open."""
        self._open_circuit("Manually forced open")

    def force_close(self) -> None:
        """Force the circuit closed."""
        self._close_circuit()

    def get_stats(self) -> BreakerStats:
        """Get current breaker statistics.

        Returns:
            BreakerStats with current state
        """
        return BreakerStats(
            state=self._state,
            total_calls=self._total_calls,
            successful_calls=self._successful_calls,
            failed_calls=self._failed_calls,
            no_change_streak=self._no_change_streak,
            same_error_streak=self._same_error_streak,
            consecutive_failures=self._consecutive_failures,
            times_opened=self._times_opened,
            last_failure_time=self._last_failure_time,
            last_error=self._last_error,
        )

    def get_health(self) -> dict[str, Any]:
        """Get health status.

        Returns:
            Health dictionary
        """
        stats = self.get_stats()

        # Calculate health score (0-100)
        health_score = 100

        if stats.total_calls > 0:
            failure_rate = stats.failed_calls / stats.total_calls
            health_score -= int(failure_rate * 50)

        health_score -= min(stats.no_change_streak * 5, 25)
        health_score -= min(stats.same_error_streak * 10, 25)
        health_score = max(0, health_score)

        return {
            "state": stats.state.value,
            "health_score": health_score,
            "total_calls": stats.total_calls,
            "success_rate": (
                stats.successful_calls / stats.total_calls
                if stats.total_calls > 0
                else 1.0
            ),
            "no_change_streak": stats.no_change_streak,
            "same_error_streak": stats.same_error_streak,
            "times_opened": stats.times_opened,
            "recovery_timeout": self._current_recovery_timeout,
        }


class AdaptiveBreaker(CircuitBreaker):
    """Circuit breaker that adapts thresholds based on history."""

    def __init__(
        self,
        config: BreakerConfig | None = None,
        learning_rate: float = 0.1,
    ) -> None:
        """Initialize adaptive breaker.

        Args:
            config: Breaker configuration
            learning_rate: How quickly to adapt (0-1)
        """
        super().__init__(config)
        self.learning_rate = learning_rate
        self._success_history: list[bool] = []
        self._change_history: list[bool] = []

    def record_result(
        self,
        success: bool,
        changes_made: bool = True,
        error: str | None = None,
    ) -> None:
        """Record result and adapt thresholds.

        Args:
            success: Whether operation succeeded
            changes_made: Whether changes were made
            error: Error message if failed
        """
        # Record for adaptation
        self._success_history.append(success)
        self._change_history.append(changes_made)

        # Keep last 100 entries
        if len(self._success_history) > 100:
            self._success_history = self._success_history[-100:]
            self._change_history = self._change_history[-100:]

        # Adapt thresholds periodically
        if len(self._success_history) % 20 == 0:
            self._adapt_thresholds()

        # Call parent
        super().record_result(success, changes_made, error)

    def _adapt_thresholds(self) -> None:
        """Adapt thresholds based on history."""
        if len(self._success_history) < 20:
            return

        recent_success = self._success_history[-20:]
        recent_changes = self._change_history[-20:]

        success_rate = sum(recent_success) / len(recent_success)
        change_rate = sum(recent_changes) / len(recent_changes)

        # If high success rate, we can be more tolerant
        if success_rate > 0.9:
            self.config.max_consecutive_failures = min(
                self.config.max_consecutive_failures + 1,
                10,
            )

        # If low change rate is normal, increase tolerance
        if change_rate < 0.3 and success_rate > 0.7:
            self.config.max_no_change = min(
                self.config.max_no_change + 1,
                15,
            )
