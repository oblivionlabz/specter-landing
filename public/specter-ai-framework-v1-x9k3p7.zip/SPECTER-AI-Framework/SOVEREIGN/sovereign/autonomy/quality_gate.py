"""Quality Gate for enforcing standards before completion."""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable


class GateDecision(Enum):
    """Decision from quality gate."""

    PASS = "pass"
    WARN = "warn"
    BLOCK = "block"


@dataclass
class QualityResult:
    """Result from a quality check."""

    check_name: str
    decision: GateDecision
    score: float  # 0-100
    message: str
    details: dict[str, Any] = field(default_factory=dict)
    duration_seconds: float = 0.0


@dataclass
class GateResult:
    """Aggregate result from quality gate."""

    passed: bool
    decision: GateDecision
    overall_score: float
    results: list[QualityResult]
    blocking_checks: list[str]
    warning_checks: list[str]
    timestamp: datetime = field(default_factory=datetime.now)


class QualityCheck(ABC):
    """Abstract base class for quality checks."""

    def __init__(
        self,
        name: str,
        threshold_warn: float = 70.0,
        threshold_block: float = 50.0,
        weight: float = 1.0,
    ) -> None:
        """Initialize quality check.

        Args:
            name: Check name
            threshold_warn: Score below this triggers warning
            threshold_block: Score below this blocks
            weight: Weight in overall score calculation
        """
        self.name = name
        self.threshold_warn = threshold_warn
        self.threshold_block = threshold_block
        self.weight = weight

    @abstractmethod
    async def evaluate(
        self,
        output: Any,
        context: dict[str, Any],
    ) -> QualityResult:
        """Evaluate quality.

        Args:
            output: Output to evaluate
            context: Execution context

        Returns:
            QualityResult
        """
        pass

    def _make_decision(self, score: float) -> GateDecision:
        """Make decision based on score.

        Args:
            score: Quality score (0-100)

        Returns:
            GateDecision
        """
        if score < self.threshold_block:
            return GateDecision.BLOCK
        elif score < self.threshold_warn:
            return GateDecision.WARN
        return GateDecision.PASS


class FunctionCheck(QualityCheck):
    """Quality check using a custom function."""

    def __init__(
        self,
        name: str,
        check_func: Callable[[Any, dict[str, Any]], Awaitable[tuple[float, str]]],
        threshold_warn: float = 70.0,
        threshold_block: float = 50.0,
        weight: float = 1.0,
    ) -> None:
        """Initialize function check.

        Args:
            name: Check name
            check_func: Async function returning (score, message)
            threshold_warn: Warning threshold
            threshold_block: Block threshold
            weight: Weight in overall score
        """
        super().__init__(name, threshold_warn, threshold_block, weight)
        self.check_func = check_func

    async def evaluate(
        self,
        output: Any,
        context: dict[str, Any],
    ) -> QualityResult:
        """Evaluate using custom function."""
        start = datetime.now()

        try:
            score, message = await self.check_func(output, context)
            decision = self._make_decision(score)
        except Exception as e:
            score = 0.0
            message = f"Check failed: {e}"
            decision = GateDecision.BLOCK

        duration = (datetime.now() - start).total_seconds()

        return QualityResult(
            check_name=self.name,
            decision=decision,
            score=score,
            message=message,
            duration_seconds=duration,
        )


class TestCoverageCheck(QualityCheck):
    """Check for test coverage."""

    def __init__(
        self,
        threshold_warn: float = 80.0,
        threshold_block: float = 60.0,
    ) -> None:
        super().__init__(
            name="test_coverage",
            threshold_warn=threshold_warn,
            threshold_block=threshold_block,
        )

    async def evaluate(
        self,
        output: Any,
        context: dict[str, Any],
    ) -> QualityResult:
        """Evaluate test coverage."""
        # Extract coverage from context or output
        coverage = context.get("test_coverage", 0.0)

        if isinstance(output, dict):
            coverage = output.get("coverage", coverage)
            coverage = output.get("test_coverage", coverage)

        decision = self._make_decision(coverage)
        message = f"Test coverage: {coverage:.1f}%"

        return QualityResult(
            check_name=self.name,
            decision=decision,
            score=coverage,
            message=message,
            details={"coverage_percent": coverage},
        )


class LintCheck(QualityCheck):
    """Check for linting issues."""

    def __init__(
        self,
        max_errors: int = 0,
        max_warnings: int = 10,
    ) -> None:
        super().__init__(
            name="lint",
            threshold_warn=80.0,
            threshold_block=50.0,
        )
        self.max_errors = max_errors
        self.max_warnings = max_warnings

    async def evaluate(
        self,
        output: Any,
        context: dict[str, Any],
    ) -> QualityResult:
        """Evaluate lint results."""
        errors = context.get("lint_errors", 0)
        warnings = context.get("lint_warnings", 0)

        if isinstance(output, dict):
            errors = output.get("lint_errors", errors)
            warnings = output.get("lint_warnings", warnings)

        # Calculate score
        if errors > self.max_errors:
            score = 0.0
            decision = GateDecision.BLOCK
        elif warnings > self.max_warnings:
            score = 60.0
            decision = GateDecision.WARN
        else:
            score = 100.0 - (errors * 10) - (warnings * 2)
            score = max(0.0, score)
            decision = self._make_decision(score)

        message = f"Lint: {errors} errors, {warnings} warnings"

        return QualityResult(
            check_name=self.name,
            decision=decision,
            score=score,
            message=message,
            details={"errors": errors, "warnings": warnings},
        )


class TypeCheck(QualityCheck):
    """Check for type errors."""

    def __init__(self, max_errors: int = 0) -> None:
        super().__init__(
            name="type_check",
            threshold_warn=90.0,
            threshold_block=70.0,
        )
        self.max_errors = max_errors

    async def evaluate(
        self,
        output: Any,
        context: dict[str, Any],
    ) -> QualityResult:
        """Evaluate type check results."""
        errors = context.get("type_errors", 0)

        if isinstance(output, dict):
            errors = output.get("type_errors", errors)

        if errors > self.max_errors:
            score = max(0.0, 100.0 - (errors * 10))
            decision = GateDecision.BLOCK
        else:
            score = 100.0
            decision = GateDecision.PASS

        message = f"Type check: {errors} errors"

        return QualityResult(
            check_name=self.name,
            decision=decision,
            score=score,
            message=message,
            details={"errors": errors},
        )


class SecurityCheck(QualityCheck):
    """Check for security issues."""

    def __init__(self) -> None:
        super().__init__(
            name="security",
            threshold_warn=90.0,
            threshold_block=70.0,
            weight=2.0,  # Security is more important
        )

    async def evaluate(
        self,
        output: Any,
        context: dict[str, Any],
    ) -> QualityResult:
        """Evaluate security scan results."""
        critical = context.get("security_critical", 0)
        high = context.get("security_high", 0)
        medium = context.get("security_medium", 0)

        if isinstance(output, dict):
            critical = output.get("security_critical", critical)
            high = output.get("security_high", high)
            medium = output.get("security_medium", medium)

        # Critical or high issues block
        if critical > 0 or high > 0:
            score = 0.0
            decision = GateDecision.BLOCK
        elif medium > 0:
            score = 70.0
            decision = GateDecision.WARN
        else:
            score = 100.0
            decision = GateDecision.PASS

        message = f"Security: {critical} critical, {high} high, {medium} medium"

        return QualityResult(
            check_name=self.name,
            decision=decision,
            score=score,
            message=message,
            details={"critical": critical, "high": high, "medium": medium},
        )


class QualityGate:
    """Aggregates quality checks and makes pass/fail decisions."""

    def __init__(self, checks: list[QualityCheck] | None = None) -> None:
        """Initialize quality gate.

        Args:
            checks: List of quality checks to run
        """
        self._checks: list[QualityCheck] = checks or []

    def add_check(self, check: QualityCheck) -> None:
        """Add a quality check.

        Args:
            check: Check to add
        """
        self._checks.append(check)

    def remove_check(self, name: str) -> bool:
        """Remove a check by name.

        Args:
            name: Check name

        Returns:
            True if removed
        """
        original_len = len(self._checks)
        self._checks = [c for c in self._checks if c.name != name]
        return len(self._checks) < original_len

    async def evaluate(
        self,
        output: Any,
        context: dict[str, Any],
    ) -> GateResult:
        """Run all quality checks.

        Args:
            output: Output to evaluate
            context: Execution context

        Returns:
            GateResult with aggregate decision
        """
        if not self._checks:
            return GateResult(
                passed=True,
                decision=GateDecision.PASS,
                overall_score=100.0,
                results=[],
                blocking_checks=[],
                warning_checks=[],
            )

        # Run all checks in parallel
        tasks = [check.evaluate(output, context) for check in self._checks]
        results = await asyncio.gather(*tasks)

        # Aggregate results
        blocking_checks: list[str] = []
        warning_checks: list[str] = []
        total_weight = 0.0
        weighted_score = 0.0

        for check, result in zip(self._checks, results, strict=False):
            if result.decision == GateDecision.BLOCK:
                blocking_checks.append(result.check_name)
            elif result.decision == GateDecision.WARN:
                warning_checks.append(result.check_name)

            weighted_score += result.score * check.weight
            total_weight += check.weight

        overall_score = weighted_score / total_weight if total_weight > 0 else 0.0

        # Determine overall decision
        if blocking_checks:
            decision = GateDecision.BLOCK
            passed = False
        elif warning_checks:
            decision = GateDecision.WARN
            passed = True  # Warnings don't block
        else:
            decision = GateDecision.PASS
            passed = True

        return GateResult(
            passed=passed,
            decision=decision,
            overall_score=overall_score,
            results=list(results),
            blocking_checks=blocking_checks,
            warning_checks=warning_checks,
        )

    def get_checks(self) -> list[str]:
        """Get list of check names.

        Returns:
            List of check names
        """
        return [c.name for c in self._checks]


def create_default_gate() -> QualityGate:
    """Create a quality gate with default checks.

    Returns:
        QualityGate with standard checks
    """
    return QualityGate(
        checks=[
            TestCoverageCheck(threshold_warn=80.0, threshold_block=60.0),
            LintCheck(max_errors=0, max_warnings=10),
            TypeCheck(max_errors=0),
            SecurityCheck(),
        ]
    )
