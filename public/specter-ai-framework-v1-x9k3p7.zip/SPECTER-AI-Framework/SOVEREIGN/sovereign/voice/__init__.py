"""SOVEREIGN Voice System.

Full voice I/O pipeline with wake word, STT, and TTS.
"""

from sovereign.voice.pipeline import VoiceConfig, VoicePipeline
from sovereign.voice.stt import SpeechToText, TranscriptionResult
from sovereign.voice.tts import TextToSpeech, TTSConfig
from sovereign.voice.wake_word import WakeWordDetector

__all__ = [
    "SpeechToText",
    "TTSConfig",
    "TextToSpeech",
    "TranscriptionResult",
    "VoiceConfig",
    "VoicePipeline",
    "WakeWordDetector",
]
