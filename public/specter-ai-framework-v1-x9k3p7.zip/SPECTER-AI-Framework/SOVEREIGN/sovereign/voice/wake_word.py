"""Wake Word Detection for voice activation."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable


@dataclass
class WakeWordConfig:
    """Configuration for wake word detection."""

    wake_word: str = "hey_sovereign"
    threshold: float = 0.5
    sample_rate: int = 16000
    chunk_size: int = 1280  # 80ms at 16kHz
    model_path: str | None = None


@dataclass
class WakeWordEvent:
    """Event when wake word is detected."""

    wake_word: str
    confidence: float
    timestamp: datetime = field(default_factory=datetime.now)
    audio_data: bytes | None = None


class WakeWordDetector:
    """Wake word detection using OpenWakeWord or simple energy detection.

    Detects activation phrases like "Hey Sovereign" to start voice interaction.
    """

    def __init__(self, config: WakeWordConfig | None = None) -> None:
        """Initialize wake word detector.

        Args:
            config: Detection configuration
        """
        self.config = config or WakeWordConfig()
        self._running = False
        self._listeners: list[Callable[[WakeWordEvent], None]] = []
        self._model: Any = None
        self._use_openwakeword = False

        # Try to load OpenWakeWord
        self._init_model()

    def _init_model(self) -> None:
        """Initialize the wake word model."""
        try:
            # Try OpenWakeWord first
            from openwakeword.model import Model

            self._model = Model(
                wakeword_models=[self.config.wake_word],
                inference_framework="onnx",
            )
            self._use_openwakeword = True
        except ImportError:
            # Fall back to energy-based detection
            self._use_openwakeword = False
            self._model = None

    def on_wake_word(self, callback: Callable[[WakeWordEvent], None]) -> None:
        """Register a callback for wake word detection.

        Args:
            callback: Function to call when wake word detected
        """
        self._listeners.append(callback)

    def remove_listener(self, callback: Callable[[WakeWordEvent], None]) -> bool:
        """Remove a callback.

        Args:
            callback: Callback to remove

        Returns:
            True if removed
        """
        if callback in self._listeners:
            self._listeners.remove(callback)
            return True
        return False

    async def detect(self, audio_chunk: bytes) -> WakeWordEvent | None:
        """Process an audio chunk for wake word detection.

        Args:
            audio_chunk: Raw PCM audio data (16-bit, mono, 16kHz)

        Returns:
            WakeWordEvent if detected, None otherwise
        """
        if self._use_openwakeword and self._model is not None:
            return await self._detect_openwakeword(audio_chunk)
        return self._detect_energy(audio_chunk)

    async def _detect_openwakeword(self, audio_chunk: bytes) -> WakeWordEvent | None:
        """Detect using OpenWakeWord model.

        Args:
            audio_chunk: Audio data

        Returns:
            WakeWordEvent if detected
        """
        import numpy as np

        # Convert bytes to numpy array
        audio_array = np.frombuffer(audio_chunk, dtype=np.int16).astype(np.float32)
        audio_array = audio_array / 32768.0  # Normalize to [-1, 1]

        # Run inference in thread pool to avoid blocking
        loop = asyncio.get_event_loop()
        prediction = await loop.run_in_executor(
            None,
            lambda: self._model.predict(audio_array),
        )

        # Check if any wake word detected
        for wake_word, scores in prediction.items():
            if scores and max(scores) >= self.config.threshold:
                event = WakeWordEvent(
                    wake_word=wake_word,
                    confidence=max(scores),
                    audio_data=audio_chunk,
                )
                self._notify_listeners(event)
                return event

        return None

    def _detect_energy(self, audio_chunk: bytes) -> WakeWordEvent | None:
        """Simple energy-based detection fallback.

        This is a basic implementation that triggers on loud sounds.
        Real usage should use OpenWakeWord for accuracy.

        Args:
            audio_chunk: Audio data

        Returns:
            WakeWordEvent if detected
        """
        import struct

        # Calculate RMS energy
        num_samples = len(audio_chunk) // 2
        if num_samples == 0:
            return None

        samples = struct.unpack(f"{num_samples}h", audio_chunk)
        sum_squares = sum(s * s for s in samples)
        rms = (sum_squares / num_samples) ** 0.5

        # Normalize to 0-1 range (assuming 16-bit audio)
        normalized_rms = rms / 32768.0

        # Trigger on high energy (this is a very basic approach)
        if normalized_rms > 0.1:  # Threshold for "loud" audio
            event = WakeWordEvent(
                wake_word=self.config.wake_word,
                confidence=min(normalized_rms * 2, 1.0),
                audio_data=audio_chunk,
            )
            self._notify_listeners(event)
            return event

        return None

    def _notify_listeners(self, event: WakeWordEvent) -> None:
        """Notify all registered listeners.

        Args:
            event: Wake word event
        """
        for listener in self._listeners:
            try:
                listener(event)
            except Exception:
                pass  # Don't let listener errors stop processing

    async def listen_continuous(
        self,
        audio_source: Any,  # AudioSource protocol
        stop_event: asyncio.Event | None = None,
    ) -> None:
        """Continuously listen for wake word.

        Args:
            audio_source: Source of audio chunks
            stop_event: Event to signal stopping
        """
        self._running = True
        stop = stop_event or asyncio.Event()

        while self._running and not stop.is_set():
            try:
                # Get audio chunk from source
                chunk = await audio_source.read(self.config.chunk_size)
                if chunk:
                    await self.detect(chunk)
            except asyncio.CancelledError:
                break
            except Exception:
                await asyncio.sleep(0.1)

        self._running = False

    def stop(self) -> None:
        """Stop continuous listening."""
        self._running = False

    @property
    def is_running(self) -> bool:
        """Check if detector is running."""
        return self._running

    def stats(self) -> dict[str, Any]:
        """Get detector statistics.

        Returns:
            Statistics dictionary
        """
        return {
            "wake_word": self.config.wake_word,
            "threshold": self.config.threshold,
            "using_openwakeword": self._use_openwakeword,
            "listener_count": len(self._listeners),
            "running": self._running,
        }
