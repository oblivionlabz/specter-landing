"""Speech-to-Text using Whisper."""

from __future__ import annotations

import asyncio
import contextlib
import tempfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any


@dataclass
class TranscriptionResult:
    """Result from speech transcription."""

    text: str
    language: str
    confidence: float
    duration_seconds: float
    segments: list[dict[str, Any]] = field(default_factory=list)
    processing_time: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class STTConfig:
    """Configuration for speech-to-text."""

    model: str = "base.en"  # tiny, base, small, medium, large
    language: str | None = "en"  # None for auto-detect
    device: str = "auto"  # cuda, cpu, auto
    compute_type: str = "float16"  # float16, int8, float32
    beam_size: int = 5
    vad_filter: bool = True
    word_timestamps: bool = False


class SpeechToText:
    """Speech-to-text transcription using faster-whisper.

    Uses GPU-accelerated Whisper for fast transcription.
    """

    def __init__(self, config: STTConfig | None = None) -> None:
        """Initialize speech-to-text.

        Args:
            config: STT configuration
        """
        self.config = config or STTConfig()
        self._model: Any = None
        self._model_loaded = False

    async def load_model(self) -> bool:
        """Load the Whisper model.

        Returns:
            True if model loaded successfully
        """
        if self._model_loaded:
            return True

        try:
            # Try faster-whisper first (GPU accelerated)
            from faster_whisper import WhisperModel

            # Determine device
            device = self.config.device
            if device == "auto":
                try:
                    import torch
                    device = "cuda" if torch.cuda.is_available() else "cpu"
                except ImportError:
                    device = "cpu"

            # Load model in thread pool
            loop = asyncio.get_event_loop()
            self._model = await loop.run_in_executor(
                None,
                lambda: WhisperModel(
                    self.config.model,
                    device=device,
                    compute_type=self.config.compute_type if device == "cuda" else "float32",
                ),
            )
            self._model_loaded = True
            return True

        except ImportError:
            # Fall back to standard whisper
            try:
                import whisper

                loop = asyncio.get_event_loop()
                self._model = await loop.run_in_executor(
                    None,
                    lambda: whisper.load_model(self.config.model),
                )
                self._model_loaded = True
                return True
            except ImportError:
                return False

    async def transcribe(
        self,
        audio_data: bytes | str | Path,
        language: str | None = None,
    ) -> TranscriptionResult:
        """Transcribe audio to text.

        Args:
            audio_data: Audio bytes, file path, or Path object
            language: Override language detection

        Returns:
            TranscriptionResult
        """
        if not self._model_loaded:
            await self.load_model()

        if not self._model_loaded:
            return TranscriptionResult(
                text="",
                language="unknown",
                confidence=0.0,
                duration_seconds=0.0,
            )

        start_time = datetime.now()

        # Handle different input types
        audio_path: str | None = None
        temp_file = None

        if isinstance(audio_data, (str, Path)):
            audio_path = str(audio_data)
        elif isinstance(audio_data, bytes):
            # Write to temporary file
            temp_file = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
            temp_file.write(audio_data)
            temp_file.close()
            audio_path = temp_file.name

        if audio_path is None:
            return TranscriptionResult(
                text="",
                language="unknown",
                confidence=0.0,
                duration_seconds=0.0,
            )

        try:
            # Transcribe using faster-whisper or standard whisper
            result = await self._transcribe_impl(
                audio_path,
                language or self.config.language,
            )
        finally:
            # Clean up temp file
            if temp_file:
                with contextlib.suppress(Exception):
                    Path(temp_file.name).unlink()

        processing_time = (datetime.now() - start_time).total_seconds()
        result.processing_time = processing_time
        return result

    async def _transcribe_impl(
        self,
        audio_path: str,
        language: str | None,
    ) -> TranscriptionResult:
        """Implementation of transcription.

        Args:
            audio_path: Path to audio file
            language: Language code or None

        Returns:
            TranscriptionResult
        """
        loop = asyncio.get_event_loop()

        # Check which library we're using
        model_type = type(self._model).__name__

        if "WhisperModel" in model_type:
            # faster-whisper
            return await loop.run_in_executor(
                None,
                lambda: self._transcribe_faster_whisper(audio_path, language),
            )
        else:
            # standard whisper
            return await loop.run_in_executor(
                None,
                lambda: self._transcribe_whisper(audio_path, language),
            )

    def _transcribe_faster_whisper(
        self,
        audio_path: str,
        language: str | None,
    ) -> TranscriptionResult:
        """Transcribe using faster-whisper.

        Args:
            audio_path: Path to audio file
            language: Language code

        Returns:
            TranscriptionResult
        """
        segments, info = self._model.transcribe(
            audio_path,
            language=language,
            beam_size=self.config.beam_size,
            vad_filter=self.config.vad_filter,
            word_timestamps=self.config.word_timestamps,
        )

        # Collect segments
        segment_list = []
        full_text = []
        total_confidence = 0.0
        segment_count = 0

        for segment in segments:
            segment_list.append({
                "start": segment.start,
                "end": segment.end,
                "text": segment.text,
                "avg_logprob": segment.avg_logprob,
            })
            full_text.append(segment.text)

            # Convert log probability to confidence
            confidence = 2 ** segment.avg_logprob  # Approximate
            total_confidence += confidence
            segment_count += 1

        avg_confidence = total_confidence / segment_count if segment_count > 0 else 0.0

        return TranscriptionResult(
            text=" ".join(full_text).strip(),
            language=info.language,
            confidence=min(avg_confidence, 1.0),
            duration_seconds=info.duration,
            segments=segment_list,
        )

    def _transcribe_whisper(
        self,
        audio_path: str,
        language: str | None,
    ) -> TranscriptionResult:
        """Transcribe using standard whisper.

        Args:
            audio_path: Path to audio file
            language: Language code

        Returns:
            TranscriptionResult
        """
        options = {"language": language} if language else {}
        result = self._model.transcribe(audio_path, **options)

        # Calculate average confidence from segments
        segments = result.get("segments", [])
        total_confidence = 0.0
        segment_count = 0

        segment_list = []
        for seg in segments:
            segment_list.append({
                "start": seg["start"],
                "end": seg["end"],
                "text": seg["text"],
            })
            # Use no_speech_prob as inverse confidence
            no_speech = seg.get("no_speech_prob", 0.5)
            total_confidence += (1 - no_speech)
            segment_count += 1

        avg_confidence = total_confidence / segment_count if segment_count > 0 else 0.0

        # Estimate duration from last segment
        duration = segments[-1]["end"] if segments else 0.0

        return TranscriptionResult(
            text=result.get("text", "").strip(),
            language=result.get("language", "unknown"),
            confidence=avg_confidence,
            duration_seconds=duration,
            segments=segment_list,
        )

    async def transcribe_stream(
        self,
        audio_chunks: Any,  # AsyncIterator[bytes]
        chunk_duration: float = 5.0,
    ) -> Any:  # AsyncIterator[TranscriptionResult]
        """Transcribe streaming audio.

        Args:
            audio_chunks: Async iterator of audio chunks
            chunk_duration: Duration to accumulate before transcribing

        Yields:
            TranscriptionResult for each chunk
        """
        buffer = b""
        bytes_per_second = 16000 * 2  # 16kHz, 16-bit
        bytes_threshold = int(chunk_duration * bytes_per_second)

        async for chunk in audio_chunks:
            buffer += chunk

            if len(buffer) >= bytes_threshold:
                result = await self.transcribe(buffer)
                yield result
                buffer = b""

        # Final chunk
        if buffer:
            result = await self.transcribe(buffer)
            yield result

    def stats(self) -> dict[str, Any]:
        """Get STT statistics.

        Returns:
            Statistics dictionary
        """
        return {
            "model": self.config.model,
            "model_loaded": self._model_loaded,
            "device": self.config.device,
            "compute_type": self.config.compute_type,
            "vad_filter": self.config.vad_filter,
        }
