"""Text-to-Speech synthesis."""

from __future__ import annotations

import asyncio
import tempfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any


@dataclass
class TTSConfig:
    """Configuration for text-to-speech."""

    engine: str = "pyttsx3"  # pyttsx3, edge-tts, espeak
    voice: str | None = None  # Voice ID or name
    rate: int = 150  # Words per minute
    volume: float = 1.0  # 0.0 to 1.0
    pitch: int = 50  # 0 to 100
    language: str = "en"


@dataclass
class SpeechResult:
    """Result from speech synthesis."""

    text: str
    audio_data: bytes | None
    audio_path: str | None
    duration_seconds: float
    processing_time: float
    timestamp: datetime = field(default_factory=datetime.now)


class TextToSpeech:
    """Text-to-speech synthesis with multiple engine support.

    Supports:
    - pyttsx3: Offline, cross-platform
    - edge-tts: Microsoft Edge TTS (online, high quality)
    - espeak: Offline, lightweight
    """

    def __init__(self, config: TTSConfig | None = None) -> None:
        """Initialize text-to-speech.

        Args:
            config: TTS configuration
        """
        self.config = config or TTSConfig()
        self._engine: Any = None
        self._engine_type: str | None = None

    async def initialize(self) -> bool:
        """Initialize the TTS engine.

        Returns:
            True if initialization successful
        """
        if self._engine is not None:
            return True

        if self.config.engine == "pyttsx3":
            return await self._init_pyttsx3()
        elif self.config.engine == "edge-tts":
            return await self._init_edge_tts()
        elif self.config.engine == "espeak":
            return await self._init_espeak()

        return False

    async def _init_pyttsx3(self) -> bool:
        """Initialize pyttsx3 engine."""
        try:
            import pyttsx3

            loop = asyncio.get_event_loop()
            self._engine = await loop.run_in_executor(
                None,
                pyttsx3.init,
            )

            # Configure engine
            if self.config.voice:
                voices = self._engine.getProperty("voices")
                for voice in voices:
                    if self.config.voice in voice.id or self.config.voice in voice.name:
                        self._engine.setProperty("voice", voice.id)
                        break

            self._engine.setProperty("rate", self.config.rate)
            self._engine.setProperty("volume", self.config.volume)

            self._engine_type = "pyttsx3"
            return True

        except ImportError:
            return False

    async def _init_edge_tts(self) -> bool:
        """Initialize edge-tts (requires internet)."""
        try:
            import edge_tts
            self._engine = edge_tts
            self._engine_type = "edge-tts"
            return True
        except ImportError:
            return False

    async def _init_espeak(self) -> bool:
        """Initialize espeak-ng."""
        try:
            import subprocess
            # Check if espeak is available
            result = subprocess.run(
                ["espeak", "--version"],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                self._engine = "espeak"
                self._engine_type = "espeak"
                return True
            return False
        except FileNotFoundError:
            return False

    async def synthesize(
        self,
        text: str,
        output_path: str | Path | None = None,
    ) -> SpeechResult:
        """Synthesize speech from text.

        Args:
            text: Text to synthesize
            output_path: Optional path to save audio file

        Returns:
            SpeechResult with audio data
        """
        if self._engine is None:
            await self.initialize()

        if self._engine is None:
            return SpeechResult(
                text=text,
                audio_data=None,
                audio_path=None,
                duration_seconds=0.0,
                processing_time=0.0,
            )

        start_time = datetime.now()

        if self._engine_type == "pyttsx3":
            result = await self._synthesize_pyttsx3(text, output_path)
        elif self._engine_type == "edge-tts":
            result = await self._synthesize_edge_tts(text, output_path)
        elif self._engine_type == "espeak":
            result = await self._synthesize_espeak(text, output_path)
        else:
            result = SpeechResult(
                text=text,
                audio_data=None,
                audio_path=None,
                duration_seconds=0.0,
                processing_time=0.0,
            )

        result.processing_time = (datetime.now() - start_time).total_seconds()
        return result

    async def _synthesize_pyttsx3(
        self,
        text: str,
        output_path: str | Path | None,
    ) -> SpeechResult:
        """Synthesize using pyttsx3.

        Args:
            text: Text to synthesize
            output_path: Output file path

        Returns:
            SpeechResult
        """
        loop = asyncio.get_event_loop()

        # Generate to file
        if output_path:
            file_path = str(output_path)
        else:
            temp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
            temp.close()
            file_path = temp.name

        def generate() -> None:
            self._engine.save_to_file(text, file_path)
            self._engine.runAndWait()

        await loop.run_in_executor(None, generate)

        # Read audio data
        audio_data = None
        if Path(file_path).exists():
            with open(file_path, "rb") as f:
                audio_data = f.read()

        # Estimate duration (rough: 150 WPM = 2.5 words/sec)
        word_count = len(text.split())
        duration = word_count / (self.config.rate / 60)

        return SpeechResult(
            text=text,
            audio_data=audio_data,
            audio_path=file_path,
            duration_seconds=duration,
            processing_time=0.0,
        )

    async def _synthesize_edge_tts(
        self,
        text: str,
        output_path: str | Path | None,
    ) -> SpeechResult:
        """Synthesize using edge-tts.

        Args:
            text: Text to synthesize
            output_path: Output file path

        Returns:
            SpeechResult
        """
        import edge_tts

        # Select voice
        voice = self.config.voice or "en-US-AriaNeural"

        # Generate to file
        if output_path:
            file_path = str(output_path)
        else:
            temp = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
            temp.close()
            file_path = temp.name

        communicate = edge_tts.Communicate(text, voice)
        await communicate.save(file_path)

        # Read audio data
        audio_data = None
        if Path(file_path).exists():
            with open(file_path, "rb") as f:
                audio_data = f.read()

        # Estimate duration
        word_count = len(text.split())
        duration = word_count / 2.5  # Approximate

        return SpeechResult(
            text=text,
            audio_data=audio_data,
            audio_path=file_path,
            duration_seconds=duration,
            processing_time=0.0,
        )

    async def _synthesize_espeak(
        self,
        text: str,
        output_path: str | Path | None,
    ) -> SpeechResult:
        """Synthesize using espeak.

        Args:
            text: Text to synthesize
            output_path: Output file path

        Returns:
            SpeechResult
        """
        import subprocess

        # Generate to file
        if output_path:
            file_path = str(output_path)
        else:
            temp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
            temp.close()
            file_path = temp.name

        # Build command
        cmd = [
            "espeak",
            "-w", file_path,
            "-s", str(self.config.rate),
            "-p", str(self.config.pitch),
        ]

        if self.config.voice:
            cmd.extend(["-v", self.config.voice])

        cmd.append(text)

        # Run espeak
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            None,
            lambda: subprocess.run(cmd, capture_output=True),
        )

        # Read audio data
        audio_data = None
        if Path(file_path).exists():
            with open(file_path, "rb") as f:
                audio_data = f.read()

        # Estimate duration
        word_count = len(text.split())
        duration = word_count / (self.config.rate / 60)

        return SpeechResult(
            text=text,
            audio_data=audio_data,
            audio_path=file_path,
            duration_seconds=duration,
            processing_time=0.0,
        )

    async def speak(self, text: str) -> bool:
        """Speak text directly to audio output.

        Args:
            text: Text to speak

        Returns:
            True if successful
        """
        if self._engine_type == "pyttsx3" and self._engine:
            loop = asyncio.get_event_loop()

            def say_text() -> None:
                self._engine.say(text)
                self._engine.runAndWait()

            await loop.run_in_executor(None, say_text)
            return True

        # For other engines, synthesize and play
        result = await self.synthesize(text)
        if result.audio_path:
            return await self._play_audio(result.audio_path)

        return False

    async def _play_audio(self, path: str) -> bool:
        """Play an audio file.

        Args:
            path: Path to audio file

        Returns:
            True if played successfully
        """
        try:
            import subprocess
            loop = asyncio.get_event_loop()

            # Try different players
            players = ["aplay", "paplay", "afplay", "play"]  # Linux, macOS, sox

            for player in players:
                try:
                    await loop.run_in_executor(
                        None,
                        lambda p=player: subprocess.run(
                            [p, path],
                            capture_output=True,
                            check=True,
                        ),
                    )
                    return True
                except (subprocess.CalledProcessError, FileNotFoundError):
                    continue

            return False

        except Exception:
            return False

    def list_voices(self) -> list[dict[str, str]]:
        """List available voices.

        Returns:
            List of voice dictionaries
        """
        if self._engine_type == "pyttsx3" and self._engine:
            voices = self._engine.getProperty("voices")
            return [
                {"id": v.id, "name": v.name, "languages": str(v.languages)}
                for v in voices
            ]

        return []

    def stats(self) -> dict[str, Any]:
        """Get TTS statistics.

        Returns:
            Statistics dictionary
        """
        return {
            "engine": self.config.engine,
            "engine_initialized": self._engine is not None,
            "engine_type": self._engine_type,
            "voice": self.config.voice,
            "rate": self.config.rate,
        }
