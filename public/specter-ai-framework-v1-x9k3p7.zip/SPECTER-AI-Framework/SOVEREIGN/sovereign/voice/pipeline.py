"""Voice Pipeline coordinating wake word, STT, and TTS."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

from sovereign.voice.stt import SpeechToText, STTConfig, TranscriptionResult
from sovereign.voice.tts import TextToSpeech, TTSConfig
from sovereign.voice.wake_word import WakeWordConfig, WakeWordDetector, WakeWordEvent


class PipelineState(Enum):
    """State of the voice pipeline."""

    IDLE = "idle"
    LISTENING_WAKE_WORD = "listening_wake_word"
    LISTENING_COMMAND = "listening_command"
    PROCESSING = "processing"
    SPEAKING = "speaking"
    ERROR = "error"


@dataclass
class VoiceConfig:
    """Configuration for voice pipeline."""

    wake_word_config: WakeWordConfig | None = None
    stt_config: STTConfig | None = None
    tts_config: TTSConfig | None = None
    listen_timeout: float = 10.0  # Seconds to listen for command
    silence_threshold: float = 0.02  # RMS threshold for silence
    silence_duration: float = 1.5  # Seconds of silence to end listening
    max_command_duration: float = 30.0  # Max seconds to listen for command
    auto_confirm: bool = True  # Auto-confirm with sound after wake word


@dataclass
class VoiceInteraction:
    """A single voice interaction."""

    interaction_id: str
    wake_word_event: WakeWordEvent | None
    transcription: TranscriptionResult | None
    response_text: str | None
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: datetime | None = None
    success: bool = False
    error: str | None = None


# Type for command processor
CommandProcessor = Callable[[str], Awaitable[str]]


class VoicePipeline:
    """Coordinates voice interaction: wake word -> STT -> process -> TTS.

    Full voice interface pipeline:
    1. Listen for wake word ("Hey Sovereign")
    2. Record user's spoken command
    3. Transcribe speech to text
    4. Process command (call handler)
    5. Convert response to speech
    6. Play response
    """

    def __init__(
        self,
        config: VoiceConfig | None = None,
        command_processor: CommandProcessor | None = None,
    ) -> None:
        """Initialize voice pipeline.

        Args:
            config: Pipeline configuration
            command_processor: Async function to process commands
        """
        self.config = config or VoiceConfig()
        self.command_processor = command_processor

        # Initialize components
        self.wake_word = WakeWordDetector(self.config.wake_word_config)
        self.stt = SpeechToText(self.config.stt_config)
        self.tts = TextToSpeech(self.config.tts_config)

        # State
        self._state = PipelineState.IDLE
        self._running = False
        self._current_interaction: VoiceInteraction | None = None
        self._interaction_history: list[VoiceInteraction] = []

        # Audio handling
        self._audio_source: Any = None
        self._audio_buffer: bytearray = bytearray()

    @property
    def state(self) -> PipelineState:
        """Current pipeline state."""
        return self._state

    @property
    def is_running(self) -> bool:
        """Check if pipeline is running."""
        return self._running

    async def initialize(self) -> bool:
        """Initialize all pipeline components.

        Returns:
            True if all components initialized
        """
        # Load STT model
        stt_ready = await self.stt.load_model()

        # Initialize TTS
        tts_ready = await self.tts.initialize()

        return stt_ready or tts_ready  # At least one should work

    async def start(self, audio_source: Any) -> None:
        """Start the voice pipeline.

        Args:
            audio_source: Source of audio data (e.g., microphone)
        """
        if self._running:
            return

        self._running = True
        self._audio_source = audio_source
        self._state = PipelineState.LISTENING_WAKE_WORD

        # Register wake word callback
        self.wake_word.on_wake_word(self._on_wake_word_detected)

        # Start main loop
        await self._main_loop()

    async def stop(self) -> None:
        """Stop the voice pipeline."""
        self._running = False
        self._state = PipelineState.IDLE
        self.wake_word.stop()

    async def _main_loop(self) -> None:
        """Main pipeline loop."""
        while self._running:
            try:
                if self._state == PipelineState.LISTENING_WAKE_WORD:
                    await self._listen_for_wake_word()

                elif self._state == PipelineState.LISTENING_COMMAND:
                    await self._listen_for_command()

                elif self._state == PipelineState.PROCESSING:
                    await self._process_command()

                elif self._state == PipelineState.SPEAKING:
                    await self._speak_response()

                else:
                    await asyncio.sleep(0.1)

            except asyncio.CancelledError:
                break
            except Exception as e:
                self._state = PipelineState.ERROR
                if self._current_interaction:
                    self._current_interaction.error = str(e)
                await asyncio.sleep(1.0)
                self._state = PipelineState.LISTENING_WAKE_WORD

    async def _listen_for_wake_word(self) -> None:
        """Listen for wake word activation."""
        if self._audio_source is None:
            await asyncio.sleep(0.1)
            return

        try:
            chunk = await self._read_audio_chunk()
            if chunk:
                await self.wake_word.detect(chunk)
        except Exception:
            pass

    def _on_wake_word_detected(self, event: WakeWordEvent) -> None:
        """Handle wake word detection.

        Args:
            event: Wake word event
        """
        if self._state != PipelineState.LISTENING_WAKE_WORD:
            return

        # Start new interaction
        self._current_interaction = VoiceInteraction(
            interaction_id=f"voice_{datetime.now().timestamp()}",
            wake_word_event=event,
            transcription=None,
            response_text=None,
        )

        # Transition to command listening
        self._state = PipelineState.LISTENING_COMMAND
        self._audio_buffer.clear()

    async def _listen_for_command(self) -> None:
        """Listen and record user's command."""
        if self._audio_source is None:
            self._state = PipelineState.LISTENING_WAKE_WORD
            return

        # Play confirmation sound if enabled
        if self.config.auto_confirm:
            await self._play_confirmation()

        start_time = datetime.now()
        silence_start: datetime | None = None

        while self._running:
            elapsed = (datetime.now() - start_time).total_seconds()

            # Check timeout
            if elapsed > self.config.max_command_duration:
                break

            # Read audio
            chunk = await self._read_audio_chunk()
            if not chunk:
                continue

            self._audio_buffer.extend(chunk)

            # Check for silence (end of command)
            if self._is_silence(chunk):
                if silence_start is None:
                    silence_start = datetime.now()
                elif (datetime.now() - silence_start).total_seconds() > self.config.silence_duration:
                    break
            else:
                silence_start = None

        # Move to processing
        self._state = PipelineState.PROCESSING

    async def _process_command(self) -> None:
        """Process the recorded command."""
        if not self._audio_buffer:
            self._state = PipelineState.LISTENING_WAKE_WORD
            return

        # Transcribe
        audio_bytes = bytes(self._audio_buffer)
        transcription = await self.stt.transcribe(audio_bytes)

        if self._current_interaction:
            self._current_interaction.transcription = transcription

        # Process command if we have text
        if transcription.text and self.command_processor:
            try:
                response = await self.command_processor(transcription.text)
                if self._current_interaction:
                    self._current_interaction.response_text = response
                self._state = PipelineState.SPEAKING
            except Exception as e:
                if self._current_interaction:
                    self._current_interaction.error = str(e)
                self._state = PipelineState.LISTENING_WAKE_WORD
        else:
            self._state = PipelineState.LISTENING_WAKE_WORD

    async def _speak_response(self) -> None:
        """Speak the response."""
        if self._current_interaction and self._current_interaction.response_text:
            await self.tts.speak(self._current_interaction.response_text)

        # Complete interaction
        if self._current_interaction:
            self._current_interaction.completed_at = datetime.now()
            self._current_interaction.success = True
            self._interaction_history.append(self._current_interaction)
            self._current_interaction = None

        self._state = PipelineState.LISTENING_WAKE_WORD

    async def _read_audio_chunk(self, size: int = 1280) -> bytes | None:
        """Read an audio chunk from the source.

        Args:
            size: Bytes to read

        Returns:
            Audio bytes or None
        """
        if self._audio_source is None:
            return None

        try:
            if hasattr(self._audio_source, "read"):
                if asyncio.iscoroutinefunction(self._audio_source.read):
                    return await self._audio_source.read(size)
                else:
                    loop = asyncio.get_event_loop()
                    return await loop.run_in_executor(
                        None,
                        lambda: self._audio_source.read(size),
                    )
            return None
        except Exception:
            return None

    def _is_silence(self, chunk: bytes) -> bool:
        """Check if audio chunk is silence.

        Args:
            chunk: Audio bytes

        Returns:
            True if silence
        """
        import struct

        num_samples = len(chunk) // 2
        if num_samples == 0:
            return True

        samples = struct.unpack(f"{num_samples}h", chunk)
        sum_squares = sum(s * s for s in samples)
        rms = (sum_squares / num_samples) ** 0.5
        normalized_rms = rms / 32768.0

        return normalized_rms < self.config.silence_threshold

    async def _play_confirmation(self) -> None:
        """Play a confirmation sound."""
        # Simple beep using TTS
        await self.tts.speak("Ready")

    async def process_text(self, text: str) -> str | None:
        """Process a text command directly (bypass STT).

        Args:
            text: Command text

        Returns:
            Response text or None
        """
        if self.command_processor is None:
            return None

        return await self.command_processor(text)

    async def speak(self, text: str) -> bool:
        """Speak text directly (bypass command processing).

        Args:
            text: Text to speak

        Returns:
            True if successful
        """
        return await self.tts.speak(text)

    def get_history(self, limit: int = 10) -> list[VoiceInteraction]:
        """Get recent interaction history.

        Args:
            limit: Maximum entries to return

        Returns:
            List of recent interactions
        """
        return self._interaction_history[-limit:]

    def stats(self) -> dict[str, Any]:
        """Get pipeline statistics.

        Returns:
            Statistics dictionary
        """
        return {
            "state": self._state.value,
            "running": self._running,
            "total_interactions": len(self._interaction_history),
            "successful_interactions": sum(
                1 for i in self._interaction_history if i.success
            ),
            "wake_word": self.wake_word.stats(),
            "stt": self.stt.stats(),
            "tts": self.tts.stats(),
        }
