# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

SPECTER (Sovereign Persistent Executive Core for Total Environment Reign) is an autonomous AI agent designed to run 24/7 as a unified intelligence controlling a digital environment. It features a distinctive personality system inspired by fictional characters (Harvey Specter, Gojo, Vegeta, House, Gibbs, etc.).

## Commands

### Run SPECTER

```bash
# Interactive mode (default)
python -m specter

# Start daemon mode
python -m specter start

# Show status
python -m specter status

# Validate configuration
python -m specter config --validate
```

### Docker

```bash
# Build and start
docker-compose -f docker/docker-compose.yml up -d

# View logs
docker-compose -f docker/docker-compose.yml logs -f specter

# Stop
docker-compose -f docker/docker-compose.yml down
```

### Testing

```bash
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_nexus.py -v

# Run with coverage
pytest tests/ --cov=core --cov=specter
```

### Development

```bash
# Install dependencies
pip install -r requirements.txt

# Linting and formatting
black core/ specter/ tests/
isort core/ specter/ tests/
ruff check core/ specter/ tests/
mypy core/ specter/
```

## Architecture

SPECTER uses a modular architecture with a central event bus for inter-component communication:

```
┌──────────────────────────────────────────────────────────────────┐
│                            SPECTER                                │
│  ┌──────────────────────────────────────────────────────────┐    │
│  │                        ANIMUS                             │    │
│  │             (Personality/Identity Engine)                 │    │
│  └────────────────────────────┬─────────────────────────────┘    │
│                               │                                   │
│  ┌────────┐ ┌────────┐ ┌─────┴────┐ ┌────────┐ ┌────────┐       │
│  │ CORTEX │ │  ECHO  │ │EXECUTOR  │ │ MEMORY │ │ NEXUS  │       │
│  │ (LLM)  │ │(Voice) │ │(Actions) │ │(Vector)│ │(Web/API│       │
│  └───┬────┘ └───┬────┘ └────┬─────┘ └───┬────┘ └───┬────┘       │
│      │          │      ┌────┴────┐      │          │             │
│      │          │      │ Browser │      │          │             │
│      │          │      │ Desktop │      │          │             │
│      └──────────┴──────┴────┬────┴──────┴──────────┘             │
│                             │                                     │
│                     ┌───────┴───────┐                            │
│                     │    NUCLEUS    │                            │
│                     │  (Event Bus)  │                            │
│                     └───────────────┘                            │
│                                                                   │
│  INTEGRATIONS: LUMINA (IoT) │ VAULT (Crypto) │ TRADER            │
└──────────────────────────────────────────────────────────────────┘
```

### Core Modules (`core/`)

| Module | Purpose | Key Files |
|--------|---------|-----------|
| **nucleus** | Central event bus for all module communication | `bus.py` - EventBus with pub/sub, priority handling |
| **animus** | Personality engine with immutable core values and mutable traits | `identity.py` - Core values, rules, quotes; `moods.py` - Dynamic mood system |
| **cortex** | LLM inference via llama-cpp-python | `engine.py` - Model loading/inference; `router.py` - Model selection; `prompts.py` - Prompt building |
| **executor** | Environment interaction (browser/desktop automation) | `executor.py` - Orchestrator; `browser_tool.py` - Playwright; `desktop_tool.py` - xdotool/wmctrl |
| **echo** | Voice interface (Whisper STT, Piper TTS, OpenWakeWord) | `stt.py`, `tts.py`, `wake_word.py`, `voice_manager.py` |
| **iris** | Vision/screen understanding (Surya OCR, screen capture) | `capture.py`, `ocr.py`, `vision_manager.py` |
| **memory** | Vector storage with Qdrant | `vector_store.py`, `embeddings.py`, `memory_manager.py` |
| **sentinel** | Security boundaries and approval gates | `guardian.py`, `validator.py` |
| **nexus** | Web GUI and REST API (FastAPI) | `api.py`, `websocket.py` |

### Entry Points (`specter/`)

| File | Purpose |
|------|---------|
| `__main__.py` | CLI entry point with Click commands |
| `daemon.py` | Main service orchestrator, component lifecycle |
| `config.py` | Configuration loading from YAML |

### Integrations (`integrations/`)

| Module | Purpose |
|--------|---------|
| **lumina** | Smart device control (Tuya, LIFX, Yeelight) |
| **vault** | Crypto wallet (Ethereum, Polygon, Base) |
| **trader** | PowerTrader AI integration |

## Key Patterns

### Event-Driven Communication
All modules communicate through the NUCLEUS event bus (`core/nucleus/bus.py`). Use `get_bus()` to access the global instance:

```python
from core.nucleus import get_bus, Event, EventType

bus = get_bus()
await bus.subscribe(EventType.INFERENCE_REQUEST, my_handler)
await bus.publish(Event(type=EventType.SYSTEM_STARTED, data={}, source="my_module"))
```

### Personality Injection
The ANIMUS personality system injects character traits into LLM responses. The `Personality` class provides `get_system_prompt_addition()` for context injection.

### Model Routing
CORTEX supports multiple models (primary/fast) with automatic routing based on query complexity. The `ModelRouter` class determines which model to use.

### Configuration
All settings flow through `SpecterConfig` dataclasses parsed from `config/specter.yaml`. Access via:

```python
from specter.config import load_config
config = load_config()  # Uses SPECTER_CONFIG env var or default path
```

### EXECUTOR - Environment Interaction
The EXECUTOR module (`core/executor/`) enables SPECTER to interact with the Ubuntu desktop and web browsers.

**Browser Automation (Playwright):**
```python
from core.executor import Executor, BrowserConfig

executor = Executor(browser_config=BrowserConfig(browser_type="firefox"))
await executor.initialize()
await executor.start()

# Navigate
await executor.browser_navigate("https://gmail.com")

# Click by text
await executor.browser_click(text="Sign in")

# Fill form
await executor.browser_fill(selector='input[type="email"]', value="user@gmail.com")
```

**Desktop Automation (xdotool/wmctrl):**
```python
# Launch apps
await executor.desktop_launch("firefox")

# Type text
await executor.desktop_type("Hello world")

# Press keys
await executor.desktop_press("ctrl+s")

# Window management
await executor.desktop_focus("Firefox")
windows = await executor.desktop_windows()
```

**Natural Language Commands:**
SPECTER understands natural language action commands in interactive mode:
- `open gmail` - Opens Gmail in browser
- `navigate to google.com` - Navigates browser
- `click Sign In` - Clicks element by text
- `type hello world` - Types text
- `launch terminal` - Opens terminal app
- `list windows` - Shows open windows
- `focus Firefox` - Brings window to front

**Prerequisites for Desktop Automation:**
```bash
sudo apt install xdotool wmctrl xclip
pip install playwright
playwright install firefox
```

## File Conventions

- **Core modules**: `core/{module_name}/` with `__init__.py` exposing public API
- **Tests**: `tests/test_{module_name}.py` mirroring the module structure
- **Config**: YAML files in `config/`, dataclass parsing in `specter/config.py`

## GPU/Model Requirements

- Models stored in `/specter/models/` (container) or `models/` (local)
- Uses llama-cpp-python with CUDA for GPU inference
- Primary model: Qwen2.5-Coder-32B-Q4_K_M (32GB VRAM recommended)
- Fast model: Qwen2.5-Coder-7B-Q4_K_M (8GB VRAM)

## Ports

| Port | Service |
|------|---------|
| 3333 | Web UI |
| 3334 | REST API |
| 3335 | WebSocket |
| 6333 | Qdrant REST |
| 6334 | Qdrant gRPC |
