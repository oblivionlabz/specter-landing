"""
TRADER PowerTrader Integration

Integrates with PowerTrader AI for trading signals and analysis.
"""

from pathlib import Path
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field
from enum import Enum
import logging
import asyncio
from datetime import datetime
import json
import subprocess

logger = logging.getLogger("specter.trader")


class SignalType(Enum):
    """Types of trading signals"""
    BUY = "buy"
    SELL = "sell"
    HOLD = "hold"
    STRONG_BUY = "strong_buy"
    STRONG_SELL = "strong_sell"


class AutomationLevel(Enum):
    """Automation levels"""
    SIGNALS_ONLY = "signals_only"      # Only show signals
    CONFIRM_EXECUTE = "confirm_execute"  # Execute with confirmation
    AUTO_EXECUTE = "auto_execute"        # Full automation


@dataclass
class TradeSignal:
    """A trading signal"""
    id: str
    symbol: str
    signal_type: SignalType
    price: float
    confidence: float
    timestamp: datetime
    timeframe: str = "1h"
    take_profit: Optional[float] = None
    stop_loss: Optional[float] = None
    analysis: str = ""
    executed: bool = False


@dataclass
class Position:
    """An open trading position"""
    symbol: str
    side: str  # "long" or "short"
    entry_price: float
    size: float
    current_price: float = 0.0
    pnl: float = 0.0
    pnl_percent: float = 0.0
    opened_at: datetime = field(default_factory=datetime.now)


class PowerTraderIntegration:
    """
    Integration with PowerTrader AI.

    Features:
    - Signal monitoring
    - Trade execution (with approval)
    - Position tracking
    - Performance analytics
    """

    def __init__(
        self,
        powertrader_path: Optional[Path] = None,
        automation_level: AutomationLevel = AutomationLevel.SIGNALS_ONLY,
        max_position_size: float = 0.1,
        stop_loss_required: bool = True
    ):
        self.powertrader_path = powertrader_path
        self.automation_level = automation_level
        self.max_position_size = max_position_size
        self.stop_loss_required = stop_loss_required

        self.signals: List[TradeSignal] = []
        self.positions: Dict[str, Position] = {}
        self.trade_history: List[Dict] = []

        self.initialized = False
        self._monitor_task = None

        # API integration
        self.exchange_client = None

        logger.info(f"TRADER created: {automation_level.value}")

    async def initialize(self) -> bool:
        """Initialize trader integration"""
        if self.initialized:
            return True

        logger.info("Initializing TRADER...")

        # Check if PowerTrader exists
        if self.powertrader_path and self.powertrader_path.exists():
            logger.info(f"  [+] PowerTrader found: {self.powertrader_path}")
        else:
            logger.warning("  [!] PowerTrader path not found")

        # Initialize CCXT for exchange connection
        try:
            import ccxt
            # Will be configured with specific exchange later
            logger.info("  [+] CCXT available for exchange integration")
        except ImportError:
            logger.warning("  [!] CCXT not installed - exchange features disabled")

        self.initialized = True
        return True

    async def connect_exchange(
        self,
        exchange: str,
        api_key: str,
        secret: str,
        sandbox: bool = True
    ) -> bool:
        """
        Connect to a cryptocurrency exchange.

        Args:
            exchange: Exchange name (binance, coinbase, etc.)
            api_key: API key
            secret: API secret
            sandbox: Use testnet/sandbox

        Returns:
            True if connected
        """
        try:
            import ccxt

            exchange_class = getattr(ccxt, exchange)
            self.exchange_client = exchange_class({
                "apiKey": api_key,
                "secret": secret,
                "sandbox": sandbox,
                "enableRateLimit": True
            })

            # Test connection
            balance = await asyncio.get_event_loop().run_in_executor(
                None,
                self.exchange_client.fetch_balance
            )

            logger.info(f"Connected to {exchange} ({'sandbox' if sandbox else 'live'})")
            return True

        except Exception as e:
            logger.error(f"Failed to connect to exchange: {e}")
            return False

    async def get_market_data(
        self,
        symbol: str,
        timeframe: str = "1h",
        limit: int = 100
    ) -> Optional[List[Dict]]:
        """
        Get market data (OHLCV).

        Args:
            symbol: Trading pair (e.g., "BTC/USDT")
            timeframe: Candle timeframe
            limit: Number of candles

        Returns:
            List of OHLCV data
        """
        if not self.exchange_client:
            logger.error("Exchange not connected")
            return None

        try:
            loop = asyncio.get_event_loop()
            ohlcv = await loop.run_in_executor(
                None,
                lambda: self.exchange_client.fetch_ohlcv(symbol, timeframe, limit=limit)
            )

            return [
                {
                    "timestamp": candle[0],
                    "open": candle[1],
                    "high": candle[2],
                    "low": candle[3],
                    "close": candle[4],
                    "volume": candle[5]
                }
                for candle in ohlcv
            ]

        except Exception as e:
            logger.error(f"Failed to get market data: {e}")
            return None

    async def analyze_symbol(self, symbol: str) -> Optional[TradeSignal]:
        """
        Analyze a symbol and generate signal.

        Uses PowerTrader if available, otherwise basic analysis.
        """
        market_data = await self.get_market_data(symbol)
        if not market_data:
            return None

        try:
            import pandas as pd
            import ta

            df = pd.DataFrame(market_data)

            # Calculate indicators
            df['rsi'] = ta.momentum.RSIIndicator(df['close']).rsi()
            df['macd'] = ta.trend.MACD(df['close']).macd()
            df['macd_signal'] = ta.trend.MACD(df['close']).macd_signal()
            df['sma_20'] = ta.trend.SMAIndicator(df['close'], window=20).sma_indicator()
            df['sma_50'] = ta.trend.SMAIndicator(df['close'], window=50).sma_indicator()

            latest = df.iloc[-1]
            current_price = latest['close']

            # Generate signal
            signal_type = SignalType.HOLD
            confidence = 0.5
            analysis_parts = []

            # RSI analysis
            if latest['rsi'] < 30:
                signal_type = SignalType.BUY
                confidence += 0.2
                analysis_parts.append("RSI oversold")
            elif latest['rsi'] > 70:
                signal_type = SignalType.SELL
                confidence += 0.2
                analysis_parts.append("RSI overbought")

            # MACD analysis
            if latest['macd'] > latest['macd_signal']:
                if signal_type == SignalType.BUY:
                    signal_type = SignalType.STRONG_BUY
                    confidence += 0.1
                analysis_parts.append("MACD bullish crossover")
            else:
                if signal_type == SignalType.SELL:
                    signal_type = SignalType.STRONG_SELL
                    confidence += 0.1
                analysis_parts.append("MACD bearish")

            # SMA analysis
            if latest['sma_20'] > latest['sma_50']:
                analysis_parts.append("SMA trend bullish")
            else:
                analysis_parts.append("SMA trend bearish")

            # Create signal
            signal = TradeSignal(
                id=f"sig_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                symbol=symbol,
                signal_type=signal_type,
                price=current_price,
                confidence=min(confidence, 1.0),
                timestamp=datetime.now(),
                take_profit=current_price * 1.05 if signal_type in [SignalType.BUY, SignalType.STRONG_BUY] else None,
                stop_loss=current_price * 0.97 if signal_type in [SignalType.BUY, SignalType.STRONG_BUY] else None,
                analysis=" | ".join(analysis_parts)
            )

            self.signals.append(signal)
            return signal

        except ImportError:
            logger.error("pandas or ta not installed for analysis")
            return None
        except Exception as e:
            logger.error(f"Analysis failed: {e}")
            return None

    async def execute_signal(
        self,
        signal: TradeSignal,
        size: Optional[float] = None
    ) -> Optional[Dict]:
        """
        Execute a trading signal.

        Args:
            signal: Signal to execute
            size: Position size (fraction of available balance)

        Returns:
            Order result or None
        """
        if not self.exchange_client:
            logger.error("Exchange not connected")
            return None

        if signal.executed:
            logger.warning("Signal already executed")
            return None

        # Validate
        size = size or self.max_position_size
        if size > self.max_position_size:
            logger.error(f"Size exceeds max: {self.max_position_size}")
            return None

        if self.stop_loss_required and signal.stop_loss is None:
            logger.error("Stop loss required but not set")
            return None

        try:
            loop = asyncio.get_event_loop()

            # Get balance
            balance = await loop.run_in_executor(
                None,
                self.exchange_client.fetch_balance
            )

            usdt_balance = balance.get('USDT', {}).get('free', 0)
            position_value = usdt_balance * size

            # Determine order side
            if signal.signal_type in [SignalType.BUY, SignalType.STRONG_BUY]:
                side = "buy"
                amount = position_value / signal.price
            else:
                side = "sell"
                amount = position_value / signal.price

            # Place order
            order = await loop.run_in_executor(
                None,
                lambda: self.exchange_client.create_order(
                    signal.symbol,
                    "market",
                    side,
                    amount
                )
            )

            signal.executed = True

            # Track position
            if side == "buy":
                self.positions[signal.symbol] = Position(
                    symbol=signal.symbol,
                    side="long",
                    entry_price=signal.price,
                    size=amount
                )

            logger.info(f"Order executed: {side} {amount} {signal.symbol}")
            return order

        except Exception as e:
            logger.error(f"Order execution failed: {e}")
            return None

    async def get_positions(self) -> Dict[str, Position]:
        """Get current positions"""
        if self.exchange_client:
            try:
                loop = asyncio.get_event_loop()
                positions = await loop.run_in_executor(
                    None,
                    self.exchange_client.fetch_positions
                )

                for pos in positions:
                    if pos['contracts'] > 0:
                        symbol = pos['symbol']
                        self.positions[symbol] = Position(
                            symbol=symbol,
                            side=pos['side'],
                            entry_price=pos['entryPrice'],
                            size=pos['contracts'],
                            current_price=pos['markPrice'],
                            pnl=pos['unrealizedPnl'],
                            pnl_percent=pos['percentage']
                        )
            except Exception as e:
                logger.error(f"Failed to fetch positions: {e}")

        return self.positions

    async def close_position(self, symbol: str) -> Optional[Dict]:
        """Close an open position"""
        if symbol not in self.positions:
            return None

        position = self.positions[symbol]

        try:
            loop = asyncio.get_event_loop()

            side = "sell" if position.side == "long" else "buy"

            order = await loop.run_in_executor(
                None,
                lambda: self.exchange_client.create_order(
                    symbol,
                    "market",
                    side,
                    position.size
                )
            )

            del self.positions[symbol]
            logger.info(f"Position closed: {symbol}")
            return order

        except Exception as e:
            logger.error(f"Failed to close position: {e}")
            return None

    def get_recent_signals(self, limit: int = 10) -> List[TradeSignal]:
        """Get recent signals"""
        return self.signals[-limit:]

    def get_status(self) -> Dict[str, Any]:
        """Get trader status"""
        return {
            "initialized": self.initialized,
            "exchange_connected": self.exchange_client is not None,
            "automation_level": self.automation_level.value,
            "open_positions": len(self.positions),
            "recent_signals": len(self.signals),
            "max_position_size": self.max_position_size
        }

    async def shutdown(self) -> None:
        """Shutdown trader"""
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass

        self.initialized = False
        logger.info("TRADER shutdown complete")
