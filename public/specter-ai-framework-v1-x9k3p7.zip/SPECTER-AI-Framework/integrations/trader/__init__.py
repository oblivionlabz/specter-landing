"""
TRADER - PowerTrader AI Integration

Trading signals and automation integration.
"Equivalent exchange. Every trade has a cost." - Alchemist mode
"""

from .trader import PowerTraderIntegration, TradeSignal, SignalType

__all__ = [
    "PowerTraderIntegration",
    "TradeSignal",
    "SignalType"
]
