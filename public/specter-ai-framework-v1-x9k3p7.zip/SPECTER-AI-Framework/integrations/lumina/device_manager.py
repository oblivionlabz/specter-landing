"""
LUMINA Device Manager

Manages all smart devices across protocols.
"""

from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field
from enum import Enum
import logging
import asyncio
from datetime import datetime

logger = logging.getLogger("specter.lumina.manager")


class DeviceType(Enum):
    """Types of smart devices"""
    LIGHT = "light"
    SWITCH = "switch"
    PLUG = "plug"
    SENSOR = "sensor"
    THERMOSTAT = "thermostat"
    UNKNOWN = "unknown"


class DeviceState(Enum):
    """Device connection states"""
    ONLINE = "online"
    OFFLINE = "offline"
    UNKNOWN = "unknown"


@dataclass
class Device:
    """A smart device"""
    id: str
    name: str
    device_type: DeviceType
    protocol: str
    ip_address: Optional[str] = None
    state: DeviceState = DeviceState.UNKNOWN
    is_on: bool = False
    brightness: int = 100
    color: Optional[Dict[str, int]] = None  # RGB or HSL
    last_seen: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class DeviceManager:
    """
    Unified device management for LUMINA.

    Supports:
    - Device discovery
    - Multi-protocol control
    - State synchronization
    - Group control
    """

    def __init__(
        self,
        protocols: Optional[List[str]] = None,
        auto_discover: bool = True,
        scan_interval: int = 3600
    ):
        self.enabled_protocols = protocols or ["tuya", "lifx", "yeelight"]
        self.auto_discover = auto_discover
        self.scan_interval = scan_interval

        self.devices: Dict[str, Device] = {}
        self.protocol_handlers: Dict[str, Any] = {}
        self.groups: Dict[str, List[str]] = {}  # Group name -> device IDs

        self.initialized = False
        self._discovery_task = None

        logger.info(f"Device manager created: {self.enabled_protocols}")

    async def initialize(self) -> bool:
        """Initialize device management"""
        if self.initialized:
            return True

        logger.info("Initializing LUMINA...")

        # Initialize protocol handlers
        for protocol in self.enabled_protocols:
            handler = await self._init_protocol(protocol)
            if handler:
                self.protocol_handlers[protocol] = handler
                logger.info(f"  [+] {protocol} protocol ready")
            else:
                logger.warning(f"  [!] {protocol} protocol failed")

        # Run initial discovery
        if self.auto_discover and self.protocol_handlers:
            await self.discover_devices()

        # Start background discovery
        if self.auto_discover:
            self._discovery_task = asyncio.create_task(self._discovery_loop())

        self.initialized = True
        return True

    async def _init_protocol(self, protocol: str) -> Optional[Any]:
        """Initialize a protocol handler"""
        try:
            if protocol == "tuya":
                from .protocols import TuyaProtocol
                return TuyaProtocol()
            elif protocol == "lifx":
                from .protocols import LifxProtocol
                return LifxProtocol()
            elif protocol == "yeelight":
                from .protocols import YeelightProtocol
                return YeelightProtocol()
            else:
                logger.warning(f"Unknown protocol: {protocol}")
                return None
        except ImportError as e:
            logger.error(f"Protocol {protocol} not available: {e}")
            return None

    async def discover_devices(self) -> List[Device]:
        """Discover devices on all protocols"""
        discovered = []

        for protocol, handler in self.protocol_handlers.items():
            try:
                devices = await handler.discover()
                for device in devices:
                    device.protocol = protocol
                    self.devices[device.id] = device
                    discovered.append(device)
                    logger.info(f"Discovered: {device.name} ({protocol})")
            except Exception as e:
                logger.error(f"Discovery failed for {protocol}: {e}")

        return discovered

    async def _discovery_loop(self) -> None:
        """Background discovery loop"""
        while True:
            try:
                await asyncio.sleep(self.scan_interval)
                await self.discover_devices()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Discovery loop error: {e}")

    def get_device(self, device_id: str) -> Optional[Device]:
        """Get a device by ID"""
        return self.devices.get(device_id)

    def get_devices_by_type(self, device_type: DeviceType) -> List[Device]:
        """Get all devices of a specific type"""
        return [d for d in self.devices.values() if d.device_type == device_type]

    def get_lights(self) -> List[Device]:
        """Get all light devices"""
        return self.get_devices_by_type(DeviceType.LIGHT)

    async def turn_on(
        self,
        device_id: str,
        brightness: Optional[int] = None,
        color: Optional[Dict[str, int]] = None
    ) -> bool:
        """
        Turn on a device.

        Args:
            device_id: Device to control
            brightness: Optional brightness (0-100)
            color: Optional color (RGB dict)

        Returns:
            True if successful
        """
        device = self.devices.get(device_id)
        if not device:
            logger.error(f"Device not found: {device_id}")
            return False

        handler = self.protocol_handlers.get(device.protocol)
        if not handler:
            logger.error(f"Protocol not available: {device.protocol}")
            return False

        try:
            await handler.turn_on(device, brightness, color)
            device.is_on = True
            if brightness is not None:
                device.brightness = brightness
            if color is not None:
                device.color = color
            return True
        except Exception as e:
            logger.error(f"Failed to turn on {device.name}: {e}")
            return False

    async def turn_off(self, device_id: str) -> bool:
        """Turn off a device"""
        device = self.devices.get(device_id)
        if not device:
            return False

        handler = self.protocol_handlers.get(device.protocol)
        if not handler:
            return False

        try:
            await handler.turn_off(device)
            device.is_on = False
            return True
        except Exception as e:
            logger.error(f"Failed to turn off {device.name}: {e}")
            return False

    async def toggle(self, device_id: str) -> bool:
        """Toggle a device on/off"""
        device = self.devices.get(device_id)
        if not device:
            return False

        if device.is_on:
            return await self.turn_off(device_id)
        else:
            return await self.turn_on(device_id)

    async def set_brightness(self, device_id: str, brightness: int) -> bool:
        """Set device brightness (0-100)"""
        device = self.devices.get(device_id)
        if not device or device.device_type != DeviceType.LIGHT:
            return False

        handler = self.protocol_handlers.get(device.protocol)
        if not handler:
            return False

        try:
            await handler.set_brightness(device, brightness)
            device.brightness = brightness
            return True
        except Exception as e:
            logger.error(f"Failed to set brightness: {e}")
            return False

    async def set_color(self, device_id: str, r: int, g: int, b: int) -> bool:
        """Set device color (RGB)"""
        device = self.devices.get(device_id)
        if not device or device.device_type != DeviceType.LIGHT:
            return False

        handler = self.protocol_handlers.get(device.protocol)
        if not handler:
            return False

        try:
            color = {"r": r, "g": g, "b": b}
            await handler.set_color(device, color)
            device.color = color
            return True
        except Exception as e:
            logger.error(f"Failed to set color: {e}")
            return False

    # Group management

    def create_group(self, name: str, device_ids: List[str]) -> None:
        """Create a device group"""
        self.groups[name] = device_ids
        logger.info(f"Created group: {name} with {len(device_ids)} devices")

    async def group_on(self, group_name: str) -> int:
        """Turn on all devices in a group"""
        device_ids = self.groups.get(group_name, [])
        success = 0
        for device_id in device_ids:
            if await self.turn_on(device_id):
                success += 1
        return success

    async def group_off(self, group_name: str) -> int:
        """Turn off all devices in a group"""
        device_ids = self.groups.get(group_name, [])
        success = 0
        for device_id in device_ids:
            if await self.turn_off(device_id):
                success += 1
        return success

    async def all_on(self) -> int:
        """Turn on all devices"""
        success = 0
        for device_id in self.devices.keys():
            if await self.turn_on(device_id):
                success += 1
        return success

    async def all_off(self) -> int:
        """Turn off all devices"""
        success = 0
        for device_id in self.devices.keys():
            if await self.turn_off(device_id):
                success += 1
        return success

    def get_status(self) -> Dict[str, Any]:
        """Get status of all devices"""
        return {
            "device_count": len(self.devices),
            "online_count": sum(1 for d in self.devices.values() if d.state == DeviceState.ONLINE),
            "protocols": list(self.protocol_handlers.keys()),
            "devices": [
                {
                    "id": d.id,
                    "name": d.name,
                    "type": d.device_type.value,
                    "is_on": d.is_on,
                    "protocol": d.protocol
                }
                for d in self.devices.values()
            ]
        }

    async def shutdown(self) -> None:
        """Shutdown device manager"""
        if self._discovery_task:
            self._discovery_task.cancel()
            try:
                await self._discovery_task
            except asyncio.CancelledError:
                pass

        # Disconnect from devices
        for handler in self.protocol_handlers.values():
            if hasattr(handler, 'disconnect'):
                await handler.disconnect()

        self.initialized = False
        logger.info("LUMINA shutdown complete")
