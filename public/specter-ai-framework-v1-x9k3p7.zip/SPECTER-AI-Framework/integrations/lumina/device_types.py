"""
LUMINA Extended Device Types

Extended device taxonomy for network-aware device management.
"""

from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

from .device_manager import Device, DeviceType, DeviceState


class DeviceCategory(Enum):
    """Extended device categories for network devices"""
    INFRASTRUCTURE = "infrastructure"  # routers, switches, modems, APs
    SECURITY = "security"              # cameras, locks, sensors, alarms
    SMART_HOME = "smart_home"          # lights, thermostats, plugs
    ENDPOINT = "endpoint"              # computers, phones, tablets
    ENTERTAINMENT = "entertainment"    # TVs, consoles, speakers, streaming
    PRINTER = "printer"                # printers, scanners, MFPs
    IOT = "iot"                        # miscellaneous IoT devices
    STORAGE = "storage"                # NAS, external drives
    UNKNOWN = "unknown"


class ConnectionType(Enum):
    """How the device connects to the network"""
    WIRED = "wired"
    WIFI = "wifi"
    BLUETOOTH = "bluetooth"
    ZIGBEE = "zigbee"
    ZWAVE = "zwave"
    UNKNOWN = "unknown"


class OperatingSystem(Enum):
    """Known operating systems"""
    WINDOWS = "windows"
    MACOS = "macos"
    LINUX = "linux"
    ANDROID = "android"
    IOS = "ios"
    EMBEDDED = "embedded"
    ROUTER_OS = "router_os"
    PRINTER_OS = "printer_os"
    UNKNOWN = "unknown"


# Port to service mapping for common ports
COMMON_PORTS: Dict[int, str] = {
    20: "ftp-data",
    21: "ftp",
    22: "ssh",
    23: "telnet",
    25: "smtp",
    53: "dns",
    67: "dhcp-server",
    68: "dhcp-client",
    80: "http",
    110: "pop3",
    123: "ntp",
    137: "netbios-ns",
    138: "netbios-dgm",
    139: "netbios-ssn",
    143: "imap",
    161: "snmp",
    162: "snmp-trap",
    443: "https",
    445: "smb",
    465: "smtps",
    514: "syslog",
    515: "lpd",
    548: "afp",
    554: "rtsp",
    587: "submission",
    631: "ipp",
    993: "imaps",
    995: "pop3s",
    1080: "socks",
    1433: "mssql",
    1883: "mqtt",
    3306: "mysql",
    3389: "rdp",
    5000: "upnp",
    5353: "mdns",
    5432: "postgresql",
    5900: "vnc",
    6379: "redis",
    8080: "http-alt",
    8443: "https-alt",
    8883: "mqtt-tls",
    9000: "portainer",
    9090: "prometheus",
    27017: "mongodb",
    32400: "plex",
    49152: "upnp-nat",
}

# MAC address prefixes for manufacturer identification
MAC_PREFIXES: Dict[str, str] = {
    "00:1a:79": "Apple",
    "00:1e:c2": "Apple",
    "00:25:00": "Apple",
    "3c:5a:b4": "Google",
    "54:60:09": "Google",
    "f4:f5:d8": "Google",
    "b8:27:eb": "Raspberry Pi",
    "dc:a6:32": "Raspberry Pi",
    "e4:5f:01": "Raspberry Pi",
    "00:17:88": "Philips Hue",
    "00:1d:c9": "LIFX",
    "d0:73:d5": "LIFX",
    "68:c6:3a": "Espressif (ESP)",
    "24:0a:c4": "Espressif (ESP)",
    "a4:cf:12": "Espressif (ESP)",
    "44:67:55": "Tuya",
    "10:d0:7a": "Tuya",
    "50:8a:06": "Tuya",
    "00:11:32": "Synology",
    "00:09:b0": "QNAP",
    "00:08:9b": "ICP DAS",
    "b0:be:76": "TP-Link",
    "c0:25:e9": "TP-Link",
    "ec:08:6b": "TP-Link",
    "00:18:4d": "Netgear",
    "00:1e:2a": "Netgear",
    "00:24:b2": "Netgear",
    "00:14:bf": "Linksys",
    "00:1a:70": "Linksys",
    "20:aa:4b": "Linksys",
    "00:0c:29": "VMware",
    "00:50:56": "VMware",
    "08:00:27": "VirtualBox",
    "52:54:00": "QEMU/KVM",
    "00:1c:42": "Parallels",
    "3c:22:fb": "Microsoft",
    "00:15:5d": "Microsoft Hyper-V",
    "00:0d:3a": "Microsoft Azure",
    "28:6c:07": "Xiaomi",
    "78:11:dc": "Xiaomi",
    "64:cc:2e": "Xiaomi",
    "fc:a1:83": "Amazon",
    "40:b4:cd": "Amazon",
    "0c:47:c9": "Amazon",
    "00:04:20": "Roku",
    "dc:3a:5e": "Roku",
    "b0:a7:37": "Roku",
    "00:1d:ba": "Sony",
    "00:24:be": "Sony",
    "ac:9b:0a": "Sony",
    "00:09:bf": "Nintendo",
    "00:17:ab": "Nintendo",
    "00:1e:35": "Nintendo",
    "70:9c:d1": "Intel",
    "3c:97:0e": "Intel",
    "f4:4d:30": "Intel",
    "a8:20:66": "Samsung",
    "78:47:1d": "Samsung",
    "00:1a:8a": "Samsung",
    "00:04:4b": "Nvidia",
    "48:b0:2d": "Nvidia",
    "00:1c:c0": "HP",
    "00:21:5a": "HP",
    "00:25:b3": "HP",
    "00:00:0c": "Cisco",
    "00:01:42": "Cisco",
    "00:01:63": "Cisco",
    "f0:9f:c2": "Ubiquiti",
    "00:27:22": "Ubiquiti",
    "24:a4:3c": "Ubiquiti",
}


def get_manufacturer_from_mac(mac_address: str) -> Optional[str]:
    """
    Get manufacturer from MAC address prefix.

    Args:
        mac_address: MAC address in any common format

    Returns:
        Manufacturer name or None if unknown
    """
    # Normalize MAC address
    mac = mac_address.lower().replace('-', ':').replace('.', ':')
    prefix = ':'.join(mac.split(':')[:3])

    return MAC_PREFIXES.get(prefix)


def get_service_from_port(port: int) -> Optional[str]:
    """
    Get service name from port number.

    Args:
        port: Port number

    Returns:
        Service name or None if unknown
    """
    return COMMON_PORTS.get(port)


def infer_category_from_ports(ports: List[int]) -> DeviceCategory:
    """
    Infer device category from open ports.

    Args:
        ports: List of open port numbers

    Returns:
        Most likely device category
    """
    port_set = set(ports)

    # Router/infrastructure indicators
    if {67, 68, 53}.intersection(port_set):  # DHCP, DNS
        return DeviceCategory.INFRASTRUCTURE

    # Printer indicators
    if {515, 631, 9100}.intersection(port_set):  # LPD, IPP, JetDirect
        return DeviceCategory.PRINTER

    # NAS/storage indicators
    if {445, 548, 2049}.intersection(port_set):  # SMB, AFP, NFS
        return DeviceCategory.STORAGE

    # Entertainment indicators
    if {32400, 8324, 1900}.intersection(port_set):  # Plex, Roku, UPnP
        return DeviceCategory.ENTERTAINMENT

    # Security indicators
    if {554, 8554}.intersection(port_set):  # RTSP for cameras
        return DeviceCategory.SECURITY

    # Smart home indicators
    if {1883, 8883, 6668}.intersection(port_set):  # MQTT, Tuya
        return DeviceCategory.SMART_HOME

    # IoT indicators
    if {80, 443}.issubset(port_set) and len(ports) <= 3:
        return DeviceCategory.IOT

    # Endpoint indicators (SSH, RDP, VNC)
    if {22, 3389, 5900}.intersection(port_set):
        return DeviceCategory.ENDPOINT

    return DeviceCategory.UNKNOWN


def infer_os_from_ports(ports: List[int]) -> OperatingSystem:
    """
    Infer operating system from open ports.

    Args:
        ports: List of open port numbers

    Returns:
        Most likely operating system
    """
    port_set = set(ports)

    # Windows indicators
    if {135, 139, 445, 3389}.intersection(port_set):
        return OperatingSystem.WINDOWS

    # macOS indicators
    if 548 in port_set:  # AFP
        return OperatingSystem.MACOS

    # Linux indicators (SSH without Windows ports)
    if 22 in port_set and not {135, 139, 445}.intersection(port_set):
        return OperatingSystem.LINUX

    # Router indicators
    if {23, 67, 68}.intersection(port_set):
        return OperatingSystem.ROUTER_OS

    # Printer indicators
    if {515, 631, 9100}.intersection(port_set):
        return OperatingSystem.PRINTER_OS

    # Embedded/IoT
    if len(ports) <= 2 and 80 in port_set:
        return OperatingSystem.EMBEDDED

    return OperatingSystem.UNKNOWN


@dataclass
class NetworkDevice(Device):
    """
    Extended device with network attributes.

    Inherits from LUMINA's Device class and adds network-specific fields.
    """

    # Network attributes
    mac_address: str = ""
    open_ports: List[int] = field(default_factory=list)
    services: Dict[int, str] = field(default_factory=dict)
    os_fingerprint: Optional[str] = None
    manufacturer: Optional[str] = None
    category: DeviceCategory = DeviceCategory.UNKNOWN
    connection_type: ConnectionType = ConnectionType.UNKNOWN
    operating_system: OperatingSystem = OperatingSystem.UNKNOWN

    # Security attributes
    threat_level: int = 0  # 0-100
    is_trusted: bool = False
    vulnerabilities: List[str] = field(default_factory=list)

    # Discovery attributes
    discovery_method: str = "unknown"
    first_seen: Optional[datetime] = None
    last_seen: Optional[datetime] = None

    def __post_init__(self):
        """Post-initialization processing"""
        # Infer manufacturer from MAC if not set
        if not self.manufacturer and self.mac_address:
            self.manufacturer = get_manufacturer_from_mac(self.mac_address)

        # Infer category from ports if unknown
        if self.category == DeviceCategory.UNKNOWN and self.open_ports:
            self.category = infer_category_from_ports(self.open_ports)

        # Infer OS from ports if unknown
        if self.operating_system == OperatingSystem.UNKNOWN and self.open_ports:
            self.operating_system = infer_os_from_ports(self.open_ports)

        # Build services dict from ports
        if self.open_ports and not self.services:
            self.services = {
                port: get_service_from_port(port) or "unknown"
                for port in self.open_ports
            }

    def update_from_scan(
        self,
        ip_address: Optional[str] = None,
        open_ports: Optional[List[int]] = None,
        os_fingerprint: Optional[str] = None
    ) -> None:
        """Update device from scan results"""
        if ip_address:
            self.ip_address = ip_address

        if open_ports:
            self.open_ports = open_ports
            self.services = {
                port: get_service_from_port(port) or "unknown"
                for port in open_ports
            }

        if os_fingerprint:
            self.os_fingerprint = os_fingerprint

        self.last_seen = datetime.now()
        self.state = DeviceState.ONLINE

    def get_security_score(self) -> int:
        """
        Calculate security score (0-100, higher is more secure).

        Considers:
        - Number of open ports
        - Dangerous services
        - Trust status
        - Known vulnerabilities
        """
        score = 100

        # Deduct for open ports
        score -= min(len(self.open_ports) * 2, 30)

        # Deduct for dangerous services
        dangerous_ports = {23, 21, 139, 445, 3389}  # Telnet, FTP, NetBIOS, SMB, RDP
        dangerous_open = dangerous_ports.intersection(set(self.open_ports))
        score -= len(dangerous_open) * 10

        # Deduct for vulnerabilities
        score -= len(self.vulnerabilities) * 5

        # Bonus for being trusted
        if self.is_trusted:
            score += 10

        return max(0, min(100, score))

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "device_type": self.device_type.value if isinstance(self.device_type, DeviceType) else self.device_type,
            "protocol": self.protocol,
            "ip_address": self.ip_address,
            "mac_address": self.mac_address,
            "state": self.state.value if isinstance(self.state, DeviceState) else self.state,
            "is_on": self.is_on,
            "category": self.category.value,
            "connection_type": self.connection_type.value,
            "operating_system": self.operating_system.value,
            "manufacturer": self.manufacturer,
            "open_ports": self.open_ports,
            "services": self.services,
            "os_fingerprint": self.os_fingerprint,
            "threat_level": self.threat_level,
            "is_trusted": self.is_trusted,
            "security_score": self.get_security_score(),
            "vulnerabilities": self.vulnerabilities,
            "first_seen": self.first_seen.isoformat() if self.first_seen else None,
            "last_seen": self.last_seen.isoformat() if self.last_seen else None,
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'NetworkDevice':
        """Create from dictionary"""
        # Handle enum conversions
        if 'category' in data and isinstance(data['category'], str):
            data['category'] = DeviceCategory(data['category'])
        if 'connection_type' in data and isinstance(data['connection_type'], str):
            data['connection_type'] = ConnectionType(data['connection_type'])
        if 'operating_system' in data and isinstance(data['operating_system'], str):
            data['operating_system'] = OperatingSystem(data['operating_system'])
        if 'device_type' in data and isinstance(data['device_type'], str):
            data['device_type'] = DeviceType(data['device_type'])
        if 'state' in data and isinstance(data['state'], str):
            data['state'] = DeviceState(data['state'])

        # Handle datetime conversions
        if 'first_seen' in data and isinstance(data['first_seen'], str):
            data['first_seen'] = datetime.fromisoformat(data['first_seen'])
        if 'last_seen' in data and isinstance(data['last_seen'], str):
            data['last_seen'] = datetime.fromisoformat(data['last_seen'])

        return cls(**data)
