"""
LUMINA Network Protocol Handlers

Network discovery and scanning protocols following the BaseProtocol pattern.

Security Note: All subprocess calls use argument lists (not shell=True)
to prevent command injection vulnerabilities.
"""

import asyncio
import logging
import socket
import re
from typing import List, Optional, Dict, Any
from abc import ABC, abstractmethod
from datetime import datetime

from .device_types import (
    NetworkDevice,
    DeviceCategory,
    ConnectionType,
    OperatingSystem,
    get_manufacturer_from_mac,
    get_service_from_port
)
from .device_manager import DeviceType, DeviceState

logger = logging.getLogger("specter.lumina.network_protocols")


def _run_command_safely(args: List[str], timeout: float = 10.0) -> Optional[str]:
    """
    Run a command safely using argument list (no shell injection).

    Args:
        args: Command and arguments as a list
        timeout: Timeout in seconds

    Returns:
        stdout as string or None on error
    """
    import subprocess
    try:
        # shell=False is default and safe
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return result.stdout
    except subprocess.TimeoutExpired:
        logger.warning(f"Command timed out: {args[0]}")
        return None
    except FileNotFoundError:
        logger.warning(f"Command not found: {args[0]}")
        return None
    except Exception as e:
        logger.error(f"Command failed: {e}")
        return None


class NetworkProtocol(ABC):
    """Base class for network discovery protocols"""

    @abstractmethod
    async def discover(self, subnet: Optional[str] = None) -> List[NetworkDevice]:
        """Discover devices on the network"""
        pass

    @abstractmethod
    async def scan_device(self, ip: str) -> Optional[NetworkDevice]:
        """Scan a specific device by IP"""
        pass

    def _get_local_subnet(self) -> Optional[str]:
        """Get local subnet for scanning"""
        try:
            import netifaces
            gateways = netifaces.gateways()
            default_iface = gateways.get('default', {}).get(netifaces.AF_INET, [None, None])[1]

            if default_iface:
                addrs = netifaces.ifaddresses(default_iface)
                if netifaces.AF_INET in addrs:
                    ip_info = addrs[netifaces.AF_INET][0]
                    ip = ip_info.get('addr')
                    netmask = ip_info.get('netmask')

                    if ip and netmask:
                        ip_parts = [int(p) for p in ip.split('.')]
                        mask_parts = [int(p) for p in netmask.split('.')]
                        subnet_parts = [ip_parts[i] & mask_parts[i] for i in range(4)]
                        bits = bin(int(''.join([format(p, '08b') for p in mask_parts]), 2)).count('1')
                        return f"{'.'.join(map(str, subnet_parts))}/{bits}"
        except ImportError:
            logger.warning("netifaces not installed, using fallback subnet detection")
        except Exception as e:
            logger.error(f"Failed to get local subnet: {e}")

        return "192.168.1.0/24"

    def _validate_ip(self, ip: str) -> bool:
        """Validate IP address format to prevent injection"""
        pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        if not re.match(pattern, ip):
            return False
        parts = ip.split('.')
        return all(0 <= int(p) <= 255 for p in parts)

    def _validate_subnet(self, subnet: str) -> bool:
        """Validate subnet format to prevent injection"""
        pattern = r'^(\d{1,3}\.){3}\d{1,3}/\d{1,2}$'
        if not re.match(pattern, subnet):
            return False
        ip, bits = subnet.split('/')
        return self._validate_ip(ip) and 0 <= int(bits) <= 32


class ARPProtocol(NetworkProtocol):
    """
    Passive ARP table monitoring.

    Discovers devices by reading the system ARP cache.
    Fast but only sees devices that have communicated recently.
    """

    def __init__(self):
        logger.info("ARP protocol initialized")

    async def discover(self, subnet: Optional[str] = None) -> List[NetworkDevice]:
        """Discover devices from ARP table"""
        discovered = []

        try:
            loop = asyncio.get_event_loop()

            # Determine OS and run appropriate command
            import platform
            is_windows = platform.system() == 'Windows'

            if is_windows:
                args = ['arp', '-a']
            else:
                args = ['arp', '-an']

            output = await loop.run_in_executor(
                None,
                lambda: _run_command_safely(args)
            )

            if not output:
                return discovered

            # Parse output
            if is_windows:
                for line in output.split('\n'):
                    match = re.search(
                        r'(\d+\.\d+\.\d+\.\d+)\s+([\da-f-]+)\s+(\w+)',
                        line, re.IGNORECASE
                    )
                    if match:
                        ip = match.group(1)
                        mac = match.group(2).replace('-', ':').lower()
                        if mac != 'ff:ff:ff:ff:ff:ff':
                            device = await self._create_device(ip, mac)
                            if device:
                                discovered.append(device)
            else:
                for line in output.split('\n'):
                    match = re.search(
                        r'\((\d+\.\d+\.\d+\.\d+)\)\s+at\s+([\da-f:]+)',
                        line, re.IGNORECASE
                    )
                    if match:
                        ip = match.group(1)
                        mac = match.group(2).lower()
                        if mac != 'ff:ff:ff:ff:ff:ff':
                            device = await self._create_device(ip, mac)
                            if device:
                                discovered.append(device)

            logger.info(f"ARP discovered {len(discovered)} devices")

        except Exception as e:
            logger.error(f"ARP discovery failed: {e}")

        return discovered

    async def scan_device(self, ip: str) -> Optional[NetworkDevice]:
        """ARP scan doesn't support single device scan"""
        return None

    async def _create_device(self, ip: str, mac: str) -> Optional[NetworkDevice]:
        """Create device from ARP entry"""
        try:
            hostname = None
            try:
                hostname = socket.gethostbyaddr(ip)[0]
            except (socket.herror, socket.gaierror):
                pass

            device = NetworkDevice(
                id=f"arp_{mac.replace(':', '')}",
                name=hostname or f"Device {ip}",
                device_type=DeviceType.UNKNOWN,
                protocol="arp",
                ip_address=ip,
                mac_address=mac,
                state=DeviceState.ONLINE,
                manufacturer=get_manufacturer_from_mac(mac),
                discovery_method="arp",
                first_seen=datetime.now(),
                last_seen=datetime.now()
            )

            return device

        except Exception as e:
            logger.error(f"Failed to create device from ARP: {e}")
            return None


class NmapProtocol(NetworkProtocol):
    """
    Active port scanning via python-nmap.

    Full network scan with service detection.
    Requires nmap to be installed on the system.
    """

    def __init__(self, arguments: str = "-sn"):
        self.arguments = arguments
        self._nmap = None
        logger.info(f"Nmap protocol initialized with: {arguments}")

    def _get_scanner(self):
        """Lazy load nmap scanner"""
        if self._nmap is None:
            try:
                import nmap
                self._nmap = nmap.PortScanner()
            except ImportError:
                logger.error("python-nmap not installed")
                raise
        return self._nmap

    async def discover(self, subnet: Optional[str] = None) -> List[NetworkDevice]:
        """Discover devices using nmap ping scan"""
        discovered = []

        if subnet is None:
            subnet = self._get_local_subnet()

        if not self._validate_subnet(subnet):
            logger.error(f"Invalid subnet format: {subnet}")
            return discovered

        try:
            loop = asyncio.get_event_loop()
            nm = self._get_scanner()

            await loop.run_in_executor(
                None,
                lambda: nm.scan(hosts=subnet, arguments=self.arguments)
            )

            for host in nm.all_hosts():
                try:
                    mac = None
                    if 'mac' in nm[host].get('addresses', {}):
                        mac = nm[host]['addresses']['mac'].lower()

                    hostname = None
                    if 'hostnames' in nm[host] and nm[host]['hostnames']:
                        hostname = nm[host]['hostnames'][0].get('name')

                    device = NetworkDevice(
                        id=f"nmap_{host.replace('.', '_')}",
                        name=hostname or f"Host {host}",
                        device_type=DeviceType.UNKNOWN,
                        protocol="nmap",
                        ip_address=host,
                        mac_address=mac or "",
                        state=DeviceState.ONLINE if nm[host].state() == 'up' else DeviceState.OFFLINE,
                        manufacturer=get_manufacturer_from_mac(mac) if mac else None,
                        discovery_method="nmap",
                        first_seen=datetime.now(),
                        last_seen=datetime.now()
                    )

                    discovered.append(device)

                except Exception as e:
                    logger.warning(f"Failed to process nmap host {host}: {e}")

            logger.info(f"Nmap discovered {len(discovered)} devices")

        except Exception as e:
            logger.error(f"Nmap discovery failed: {e}")

        return discovered

    async def scan_device(self, ip: str) -> Optional[NetworkDevice]:
        """Detailed scan of a specific device"""
        if not self._validate_ip(ip):
            logger.error(f"Invalid IP format: {ip}")
            return None

        try:
            loop = asyncio.get_event_loop()
            nm = self._get_scanner()

            await loop.run_in_executor(
                None,
                lambda: nm.scan(hosts=ip, arguments="-sV -O --version-intensity 5")
            )

            if ip not in nm.all_hosts():
                return None

            host_data = nm[ip]

            open_ports = []
            services = {}
            if 'tcp' in host_data:
                for port, data in host_data['tcp'].items():
                    if data.get('state') == 'open':
                        open_ports.append(port)
                        services[port] = data.get('name', 'unknown')

            os_fingerprint = None
            if 'osmatch' in host_data and host_data['osmatch']:
                os_fingerprint = host_data['osmatch'][0].get('name')

            mac = host_data.get('addresses', {}).get('mac', '')
            if mac:
                mac = mac.lower()

            hostname = None
            if 'hostnames' in host_data and host_data['hostnames']:
                hostname = host_data['hostnames'][0].get('name')

            device = NetworkDevice(
                id=f"nmap_{ip.replace('.', '_')}",
                name=hostname or f"Host {ip}",
                device_type=DeviceType.UNKNOWN,
                protocol="nmap",
                ip_address=ip,
                mac_address=mac,
                state=DeviceState.ONLINE if host_data.state() == 'up' else DeviceState.OFFLINE,
                open_ports=open_ports,
                services=services,
                os_fingerprint=os_fingerprint,
                manufacturer=get_manufacturer_from_mac(mac) if mac else None,
                discovery_method="nmap",
                last_seen=datetime.now()
            )

            return device

        except Exception as e:
            logger.error(f"Nmap device scan failed: {e}")
            return None


class MDNSProtocol(NetworkProtocol):
    """
    Bonjour/mDNS service discovery.

    Discovers devices advertising services via mDNS.
    Great for Apple devices, printers, and smart home devices.
    """

    def __init__(self, timeout: float = 5.0):
        self.timeout = timeout
        logger.info("mDNS protocol initialized")

    async def discover(self, subnet: Optional[str] = None) -> List[NetworkDevice]:
        """Discover devices via mDNS"""
        discovered = []

        try:
            from zeroconf import Zeroconf, ServiceBrowser

            services = []

            class Listener:
                def add_service(self, zc, type_, name):
                    info = zc.get_service_info(type_, name)
                    if info:
                        services.append({
                            'name': name,
                            'type': type_,
                            'addresses': [socket.inet_ntoa(addr) for addr in info.addresses],
                            'port': info.port,
                            'server': info.server,
                            'properties': dict(info.properties) if info.properties else {}
                        })

                def remove_service(self, zc, type_, name):
                    pass

                def update_service(self, zc, type_, name):
                    pass

            service_types = [
                "_http._tcp.local.",
                "_https._tcp.local.",
                "_ssh._tcp.local.",
                "_smb._tcp.local.",
                "_afpovertcp._tcp.local.",
                "_printer._tcp.local.",
                "_ipp._tcp.local.",
                "_hap._tcp.local.",
                "_homekit._tcp.local.",
                "_airplay._tcp.local.",
                "_raop._tcp.local.",
                "_googlecast._tcp.local.",
                "_spotify-connect._tcp.local.",
                "_hue._tcp.local.",
            ]

            loop = asyncio.get_event_loop()

            def browse():
                zc = Zeroconf()
                listener = Listener()
                browsers = []

                for service_type in service_types:
                    try:
                        browser = ServiceBrowser(zc, service_type, listener)
                        browsers.append(browser)
                    except Exception:
                        pass

                import time
                time.sleep(self.timeout)
                zc.close()

            await loop.run_in_executor(None, browse)

            device_map = {}
            for svc in services:
                for ip in svc.get('addresses', []):
                    if ip not in device_map:
                        device_map[ip] = {
                            'services': [],
                            'name': svc.get('server', '').rstrip('.') or f"mDNS {ip}",
                            'ports': set()
                        }
                    device_map[ip]['services'].append(svc['type'])
                    device_map[ip]['ports'].add(svc.get('port', 0))

            for ip, info in device_map.items():
                device = NetworkDevice(
                    id=f"mdns_{ip.replace('.', '_')}",
                    name=info['name'],
                    device_type=DeviceType.UNKNOWN,
                    protocol="mdns",
                    ip_address=ip,
                    mac_address="",
                    state=DeviceState.ONLINE,
                    open_ports=list(info['ports']),
                    discovery_method="mdns",
                    first_seen=datetime.now(),
                    last_seen=datetime.now(),
                    metadata={'mdns_services': info['services']}
                )
                discovered.append(device)

            logger.info(f"mDNS discovered {len(discovered)} devices")

        except ImportError:
            logger.warning("zeroconf not installed")
        except Exception as e:
            logger.error(f"mDNS discovery failed: {e}")

        return discovered

    async def scan_device(self, ip: str) -> Optional[NetworkDevice]:
        """mDNS doesn't support single device scan"""
        return None


class UPnPProtocol(NetworkProtocol):
    """
    UPnP device discovery.

    Discovers devices using SSDP (Simple Service Discovery Protocol).
    Great for routers, media devices, and smart TVs.
    """

    def __init__(self, timeout: float = 3.0):
        self.timeout = timeout
        logger.info("UPnP protocol initialized")

    async def discover(self, subnet: Optional[str] = None) -> List[NetworkDevice]:
        """Discover UPnP devices"""
        discovered = []

        try:
            loop = asyncio.get_event_loop()

            def ssdp_discover():
                devices = []

                msg = (
                    'M-SEARCH * HTTP/1.1\r\n'
                    'HOST:239.255.255.250:1900\r\n'
                    'ST:ssdp:all\r\n'
                    'MX:2\r\n'
                    'MAN:"ssdp:discover"\r\n'
                    '\r\n'
                )

                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
                sock.settimeout(self.timeout)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

                try:
                    sock.sendto(msg.encode(), ('239.255.255.250', 1900))

                    while True:
                        try:
                            data, addr = sock.recvfrom(1024)
                            response = data.decode('utf-8', errors='ignore')

                            location = None
                            server = None
                            st = None

                            for line in response.split('\r\n'):
                                line_lower = line.lower()
                                if line_lower.startswith('location:'):
                                    location = line.split(':', 1)[1].strip()
                                elif line_lower.startswith('server:'):
                                    server = line.split(':', 1)[1].strip()
                                elif line_lower.startswith('st:'):
                                    st = line.split(':', 1)[1].strip()

                            devices.append({
                                'ip': addr[0],
                                'port': addr[1],
                                'location': location,
                                'server': server,
                                'service_type': st
                            })

                        except socket.timeout:
                            break

                except Exception as e:
                    logger.error(f"SSDP error: {e}")
                finally:
                    sock.close()

                return devices

            ssdp_devices = await loop.run_in_executor(None, ssdp_discover)

            device_map = {}
            for dev in ssdp_devices:
                ip = dev['ip']
                if ip not in device_map:
                    device_map[ip] = {
                        'services': [],
                        'server': dev.get('server'),
                        'ports': set()
                    }
                device_map[ip]['services'].append(dev.get('service_type'))
                device_map[ip]['ports'].add(dev.get('port', 0))
                device_map[ip]['ports'].add(1900)

            for ip, info in device_map.items():
                device = NetworkDevice(
                    id=f"upnp_{ip.replace('.', '_')}",
                    name=info.get('server') or f"UPnP {ip}",
                    device_type=DeviceType.UNKNOWN,
                    protocol="upnp",
                    ip_address=ip,
                    mac_address="",
                    state=DeviceState.ONLINE,
                    open_ports=list(info['ports']),
                    discovery_method="upnp",
                    first_seen=datetime.now(),
                    last_seen=datetime.now(),
                    metadata={'upnp_services': info['services']}
                )
                discovered.append(device)

            logger.info(f"UPnP discovered {len(discovered)} devices")

        except Exception as e:
            logger.error(f"UPnP discovery failed: {e}")

        return discovered

    async def scan_device(self, ip: str) -> Optional[NetworkDevice]:
        """UPnP doesn't support single device scan"""
        return None


class SNMPProtocol(NetworkProtocol):
    """
    SNMP discovery for routers, switches, and printers.

    Uses SNMP to query device information.
    """

    def __init__(self, community: str = "public", timeout: float = 2.0):
        self.community = community
        self.timeout = timeout
        logger.info("SNMP protocol initialized")

    async def discover(self, subnet: Optional[str] = None) -> List[NetworkDevice]:
        """SNMP discovery requires knowing device IPs first"""
        return []

    async def scan_device(self, ip: str) -> Optional[NetworkDevice]:
        """Query device via SNMP"""
        if not self._validate_ip(ip):
            logger.error(f"Invalid IP format: {ip}")
            return None

        try:
            from pysnmp.hlapi import (
                getCmd, SnmpEngine, CommunityData, UdpTransportTarget,
                ContextData, ObjectType, ObjectIdentity
            )

            loop = asyncio.get_event_loop()

            oids = {
                'sysDescr': '1.3.6.1.2.1.1.1.0',
                'sysName': '1.3.6.1.2.1.1.5.0',
                'sysContact': '1.3.6.1.2.1.1.4.0',
                'sysLocation': '1.3.6.1.2.1.1.6.0',
            }

            results = {}

            def query_snmp():
                for name, oid in oids.items():
                    try:
                        iterator = getCmd(
                            SnmpEngine(),
                            CommunityData(self.community),
                            UdpTransportTarget((ip, 161), timeout=self.timeout),
                            ContextData(),
                            ObjectType(ObjectIdentity(oid))
                        )

                        errorIndication, errorStatus, errorIndex, varBinds = next(iterator)

                        if not errorIndication and not errorStatus:
                            for varBind in varBinds:
                                results[name] = str(varBind[1])
                    except Exception:
                        pass

            await loop.run_in_executor(None, query_snmp)

            if not results:
                return None

            device = NetworkDevice(
                id=f"snmp_{ip.replace('.', '_')}",
                name=results.get('sysName', f"SNMP {ip}"),
                device_type=DeviceType.UNKNOWN,
                protocol="snmp",
                ip_address=ip,
                mac_address="",
                state=DeviceState.ONLINE,
                open_ports=[161],
                discovery_method="snmp",
                last_seen=datetime.now(),
                metadata={
                    'snmp_description': results.get('sysDescr'),
                    'snmp_contact': results.get('sysContact'),
                    'snmp_location': results.get('sysLocation')
                }
            )

            return device

        except ImportError:
            logger.warning("pysnmp not installed")
        except Exception as e:
            logger.error(f"SNMP scan failed: {e}")

        return None


class PingProtocol(NetworkProtocol):
    """
    Simple ICMP ping sweep.

    Fast way to find live hosts without nmap.
    """

    def __init__(self, timeout: float = 1.0):
        self.timeout = timeout
        logger.info("Ping protocol initialized")

    async def discover(self, subnet: Optional[str] = None) -> List[NetworkDevice]:
        """Ping sweep a subnet"""
        discovered = []

        if subnet is None:
            subnet = self._get_local_subnet()

        if not self._validate_subnet(subnet):
            logger.error(f"Invalid subnet format: {subnet}")
            return discovered

        try:
            network, bits = subnet.split('/')
            bits = int(bits)

            if bits < 24:
                logger.warning(f"Subnet {subnet} too large for ping sweep")
                return []

            base_parts = [int(p) for p in network.split('.')]
            host_count = 2 ** (32 - bits) - 2

            async def ping_host(ip: str) -> Optional[str]:
                if not self._validate_ip(ip):
                    return None

                try:
                    import platform
                    is_windows = platform.system() == 'Windows'

                    if is_windows:
                        args = ['ping', '-n', '1', '-w', str(int(self.timeout * 1000)), ip]
                    else:
                        args = ['ping', '-c', '1', '-W', str(int(self.timeout)), ip]

                    proc = await asyncio.create_subprocess_exec(
                        *args,
                        stdout=asyncio.subprocess.DEVNULL,
                        stderr=asyncio.subprocess.DEVNULL
                    )
                    await asyncio.wait_for(proc.wait(), timeout=self.timeout + 1)

                    if proc.returncode == 0:
                        return ip

                except asyncio.TimeoutError:
                    pass
                except Exception:
                    pass

                return None

            ips = []
            for i in range(1, min(host_count + 1, 255)):
                ip_parts = base_parts.copy()
                ip_parts[3] = i
                ips.append('.'.join(map(str, ip_parts)))

            batch_size = 50
            for i in range(0, len(ips), batch_size):
                batch = ips[i:i + batch_size]
                results = await asyncio.gather(*[ping_host(ip) for ip in batch])

                for ip in results:
                    if ip:
                        device = NetworkDevice(
                            id=f"ping_{ip.replace('.', '_')}",
                            name=f"Host {ip}",
                            device_type=DeviceType.UNKNOWN,
                            protocol="ping",
                            ip_address=ip,
                            mac_address="",
                            state=DeviceState.ONLINE,
                            discovery_method="ping",
                            first_seen=datetime.now(),
                            last_seen=datetime.now()
                        )
                        discovered.append(device)

            logger.info(f"Ping discovered {len(discovered)} devices")

        except Exception as e:
            logger.error(f"Ping discovery failed: {e}")

        return discovered

    async def scan_device(self, ip: str) -> Optional[NetworkDevice]:
        """Check if device responds to ping"""
        if not self._validate_ip(ip):
            logger.error(f"Invalid IP format: {ip}")
            return None

        try:
            import platform
            is_windows = platform.system() == 'Windows'

            if is_windows:
                args = ['ping', '-n', '1', '-w', str(int(self.timeout * 1000)), ip]
            else:
                args = ['ping', '-c', '1', '-W', str(int(self.timeout)), ip]

            proc = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL
            )
            await asyncio.wait_for(proc.wait(), timeout=self.timeout + 1)

            if proc.returncode == 0:
                return NetworkDevice(
                    id=f"ping_{ip.replace('.', '_')}",
                    name=f"Host {ip}",
                    device_type=DeviceType.UNKNOWN,
                    protocol="ping",
                    ip_address=ip,
                    mac_address="",
                    state=DeviceState.ONLINE,
                    discovery_method="ping",
                    last_seen=datetime.now()
                )

        except Exception as e:
            logger.error(f"Ping scan failed: {e}")

        return None


def get_protocol(name: str, **kwargs) -> NetworkProtocol:
    """
    Get a network protocol by name.

    Args:
        name: Protocol name (arp, nmap, mdns, upnp, snmp, ping)
        **kwargs: Protocol-specific arguments

    Returns:
        NetworkProtocol instance
    """
    protocols = {
        'arp': ARPProtocol,
        'nmap': NmapProtocol,
        'mdns': MDNSProtocol,
        'upnp': UPnPProtocol,
        'snmp': SNMPProtocol,
        'ping': PingProtocol
    }

    if name not in protocols:
        raise ValueError(f"Unknown protocol: {name}")

    return protocols[name](**kwargs)
