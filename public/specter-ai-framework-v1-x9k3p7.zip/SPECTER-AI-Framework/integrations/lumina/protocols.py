"""
LUMINA Protocol Implementations

Handlers for different smart device protocols.
"""

from typing import List, Optional, Dict, Any
import logging
import asyncio
from abc import ABC, abstractmethod

from .device_manager import Device, DeviceType, DeviceState

logger = logging.getLogger("specter.lumina.protocols")


class BaseProtocol(ABC):
    """Base class for protocol handlers"""

    @abstractmethod
    async def discover(self) -> List[Device]:
        """Discover devices"""
        pass

    @abstractmethod
    async def turn_on(
        self,
        device: Device,
        brightness: Optional[int] = None,
        color: Optional[Dict[str, int]] = None
    ) -> None:
        """Turn on device"""
        pass

    @abstractmethod
    async def turn_off(self, device: Device) -> None:
        """Turn off device"""
        pass

    @abstractmethod
    async def set_brightness(self, device: Device, brightness: int) -> None:
        """Set brightness"""
        pass

    @abstractmethod
    async def set_color(self, device: Device, color: Dict[str, int]) -> None:
        """Set color"""
        pass


class TuyaProtocol(BaseProtocol):
    """
    Tuya/Smart Life protocol handler.

    Uses tinytuya for local control.
    """

    def __init__(self):
        self.devices: Dict[str, Any] = {}
        logger.info("Tuya protocol initialized")

    async def discover(self) -> List[Device]:
        """Discover Tuya devices"""
        discovered = []

        try:
            import tinytuya

            loop = asyncio.get_event_loop()
            devices = await loop.run_in_executor(
                None,
                tinytuya.deviceScan
            )

            for dev_info in devices.values():
                device = Device(
                    id=dev_info.get("id", "unknown"),
                    name=dev_info.get("name", "Tuya Device"),
                    device_type=DeviceType.LIGHT,
                    protocol="tuya",
                    ip_address=dev_info.get("ip"),
                    state=DeviceState.ONLINE
                )
                discovered.append(device)
                self.devices[device.id] = dev_info

        except ImportError:
            logger.warning("tinytuya not installed")
        except Exception as e:
            logger.error(f"Tuya discovery failed: {e}")

        return discovered

    async def turn_on(
        self,
        device: Device,
        brightness: Optional[int] = None,
        color: Optional[Dict[str, int]] = None
    ) -> None:
        """Turn on Tuya device"""
        try:
            import tinytuya

            dev_info = self.devices.get(device.id)
            if not dev_info:
                return

            d = tinytuya.BulbDevice(
                dev_id=device.id,
                address=device.ip_address,
                local_key=dev_info.get("key", ""),
                version=dev_info.get("version", 3.3)
            )

            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, d.turn_on)

            if brightness is not None:
                await loop.run_in_executor(
                    None,
                    lambda: d.set_brightness_percentage(brightness)
                )

            if color is not None:
                await loop.run_in_executor(
                    None,
                    lambda: d.set_colour(color["r"], color["g"], color["b"])
                )

        except Exception as e:
            logger.error(f"Tuya turn_on failed: {e}")
            raise

    async def turn_off(self, device: Device) -> None:
        """Turn off Tuya device"""
        try:
            import tinytuya

            dev_info = self.devices.get(device.id)
            if not dev_info:
                return

            d = tinytuya.BulbDevice(
                dev_id=device.id,
                address=device.ip_address,
                local_key=dev_info.get("key", ""),
                version=dev_info.get("version", 3.3)
            )

            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, d.turn_off)

        except Exception as e:
            logger.error(f"Tuya turn_off failed: {e}")
            raise

    async def set_brightness(self, device: Device, brightness: int) -> None:
        """Set Tuya device brightness"""
        await self.turn_on(device, brightness=brightness)

    async def set_color(self, device: Device, color: Dict[str, int]) -> None:
        """Set Tuya device color"""
        await self.turn_on(device, color=color)


class LifxProtocol(BaseProtocol):
    """
    LIFX protocol handler.

    Uses lifxlan for local control.
    """

    def __init__(self):
        self.lan = None
        self.devices: Dict[str, Any] = {}
        logger.info("LIFX protocol initialized")

    async def discover(self) -> List[Device]:
        """Discover LIFX devices"""
        discovered = []

        try:
            from lifxlan import LifxLAN

            loop = asyncio.get_event_loop()
            self.lan = await loop.run_in_executor(
                None,
                LifxLAN
            )

            lights = await loop.run_in_executor(
                None,
                self.lan.get_lights
            )

            for light in lights:
                label = await loop.run_in_executor(None, light.get_label)
                device = Device(
                    id=light.get_mac_addr(),
                    name=label,
                    device_type=DeviceType.LIGHT,
                    protocol="lifx",
                    ip_address=light.get_ip_addr(),
                    state=DeviceState.ONLINE
                )
                discovered.append(device)
                self.devices[device.id] = light

        except ImportError:
            logger.warning("lifxlan not installed")
        except Exception as e:
            logger.error(f"LIFX discovery failed: {e}")

        return discovered

    async def turn_on(
        self,
        device: Device,
        brightness: Optional[int] = None,
        color: Optional[Dict[str, int]] = None
    ) -> None:
        """Turn on LIFX device"""
        try:
            light = self.devices.get(device.id)
            if not light:
                return

            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, light.set_power, True)

            if brightness is not None:
                # LIFX uses 0-65535 for brightness
                lifx_brightness = int(brightness * 655.35)
                await loop.run_in_executor(
                    None,
                    lambda: light.set_brightness(lifx_brightness)
                )

            if color is not None:
                # Convert RGB to HSBK
                h, s, b = self._rgb_to_hsb(color["r"], color["g"], color["b"])
                await loop.run_in_executor(
                    None,
                    lambda: light.set_color([h, s, b, 3500])  # 3500K color temp
                )

        except Exception as e:
            logger.error(f"LIFX turn_on failed: {e}")
            raise

    async def turn_off(self, device: Device) -> None:
        """Turn off LIFX device"""
        try:
            light = self.devices.get(device.id)
            if not light:
                return

            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, light.set_power, False)

        except Exception as e:
            logger.error(f"LIFX turn_off failed: {e}")
            raise

    async def set_brightness(self, device: Device, brightness: int) -> None:
        """Set LIFX device brightness"""
        try:
            light = self.devices.get(device.id)
            if not light:
                return

            lifx_brightness = int(brightness * 655.35)
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: light.set_brightness(lifx_brightness)
            )

        except Exception as e:
            logger.error(f"LIFX set_brightness failed: {e}")
            raise

    async def set_color(self, device: Device, color: Dict[str, int]) -> None:
        """Set LIFX device color"""
        try:
            light = self.devices.get(device.id)
            if not light:
                return

            h, s, b = self._rgb_to_hsb(color["r"], color["g"], color["b"])
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: light.set_color([h, s, b, 3500])
            )

        except Exception as e:
            logger.error(f"LIFX set_color failed: {e}")
            raise

    def _rgb_to_hsb(self, r: int, g: int, b: int) -> tuple:
        """Convert RGB to LIFX HSBK format"""
        r, g, b = r / 255.0, g / 255.0, b / 255.0
        max_c = max(r, g, b)
        min_c = min(r, g, b)
        diff = max_c - min_c

        if diff == 0:
            h = 0
        elif max_c == r:
            h = (60 * ((g - b) / diff) + 360) % 360
        elif max_c == g:
            h = (60 * ((b - r) / diff) + 120) % 360
        else:
            h = (60 * ((r - g) / diff) + 240) % 360

        s = 0 if max_c == 0 else (diff / max_c)
        v = max_c

        # Convert to LIFX scale (0-65535)
        return int(h * 182.04), int(s * 65535), int(v * 65535)


class YeelightProtocol(BaseProtocol):
    """
    Yeelight protocol handler.

    Uses yeelight library for control.
    """

    def __init__(self):
        self.devices: Dict[str, Any] = {}
        logger.info("Yeelight protocol initialized")

    async def discover(self) -> List[Device]:
        """Discover Yeelight devices"""
        discovered = []

        try:
            from yeelight import discover_bulbs, Bulb

            loop = asyncio.get_event_loop()
            bulbs = await loop.run_in_executor(None, discover_bulbs)

            for bulb_info in bulbs:
                ip = bulb_info["ip"]
                bulb = Bulb(ip)

                device = Device(
                    id=bulb_info.get("capabilities", {}).get("id", ip),
                    name=bulb_info.get("capabilities", {}).get("name", f"Yeelight {ip}"),
                    device_type=DeviceType.LIGHT,
                    protocol="yeelight",
                    ip_address=ip,
                    state=DeviceState.ONLINE
                )
                discovered.append(device)
                self.devices[device.id] = bulb

        except ImportError:
            logger.warning("yeelight not installed")
        except Exception as e:
            logger.error(f"Yeelight discovery failed: {e}")

        return discovered

    async def turn_on(
        self,
        device: Device,
        brightness: Optional[int] = None,
        color: Optional[Dict[str, int]] = None
    ) -> None:
        """Turn on Yeelight device"""
        try:
            bulb = self.devices.get(device.id)
            if not bulb:
                return

            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, bulb.turn_on)

            if brightness is not None:
                await loop.run_in_executor(
                    None,
                    lambda: bulb.set_brightness(brightness)
                )

            if color is not None:
                await loop.run_in_executor(
                    None,
                    lambda: bulb.set_rgb(color["r"], color["g"], color["b"])
                )

        except Exception as e:
            logger.error(f"Yeelight turn_on failed: {e}")
            raise

    async def turn_off(self, device: Device) -> None:
        """Turn off Yeelight device"""
        try:
            bulb = self.devices.get(device.id)
            if not bulb:
                return

            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, bulb.turn_off)

        except Exception as e:
            logger.error(f"Yeelight turn_off failed: {e}")
            raise

    async def set_brightness(self, device: Device, brightness: int) -> None:
        """Set Yeelight device brightness"""
        try:
            bulb = self.devices.get(device.id)
            if not bulb:
                return

            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: bulb.set_brightness(brightness)
            )

        except Exception as e:
            logger.error(f"Yeelight set_brightness failed: {e}")
            raise

    async def set_color(self, device: Device, color: Dict[str, int]) -> None:
        """Set Yeelight device color"""
        try:
            bulb = self.devices.get(device.id)
            if not bulb:
                return

            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: bulb.set_rgb(color["r"], color["g"], color["b"])
            )

        except Exception as e:
            logger.error(f"Yeelight set_color failed: {e}")
            raise
