"""
HIVEMIND Coordination Protocol

Defines the A2A (Agent-to-Agent) communication protocol for SPECTER.
Based on Google/Linux Foundation A2A specification patterns.

"The impossible is possible." - Barry Allen
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional
import uuid

logger = logging.getLogger("specter.integrations.hivemind.protocol")


class ConsensusAlgorithm(Enum):
    """Available consensus algorithms"""
    SIMPLE_MAJORITY = "simple-majority"      # > 50%
    WEIGHTED_MAJORITY = "weighted-majority"  # Confidence-weighted
    UNANIMOUS = "unanimous"                   # 100% agreement
    QUORUM = "quorum"                         # Minimum participants
    BYZANTINE = "byzantine"                   # BFT for adversarial


class MessageType(Enum):
    """Types of A2A messages"""
    # Discovery
    AGENT_CARD = auto()       # Agent capability announcement
    DISCOVER = auto()         # Request for agent cards

    # Task coordination
    TASK_ASSIGN = auto()      # Assign task to agent
    TASK_STATUS = auto()      # Task status update
    TASK_RESULT = auto()      # Task completion result

    # Consensus
    VOTE_REQUEST = auto()     # Request vote on decision
    VOTE_CAST = auto()        # Cast vote
    CONSENSUS_RESULT = auto() # Announce consensus

    # Knowledge
    KNOWLEDGE_SHARE = auto()  # Share knowledge
    KNOWLEDGE_QUERY = auto()  # Query for knowledge

    # Coordination
    HEARTBEAT = auto()        # Health check
    SYNC = auto()             # State synchronization


@dataclass
class AgentCard:
    """
    Agent capability card (A2A specification).

    Describes an agent's capabilities for discovery and routing.
    """
    agent_id: str
    name: str
    description: str
    capabilities: List[str]
    input_modes: List[str] = field(default_factory=lambda: ["text"])
    output_modes: List[str] = field(default_factory=lambda: ["text"])
    skills: List[str] = field(default_factory=list)
    version: str = "1.0"
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "description": self.description,
            "capabilities": self.capabilities,
            "input_modes": self.input_modes,
            "output_modes": self.output_modes,
            "skills": self.skills,
            "version": self.version,
            "created_at": self.created_at.isoformat()
        }


@dataclass
class A2AMessage:
    """
    Agent-to-Agent message format (JSON-RPC 2.0 based).
    """
    type: MessageType
    sender: str
    receiver: Optional[str]  # None = broadcast
    payload: Dict[str, Any]
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: datetime = field(default_factory=datetime.now)
    correlation_id: Optional[str] = None  # For request/response pairing

    def to_json(self) -> str:
        return json.dumps({
            "jsonrpc": "2.0",
            "id": self.id,
            "method": self.type.name,
            "params": {
                "sender": self.sender,
                "receiver": self.receiver,
                "payload": self.payload,
                "timestamp": self.timestamp.isoformat(),
                "correlation_id": self.correlation_id
            }
        })

    @classmethod
    def from_json(cls, data: str) -> "A2AMessage":
        parsed = json.loads(data)
        params = parsed["params"]
        return cls(
            type=MessageType[parsed["method"]],
            sender=params["sender"],
            receiver=params.get("receiver"),
            payload=params["payload"],
            id=parsed["id"],
            timestamp=datetime.fromisoformat(params["timestamp"]),
            correlation_id=params.get("correlation_id")
        )


@dataclass
class Vote:
    """A vote in a consensus round"""
    voter_id: str
    value: Any
    confidence: float  # 0.0 to 1.0
    reasoning: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.now)


class CoordinationProtocol:
    """
    A2A Coordination Protocol implementation.

    Handles:
    - Agent discovery and capability exchange
    - Task assignment and tracking
    - Consensus building
    - Knowledge sharing
    - Health monitoring

    Channels:
    - task-coordination: Task-related messages
    - knowledge-sharing: Knowledge exchange
    - consensus-voting: Voting and consensus
    """

    CHANNELS = [
        "task-coordination",
        "knowledge-sharing",
        "consensus-voting"
    ]

    def __init__(
        self,
        agent_id: str,
        agent_card: AgentCard
    ):
        self.agent_id = agent_id
        self.agent_card = agent_card

        # Known agents
        self.known_agents: Dict[str, AgentCard] = {}

        # Message handlers
        self._handlers: Dict[MessageType, List[Callable]] = {}

        # Pending consensus rounds
        self._pending_votes: Dict[str, List[Vote]] = {}

        # Message queue
        self._message_queue: asyncio.Queue = asyncio.Queue()

        # State
        self.running = False

        logger.info(f"Coordination Protocol initialized for agent {agent_id}")

    async def start(self) -> None:
        """Start the protocol handler"""
        self.running = True
        asyncio.create_task(self._process_messages())
        logger.info("Coordination Protocol started")

    async def stop(self) -> None:
        """Stop the protocol handler"""
        self.running = False
        logger.info("Coordination Protocol stopped")

    def register_handler(
        self,
        message_type: MessageType,
        handler: Callable[[A2AMessage], Any]
    ) -> None:
        """Register a handler for a message type"""
        if message_type not in self._handlers:
            self._handlers[message_type] = []
        self._handlers[message_type].append(handler)

    async def send(self, message: A2AMessage) -> None:
        """Send a message"""
        # In a full implementation, this would use WebSocket or similar
        await self._message_queue.put(message)
        logger.debug(f"Sent {message.type.name} to {message.receiver or 'broadcast'}")

    async def broadcast(self, message_type: MessageType, payload: Dict[str, Any]) -> None:
        """Broadcast a message to all agents"""
        message = A2AMessage(
            type=message_type,
            sender=self.agent_id,
            receiver=None,
            payload=payload
        )
        await self.send(message)

    async def request_consensus(
        self,
        topic: str,
        options: List[Any],
        algorithm: ConsensusAlgorithm = ConsensusAlgorithm.WEIGHTED_MAJORITY,
        timeout: int = 30
    ) -> Optional[Any]:
        """
        Request consensus on a topic.

        Args:
            topic: What we're voting on
            options: Available options
            algorithm: Consensus algorithm to use
            timeout: Max time to wait for votes

        Returns:
            Consensus result or None if not achieved
        """
        round_id = f"vote-{datetime.now().timestamp()}"
        self._pending_votes[round_id] = []

        # Request votes
        await self.broadcast(MessageType.VOTE_REQUEST, {
            "round_id": round_id,
            "topic": topic,
            "options": options,
            "algorithm": algorithm.value,
            "deadline": (datetime.now().timestamp() + timeout)
        })

        # Wait for votes
        await asyncio.sleep(timeout)

        # Calculate result
        votes = self._pending_votes.get(round_id, [])
        result = self._calculate_consensus(votes, algorithm)

        # Announce result
        await self.broadcast(MessageType.CONSENSUS_RESULT, {
            "round_id": round_id,
            "topic": topic,
            "result": result,
            "votes_received": len(votes)
        })

        del self._pending_votes[round_id]
        return result

    def _calculate_consensus(
        self,
        votes: List[Vote],
        algorithm: ConsensusAlgorithm
    ) -> Optional[Any]:
        """Calculate consensus from votes"""

        if not votes:
            return None

        if algorithm == ConsensusAlgorithm.SIMPLE_MAJORITY:
            # Simple majority (> 50%)
            vote_counts: Dict[Any, int] = {}
            for vote in votes:
                vote_counts[vote.value] = vote_counts.get(vote.value, 0) + 1

            total = len(votes)
            for value, count in vote_counts.items():
                if count / total > 0.5:
                    return value
            return None

        elif algorithm == ConsensusAlgorithm.WEIGHTED_MAJORITY:
            # Confidence-weighted majority
            weighted_votes: Dict[Any, float] = {}
            total_weight = sum(v.confidence for v in votes)

            for vote in votes:
                weighted_votes[vote.value] = (
                    weighted_votes.get(vote.value, 0) + vote.confidence
                )

            for value, weight in weighted_votes.items():
                if weight / total_weight > 0.5:
                    return value
            return None

        elif algorithm == ConsensusAlgorithm.UNANIMOUS:
            # All must agree
            values = set(v.value for v in votes)
            if len(values) == 1:
                return values.pop()
            return None

        elif algorithm == ConsensusAlgorithm.QUORUM:
            # Need minimum participants
            if len(votes) < 3:
                return None
            return self._calculate_consensus(votes, ConsensusAlgorithm.SIMPLE_MAJORITY)

        return None

    async def _process_messages(self) -> None:
        """Process incoming messages"""
        while self.running:
            try:
                message = await asyncio.wait_for(
                    self._message_queue.get(),
                    timeout=1.0
                )
                await self._handle_message(message)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Message processing error: {e}")

    async def _handle_message(self, message: A2AMessage) -> None:
        """Handle a received message"""

        # Built-in handlers
        if message.type == MessageType.AGENT_CARD:
            card = AgentCard(**message.payload)
            self.known_agents[card.agent_id] = card
            logger.info(f"Discovered agent: {card.name}")

        elif message.type == MessageType.DISCOVER:
            # Respond with our card
            await self.send(A2AMessage(
                type=MessageType.AGENT_CARD,
                sender=self.agent_id,
                receiver=message.sender,
                payload=self.agent_card.to_dict(),
                correlation_id=message.id
            ))

        elif message.type == MessageType.VOTE_CAST:
            round_id = message.payload.get("round_id")
            if round_id in self._pending_votes:
                vote = Vote(
                    voter_id=message.sender,
                    value=message.payload.get("value"),
                    confidence=message.payload.get("confidence", 0.5),
                    reasoning=message.payload.get("reasoning")
                )
                self._pending_votes[round_id].append(vote)

        elif message.type == MessageType.HEARTBEAT:
            # Respond to heartbeat
            await self.send(A2AMessage(
                type=MessageType.HEARTBEAT,
                sender=self.agent_id,
                receiver=message.sender,
                payload={"status": "alive"},
                correlation_id=message.id
            ))

        # Call registered handlers
        handlers = self._handlers.get(message.type, [])
        for handler in handlers:
            try:
                result = handler(message)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.error(f"Handler error for {message.type.name}: {e}")

    async def discover_agents(self) -> List[AgentCard]:
        """Discover all available agents"""
        await self.broadcast(MessageType.DISCOVER, {})
        await asyncio.sleep(2)  # Wait for responses
        return list(self.known_agents.values())

    async def share_knowledge(
        self,
        topic: str,
        content: Any,
        target: Optional[str] = None
    ) -> None:
        """Share knowledge with other agents"""
        message = A2AMessage(
            type=MessageType.KNOWLEDGE_SHARE,
            sender=self.agent_id,
            receiver=target,
            payload={
                "topic": topic,
                "content": content
            }
        )
        await self.send(message)

    async def query_knowledge(
        self,
        query: str,
        target: Optional[str] = None
    ) -> None:
        """Query for knowledge from other agents"""
        message = A2AMessage(
            type=MessageType.KNOWLEDGE_QUERY,
            sender=self.agent_id,
            receiver=target,
            payload={"query": query}
        )
        await self.send(message)

    def get_known_agents(self) -> List[AgentCard]:
        """Get all known agents"""
        return list(self.known_agents.values())

    def get_agent(self, agent_id: str) -> Optional[AgentCard]:
        """Get a specific agent's card"""
        return self.known_agents.get(agent_id)
