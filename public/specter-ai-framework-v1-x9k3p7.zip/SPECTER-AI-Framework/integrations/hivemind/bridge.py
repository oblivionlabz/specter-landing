"""
HIVEMIND Bridge

Connects SPECTER to the Hive-Mind multi-agent system.
Based on the Queen-Genesis + 8 workers architecture.

"The Queen commands, the workers execute." - Hive-Mind Protocol
"""

import asyncio
import json
import logging
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("specter.integrations.hivemind")


class WorkerType(Enum):
    """Types of workers in the Hive-Mind"""
    ARCHITECT = "architect"
    RESEARCHER = "researcher"
    IMPLEMENTER = "implementer"
    TESTER = "tester"
    REVIEWER = "reviewer"
    DOCUMENTER = "documenter"
    OPTIMIZER = "optimizer"
    SECURITY = "security"


class TaskStatus(Enum):
    """Status of a delegated task"""
    PENDING = auto()
    ASSIGNED = auto()
    IN_PROGRESS = auto()
    COMPLETED = auto()
    FAILED = auto()
    CONSENSUS_PENDING = auto()


@dataclass
class WorkerResult:
    """Result from a single worker"""
    worker_type: WorkerType
    worker_id: str
    result: Any
    confidence: float  # 0.0 to 1.0
    execution_time: float
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ConsensusResult:
    """Result after consensus building"""
    final_result: Any
    agreement_level: float  # 0.0 to 1.0
    participating_workers: int
    dissenting_workers: List[str]
    method: str  # consensus algorithm used
    iterations: int


@dataclass
class DelegatedTask:
    """A task delegated to Hive-Mind"""
    id: str
    description: str
    subtasks: List[str] = field(default_factory=list)
    worker_assignments: Dict[str, WorkerType] = field(default_factory=dict)
    results: List[WorkerResult] = field(default_factory=list)
    consensus: Optional[ConsensusResult] = None
    status: TaskStatus = TaskStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None


class HiveMindBridge:
    """
    Bridge connecting SPECTER to the Hive-Mind multi-agent system.

    The Hive-Mind consists of:
    - Queen-Genesis: Central coordinator and task decomposer
    - 8 Workers: Specialized agents for different task types

    SPECTER delegates complex tasks to Hive-Mind when:
    1. Task requires multiple specialized skills
    2. Task benefits from parallel execution
    3. Task requires consensus for critical decisions

    Coordination Protocol:
    - decision_threshold: 0.75
    - consensus_algorithm: weighted-majority
    - minimum_participants: 3
    - required_consensus: 0.67
    """

    # Default paths
    HIVE_DB_PATH = Path("/home/dxverm/.hive-mind/hive.db")
    SWARM_MEMORY_PATH = Path("/home/dxverm/.swarm/memory.db")
    CONFIG_PATH = Path("/home/dxverm/.hive-mind/config.json")

    # Consensus thresholds
    DECISION_THRESHOLD = 0.75
    MINIMUM_PARTICIPANTS = 3
    REQUIRED_CONSENSUS = 0.67

    def __init__(
        self,
        hive_db_path: Optional[Path] = None,
        swarm_memory_path: Optional[Path] = None,
        config_path: Optional[Path] = None
    ):
        self.hive_db_path = hive_db_path or self.HIVE_DB_PATH
        self.swarm_memory_path = swarm_memory_path or self.SWARM_MEMORY_PATH
        self.config_path = config_path or self.CONFIG_PATH

        # Database connections (lazy)
        self._hive_db: Optional[sqlite3.Connection] = None
        self._swarm_db: Optional[sqlite3.Connection] = None

        # Configuration
        self.config: Dict[str, Any] = {}

        # State
        self.initialized = False
        self.active_tasks: Dict[str, DelegatedTask] = {}

        # Stats
        self.tasks_delegated = 0
        self.consensus_achieved = 0
        self.avg_agreement = 0.0

        logger.info("Hive-Mind Bridge created")

    async def initialize(self) -> bool:
        """Initialize the bridge and connect to databases"""
        if self.initialized:
            return True

        logger.info("Initializing Hive-Mind Bridge...")

        # Load configuration
        if self.config_path.exists():
            try:
                with open(self.config_path) as f:
                    self.config = json.load(f)
                logger.info("  [+] Configuration loaded")
            except Exception as e:
                logger.warning(f"  [!] Failed to load config: {e}")
                self.config = {}

        # Connect to Hive database
        if self.hive_db_path.exists():
            try:
                self._hive_db = sqlite3.connect(str(self.hive_db_path))
                logger.info("  [+] Connected to Hive database")
            except Exception as e:
                logger.warning(f"  [!] Failed to connect to Hive DB: {e}")

        # Connect to Swarm memory
        if self.swarm_memory_path.exists():
            try:
                self._swarm_db = sqlite3.connect(str(self.swarm_memory_path))
                logger.info("  [+] Connected to Swarm memory")
            except Exception as e:
                logger.warning(f"  [!] Failed to connect to Swarm memory: {e}")

        self.initialized = True
        logger.info("Hive-Mind Bridge initialized")
        return True

    async def delegate_complex_task(
        self,
        task: str,
        required_workers: Optional[List[WorkerType]] = None,
        timeout: int = 300
    ) -> ConsensusResult:
        """
        Delegate a complex task to the Hive-Mind.

        Steps:
        1. Send to Queen for decomposition
        2. Assign subtasks to appropriate workers
        3. Execute in parallel
        4. Build consensus from results
        5. Return aggregated result

        Args:
            task: Task description
            required_workers: Specific worker types to use (optional)
            timeout: Maximum time to wait for completion

        Returns:
            ConsensusResult with the agreed-upon result
        """
        self.tasks_delegated += 1

        # Create task record
        task_id = f"hive-{datetime.now().timestamp()}"
        delegated = DelegatedTask(
            id=task_id,
            description=task
        )
        self.active_tasks[task_id] = delegated

        try:
            # Step 1: Decompose task via Queen
            subtasks = await self._queen_decompose(task)
            delegated.subtasks = subtasks
            delegated.status = TaskStatus.ASSIGNED

            # Step 2: Assign workers
            assignments = self._assign_workers(subtasks, required_workers)
            delegated.worker_assignments = assignments

            # Step 3: Execute in parallel
            delegated.status = TaskStatus.IN_PROGRESS
            worker_results = await self._execute_parallel(
                subtasks,
                assignments,
                timeout
            )
            delegated.results = worker_results

            # Step 4: Build consensus
            delegated.status = TaskStatus.CONSENSUS_PENDING
            consensus = await self._build_consensus(worker_results)
            delegated.consensus = consensus
            delegated.status = TaskStatus.COMPLETED
            delegated.completed_at = datetime.now()

            # Update stats
            self.consensus_achieved += 1
            self._update_avg_agreement(consensus.agreement_level)

            return consensus

        except Exception as e:
            logger.error(f"Task delegation failed: {e}")
            delegated.status = TaskStatus.FAILED
            raise

    async def _queen_decompose(self, task: str) -> List[str]:
        """
        Send task to Queen-Genesis for decomposition.

        The Queen analyzes the task and breaks it into subtasks
        that can be executed by specialized workers.
        """

        # For now, use simple rule-based decomposition
        # Full implementation will use actual Queen agent

        subtasks = []

        task_lower = task.lower()

        # Decomposition rules
        if "implement" in task_lower or "build" in task_lower:
            subtasks.extend([
                f"[ARCHITECT] Design the architecture for: {task}",
                f"[IMPLEMENTER] Implement the core functionality: {task}",
                f"[TESTER] Write tests for: {task}",
                f"[REVIEWER] Review the implementation: {task}"
            ])

        elif "fix" in task_lower or "debug" in task_lower:
            subtasks.extend([
                f"[RESEARCHER] Investigate the root cause: {task}",
                f"[IMPLEMENTER] Implement the fix: {task}",
                f"[TESTER] Verify the fix: {task}"
            ])

        elif "research" in task_lower or "analyze" in task_lower:
            subtasks.extend([
                f"[RESEARCHER] Conduct deep research: {task}",
                f"[DOCUMENTER] Document findings: {task}"
            ])

        elif "optimize" in task_lower or "improve" in task_lower:
            subtasks.extend([
                f"[ARCHITECT] Analyze current architecture: {task}",
                f"[OPTIMIZER] Identify optimization opportunities: {task}",
                f"[IMPLEMENTER] Implement optimizations: {task}",
                f"[TESTER] Benchmark improvements: {task}"
            ])

        elif "security" in task_lower or "audit" in task_lower:
            subtasks.extend([
                f"[SECURITY] Conduct security audit: {task}",
                f"[REVIEWER] Review security findings: {task}",
                f"[DOCUMENTER] Document security recommendations: {task}"
            ])

        else:
            # Default decomposition
            subtasks.extend([
                f"[RESEARCHER] Understand requirements: {task}",
                f"[ARCHITECT] Design approach: {task}",
                f"[IMPLEMENTER] Execute: {task}",
                f"[REVIEWER] Review: {task}"
            ])

        logger.info(f"Queen decomposed task into {len(subtasks)} subtasks")
        return subtasks

    def _assign_workers(
        self,
        subtasks: List[str],
        required_workers: Optional[List[WorkerType]] = None
    ) -> Dict[str, WorkerType]:
        """Assign workers to subtasks based on tags"""

        assignments = {}

        worker_tag_map = {
            "[ARCHITECT]": WorkerType.ARCHITECT,
            "[RESEARCHER]": WorkerType.RESEARCHER,
            "[IMPLEMENTER]": WorkerType.IMPLEMENTER,
            "[TESTER]": WorkerType.TESTER,
            "[REVIEWER]": WorkerType.REVIEWER,
            "[DOCUMENTER]": WorkerType.DOCUMENTER,
            "[OPTIMIZER]": WorkerType.OPTIMIZER,
            "[SECURITY]": WorkerType.SECURITY
        }

        for subtask in subtasks:
            for tag, worker_type in worker_tag_map.items():
                if tag in subtask:
                    if required_workers is None or worker_type in required_workers:
                        assignments[subtask] = worker_type
                    break
            else:
                # Default to implementer
                assignments[subtask] = WorkerType.IMPLEMENTER

        return assignments

    async def _execute_parallel(
        self,
        subtasks: List[str],
        assignments: Dict[str, WorkerType],
        timeout: int
    ) -> List[WorkerResult]:
        """Execute subtasks in parallel via workers"""

        # Create execution tasks
        async def execute_subtask(subtask: str, worker_type: WorkerType) -> WorkerResult:
            start = datetime.now()

            # Simulate worker execution
            # Full implementation will spawn actual worker agents
            await asyncio.sleep(0.1)  # Placeholder

            result = WorkerResult(
                worker_type=worker_type,
                worker_id=f"{worker_type.value}-001",
                result=f"Completed: {subtask}",
                confidence=0.8,  # Placeholder
                execution_time=(datetime.now() - start).total_seconds()
            )

            return result

        # Execute all in parallel
        tasks = [
            execute_subtask(subtask, worker_type)
            for subtask, worker_type in assignments.items()
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Filter out errors
        valid_results = [
            r for r in results
            if isinstance(r, WorkerResult)
        ]

        for r in results:
            if isinstance(r, Exception):
                logger.warning(f"Worker execution failed: {r}")

        return valid_results

    async def _build_consensus(
        self,
        worker_results: List[WorkerResult]
    ) -> ConsensusResult:
        """
        Build consensus from worker results.

        Uses weighted-majority voting where:
        - Each worker's vote is weighted by their confidence
        - Consensus requires 67% agreement
        - At least 3 workers must participate
        """

        if len(worker_results) < self.MINIMUM_PARTICIPANTS:
            logger.warning(
                f"Not enough participants ({len(worker_results)}) "
                f"for consensus (need {self.MINIMUM_PARTICIPANTS})"
            )

        # Calculate weighted agreement
        total_weight = sum(r.confidence for r in worker_results)
        if total_weight == 0:
            total_weight = 1

        # For now, simple aggregation
        # Full implementation will use proper voting

        # Calculate agreement (placeholder)
        avg_confidence = (
            sum(r.confidence for r in worker_results) / len(worker_results)
            if worker_results else 0
        )

        # Combine results
        combined = "\n".join([
            f"[{r.worker_type.value}] {r.result}"
            for r in worker_results
        ])

        return ConsensusResult(
            final_result=combined,
            agreement_level=avg_confidence,
            participating_workers=len(worker_results),
            dissenting_workers=[],  # Placeholder
            method="weighted-majority",
            iterations=1
        )

    def _update_avg_agreement(self, new_agreement: float) -> None:
        """Update running average agreement"""
        if self.consensus_achieved == 1:
            self.avg_agreement = new_agreement
        else:
            alpha = 0.1
            self.avg_agreement = (
                alpha * new_agreement +
                (1 - alpha) * self.avg_agreement
            )

    async def get_swarm_memory(self, key: str) -> Optional[Any]:
        """Get data from shared swarm memory"""
        if not self._swarm_db:
            return None

        try:
            cursor = self._swarm_db.execute(
                "SELECT value FROM memory WHERE key = ?",
                (key,)
            )
            row = cursor.fetchone()
            if row:
                return json.loads(row[0])
        except Exception as e:
            logger.warning(f"Failed to get swarm memory: {e}")

        return None

    async def set_swarm_memory(self, key: str, value: Any) -> bool:
        """Set data in shared swarm memory"""
        if not self._swarm_db:
            return False

        try:
            self._swarm_db.execute(
                "INSERT OR REPLACE INTO memory (key, value, updated_at) VALUES (?, ?, ?)",
                (key, json.dumps(value), datetime.now().isoformat())
            )
            self._swarm_db.commit()
            return True
        except Exception as e:
            logger.warning(f"Failed to set swarm memory: {e}")
            return False

    def get_active_tasks(self) -> List[DelegatedTask]:
        """Get all active tasks"""
        return list(self.active_tasks.values())

    def get_task(self, task_id: str) -> Optional[DelegatedTask]:
        """Get a specific task by ID"""
        return self.active_tasks.get(task_id)

    def get_stats(self) -> Dict[str, Any]:
        """Get bridge statistics"""
        return {
            "initialized": self.initialized,
            "hive_db_connected": self._hive_db is not None,
            "swarm_db_connected": self._swarm_db is not None,
            "tasks_delegated": self.tasks_delegated,
            "consensus_achieved": self.consensus_achieved,
            "avg_agreement": self.avg_agreement,
            "active_tasks": len(self.active_tasks)
        }

    async def shutdown(self) -> None:
        """Shutdown the bridge"""
        logger.info("Shutting down Hive-Mind Bridge...")

        if self._hive_db:
            self._hive_db.close()
            self._hive_db = None

        if self._swarm_db:
            self._swarm_db.close()
            self._swarm_db = None

        self.initialized = False
        logger.info("Hive-Mind Bridge shutdown complete")
