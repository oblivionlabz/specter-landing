"""
HIVEMIND Integration

Connects SPECTER to the Hive-Mind multi-agent system for complex task delegation.
Enables Queen-Genesis + 8 workers coordination.

"I alone am the honored one. But even I know when to delegate." - Gojo mode
"""

from .bridge import HiveMindBridge, ConsensusResult, WorkerResult
from .protocol import CoordinationProtocol, ConsensusAlgorithm

__all__ = [
    "HiveMindBridge",
    "ConsensusResult",
    "WorkerResult",
    "CoordinationProtocol",
    "ConsensusAlgorithm"
]
