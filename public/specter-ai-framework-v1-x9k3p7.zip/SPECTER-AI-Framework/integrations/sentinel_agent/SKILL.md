# SENTINEL Agent Skill

Network-aware guardian for device discovery, security monitoring, and automated threat response.

## Capabilities

### Device Discovery
- **Passive scanning**: ARP/mDNS monitoring without network disruption
- **Active scanning**: TCP/UDP port probing with service detection
- **Quick scan**: Fast network sweep for online devices
- **Full scan**: Comprehensive fingerprinting with OS detection (requires nmap)

### Security Monitoring
- Real-time threat detection and classification
- Rogue device identification
- Network anomaly detection
- Policy violation tracking

### Device Control
- Block/unblock devices via iptables
- Network isolation
- Rate limiting
- Wake-on-LAN
- Smart device control (on/off, brightness)

### Threat Response
- Automated threat mitigation
- Configurable response policies
- Severity-based escalation
- Audit trail and logging

## Usage

### Python API

```python
from integrations.sentinel_agent import SentinelAgent, ScanMode

# Initialize agent
agent = SentinelAgent(db_path="sentinel.db")

# Discover network devices
devices = await agent.discover_network(ScanMode.ACTIVE)

# Get network status
status = await agent.get_network_status()
print(f"Online devices: {status.online_devices}")
print(f"Active threats: {status.active_threats}")

# Control devices
await agent.block_device("device-id", duration=3600)
await agent.isolate_device("suspicious-device")
await agent.trust_device("known-device")

# Register threat callbacks
agent.on_threat_detected(lambda t: print(f"Threat: {t.description}"))
agent.on_response_executed(lambda r: print(f"Response: {r.action}"))
```

### REST API

Start the API server:
```bash
python -m integrations.sentinel_agent.api --host 0.0.0.0 --port 8888
```

Endpoints:
- `GET /devices` - List all devices
- `GET /devices/{id}` - Get device details
- `POST /devices/{id}/control` - Control device
- `POST /devices/{id}/trust` - Set trust status
- `POST /devices/{id}/isolate` - Isolate device
- `POST /devices/{id}/block` - Block device
- `GET /threats` - List threats
- `POST /threats/{id}/resolve` - Resolve threat
- `POST /scan` - Start network scan
- `GET /status/network` - Network status
- `GET /status/security` - Security status
- `WS /events` - Real-time event stream

### WebSocket Events

```javascript
const ws = new WebSocket('ws://localhost:8888/events');

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  switch(data.type) {
    case 'device_discovered':
      console.log('New device:', data.device);
      break;
    case 'threat_detected':
      console.log('Threat:', data.threat);
      break;
    case 'response_executed':
      console.log('Response:', data.response);
      break;
  }
};
```

## Configuration

### Database
SQLite database stores devices, threats, scans, and baselines.

```python
from integrations.sentinel_agent import SentinelDB

db = SentinelDB("sentinel.db")
devices = db.get_all_devices()
threats = db.get_active_threats()
```

### Scanner Options
- `interface`: Network interface (default: auto-detect)
- `subnet`: Target subnet (default: local network)
- `timeout`: Scan timeout in seconds
- `use_nmap`: Enable nmap for deep scanning

### Controller Options
- `db`: SentinelDB instance for device lookups
- Rate limiting and blocking use iptables (requires root)

## Dependencies

Required:
- Python 3.10+
- aiosqlite
- scapy (for passive scanning)

Optional:
- nmap (for full scanning)
- FastAPI + uvicorn (for REST API)

## Architecture

```
sentinel_agent/
├── __init__.py      # Public exports
├── db.py            # SQLite persistence (SentinelDB)
├── scanner.py       # Network discovery (NetworkScanner)
├── controller.py    # Device control (DeviceController)
├── agent.py         # Main orchestrator (SentinelAgent)
└── api.py           # REST/WebSocket API
```

### Integration with SPECTER

The Sentinel Agent integrates with:
- `core.sentinel.network_monitor` - Network event monitoring
- `core.sentinel.threat_analyzer` - Threat classification
- `integrations.lumina.device_types` - Device categorization
- `integrations.lumina.network_protocols` - Protocol handling

## Test Coverage

- **Total**: 80.93% (excluding api.py due to Pydantic v2 incompatibility)
- 268 tests passing
- Covers: db.py (89%), scanner.py (81%), controller.py (85%), agent.py (68%)

## Security Considerations

- Device control operations require elevated privileges
- API uses CORS middleware (configure for production)
- Sensitive operations logged for audit
- Rate limiting prevents abuse
