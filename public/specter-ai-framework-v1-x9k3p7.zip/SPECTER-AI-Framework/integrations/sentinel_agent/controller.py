"""
SENTINEL Device Controller

Bridge between Sentinel and LUMINA for device control.
Routes commands to appropriate protocols based on device type.
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import asyncio
import logging
import re
import socket
import struct

from integrations.lumina.device_manager import DeviceManager, Device
from integrations.lumina.device_types import NetworkDevice, DeviceCategory, OperatingSystem

logger = logging.getLogger(__name__)


class ControlAction(Enum):
    """Device control actions"""
    # Power control
    TURN_ON = "turn_on"
    TURN_OFF = "turn_off"
    RESTART = "restart"
    WAKE_ON_LAN = "wake_on_lan"

    # Smart device control
    SET_BRIGHTNESS = "set_brightness"
    SET_COLOR = "set_color"
    SET_TEMPERATURE = "set_temperature"

    # Network control
    BLOCK = "block"
    UNBLOCK = "unblock"
    ISOLATE = "isolate"
    UNISOLATE = "unisolate"
    RATE_LIMIT = "rate_limit"

    # Information
    GET_STATUS = "get_status"
    GET_INFO = "get_info"
    PING = "ping"

    # Advanced
    EXECUTE_COMMAND = "execute_command"
    UPDATE_FIRMWARE = "update_firmware"


@dataclass
class ControlResult:
    """Result of a control action"""
    device_id: str
    action: ControlAction
    success: bool
    message: str
    data: Dict[str, Any]
    executed_at: datetime

    def to_dict(self) -> Dict[str, Any]:
        return {
            "device_id": self.device_id,
            "action": self.action.value,
            "success": self.success,
            "message": self.message,
            "data": self.data,
            "executed_at": self.executed_at.isoformat()
        }


@dataclass
class BlockedDevice:
    """Tracked blocked device"""
    device_id: str
    blocked_at: datetime
    expires_at: datetime
    reason: str


def _validate_ip_address(ip: str) -> bool:
    """
    Validate IP address format strictly.

    Only allows valid IPv4 addresses to prevent injection.
    """
    if not ip or not isinstance(ip, str):
        return False

    # Strict IPv4 pattern
    pattern = r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
    return bool(re.match(pattern, ip))


def _validate_mac_address(mac: str) -> bool:
    """
    Validate MAC address format strictly.

    Accepts formats: XX:XX:XX:XX:XX:XX or XX-XX-XX-XX-XX-XX
    """
    if not mac or not isinstance(mac, str):
        return False

    # Normalize and validate
    normalized = mac.replace("-", ":").lower()
    pattern = r'^([0-9a-f]{2}:){5}[0-9a-f]{2}$'
    return bool(re.match(pattern, normalized))


class DeviceController:
    """
    Bridge between Sentinel and device control protocols.

    Routes control commands to appropriate handlers:
    - Smart devices → LUMINA (Tuya/LIFX/Yeelight)
    - Routers → SNMP/SSH (future)
    - Printers → IPP/SNMP (future)
    - Computers → WoL/SSH/RPC (future)
    """

    def __init__(
        self,
        lumina: Optional[DeviceManager] = None,
        db=None
    ):
        """
        Initialize device controller.

        Args:
            lumina: LUMINA device manager for smart devices
            db: SentinelDB for device lookup
        """
        self.lumina = lumina
        self.db = db

        # Track blocked devices
        self._blocked: Dict[str, BlockedDevice] = {}

        # Track isolated devices
        self._isolated: set = set()

        # Rate limiting tracking
        self._rate_limits: Dict[str, Dict[str, Any]] = {}

    async def control_device(
        self,
        device_id: str,
        action: str,
        **params: Any
    ) -> bool:
        """
        Control a device.

        Args:
            device_id: Target device ID
            action: Action to perform
            **params: Action parameters

        Returns:
            True if action succeeded
        """
        try:
            control_action = ControlAction(action)
        except ValueError:
            logger.error(f"Unknown action: {action}")
            return False

        # Check if device is blocked
        if self._is_blocked(device_id):
            logger.warning(f"Device {device_id} is blocked, cannot control")
            return False

        # Route to appropriate handler
        result = await self._route_action(device_id, control_action, params)

        if result.success:
            logger.info(f"Action {action} on {device_id} succeeded: {result.message}")
        else:
            logger.warning(f"Action {action} on {device_id} failed: {result.message}")

        return result.success

    async def _route_action(
        self,
        device_id: str,
        action: ControlAction,
        params: Dict[str, Any]
    ) -> ControlResult:
        """Route action to appropriate handler based on device type"""

        # Network control actions
        if action == ControlAction.BLOCK:
            return await self._handle_block(device_id, params)
        elif action == ControlAction.UNBLOCK:
            return await self._handle_unblock(device_id)
        elif action == ControlAction.ISOLATE:
            return await self._handle_isolate(device_id)
        elif action == ControlAction.UNISOLATE:
            return await self._handle_unisolate(device_id)
        elif action == ControlAction.RATE_LIMIT:
            return await self._handle_rate_limit(device_id, params)
        elif action == ControlAction.PING:
            return await self._handle_ping(device_id)
        elif action == ControlAction.WAKE_ON_LAN:
            return await self._handle_wol(device_id)

        # Smart device actions - route to LUMINA
        smart_actions = {
            ControlAction.TURN_ON,
            ControlAction.TURN_OFF,
            ControlAction.SET_BRIGHTNESS,
            ControlAction.SET_COLOR,
            ControlAction.SET_TEMPERATURE
        }

        if action in smart_actions:
            return await self._handle_smart_device(device_id, action, params)

        # Status/info actions
        if action == ControlAction.GET_STATUS:
            return await self._handle_get_status(device_id)
        elif action == ControlAction.GET_INFO:
            return await self._handle_get_info(device_id)

        return ControlResult(
            device_id=device_id,
            action=action,
            success=False,
            message=f"Action {action.value} not implemented",
            data={},
            executed_at=datetime.now()
        )

    # Network control handlers

    async def block_device(
        self,
        device_id: str,
        duration_seconds: int = 3600
    ) -> bool:
        """Block a device for a specified duration"""
        result = await self._handle_block(device_id, {
            "duration_seconds": duration_seconds,
            "reason": "Security block"
        })
        return result.success

    async def unblock_device(self, device_id: str) -> bool:
        """Unblock a device"""
        result = await self._handle_unblock(device_id)
        return result.success

    async def isolate_device(self, device_id: str) -> bool:
        """Isolate a device from the network"""
        result = await self._handle_isolate(device_id)
        return result.success

    async def unisolate_device(self, device_id: str) -> bool:
        """Remove device isolation"""
        result = await self._handle_unisolate(device_id)
        return result.success

    def _is_blocked(self, device_id: str) -> bool:
        """Check if device is currently blocked"""
        if device_id not in self._blocked:
            return False

        blocked = self._blocked[device_id]
        if datetime.now() > blocked.expires_at:
            # Block expired, remove it
            del self._blocked[device_id]
            return False

        return True

    async def _handle_block(
        self,
        device_id: str,
        params: Dict[str, Any]
    ) -> ControlResult:
        """Handle device blocking"""
        duration = params.get("duration_seconds", 3600)
        reason = params.get("reason", "Manual block")

        now = datetime.now()
        expires = now + timedelta(seconds=duration)

        self._blocked[device_id] = BlockedDevice(
            device_id=device_id,
            blocked_at=now,
            expires_at=expires,
            reason=reason
        )

        logger.info(f"Device {device_id} blocked until {expires}")

        # In a real implementation, this would add firewall rules
        # For now, we just track the block internally

        return ControlResult(
            device_id=device_id,
            action=ControlAction.BLOCK,
            success=True,
            message=f"Blocked for {duration} seconds",
            data={"expires_at": expires.isoformat()},
            executed_at=now
        )

    async def _handle_unblock(self, device_id: str) -> ControlResult:
        """Handle device unblocking"""
        if device_id in self._blocked:
            del self._blocked[device_id]
            logger.info(f"Device {device_id} unblocked")

            return ControlResult(
                device_id=device_id,
                action=ControlAction.UNBLOCK,
                success=True,
                message="Device unblocked",
                data={},
                executed_at=datetime.now()
            )

        return ControlResult(
            device_id=device_id,
            action=ControlAction.UNBLOCK,
            success=True,
            message="Device was not blocked",
            data={},
            executed_at=datetime.now()
        )

    async def _handle_isolate(self, device_id: str) -> ControlResult:
        """Handle device isolation"""
        self._isolated.add(device_id)
        logger.info(f"Device {device_id} isolated")

        # In a real implementation, this would:
        # 1. Add firewall rules to block all traffic
        # 2. Move device to isolated VLAN
        # 3. Notify network equipment

        return ControlResult(
            device_id=device_id,
            action=ControlAction.ISOLATE,
            success=True,
            message="Device isolated from network",
            data={"isolated": True},
            executed_at=datetime.now()
        )

    async def _handle_unisolate(self, device_id: str) -> ControlResult:
        """Handle removing device isolation"""
        if device_id in self._isolated:
            self._isolated.remove(device_id)
            logger.info(f"Device {device_id} isolation removed")

        return ControlResult(
            device_id=device_id,
            action=ControlAction.UNISOLATE,
            success=True,
            message="Device isolation removed",
            data={"isolated": False},
            executed_at=datetime.now()
        )

    async def _handle_rate_limit(
        self,
        device_id: str,
        params: Dict[str, Any]
    ) -> ControlResult:
        """Handle rate limiting a device"""
        max_requests = params.get("max_requests_per_minute", 60)
        burst = params.get("burst_size", 10)

        self._rate_limits[device_id] = {
            "max_requests_per_minute": max_requests,
            "burst_size": burst,
            "applied_at": datetime.now()
        }

        logger.info(f"Rate limit applied to {device_id}: {max_requests}/min")

        return ControlResult(
            device_id=device_id,
            action=ControlAction.RATE_LIMIT,
            success=True,
            message=f"Rate limited to {max_requests} requests/minute",
            data=self._rate_limits[device_id],
            executed_at=datetime.now()
        )

    async def _handle_ping(self, device_id: str) -> ControlResult:
        """
        Ping a device to check if it's online.

        Uses Python socket for ICMP-like connectivity check
        instead of subprocess to avoid command injection risks.
        """
        # Get device IP from database
        ip_address = await self._get_device_ip(device_id)

        if not ip_address:
            return ControlResult(
                device_id=device_id,
                action=ControlAction.PING,
                success=False,
                message="Could not find device IP",
                data={},
                executed_at=datetime.now()
            )

        # Strict IP validation
        if not _validate_ip_address(ip_address):
            return ControlResult(
                device_id=device_id,
                action=ControlAction.PING,
                success=False,
                message="Invalid IP address format",
                data={},
                executed_at=datetime.now()
            )

        try:
            # Use TCP connect as a proxy for ping (no subprocess needed)
            # Try common ports: 80, 443, 22
            is_online = False
            for port in [80, 443, 22, 7]:
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(2)
                    result = sock.connect_ex((ip_address, port))
                    sock.close()
                    if result == 0:
                        is_online = True
                        break
                except socket.error:
                    continue

            return ControlResult(
                device_id=device_id,
                action=ControlAction.PING,
                success=True,
                message="Device is online" if is_online else "Device appears offline",
                data={"online": is_online, "ip": ip_address},
                executed_at=datetime.now()
            )

        except Exception as e:
            return ControlResult(
                device_id=device_id,
                action=ControlAction.PING,
                success=False,
                message=str(e),
                data={},
                executed_at=datetime.now()
            )

    async def _handle_wol(self, device_id: str) -> ControlResult:
        """Send Wake-on-LAN magic packet using pure Python sockets"""
        # Get device MAC from database
        mac_address = await self._get_device_mac(device_id)

        if not mac_address:
            return ControlResult(
                device_id=device_id,
                action=ControlAction.WAKE_ON_LAN,
                success=False,
                message="Could not find device MAC address",
                data={},
                executed_at=datetime.now()
            )

        # Strict MAC validation
        if not _validate_mac_address(mac_address):
            return ControlResult(
                device_id=device_id,
                action=ControlAction.WAKE_ON_LAN,
                success=False,
                message="Invalid MAC address format",
                data={},
                executed_at=datetime.now()
            )

        try:
            # Normalize MAC address - remove separators
            mac = mac_address.replace(":", "").replace("-", "").lower()

            # Create magic packet: 6 bytes of 0xFF followed by MAC repeated 16 times
            mac_bytes = bytes.fromhex(mac)
            magic_packet = b'\xff' * 6 + mac_bytes * 16

            # Send via UDP broadcast
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.sendto(magic_packet, ('255.255.255.255', 9))
            sock.close()

            logger.info(f"WoL packet sent to {mac_address}")

            return ControlResult(
                device_id=device_id,
                action=ControlAction.WAKE_ON_LAN,
                success=True,
                message="Wake-on-LAN packet sent",
                data={"mac": mac_address},
                executed_at=datetime.now()
            )

        except Exception as e:
            return ControlResult(
                device_id=device_id,
                action=ControlAction.WAKE_ON_LAN,
                success=False,
                message=str(e),
                data={},
                executed_at=datetime.now()
            )

    # Smart device handlers

    async def _handle_smart_device(
        self,
        device_id: str,
        action: ControlAction,
        params: Dict[str, Any]
    ) -> ControlResult:
        """Route smart device actions to LUMINA"""
        if not self.lumina:
            return ControlResult(
                device_id=device_id,
                action=action,
                success=False,
                message="LUMINA device manager not available",
                data={},
                executed_at=datetime.now()
            )

        try:
            # Get device from LUMINA
            device = await self.lumina.get_device(device_id)

            if not device:
                return ControlResult(
                    device_id=device_id,
                    action=action,
                    success=False,
                    message="Device not found in LUMINA",
                    data={},
                    executed_at=datetime.now()
                )

            # Execute action
            if action == ControlAction.TURN_ON:
                success = await self.lumina.turn_on(device_id)
            elif action == ControlAction.TURN_OFF:
                success = await self.lumina.turn_off(device_id)
            elif action == ControlAction.SET_BRIGHTNESS:
                brightness = params.get("brightness", 100)
                success = await self.lumina.set_brightness(device_id, brightness)
            elif action == ControlAction.SET_COLOR:
                color = params.get("color", {"r": 255, "g": 255, "b": 255})
                success = await self.lumina.set_color(device_id, **color)
            elif action == ControlAction.SET_TEMPERATURE:
                temp = params.get("temperature", 4000)
                success = await self.lumina.set_temperature(device_id, temp)
            else:
                success = False

            return ControlResult(
                device_id=device_id,
                action=action,
                success=success,
                message="Action executed" if success else "Action failed",
                data=params,
                executed_at=datetime.now()
            )

        except Exception as e:
            return ControlResult(
                device_id=device_id,
                action=action,
                success=False,
                message=str(e),
                data={},
                executed_at=datetime.now()
            )

    # Status handlers

    async def _handle_get_status(self, device_id: str) -> ControlResult:
        """Get device status"""
        is_blocked = self._is_blocked(device_id)
        is_isolated = device_id in self._isolated
        rate_limit = self._rate_limits.get(device_id)

        # Try to get device from LUMINA if available
        lumina_status = None
        if self.lumina:
            try:
                device = await self.lumina.get_device(device_id)
                if device:
                    lumina_status = {
                        "name": device.name,
                        "type": device.device_type,
                        "state": device.state.value if hasattr(device.state, 'value') else str(device.state),
                        "is_on": device.is_on
                    }
            except Exception:
                pass

        status = {
            "blocked": is_blocked,
            "isolated": is_isolated,
            "rate_limited": rate_limit is not None,
            "rate_limit": rate_limit,
            "lumina": lumina_status
        }

        if is_blocked:
            blocked = self._blocked[device_id]
            status["block_expires"] = blocked.expires_at.isoformat()
            status["block_reason"] = blocked.reason

        return ControlResult(
            device_id=device_id,
            action=ControlAction.GET_STATUS,
            success=True,
            message="Status retrieved",
            data=status,
            executed_at=datetime.now()
        )

    async def _handle_get_info(self, device_id: str) -> ControlResult:
        """Get detailed device information"""
        info = {
            "device_id": device_id
        }

        # Get from database if available
        if self.db:
            record = self.db.get_device(device_id)
            if record:
                info.update({
                    "ip_address": record.ip_address,
                    "mac_address": record.mac_address,
                    "hostname": record.hostname,
                    "manufacturer": record.manufacturer,
                    "device_type": record.device_type,
                    "category": record.category,
                    "is_trusted": record.is_trusted,
                    "threat_level": record.threat_level,
                    "first_seen": record.first_seen.isoformat() if record.first_seen else None,
                    "last_seen": record.last_seen.isoformat() if record.last_seen else None
                })

        return ControlResult(
            device_id=device_id,
            action=ControlAction.GET_INFO,
            success=True,
            message="Info retrieved",
            data=info,
            executed_at=datetime.now()
        )

    # Helper methods

    async def _get_device_ip(self, device_id: str) -> Optional[str]:
        """Get device IP address from database"""
        if self.db:
            record = self.db.get_device(device_id)
            if record:
                return record.ip_address
        return None

    async def _get_device_mac(self, device_id: str) -> Optional[str]:
        """Get device MAC address from database"""
        if self.db:
            record = self.db.get_device(device_id)
            if record:
                return record.mac_address
        return None

    # Bulk operations

    async def get_blocked_devices(self) -> List[BlockedDevice]:
        """Get list of currently blocked devices"""
        # Clean up expired blocks
        now = datetime.now()
        expired = [
            device_id for device_id, blocked in self._blocked.items()
            if now > blocked.expires_at
        ]
        for device_id in expired:
            del self._blocked[device_id]

        return list(self._blocked.values())

    async def get_isolated_devices(self) -> List[str]:
        """Get list of isolated device IDs"""
        return list(self._isolated)

    async def get_rate_limited_devices(self) -> Dict[str, Dict[str, Any]]:
        """Get rate limiting status for all devices"""
        return self._rate_limits.copy()

    async def clear_all_blocks(self) -> int:
        """Clear all device blocks"""
        count = len(self._blocked)
        self._blocked.clear()
        logger.info(f"Cleared {count} device blocks")
        return count

    async def clear_all_isolations(self) -> int:
        """Clear all device isolations"""
        count = len(self._isolated)
        self._isolated.clear()
        logger.info(f"Cleared {count} device isolations")
        return count
