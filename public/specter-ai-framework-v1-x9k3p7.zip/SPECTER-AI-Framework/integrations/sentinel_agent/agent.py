"""
SENTINEL Agent - Unified Guardian

Main orchestrator combining network scanning, threat detection,
and device control into a unified guardian agent.
"""

from typing import List, Optional, Dict, Any, Callable, Awaitable
from dataclasses import dataclass
from datetime import datetime
import asyncio
import logging

from integrations.sentinel_agent.db import SentinelDB, DeviceRecord, ThreatRecord, ScanRecord, ThreatSeverity
from integrations.sentinel_agent.scanner import NetworkScanner, ScanMode
from integrations.sentinel_agent.controller import DeviceController

from core.sentinel.network_monitor import (
    NetworkMonitor,
    Threat,
    ThreatType,
    ThreatSeverity as MonitorSeverity
)
from core.sentinel.threat_analyzer import (
    ThreatAnalyzer,
    ResponseRecommendation,
    ResponseResult,
    ResponseAction
)
from integrations.lumina.device_types import NetworkDevice, DeviceCategory
from integrations.lumina.device_manager import DeviceManager

logger = logging.getLogger(__name__)


@dataclass
class NetworkStatus:
    """Current network status summary"""
    total_devices: int
    online_devices: int
    trusted_devices: int
    untrusted_devices: int
    active_threats: int
    critical_threats: int
    last_scan: Optional[datetime]
    scanning: bool

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_devices": self.total_devices,
            "online_devices": self.online_devices,
            "trusted_devices": self.trusted_devices,
            "untrusted_devices": self.untrusted_devices,
            "active_threats": self.active_threats,
            "critical_threats": self.critical_threats,
            "last_scan": self.last_scan.isoformat() if self.last_scan else None,
            "scanning": self.scanning
        }


@dataclass
class SecurityStatus:
    """Security posture summary"""
    overall_score: int  # 0-100
    threat_level: str  # low, medium, high, critical
    active_threats: List[Threat]
    recent_responses: List[ResponseResult]
    vulnerable_devices: int
    policy_violations: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "overall_score": self.overall_score,
            "threat_level": self.threat_level,
            "active_threats": [t.to_dict() for t in self.active_threats],
            "recent_responses": [r.to_dict() for r in self.recent_responses],
            "vulnerable_devices": self.vulnerable_devices,
            "policy_violations": self.policy_violations
        }


# Event callback types
DeviceCallback = Callable[[NetworkDevice], Awaitable[None]]
ThreatCallback = Callable[[Threat], Awaitable[None]]
ResponseCallback = Callable[[ResponseResult], Awaitable[None]]


class SentinelAgent:
    """
    Unified Guardian Agent.

    Combines:
    - Network scanning (discovery)
    - Threat detection (security)
    - Device control (automation)
    - Approval gates (defensive autonomy)

    Autonomy levels:
    - AUTO: Automatically respond to all threats up to HIGH severity
    - DEFENSIVE: Auto-block/isolate threats, ask before changes
    - MANUAL: Log only, require approval for all actions
    """

    def __init__(
        self,
        db_path: str = "data/sentinel.db",
        lumina: Optional[DeviceManager] = None,
        auto_respond: bool = True,
        max_auto_severity: str = "high",
        approval_callback: Optional[Callable[[ResponseRecommendation], Awaitable[bool]]] = None
    ):
        """
        Initialize Sentinel Agent.

        Args:
            db_path: Path to SQLite database
            lumina: Optional LUMINA device manager for smart device control
            auto_respond: Whether to auto-respond to threats
            max_auto_severity: Maximum severity for auto-response
            approval_callback: Callback for requesting user approval
        """
        # Core components
        self.db = SentinelDB(db_path)
        self.lumina = lumina
        self.scanner = NetworkScanner(db=self.db)
        self.controller = DeviceController(lumina=lumina)

        # Security components
        severity_map = {
            "critical": MonitorSeverity.CRITICAL,
            "high": MonitorSeverity.HIGH,
            "medium": MonitorSeverity.MEDIUM,
            "low": MonitorSeverity.LOW,
            "info": MonitorSeverity.INFO
        }
        max_severity = severity_map.get(max_auto_severity.lower(), MonitorSeverity.HIGH)

        self.monitor = NetworkMonitor()
        self.analyzer = ThreatAnalyzer(
            auto_respond_enabled=auto_respond,
            max_auto_severity=max_severity,
            approval_callback=approval_callback
        )

        # State
        self._running = False
        self._scan_task: Optional[asyncio.Task] = None
        self._monitor_task: Optional[asyncio.Task] = None

        # Event callbacks
        self._device_callbacks: List[DeviceCallback] = []
        self._threat_callbacks: List[ThreatCallback] = []
        self._response_callbacks: List[ResponseCallback] = []

        # Wire up internal callbacks
        self.scanner.on_device_discovered(self._on_device_discovered)
        self.scanner.on_device_updated(self._on_device_updated)

        # Register controller response handlers
        self._register_response_handlers()

        logger.info("SentinelAgent initialized")

    def _register_response_handlers(self) -> None:
        """Register device control handlers with threat analyzer"""
        self.analyzer.register_handler(
            ResponseAction.BLOCK_DEVICE,
            self._handle_block_device
        )
        self.analyzer.register_handler(
            ResponseAction.ISOLATE_DEVICE,
            self._handle_isolate_device
        )
        self.analyzer.register_handler(
            ResponseAction.DEEP_SCAN,
            self._handle_deep_scan
        )
        self.analyzer.register_handler(
            ResponseAction.FINGERPRINT_DEVICE,
            self._handle_fingerprint_device
        )

    # Event registration

    def on_device_discovered(self, callback: DeviceCallback) -> None:
        """Register callback for new device discovery"""
        self._device_callbacks.append(callback)

    def on_threat_detected(self, callback: ThreatCallback) -> None:
        """Register callback for threat detection"""
        self._threat_callbacks.append(callback)

    def on_response_executed(self, callback: ResponseCallback) -> None:
        """Register callback for response execution"""
        self._response_callbacks.append(callback)

    # Lifecycle

    async def start(self) -> None:
        """Start the Sentinel Agent"""
        if self._running:
            logger.warning("Agent already running")
            return

        self._running = True

        # Start background scanning
        self._scan_task = asyncio.create_task(self._background_scan_loop())

        # Start threat monitoring
        self._monitor_task = asyncio.create_task(self._threat_monitor_loop())

        logger.info("SentinelAgent started")

    async def stop(self) -> None:
        """Stop the Sentinel Agent"""
        self._running = False

        # Cancel background tasks
        if self._scan_task:
            self._scan_task.cancel()
            try:
                await self._scan_task
            except asyncio.CancelledError:
                pass

        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass

        # Stop scanner
        await self.scanner.stop_background_scanning()

        logger.info("SentinelAgent stopped")

    async def _background_scan_loop(self) -> None:
        """Background loop for periodic scanning"""
        while self._running:
            try:
                # Wait for scanner to complete current scan
                await asyncio.sleep(60)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in scan loop: {e}")
                await asyncio.sleep(30)

    async def _threat_monitor_loop(self) -> None:
        """Background loop for threat monitoring"""
        while self._running:
            try:
                # Check for unresolved threats
                threats = self.db.get_active_threats()

                for threat_record in threats:
                    # Convert to Threat object and analyze
                    threat = self._record_to_threat(threat_record)
                    if threat:
                        result = await self.analyzer.auto_respond(threat)
                        if result:
                            await self._notify_response(result)

                await asyncio.sleep(30)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in monitor loop: {e}")
                await asyncio.sleep(30)

    # Discovery

    async def discover_network(
        self,
        mode: ScanMode = ScanMode.ACTIVE
    ) -> List[NetworkDevice]:
        """
        Scan network for devices.

        Args:
            mode: Scan mode (PASSIVE, ACTIVE, FULL, QUICK)

        Returns:
            List of discovered devices
        """
        logger.info(f"Starting network discovery (mode: {mode.value})")

        if mode == ScanMode.FULL:
            return await self.scanner.full_scan()
        elif mode == ScanMode.QUICK:
            return await self.scanner.quick_scan()
        elif mode == ScanMode.PASSIVE:
            # Return current known devices from passive monitoring
            records = self.db.get_all_devices()
            return [self._record_to_device(r) for r in records]
        else:
            return await self.scanner.active_scan()

    async def get_all_devices(self) -> List[NetworkDevice]:
        """Get all known devices"""
        records = self.db.get_all_devices()
        return [self._record_to_device(r) for r in records]

    async def get_device(self, device_id: str) -> Optional[NetworkDevice]:
        """Get a specific device by ID"""
        record = self.db.get_device(device_id)
        if record:
            return self._record_to_device(record)
        return None

    async def get_devices_by_category(
        self,
        category: DeviceCategory
    ) -> List[NetworkDevice]:
        """Get devices by category"""
        devices = await self.get_all_devices()
        return [d for d in devices if d.category == category]

    async def trust_device(self, device_id: str) -> bool:
        """Mark a device as trusted"""
        record = self.db.get_device(device_id)
        if record:
            record.is_trusted = True
            record.threat_level = 0
            self.db.update_device(record)
            logger.info(f"Device {device_id} marked as trusted")
            return True
        return False

    async def untrust_device(self, device_id: str) -> bool:
        """Mark a device as untrusted"""
        record = self.db.get_device(device_id)
        if record:
            record.is_trusted = False
            self.db.update_device(record)
            logger.info(f"Device {device_id} marked as untrusted")
            return True
        return False

    # Security

    async def get_threats(
        self,
        severity: Optional[str] = None,
        resolved: bool = False
    ) -> List[Threat]:
        """
        Get threats.

        Args:
            severity: Filter by severity (critical, high, medium, low, info)
            resolved: Include resolved threats

        Returns:
            List of threats
        """
        if resolved:
            records = self.db.get_all_threats()
        else:
            records = self.db.get_active_threats()

        threats = [self._record_to_threat(r) for r in records]
        threats = [t for t in threats if t is not None]

        if severity:
            severity_enum = ThreatSeverity(severity.lower())
            threats = [t for t in threats if t.severity == severity_enum]

        return threats

    async def resolve_threat(
        self,
        threat_id: str,
        action: str = "manual"
    ) -> bool:
        """
        Resolve a threat.

        Args:
            threat_id: Threat ID to resolve
            action: Resolution action taken

        Returns:
            True if resolved
        """
        record = self.db.get_threat(threat_id)
        if record:
            record.resolved_at = datetime.now()
            record.auto_response = action
            self.db.update_threat(record)
            logger.info(f"Threat {threat_id} resolved with action: {action}")
            return True
        return False

    async def isolate_device(self, device_id: str) -> bool:
        """
        Isolate a device from the network.

        Args:
            device_id: Device to isolate

        Returns:
            True if isolated
        """
        return await self.controller.isolate_device(device_id)

    async def block_device(
        self,
        device_id: str,
        duration_seconds: int = 3600
    ) -> bool:
        """
        Block a device temporarily.

        Args:
            device_id: Device to block
            duration_seconds: Block duration

        Returns:
            True if blocked
        """
        return await self.controller.block_device(device_id, duration_seconds)

    # Control

    async def control_device(
        self,
        device_id: str,
        action: str,
        **params: Any
    ) -> bool:
        """
        Control a device.

        Args:
            device_id: Target device
            action: Action to perform (turn_on, turn_off, set_brightness, etc.)
            **params: Action parameters

        Returns:
            True if action succeeded
        """
        return await self.controller.control_device(device_id, action, **params)

    async def group_control(
        self,
        category: DeviceCategory,
        action: str,
        **params: Any
    ) -> int:
        """
        Control all devices in a category.

        Args:
            category: Device category
            action: Action to perform
            **params: Action parameters

        Returns:
            Number of devices controlled
        """
        devices = await self.get_devices_by_category(category)
        success_count = 0

        for device in devices:
            try:
                if await self.control_device(device.id, action, **params):
                    success_count += 1
            except Exception as e:
                logger.error(f"Error controlling {device.id}: {e}")

        return success_count

    # Status

    async def get_network_status(self) -> NetworkStatus:
        """Get current network status summary"""
        devices = await self.get_all_devices()
        threats = await self.get_threats()

        online = sum(1 for d in devices if d.state.value == "online")
        trusted = sum(1 for d in devices if d.is_trusted)
        critical = sum(
            1 for t in threats
            if t.severity == MonitorSeverity.CRITICAL
        )

        # Get last scan time
        scans = self.db.get_recent_scans(limit=1)
        last_scan = scans[0].end_time if scans else None

        return NetworkStatus(
            total_devices=len(devices),
            online_devices=online,
            trusted_devices=trusted,
            untrusted_devices=len(devices) - trusted,
            active_threats=len(threats),
            critical_threats=critical,
            last_scan=last_scan,
            scanning=self.scanner._scanning
        )

    async def get_security_status(self) -> SecurityStatus:
        """Get security posture summary"""
        threats = await self.get_threats()
        responses = await self.analyzer.get_response_history(limit=10)
        devices = await self.get_all_devices()

        # Calculate overall score
        score = 100

        # Deduct for threats
        for threat in threats:
            if threat.severity == MonitorSeverity.CRITICAL:
                score -= 25
            elif threat.severity == MonitorSeverity.HIGH:
                score -= 15
            elif threat.severity == MonitorSeverity.MEDIUM:
                score -= 10
            elif threat.severity == MonitorSeverity.LOW:
                score -= 5

        # Deduct for untrusted devices
        untrusted = sum(1 for d in devices if not d.is_trusted)
        score -= min(20, untrusted * 2)

        # Deduct for vulnerable devices
        vulnerable = sum(1 for d in devices if d.threat_level > 50)
        score -= min(20, vulnerable * 5)

        score = max(0, score)

        # Determine threat level
        if score >= 80:
            threat_level = "low"
        elif score >= 60:
            threat_level = "medium"
        elif score >= 40:
            threat_level = "high"
        else:
            threat_level = "critical"

        # Count policy violations
        violations = sum(
            1 for t in threats
            if t.threat_type == ThreatType.POLICY_VIOLATION
        )

        return SecurityStatus(
            overall_score=score,
            threat_level=threat_level,
            active_threats=threats,
            recent_responses=responses,
            vulnerable_devices=vulnerable,
            policy_violations=violations
        )

    # Internal callbacks

    async def _on_device_discovered(self, device: NetworkDevice) -> None:
        """Handle new device discovery"""
        logger.info(f"New device discovered: {device.name or device.ip_address}")

        # Analyze for threats
        threats = await self.monitor.analyze_device(device)

        for threat in threats:
            # Save to database
            self._save_threat(threat)

            # Notify callbacks
            await self._notify_threat(threat)

            # Auto-respond if enabled
            result = await self.analyzer.auto_respond(threat)
            if result:
                await self._notify_response(result)

        # Notify device callbacks
        for callback in self._device_callbacks:
            try:
                await callback(device)
            except Exception as e:
                logger.error(f"Error in device callback: {e}")

    async def _on_device_updated(self, device: NetworkDevice) -> None:
        """Handle device update"""
        # Check for changes that might indicate threats
        threats = await self.monitor.analyze_device(device)

        for threat in threats:
            self._save_threat(threat)
            await self._notify_threat(threat)

            result = await self.analyzer.auto_respond(threat)
            if result:
                await self._notify_response(result)

    async def _notify_threat(self, threat: Threat) -> None:
        """Notify threat callbacks"""
        for callback in self._threat_callbacks:
            try:
                await callback(threat)
            except Exception as e:
                logger.error(f"Error in threat callback: {e}")

    async def _notify_response(self, result: ResponseResult) -> None:
        """Notify response callbacks"""
        for callback in self._response_callbacks:
            try:
                await callback(result)
            except Exception as e:
                logger.error(f"Error in response callback: {e}")

    def _save_threat(self, threat: Threat) -> None:
        """Save threat to database"""
        record = ThreatRecord(
            id=threat.id,
            device_id=threat.device_id,
            threat_type=threat.threat_type.value,
            severity=threat.severity.value,
            description=threat.description,
            detected_at=threat.detected_at,
            details=threat.details
        )
        self.db.save_threat(record)

    # Response handlers

    async def _handle_block_device(
        self,
        threat: Threat,
        params: Dict[str, Any]
    ) -> ResponseResult:
        """Handle BLOCK_DEVICE response"""
        from .controller import DeviceController

        device_id = params.get("device_id")
        duration = params.get("duration_seconds", 3600)

        if device_id:
            success = await self.controller.block_device(device_id, duration)
            return ResponseResult(
                threat_id=threat.id,
                action=ResponseAction.BLOCK_DEVICE,
                outcome="success" if success else "failed",
                executed_at=datetime.now(),
                message=f"Device {device_id} blocked for {duration}s",
                details={"device_id": device_id, "duration": duration}
            )

        return ResponseResult(
            threat_id=threat.id,
            action=ResponseAction.BLOCK_DEVICE,
            outcome="failed",
            executed_at=datetime.now(),
            message="No device_id provided",
            details={}
        )

    async def _handle_isolate_device(
        self,
        threat: Threat,
        params: Dict[str, Any]
    ) -> ResponseResult:
        """Handle ISOLATE_DEVICE response"""
        device_id = params.get("device_id")

        if device_id:
            success = await self.controller.isolate_device(device_id)
            return ResponseResult(
                threat_id=threat.id,
                action=ResponseAction.ISOLATE_DEVICE,
                outcome="success" if success else "failed",
                executed_at=datetime.now(),
                message=f"Device {device_id} isolated",
                details={"device_id": device_id}
            )

        return ResponseResult(
            threat_id=threat.id,
            action=ResponseAction.ISOLATE_DEVICE,
            outcome="failed",
            executed_at=datetime.now(),
            message="No device_id provided",
            details={}
        )

    async def _handle_deep_scan(
        self,
        threat: Threat,
        params: Dict[str, Any]
    ) -> ResponseResult:
        """Handle DEEP_SCAN response"""
        device_id = params.get("device_id")

        if device_id:
            device = await self.get_device(device_id)
            if device and device.ip_address:
                # Run detailed scan
                await self.scanner.scan_device(device.ip_address)
                return ResponseResult(
                    threat_id=threat.id,
                    action=ResponseAction.DEEP_SCAN,
                    outcome="success",
                    executed_at=datetime.now(),
                    message=f"Deep scan completed for {device_id}",
                    details={"device_id": device_id}
                )

        return ResponseResult(
            threat_id=threat.id,
            action=ResponseAction.DEEP_SCAN,
            outcome="failed",
            executed_at=datetime.now(),
            message="Could not perform deep scan",
            details={}
        )

    async def _handle_fingerprint_device(
        self,
        threat: Threat,
        params: Dict[str, Any]
    ) -> ResponseResult:
        """Handle FINGERPRINT_DEVICE response"""
        device_id = params.get("device_id")

        if device_id:
            device = await self.get_device(device_id)
            if device and device.ip_address:
                # Run fingerprinting scan
                await self.scanner.scan_device(device.ip_address)
                return ResponseResult(
                    threat_id=threat.id,
                    action=ResponseAction.FINGERPRINT_DEVICE,
                    outcome="success",
                    executed_at=datetime.now(),
                    message=f"Device {device_id} fingerprinted",
                    details={"device_id": device_id}
                )

        return ResponseResult(
            threat_id=threat.id,
            action=ResponseAction.FINGERPRINT_DEVICE,
            outcome="failed",
            executed_at=datetime.now(),
            message="Could not fingerprint device",
            details={}
        )

    # Conversion helpers

    def _record_to_device(self, record: DeviceRecord) -> NetworkDevice:
        """Convert database record to NetworkDevice"""
        return NetworkDevice(
            id=record.id,
            name=record.hostname or record.ip_address or "Unknown",
            device_type=record.device_type or "unknown",
            protocol=record.protocol or "",
            ip_address=record.ip_address,
            mac_address=record.mac_address,
            category=DeviceCategory(record.category) if record.category else DeviceCategory.UNKNOWN,
            manufacturer=record.manufacturer,
            is_trusted=record.is_trusted,
            threat_level=record.threat_level,
            first_seen=record.first_seen,
            last_seen=record.last_seen,
            metadata=record.metadata or {}
        )

    def _record_to_threat(self, record: ThreatRecord) -> Optional[Threat]:
        """Convert database record to Threat"""
        try:
            return Threat(
                id=record.id,
                device_id=record.device_id,
                threat_type=ThreatType(record.threat_type),
                severity=MonitorSeverity(record.severity),
                description=record.description,
                detected_at=record.detected_at,
                details=record.details or {}
            )
        except (ValueError, KeyError) as e:
            logger.error(f"Error converting threat record: {e}")
            return None
