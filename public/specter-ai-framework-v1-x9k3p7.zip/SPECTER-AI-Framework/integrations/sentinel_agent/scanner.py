"""
SENTINEL Network Scanner

Hybrid network scanner combining passive and active discovery methods.
"""

import asyncio
import logging
from typing import List, Optional, Dict, Any, AsyncGenerator, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import uuid

from integrations.lumina.network_protocols import (
    NetworkProtocol,
    ARPProtocol,
    NmapProtocol,
    MDNSProtocol,
    UPnPProtocol,
    SNMPProtocol,
    PingProtocol,
    get_protocol
)
from integrations.lumina.device_types import NetworkDevice, DeviceCategory
from integrations.lumina.device_manager import DeviceState
from integrations.sentinel_agent.db import SentinelDB, DeviceRecord, ScanRecord

logger = logging.getLogger("specter.sentinel.scanner")


class ScanMode(Enum):
    """Scanning modes"""
    PASSIVE = "passive"     # ARP monitoring, mDNS listening
    ACTIVE = "active"       # nmap scans, ping sweeps
    FULL = "full"           # All protocols, detailed scanning
    QUICK = "quick"         # Fast discovery only


class ScanStatus(Enum):
    """Scan status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class ScanResult:
    """Result of a network scan"""
    scan_id: str
    mode: ScanMode
    status: ScanStatus
    started_at: datetime
    completed_at: Optional[datetime] = None
    devices_found: int = 0
    new_devices: int = 0
    threats_detected: int = 0
    errors: List[str] = field(default_factory=list)
    devices: List[NetworkDevice] = field(default_factory=list)


class NetworkScanner:
    """
    Hybrid network scanner.

    Modes:
    - PASSIVE: ARP monitoring, mDNS listening, UPnP discovery
    - ACTIVE: nmap scans, ping sweeps
    - FULL: All protocols with detailed scanning
    - QUICK: Fast discovery without detailed scanning

    Features:
    - Scheduled scanning (cron-like)
    - Continuous passive monitoring
    - Device deduplication and merging
    - Integration with SentinelDB for persistence
    """

    def __init__(
        self,
        db: Optional[SentinelDB] = None,
        passive_interval: int = 60,      # 1 min passive check
        active_interval: int = 3600,     # 1 hour active scan
        full_scan_interval: int = 86400, # Daily full scan
        subnet: Optional[str] = None
    ):
        self.db = db or SentinelDB()
        self.passive_interval = passive_interval
        self.active_interval = active_interval
        self.full_scan_interval = full_scan_interval
        self.subnet = subnet

        # Protocol instances
        self.protocols: Dict[str, NetworkProtocol] = {
            'arp': ARPProtocol(),
            'ping': PingProtocol(),
            'mdns': MDNSProtocol(),
            'upnp': UPnPProtocol(),
            'snmp': SNMPProtocol(),
        }

        # Try to add nmap if available
        try:
            self.protocols['nmap'] = NmapProtocol()
        except Exception:
            logger.warning("nmap not available")

        # Discovered devices cache
        self._device_cache: Dict[str, NetworkDevice] = {}

        # Running scans
        self._running_scans: Dict[str, ScanResult] = {}

        # Background tasks
        self._passive_task: Optional[asyncio.Task] = None
        self._active_task: Optional[asyncio.Task] = None
        self._full_scan_task: Optional[asyncio.Task] = None

        # Callbacks
        self._on_device_discovered: List[Callable] = []
        self._on_device_updated: List[Callable] = []
        self._on_device_offline: List[Callable] = []

        logger.info("NetworkScanner initialized")

    # ==================== Event Callbacks ====================

    def on_device_discovered(self, callback: Callable[[NetworkDevice], None]) -> None:
        """Register callback for new device discovery"""
        self._on_device_discovered.append(callback)

    def on_device_updated(self, callback: Callable[[NetworkDevice], None]) -> None:
        """Register callback for device updates"""
        self._on_device_updated.append(callback)

    def on_device_offline(self, callback: Callable[[NetworkDevice], None]) -> None:
        """Register callback for device going offline"""
        self._on_device_offline.append(callback)

    async def _notify_discovered(self, device: NetworkDevice) -> None:
        """Notify callbacks of new device"""
        for callback in self._on_device_discovered:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(device)
                else:
                    callback(device)
            except Exception as e:
                logger.error(f"Callback error: {e}")

    async def _notify_updated(self, device: NetworkDevice) -> None:
        """Notify callbacks of device update"""
        for callback in self._on_device_updated:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(device)
                else:
                    callback(device)
            except Exception as e:
                logger.error(f"Callback error: {e}")

    async def _notify_offline(self, device: NetworkDevice) -> None:
        """Notify callbacks of device going offline"""
        for callback in self._on_device_offline:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(device)
                else:
                    callback(device)
            except Exception as e:
                logger.error(f"Callback error: {e}")

    # ==================== Scanning Methods ====================

    async def scan(
        self,
        mode: ScanMode = ScanMode.ACTIVE,
        subnet: Optional[str] = None
    ) -> ScanResult:
        """
        Perform a network scan.

        Args:
            mode: Scanning mode
            subnet: Subnet to scan (uses default if not specified)

        Returns:
            ScanResult with discovered devices
        """
        scan_id = str(uuid.uuid4())[:8]
        target_subnet = subnet or self.subnet

        result = ScanResult(
            scan_id=scan_id,
            mode=mode,
            status=ScanStatus.RUNNING,
            started_at=datetime.now()
        )

        self._running_scans[scan_id] = result

        # Log scan start
        scan_record = ScanRecord(
            id=scan_id,
            scan_type=mode.value,
            started_at=result.started_at.isoformat(),
            subnet=target_subnet,
            status="running"
        )
        self.db.add_scan(scan_record)

        logger.info(f"Starting {mode.value} scan: {scan_id}")

        try:
            discovered = []

            if mode == ScanMode.PASSIVE:
                discovered = await self._passive_scan(target_subnet)
            elif mode == ScanMode.ACTIVE:
                discovered = await self._active_scan(target_subnet)
            elif mode == ScanMode.FULL:
                discovered = await self._full_scan(target_subnet)
            elif mode == ScanMode.QUICK:
                discovered = await self._quick_scan(target_subnet)

            # Process discovered devices
            result.devices = discovered
            result.devices_found = len(discovered)

            for device in discovered:
                is_new = await self._process_device(device)
                if is_new:
                    result.new_devices += 1

            result.status = ScanStatus.COMPLETED
            result.completed_at = datetime.now()

            logger.info(f"Scan {scan_id} completed: {result.devices_found} devices, {result.new_devices} new")

        except Exception as e:
            logger.error(f"Scan {scan_id} failed: {e}")
            result.status = ScanStatus.FAILED
            result.errors.append(str(e))
            result.completed_at = datetime.now()

        # Update scan record
        self.db.update_scan(
            scan_id,
            status=result.status.value,
            completed_at=result.completed_at.isoformat() if result.completed_at else None,
            devices_found=result.devices_found
        )

        del self._running_scans[scan_id]
        return result

    async def _passive_scan(self, subnet: Optional[str] = None) -> List[NetworkDevice]:
        """Passive discovery using ARP, mDNS, UPnP"""
        discovered = []

        # Run passive protocols in parallel
        tasks = [
            self.protocols['arp'].discover(subnet),
            self.protocols['mdns'].discover(subnet),
            self.protocols['upnp'].discover(subnet),
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, list):
                discovered.extend(result)
            elif isinstance(result, Exception):
                logger.warning(f"Protocol error: {result}")

        return self._deduplicate_devices(discovered)

    async def _active_scan(self, subnet: Optional[str] = None) -> List[NetworkDevice]:
        """Active scanning using ping and nmap"""
        discovered = []

        # First, passive discovery
        passive = await self._passive_scan(subnet)
        discovered.extend(passive)

        # Then active scanning
        if 'nmap' in self.protocols:
            try:
                nmap_devices = await self.protocols['nmap'].discover(subnet)
                discovered.extend(nmap_devices)
            except Exception as e:
                logger.warning(f"Nmap scan failed: {e}")
                # Fallback to ping sweep
                ping_devices = await self.protocols['ping'].discover(subnet)
                discovered.extend(ping_devices)
        else:
            ping_devices = await self.protocols['ping'].discover(subnet)
            discovered.extend(ping_devices)

        return self._deduplicate_devices(discovered)

    async def _full_scan(self, subnet: Optional[str] = None) -> List[NetworkDevice]:
        """Full detailed scan with service detection"""
        # First get all devices
        discovered = await self._active_scan(subnet)

        # Then do detailed scans on each device
        if 'nmap' in self.protocols:
            nmap = self.protocols['nmap']
            for i, device in enumerate(discovered):
                if device.ip_address:
                    try:
                        detailed = await nmap.scan_device(device.ip_address)
                        if detailed:
                            # Merge detailed info
                            device.open_ports = detailed.open_ports
                            device.services = detailed.services
                            device.os_fingerprint = detailed.os_fingerprint
                    except Exception as e:
                        logger.warning(f"Detailed scan failed for {device.ip_address}: {e}")

        # Try SNMP on devices with port 161
        snmp = self.protocols['snmp']
        for device in discovered:
            if device.ip_address and (161 in device.open_ports or not device.open_ports):
                try:
                    snmp_info = await snmp.scan_device(device.ip_address)
                    if snmp_info:
                        device.metadata.update(snmp_info.metadata)
                except Exception:
                    pass

        return discovered

    async def _quick_scan(self, subnet: Optional[str] = None) -> List[NetworkDevice]:
        """Quick discovery without detailed scanning"""
        discovered = []

        # Just ARP and ping - fastest methods
        tasks = [
            self.protocols['arp'].discover(subnet),
            self.protocols['ping'].discover(subnet),
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for result in results:
            if isinstance(result, list):
                discovered.extend(result)

        return self._deduplicate_devices(discovered)

    async def scan_device(self, ip: str) -> Optional[NetworkDevice]:
        """
        Detailed scan of a specific device.

        Args:
            ip: IP address to scan

        Returns:
            NetworkDevice with detailed information
        """
        device = None

        # Try nmap first for detailed info
        if 'nmap' in self.protocols:
            try:
                device = await self.protocols['nmap'].scan_device(ip)
            except Exception as e:
                logger.warning(f"Nmap scan failed: {e}")

        # Fallback to ping
        if not device:
            device = await self.protocols['ping'].scan_device(ip)

        # Enrich with SNMP if available
        if device:
            try:
                snmp_info = await self.protocols['snmp'].scan_device(ip)
                if snmp_info:
                    device.metadata.update(snmp_info.metadata)
            except Exception:
                pass

        if device:
            await self._process_device(device)

        return device

    # ==================== Device Processing ====================

    def _deduplicate_devices(self, devices: List[NetworkDevice]) -> List[NetworkDevice]:
        """
        Deduplicate and merge device information.

        Devices are matched by MAC address (preferred) or IP address.
        """
        merged: Dict[str, NetworkDevice] = {}

        for device in devices:
            # Use MAC as primary key, IP as fallback
            key = device.mac_address if device.mac_address else device.ip_address

            if not key:
                continue

            if key in merged:
                # Merge information
                existing = merged[key]
                self._merge_device_info(existing, device)
            else:
                merged[key] = device

        return list(merged.values())

    def _merge_device_info(self, target: NetworkDevice, source: NetworkDevice) -> None:
        """Merge information from source into target device"""
        # Update IP if target doesn't have one
        if not target.ip_address and source.ip_address:
            target.ip_address = source.ip_address

        # Update MAC if target doesn't have one
        if not target.mac_address and source.mac_address:
            target.mac_address = source.mac_address

        # Merge ports
        target.open_ports = list(set(target.open_ports + source.open_ports))

        # Merge services
        target.services.update(source.services)

        # Use better name
        if source.name and not source.name.startswith("Device ") and not source.name.startswith("Host "):
            target.name = source.name

        # Update metadata
        target.metadata.update(source.metadata)

        # Use OS fingerprint if available
        if source.os_fingerprint and not target.os_fingerprint:
            target.os_fingerprint = source.os_fingerprint

        # Update manufacturer if available
        if source.manufacturer and not target.manufacturer:
            target.manufacturer = source.manufacturer

        # Update last seen
        target.last_seen = datetime.now()

    async def _process_device(self, device: NetworkDevice) -> bool:
        """
        Process a discovered device.

        Updates cache and database, triggers callbacks.
        Returns True if device is new.
        """
        key = device.mac_address if device.mac_address else device.ip_address

        if not key:
            return False

        is_new = key not in self._device_cache

        if is_new:
            # New device discovered
            device.first_seen = datetime.now()
            self._device_cache[key] = device

            # Save to database
            record = DeviceRecord(
                id=device.id,
                mac_address=device.mac_address,
                ip_address=device.ip_address,
                hostname=device.name if not device.name.startswith("Device ") else None,
                device_type=device.category.value if device.category else "unknown",
                manufacturer=device.manufacturer,
                protocol=device.protocol,
                first_seen=device.first_seen.isoformat() if device.first_seen else None,
                last_seen=device.last_seen.isoformat() if device.last_seen else None,
                is_trusted=device.is_trusted,
                threat_level=device.threat_level,
                open_ports=device.open_ports,
                services=device.services,
                os_fingerprint=device.os_fingerprint,
                metadata=device.metadata
            )
            self.db.upsert_device(record)

            await self._notify_discovered(device)
            logger.info(f"New device discovered: {device.name} ({device.ip_address})")

        else:
            # Update existing device
            existing = self._device_cache[key]
            self._merge_device_info(existing, device)

            # Update database
            record = DeviceRecord(
                id=existing.id,
                mac_address=existing.mac_address,
                ip_address=existing.ip_address,
                hostname=existing.name,
                device_type=existing.category.value if existing.category else "unknown",
                manufacturer=existing.manufacturer,
                protocol=existing.protocol,
                last_seen=existing.last_seen.isoformat() if existing.last_seen else None,
                is_trusted=existing.is_trusted,
                threat_level=existing.threat_level,
                open_ports=existing.open_ports,
                services=existing.services,
                os_fingerprint=existing.os_fingerprint,
                metadata=existing.metadata
            )
            self.db.upsert_device(record)

            await self._notify_updated(existing)

        return is_new

    # ==================== Background Tasks ====================

    async def start_background_scanning(self) -> None:
        """Start background scanning tasks"""
        logger.info("Starting background scanning tasks")

        self._passive_task = asyncio.create_task(self._passive_loop())
        self._active_task = asyncio.create_task(self._active_loop())
        self._full_scan_task = asyncio.create_task(self._full_scan_loop())

    async def stop_background_scanning(self) -> None:
        """Stop background scanning tasks"""
        logger.info("Stopping background scanning tasks")

        for task in [self._passive_task, self._active_task, self._full_scan_task]:
            if task:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

    async def _passive_loop(self) -> None:
        """Continuous passive monitoring loop"""
        while True:
            try:
                await asyncio.sleep(self.passive_interval)
                await self.scan(ScanMode.PASSIVE)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Passive scan error: {e}")
                await asyncio.sleep(60)

    async def _active_loop(self) -> None:
        """Periodic active scanning loop"""
        while True:
            try:
                await asyncio.sleep(self.active_interval)
                await self.scan(ScanMode.ACTIVE)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Active scan error: {e}")
                await asyncio.sleep(300)

    async def _full_scan_loop(self) -> None:
        """Daily full scan loop"""
        while True:
            try:
                await asyncio.sleep(self.full_scan_interval)
                await self.scan(ScanMode.FULL)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Full scan error: {e}")
                await asyncio.sleep(3600)

    # ==================== Device Access ====================

    def get_all_devices(self) -> List[NetworkDevice]:
        """Get all cached devices"""
        return list(self._device_cache.values())

    def get_device(self, identifier: str) -> Optional[NetworkDevice]:
        """Get device by MAC, IP, or ID"""
        # Check cache first
        if identifier in self._device_cache:
            return self._device_cache[identifier]

        # Search by various fields
        for device in self._device_cache.values():
            if device.id == identifier:
                return device
            if device.ip_address == identifier:
                return device
            if device.mac_address == identifier:
                return device

        return None

    def get_devices_by_category(self, category: DeviceCategory) -> List[NetworkDevice]:
        """Get devices by category"""
        return [d for d in self._device_cache.values() if d.category == category]

    def get_online_devices(self) -> List[NetworkDevice]:
        """Get currently online devices"""
        return [d for d in self._device_cache.values() if d.state == DeviceState.ONLINE]

    def get_untrusted_devices(self) -> List[NetworkDevice]:
        """Get untrusted devices"""
        return [d for d in self._device_cache.values() if not d.is_trusted]

    # ==================== Status ====================

    def get_status(self) -> Dict[str, Any]:
        """Get scanner status"""
        return {
            "total_devices": len(self._device_cache),
            "online_devices": len(self.get_online_devices()),
            "untrusted_devices": len(self.get_untrusted_devices()),
            "running_scans": len(self._running_scans),
            "available_protocols": list(self.protocols.keys()),
            "passive_interval": self.passive_interval,
            "active_interval": self.active_interval,
            "background_scanning": self._passive_task is not None
        }

    def get_running_scans(self) -> List[ScanResult]:
        """Get currently running scans"""
        return list(self._running_scans.values())


# Convenience function
async def quick_discover(subnet: Optional[str] = None) -> List[NetworkDevice]:
    """Quick network discovery without persistence"""
    scanner = NetworkScanner()
    result = await scanner.scan(ScanMode.QUICK, subnet)
    return result.devices
