"""
SENTINEL Database Layer

SQLite persistence for network state, device tracking, and threat history.
"""

import sqlite3
import json
import logging
from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from contextlib import contextmanager
from enum import Enum
import threading

logger = logging.getLogger("specter.sentinel.db")


class ThreatSeverity(Enum):
    """Threat severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ThreatType(Enum):
    """Types of security threats"""
    NEW_DEVICE = "new_device"
    PORT_CHANGE = "port_change"
    SERVICE_CHANGE = "service_change"
    ANOMALY = "anomaly"
    VULNERABILITY = "vulnerability"
    ROGUE_AP = "rogue_ap"
    OFFLINE = "offline"
    UNAUTHORIZED = "unauthorized"


@dataclass
class DeviceRecord:
    """Database record for a network device"""
    id: str
    mac_address: str
    ip_address: Optional[str] = None
    hostname: Optional[str] = None
    device_type: str = "unknown"
    manufacturer: Optional[str] = None
    model: Optional[str] = None
    protocol: Optional[str] = None
    first_seen: Optional[str] = None
    last_seen: Optional[str] = None
    is_trusted: bool = False
    threat_level: int = 0
    open_ports: List[int] = field(default_factory=list)
    services: Dict[int, str] = field(default_factory=dict)
    os_fingerprint: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for database storage"""
        data = asdict(self)
        data['open_ports'] = json.dumps(data['open_ports'])
        data['services'] = json.dumps(data['services'])
        data['metadata'] = json.dumps(data['metadata'])
        return data

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> 'DeviceRecord':
        """Create from database row"""
        data = dict(row)
        data['open_ports'] = json.loads(data.get('open_ports', '[]') or '[]')
        data['services'] = json.loads(data.get('services', '{}') or '{}')
        data['metadata'] = json.loads(data.get('metadata', '{}') or '{}')
        return cls(**data)


@dataclass
class ThreatRecord:
    """Database record for a security threat"""
    id: str
    device_id: Optional[str] = None
    threat_type: str = "unknown"
    severity: str = "info"
    description: str = ""
    detected_at: Optional[str] = None
    resolved_at: Optional[str] = None
    auto_response: Optional[str] = None
    requires_approval: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for database storage"""
        data = asdict(self)
        data['metadata'] = json.dumps(data['metadata'])
        return data

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> 'ThreatRecord':
        """Create from database row"""
        data = dict(row)
        data['metadata'] = json.loads(data.get('metadata', '{}') or '{}')
        return cls(**data)


@dataclass
class ScanRecord:
    """Database record for a network scan"""
    id: str
    scan_type: str  # passive, active, full
    started_at: str
    completed_at: Optional[str] = None
    devices_found: int = 0
    threats_detected: int = 0
    subnet: Optional[str] = None
    status: str = "running"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for database storage"""
        data = asdict(self)
        data['metadata'] = json.dumps(data['metadata'])
        return data

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> 'ScanRecord':
        """Create from database row"""
        data = dict(row)
        data['metadata'] = json.loads(data.get('metadata', '{}') or '{}')
        return cls(**data)


@dataclass
class BaselineRecord:
    """Device behavioral baseline for anomaly detection"""
    device_id: str
    normal_ports: List[int] = field(default_factory=list)
    normal_services: Dict[int, str] = field(default_factory=dict)
    typical_online_hours: List[int] = field(default_factory=list)
    avg_bandwidth: float = 0.0
    last_updated: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for database storage"""
        data = asdict(self)
        data['normal_ports'] = json.dumps(data['normal_ports'])
        data['normal_services'] = json.dumps(data['normal_services'])
        data['typical_online_hours'] = json.dumps(data['typical_online_hours'])
        data['metadata'] = json.dumps(data['metadata'])
        return data

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> 'BaselineRecord':
        """Create from database row"""
        data = dict(row)
        data['normal_ports'] = json.loads(data.get('normal_ports', '[]') or '[]')
        data['normal_services'] = json.loads(data.get('normal_services', '{}') or '{}')
        data['typical_online_hours'] = json.loads(data.get('typical_online_hours', '[]') or '[]')
        data['metadata'] = json.loads(data.get('metadata', '{}') or '{}')
        return cls(**data)


class SentinelDB:
    """
    SQLite database for Sentinel Agent.

    Handles:
    - Device inventory and tracking
    - Threat/security event history
    - Scan results and history
    - Behavioral baselines for anomaly detection
    - Device state history
    """

    SCHEMA_VERSION = 1

    def __init__(self, db_path: Optional[str] = None):
        if db_path is None:
            db_path = str(Path(__file__).parent.parent.parent / "data" / "sentinel.db")

        self.db_path = db_path
        self._local = threading.local()

        # Ensure directory exists
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)

        # Initialize schema
        self._init_schema()

        logger.info(f"SentinelDB initialized: {db_path}")

    @property
    def _conn(self) -> sqlite3.Connection:
        """Thread-local database connection"""
        if not hasattr(self._local, 'conn') or self._local.conn is None:
            self._local.conn = sqlite3.connect(self.db_path)
            self._local.conn.row_factory = sqlite3.Row
            self._local.conn.execute("PRAGMA foreign_keys = ON")
            self._local.conn.execute("PRAGMA journal_mode = WAL")
        return self._local.conn

    @contextmanager
    def transaction(self):
        """Context manager for database transactions"""
        try:
            yield self._conn
            self._conn.commit()
        except Exception as e:
            self._conn.rollback()
            logger.error(f"Transaction failed: {e}")
            raise

    def _init_schema(self) -> None:
        """Initialize database schema"""
        with self.transaction() as conn:
            # Devices table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS devices (
                    id TEXT PRIMARY KEY,
                    mac_address TEXT UNIQUE,
                    ip_address TEXT,
                    hostname TEXT,
                    device_type TEXT DEFAULT 'unknown',
                    manufacturer TEXT,
                    model TEXT,
                    protocol TEXT,
                    first_seen TEXT,
                    last_seen TEXT,
                    is_trusted INTEGER DEFAULT 0,
                    threat_level INTEGER DEFAULT 0,
                    open_ports TEXT DEFAULT '[]',
                    services TEXT DEFAULT '{}',
                    os_fingerprint TEXT,
                    metadata TEXT DEFAULT '{}'
                )
            """)

            # Threats table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS threats (
                    id TEXT PRIMARY KEY,
                    device_id TEXT,
                    threat_type TEXT,
                    severity TEXT DEFAULT 'info',
                    description TEXT,
                    detected_at TEXT,
                    resolved_at TEXT,
                    auto_response TEXT,
                    requires_approval INTEGER DEFAULT 0,
                    metadata TEXT DEFAULT '{}',
                    FOREIGN KEY (device_id) REFERENCES devices(id)
                )
            """)

            # Scans table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS scans (
                    id TEXT PRIMARY KEY,
                    scan_type TEXT,
                    started_at TEXT,
                    completed_at TEXT,
                    devices_found INTEGER DEFAULT 0,
                    threats_detected INTEGER DEFAULT 0,
                    subnet TEXT,
                    status TEXT DEFAULT 'running',
                    metadata TEXT DEFAULT '{}'
                )
            """)

            # Baselines table (for anomaly detection)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS baselines (
                    device_id TEXT PRIMARY KEY,
                    normal_ports TEXT DEFAULT '[]',
                    normal_services TEXT DEFAULT '{}',
                    typical_online_hours TEXT DEFAULT '[]',
                    avg_bandwidth REAL DEFAULT 0.0,
                    last_updated TEXT,
                    metadata TEXT DEFAULT '{}',
                    FOREIGN KEY (device_id) REFERENCES devices(id)
                )
            """)

            # Device state history
            conn.execute("""
                CREATE TABLE IF NOT EXISTS device_states (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_id TEXT,
                    state TEXT,
                    ip_address TEXT,
                    open_ports TEXT,
                    recorded_at TEXT,
                    FOREIGN KEY (device_id) REFERENCES devices(id)
                )
            """)

            # Indexes for performance
            conn.execute("CREATE INDEX IF NOT EXISTS idx_devices_mac ON devices(mac_address)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_devices_ip ON devices(ip_address)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_threats_device ON threats(device_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_threats_severity ON threats(severity)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_threats_unresolved ON threats(resolved_at) WHERE resolved_at IS NULL")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_scans_status ON scans(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_device_states_device ON device_states(device_id)")

            # Schema version tracking
            conn.execute("""
                CREATE TABLE IF NOT EXISTS schema_info (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
            """)
            conn.execute(
                "INSERT OR REPLACE INTO schema_info (key, value) VALUES (?, ?)",
                ("version", str(self.SCHEMA_VERSION))
            )

    # ==================== Device Operations ====================

    def upsert_device(self, device: DeviceRecord) -> bool:
        """Insert or update a device record"""
        try:
            with self.transaction() as conn:
                data = device.to_dict()
                columns = ', '.join(data.keys())
                placeholders = ', '.join(['?' for _ in data])
                updates = ', '.join([f"{k}=excluded.{k}" for k in data.keys() if k != 'id'])

                conn.execute(f"""
                    INSERT INTO devices ({columns})
                    VALUES ({placeholders})
                    ON CONFLICT(id) DO UPDATE SET {updates}
                """, list(data.values()))

            logger.debug(f"Upserted device: {device.id}")
            return True
        except Exception as e:
            logger.error(f"Failed to upsert device: {e}")
            return False

    def get_device(self, device_id: str) -> Optional[DeviceRecord]:
        """Get a device by ID"""
        row = self._conn.execute(
            "SELECT * FROM devices WHERE id = ?", (device_id,)
        ).fetchone()
        return DeviceRecord.from_row(row) if row else None

    def get_device_by_mac(self, mac_address: str) -> Optional[DeviceRecord]:
        """Get a device by MAC address"""
        row = self._conn.execute(
            "SELECT * FROM devices WHERE mac_address = ?", (mac_address.lower(),)
        ).fetchone()
        return DeviceRecord.from_row(row) if row else None

    def get_device_by_ip(self, ip_address: str) -> Optional[DeviceRecord]:
        """Get a device by IP address"""
        row = self._conn.execute(
            "SELECT * FROM devices WHERE ip_address = ?", (ip_address,)
        ).fetchone()
        return DeviceRecord.from_row(row) if row else None

    def get_all_devices(self, include_offline: bool = True) -> List[DeviceRecord]:
        """Get all devices"""
        query = "SELECT * FROM devices ORDER BY last_seen DESC"
        rows = self._conn.execute(query).fetchall()
        return [DeviceRecord.from_row(row) for row in rows]

    def get_devices_by_type(self, device_type: str) -> List[DeviceRecord]:
        """Get devices by type"""
        rows = self._conn.execute(
            "SELECT * FROM devices WHERE device_type = ?", (device_type,)
        ).fetchall()
        return [DeviceRecord.from_row(row) for row in rows]

    def get_trusted_devices(self) -> List[DeviceRecord]:
        """Get all trusted devices"""
        rows = self._conn.execute(
            "SELECT * FROM devices WHERE is_trusted = 1"
        ).fetchall()
        return [DeviceRecord.from_row(row) for row in rows]

    def get_untrusted_devices(self) -> List[DeviceRecord]:
        """Get all untrusted/unknown devices"""
        rows = self._conn.execute(
            "SELECT * FROM devices WHERE is_trusted = 0"
        ).fetchall()
        return [DeviceRecord.from_row(row) for row in rows]

    def set_device_trusted(self, device_id: str, trusted: bool = True) -> bool:
        """Mark a device as trusted or untrusted"""
        try:
            with self.transaction() as conn:
                conn.execute(
                    "UPDATE devices SET is_trusted = ? WHERE id = ?",
                    (1 if trusted else 0, device_id)
                )
            return True
        except Exception as e:
            logger.error(f"Failed to set device trust: {e}")
            return False

    def delete_device(self, device_id: str) -> bool:
        """Delete a device and its related records"""
        try:
            with self.transaction() as conn:
                conn.execute("DELETE FROM device_states WHERE device_id = ?", (device_id,))
                conn.execute("DELETE FROM baselines WHERE device_id = ?", (device_id,))
                conn.execute("DELETE FROM threats WHERE device_id = ?", (device_id,))
                conn.execute("DELETE FROM devices WHERE id = ?", (device_id,))
            return True
        except Exception as e:
            logger.error(f"Failed to delete device: {e}")
            return False

    def update_device_last_seen(self, device_id: str, timestamp: Optional[str] = None) -> bool:
        """Update device last seen timestamp"""
        if timestamp is None:
            timestamp = datetime.now().isoformat()
        try:
            with self.transaction() as conn:
                conn.execute(
                    "UPDATE devices SET last_seen = ? WHERE id = ?",
                    (timestamp, device_id)
                )
            return True
        except Exception as e:
            logger.error(f"Failed to update last seen: {e}")
            return False

    # ==================== Threat Operations ====================

    def add_threat(self, threat: ThreatRecord) -> bool:
        """Add a new threat record"""
        try:
            with self.transaction() as conn:
                data = threat.to_dict()
                columns = ', '.join(data.keys())
                placeholders = ', '.join(['?' for _ in data])
                conn.execute(
                    f"INSERT INTO threats ({columns}) VALUES ({placeholders})",
                    list(data.values())
                )
            logger.info(f"Added threat: {threat.id} ({threat.severity})")
            return True
        except Exception as e:
            logger.error(f"Failed to add threat: {e}")
            return False

    def get_threat(self, threat_id: str) -> Optional[ThreatRecord]:
        """Get a threat by ID"""
        row = self._conn.execute(
            "SELECT * FROM threats WHERE id = ?", (threat_id,)
        ).fetchone()
        return ThreatRecord.from_row(row) if row else None

    def get_active_threats(self, severity: Optional[str] = None) -> List[ThreatRecord]:
        """Get all unresolved threats"""
        if severity:
            rows = self._conn.execute(
                "SELECT * FROM threats WHERE resolved_at IS NULL AND severity = ? ORDER BY detected_at DESC",
                (severity,)
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM threats WHERE resolved_at IS NULL ORDER BY detected_at DESC"
            ).fetchall()
        return [ThreatRecord.from_row(row) for row in rows]

    def get_threats_for_device(self, device_id: str) -> List[ThreatRecord]:
        """Get all threats for a device"""
        rows = self._conn.execute(
            "SELECT * FROM threats WHERE device_id = ? ORDER BY detected_at DESC",
            (device_id,)
        ).fetchall()
        return [ThreatRecord.from_row(row) for row in rows]

    def resolve_threat(self, threat_id: str, response: Optional[str] = None) -> bool:
        """Mark a threat as resolved"""
        try:
            with self.transaction() as conn:
                conn.execute(
                    "UPDATE threats SET resolved_at = ?, auto_response = ? WHERE id = ?",
                    (datetime.now().isoformat(), response, threat_id)
                )
            logger.info(f"Resolved threat: {threat_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to resolve threat: {e}")
            return False

    def get_threat_count_by_severity(self) -> Dict[str, int]:
        """Get count of active threats by severity"""
        rows = self._conn.execute("""
            SELECT severity, COUNT(*) as count
            FROM threats
            WHERE resolved_at IS NULL
            GROUP BY severity
        """).fetchall()
        return {row['severity']: row['count'] for row in rows}

    # ==================== Scan Operations ====================

    def add_scan(self, scan: ScanRecord) -> bool:
        """Add a new scan record"""
        try:
            with self.transaction() as conn:
                data = scan.to_dict()
                columns = ', '.join(data.keys())
                placeholders = ', '.join(['?' for _ in data])
                conn.execute(
                    f"INSERT INTO scans ({columns}) VALUES ({placeholders})",
                    list(data.values())
                )
            return True
        except Exception as e:
            logger.error(f"Failed to add scan: {e}")
            return False

    def update_scan(self, scan_id: str, **updates) -> bool:
        """Update a scan record"""
        try:
            with self.transaction() as conn:
                set_clause = ', '.join([f"{k} = ?" for k in updates.keys()])
                conn.execute(
                    f"UPDATE scans SET {set_clause} WHERE id = ?",
                    list(updates.values()) + [scan_id]
                )
            return True
        except Exception as e:
            logger.error(f"Failed to update scan: {e}")
            return False

    def get_recent_scans(self, limit: int = 10) -> List[ScanRecord]:
        """Get recent scan history"""
        rows = self._conn.execute(
            "SELECT * FROM scans ORDER BY started_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
        return [ScanRecord.from_row(row) for row in rows]

    def get_running_scans(self) -> List[ScanRecord]:
        """Get currently running scans"""
        rows = self._conn.execute(
            "SELECT * FROM scans WHERE status = 'running'"
        ).fetchall()
        return [ScanRecord.from_row(row) for row in rows]

    # ==================== Baseline Operations ====================

    def upsert_baseline(self, baseline: BaselineRecord) -> bool:
        """Insert or update a device baseline"""
        try:
            with self.transaction() as conn:
                data = baseline.to_dict()
                columns = ', '.join(data.keys())
                placeholders = ', '.join(['?' for _ in data])
                updates = ', '.join([f"{k}=excluded.{k}" for k in data.keys() if k != 'device_id'])

                conn.execute(f"""
                    INSERT INTO baselines ({columns})
                    VALUES ({placeholders})
                    ON CONFLICT(device_id) DO UPDATE SET {updates}
                """, list(data.values()))
            return True
        except Exception as e:
            logger.error(f"Failed to upsert baseline: {e}")
            return False

    def get_baseline(self, device_id: str) -> Optional[BaselineRecord]:
        """Get baseline for a device"""
        row = self._conn.execute(
            "SELECT * FROM baselines WHERE device_id = ?", (device_id,)
        ).fetchone()
        return BaselineRecord.from_row(row) if row else None

    # ==================== Device State History ====================

    def record_device_state(
        self,
        device_id: str,
        state: str,
        ip_address: Optional[str] = None,
        open_ports: Optional[List[int]] = None
    ) -> bool:
        """Record a device state snapshot"""
        try:
            with self.transaction() as conn:
                conn.execute("""
                    INSERT INTO device_states (device_id, state, ip_address, open_ports, recorded_at)
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    device_id,
                    state,
                    ip_address,
                    json.dumps(open_ports or []),
                    datetime.now().isoformat()
                ))
            return True
        except Exception as e:
            logger.error(f"Failed to record device state: {e}")
            return False

    def get_device_state_history(
        self,
        device_id: str,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Get state history for a device"""
        rows = self._conn.execute("""
            SELECT * FROM device_states
            WHERE device_id = ?
            ORDER BY recorded_at DESC
            LIMIT ?
        """, (device_id, limit)).fetchall()

        return [
            {
                'state': row['state'],
                'ip_address': row['ip_address'],
                'open_ports': json.loads(row['open_ports'] or '[]'),
                'recorded_at': row['recorded_at']
            }
            for row in rows
        ]

    # ==================== Statistics ====================

    def get_stats(self) -> Dict[str, Any]:
        """Get database statistics"""
        device_count = self._conn.execute("SELECT COUNT(*) FROM devices").fetchone()[0]
        trusted_count = self._conn.execute("SELECT COUNT(*) FROM devices WHERE is_trusted = 1").fetchone()[0]
        active_threats = self._conn.execute("SELECT COUNT(*) FROM threats WHERE resolved_at IS NULL").fetchone()[0]
        total_scans = self._conn.execute("SELECT COUNT(*) FROM scans").fetchone()[0]

        return {
            "device_count": device_count,
            "trusted_devices": trusted_count,
            "untrusted_devices": device_count - trusted_count,
            "active_threats": active_threats,
            "threat_breakdown": self.get_threat_count_by_severity(),
            "total_scans": total_scans,
            "running_scans": len(self.get_running_scans())
        }

    def close(self) -> None:
        """Close database connection"""
        if hasattr(self._local, 'conn') and self._local.conn:
            self._local.conn.close()
            self._local.conn = None
