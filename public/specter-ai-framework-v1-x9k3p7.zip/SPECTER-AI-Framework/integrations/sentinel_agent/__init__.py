"""
SENTINEL Agent Integration

Network-aware guardian for device discovery, security monitoring, and control.
"""

from integrations.sentinel_agent.db import (
    SentinelDB,
    DeviceRecord,
    ThreatRecord,
    ScanRecord,
    BaselineRecord,
    ThreatSeverity,
    ThreatType
)
from integrations.sentinel_agent.scanner import NetworkScanner, ScanMode
from integrations.sentinel_agent.controller import DeviceController, ControlAction, ControlResult

# API imports are optional (requires FastAPI)
try:
    from integrations.sentinel_agent.agent import SentinelAgent, NetworkStatus, SecurityStatus
    from integrations.sentinel_agent.api import create_api, run_api
    _HAS_API = True
except ImportError:
    _HAS_API = False
    SentinelAgent = None
    NetworkStatus = None
    SecurityStatus = None
    create_api = None
    run_api = None

__all__ = [
    # Database
    'SentinelDB',
    'DeviceRecord',
    'ThreatRecord',
    'ScanRecord',
    'BaselineRecord',
    'ThreatSeverity',
    'ThreatType',
    # Scanner
    'NetworkScanner',
    'ScanMode',
    # Controller
    'DeviceController',
    'ControlAction',
    'ControlResult',
    # Agent (optional)
    'SentinelAgent',
    'NetworkStatus',
    'SecurityStatus',
    # API (optional)
    'create_api',
    'run_api',
]
