"""
SENTINEL Agent API

REST and WebSocket API for network monitoring, device discovery, and control.
"""

from typing import Optional, List, Dict, Any
from datetime import datetime
import asyncio
import logging
import json

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Depends, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from integrations.sentinel_agent.agent import SentinelAgent, NetworkStatus, SecurityStatus
from integrations.sentinel_agent.scanner import ScanMode
from integrations.lumina.device_types import DeviceCategory

logger = logging.getLogger(__name__)


# Pydantic models for API

class DeviceResponse(BaseModel):
    """Device information response"""
    id: str
    name: str
    ip_address: Optional[str] = None
    mac_address: Optional[str] = None
    category: str
    manufacturer: Optional[str] = None
    is_trusted: bool
    threat_level: int
    state: str
    first_seen: Optional[str] = None
    last_seen: Optional[str] = None


class ThreatResponse(BaseModel):
    """Threat information response"""
    id: str
    device_id: Optional[str] = None
    threat_type: str
    severity: str
    description: str
    detected_at: str
    resolved: bool = False


class ControlRequest(BaseModel):
    """Device control request"""
    action: str
    params: Dict[str, Any] = Field(default_factory=dict)


class ControlResponse(BaseModel):
    """Control action response"""
    success: bool
    message: str
    data: Dict[str, Any] = Field(default_factory=dict)


class TrustRequest(BaseModel):
    """Device trust request"""
    trusted: bool


class ThreatResolveRequest(BaseModel):
    """Threat resolution request"""
    action: str = "manual"


class ScanRequest(BaseModel):
    """Network scan request"""
    mode: str = "active"  # passive, active, full, quick


class NetworkStatusResponse(BaseModel):
    """Network status response"""
    total_devices: int
    online_devices: int
    trusted_devices: int
    untrusted_devices: int
    active_threats: int
    critical_threats: int
    last_scan: Optional[str] = None
    scanning: bool


class SecurityStatusResponse(BaseModel):
    """Security status response"""
    overall_score: int
    threat_level: str
    active_threats: int
    vulnerable_devices: int
    policy_violations: int


# Global agent instance (set during app startup)
_agent: Optional[SentinelAgent] = None


def get_agent() -> SentinelAgent:
    """Dependency to get the Sentinel agent instance"""
    if _agent is None:
        raise HTTPException(status_code=503, detail="Sentinel agent not initialized")
    return _agent


def create_api(agent: SentinelAgent) -> FastAPI:
    """
    Create FastAPI application for Sentinel Agent.

    Args:
        agent: Initialized SentinelAgent instance

    Returns:
        FastAPI application
    """
    global _agent
    _agent = agent

    app = FastAPI(
        title="SENTINEL Agent API",
        description="Network monitoring, device discovery, and security control",
        version="1.0.0"
    )

    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # WebSocket connection manager
    ws_manager = WebSocketManager()

    # Wire up agent callbacks for real-time events
    agent.on_device_discovered(
        lambda d: ws_manager.broadcast({"type": "device_discovered", "device": d.to_dict()})
    )
    agent.on_threat_detected(
        lambda t: ws_manager.broadcast({"type": "threat_detected", "threat": t.to_dict()})
    )
    agent.on_response_executed(
        lambda r: ws_manager.broadcast({"type": "response_executed", "response": r.to_dict()})
    )

    # Routes

    @app.get("/")
    async def root():
        """API root - health check"""
        return {
            "name": "SENTINEL Agent",
            "status": "online",
            "version": "1.0.0"
        }

    @app.get("/health")
    async def health():
        """Health check endpoint"""
        return {"status": "healthy", "timestamp": datetime.now().isoformat()}

    # Device endpoints

    @app.get("/devices", response_model=List[DeviceResponse])
    async def list_devices(
        category: Optional[str] = None,
        trusted: Optional[bool] = None,
        agent: SentinelAgent = Depends(get_agent)
    ):
        """List all discovered devices"""
        if category:
            try:
                cat = DeviceCategory(category)
                devices = await agent.get_devices_by_category(cat)
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid category: {category}")
        else:
            devices = await agent.get_all_devices()

        if trusted is not None:
            devices = [d for d in devices if d.is_trusted == trusted]

        return [_device_to_response(d) for d in devices]

    @app.get("/devices/{device_id}", response_model=DeviceResponse)
    async def get_device(
        device_id: str,
        agent: SentinelAgent = Depends(get_agent)
    ):
        """Get a specific device"""
        device = await agent.get_device(device_id)
        if not device:
            raise HTTPException(status_code=404, detail="Device not found")
        return _device_to_response(device)

    @app.post("/devices/{device_id}/control", response_model=ControlResponse)
    async def control_device(
        device_id: str,
        request: ControlRequest,
        agent: SentinelAgent = Depends(get_agent)
    ):
        """Control a device"""
        success = await agent.control_device(
            device_id,
            request.action,
            **request.params
        )
        return ControlResponse(
            success=success,
            message="Action executed" if success else "Action failed",
            data={"action": request.action}
        )

    @app.post("/devices/{device_id}/trust", response_model=ControlResponse)
    async def set_device_trust(
        device_id: str,
        request: TrustRequest,
        agent: SentinelAgent = Depends(get_agent)
    ):
        """Set device trust status"""
        if request.trusted:
            success = await agent.trust_device(device_id)
        else:
            success = await agent.untrust_device(device_id)

        return ControlResponse(
            success=success,
            message=f"Device {'trusted' if request.trusted else 'untrusted'}",
            data={"trusted": request.trusted}
        )

    @app.post("/devices/{device_id}/isolate", response_model=ControlResponse)
    async def isolate_device(
        device_id: str,
        agent: SentinelAgent = Depends(get_agent)
    ):
        """Isolate a device from the network"""
        success = await agent.isolate_device(device_id)
        return ControlResponse(
            success=success,
            message="Device isolated" if success else "Isolation failed",
            data={}
        )

    @app.post("/devices/{device_id}/block", response_model=ControlResponse)
    async def block_device(
        device_id: str,
        duration: int = Query(default=3600, ge=60, le=86400),
        agent: SentinelAgent = Depends(get_agent)
    ):
        """Block a device temporarily"""
        success = await agent.block_device(device_id, duration)
        return ControlResponse(
            success=success,
            message=f"Device blocked for {duration}s" if success else "Block failed",
            data={"duration": duration}
        )

    # Threat endpoints

    @app.get("/threats", response_model=List[ThreatResponse])
    async def list_threats(
        severity: Optional[str] = None,
        resolved: bool = False,
        agent: SentinelAgent = Depends(get_agent)
    ):
        """List security threats"""
        threats = await agent.get_threats(severity=severity, resolved=resolved)
        return [_threat_to_response(t) for t in threats]

    @app.get("/threats/{threat_id}", response_model=ThreatResponse)
    async def get_threat(
        threat_id: str,
        agent: SentinelAgent = Depends(get_agent)
    ):
        """Get a specific threat"""
        threats = await agent.get_threats(resolved=True)
        for t in threats:
            if t.id == threat_id:
                return _threat_to_response(t)
        raise HTTPException(status_code=404, detail="Threat not found")

    @app.post("/threats/{threat_id}/resolve", response_model=ControlResponse)
    async def resolve_threat(
        threat_id: str,
        request: ThreatResolveRequest,
        agent: SentinelAgent = Depends(get_agent)
    ):
        """Resolve a threat"""
        success = await agent.resolve_threat(threat_id, request.action)
        return ControlResponse(
            success=success,
            message="Threat resolved" if success else "Resolution failed",
            data={"action": request.action}
        )

    # Scanning endpoints

    @app.post("/scan", response_model=ControlResponse)
    async def start_scan(
        request: ScanRequest,
        agent: SentinelAgent = Depends(get_agent)
    ):
        """Start a network scan"""
        try:
            mode = ScanMode(request.mode)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid scan mode: {request.mode}")

        # Start scan in background
        asyncio.create_task(agent.discover_network(mode))

        return ControlResponse(
            success=True,
            message=f"Scan started (mode: {request.mode})",
            data={"mode": request.mode}
        )

    # Status endpoints

    @app.get("/status/network", response_model=NetworkStatusResponse)
    async def get_network_status(
        agent: SentinelAgent = Depends(get_agent)
    ):
        """Get network status summary"""
        status = await agent.get_network_status()
        return NetworkStatusResponse(
            total_devices=status.total_devices,
            online_devices=status.online_devices,
            trusted_devices=status.trusted_devices,
            untrusted_devices=status.untrusted_devices,
            active_threats=status.active_threats,
            critical_threats=status.critical_threats,
            last_scan=status.last_scan.isoformat() if status.last_scan else None,
            scanning=status.scanning
        )

    @app.get("/status/security", response_model=SecurityStatusResponse)
    async def get_security_status(
        agent: SentinelAgent = Depends(get_agent)
    ):
        """Get security status summary"""
        status = await agent.get_security_status()
        return SecurityStatusResponse(
            overall_score=status.overall_score,
            threat_level=status.threat_level,
            active_threats=len(status.active_threats),
            vulnerable_devices=status.vulnerable_devices,
            policy_violations=status.policy_violations
        )

    # WebSocket endpoint

    @app.websocket("/events")
    async def websocket_events(websocket: WebSocket):
        """WebSocket endpoint for real-time events"""
        await ws_manager.connect(websocket)
        try:
            while True:
                # Keep connection alive, wait for messages
                data = await websocket.receive_text()
                # Echo back or handle commands
                if data == "ping":
                    await websocket.send_text("pong")
        except WebSocketDisconnect:
            ws_manager.disconnect(websocket)

    return app


class WebSocketManager:
    """Manage WebSocket connections for real-time updates"""

    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        """Accept and track new connection"""
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket connected. Total: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        """Remove disconnected client"""
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        logger.info(f"WebSocket disconnected. Total: {len(self.active_connections)}")

    async def broadcast(self, message: Dict[str, Any]):
        """Broadcast message to all connected clients"""
        if not self.active_connections:
            return

        text = json.dumps(message, default=str)
        disconnected = []

        for connection in self.active_connections:
            try:
                await connection.send_text(text)
            except Exception:
                disconnected.append(connection)

        # Clean up disconnected clients
        for conn in disconnected:
            self.disconnect(conn)


# Helper functions

def _device_to_response(device) -> DeviceResponse:
    """Convert NetworkDevice to API response"""
    return DeviceResponse(
        id=device.id,
        name=device.name,
        ip_address=device.ip_address,
        mac_address=device.mac_address,
        category=device.category.value if hasattr(device.category, 'value') else str(device.category),
        manufacturer=device.manufacturer,
        is_trusted=device.is_trusted,
        threat_level=device.threat_level,
        state=device.state.value if hasattr(device.state, 'value') else str(device.state),
        first_seen=device.first_seen.isoformat() if device.first_seen else None,
        last_seen=device.last_seen.isoformat() if device.last_seen else None
    )


def _threat_to_response(threat) -> ThreatResponse:
    """Convert Threat to API response"""
    return ThreatResponse(
        id=threat.id,
        device_id=threat.device_id,
        threat_type=threat.threat_type.value if hasattr(threat.threat_type, 'value') else str(threat.threat_type),
        severity=threat.severity.value if hasattr(threat.severity, 'value') else str(threat.severity),
        description=threat.description,
        detected_at=threat.detected_at.isoformat() if threat.detected_at else "",
        resolved=threat.resolved if hasattr(threat, 'resolved') else False
    )


# Standalone server runner

async def run_api(
    agent: SentinelAgent,
    host: str = "0.0.0.0",
    port: int = 8888
):
    """
    Run the API server.

    Args:
        agent: Initialized SentinelAgent
        host: Host to bind to
        port: Port to listen on
    """
    import uvicorn

    app = create_api(agent)
    config = uvicorn.Config(app, host=host, port=port, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()


def main():
    """CLI entry point"""
    import argparse

    parser = argparse.ArgumentParser(description="SENTINEL Agent API Server")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8888, help="Port to listen on")
    parser.add_argument("--db", default="data/sentinel.db", help="Database path")

    args = parser.parse_args()

    # Create agent
    agent = SentinelAgent(db_path=args.db)

    # Run
    asyncio.run(run_api(agent, args.host, args.port))


if __name__ == "__main__":
    main()
