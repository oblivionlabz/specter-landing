"""
VAULT Crypto Wallet

Multi-chain cryptocurrency wallet with transaction management.
"""

from pathlib import Path
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, field
from enum import Enum
import logging
import asyncio
from datetime import datetime
import json

logger = logging.getLogger("specter.vault.wallet")


class TransactionStatus(Enum):
    """Transaction status"""
    PENDING = "pending"
    AWAITING_APPROVAL = "awaiting_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    SUBMITTED = "submitted"
    CONFIRMED = "confirmed"
    FAILED = "failed"


@dataclass
class Transaction:
    """A cryptocurrency transaction"""
    id: str
    chain: str
    from_address: str
    to_address: str
    amount: float
    token: str = "ETH"
    status: TransactionStatus = TransactionStatus.PENDING
    gas_price: Optional[float] = None
    gas_limit: int = 21000
    tx_hash: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    confirmed_at: Optional[datetime] = None
    error: Optional[str] = None


class CryptoWallet:
    """
    Multi-chain cryptocurrency wallet.

    Features:
    - Ethereum, Polygon, Base support
    - Approval gates for transactions
    - Transaction limits
    - Secure key storage
    """

    SUPPORTED_CHAINS = {
        "ethereum": {
            "chain_id": 1,
            "rpc": "https://eth.llamarpc.com",
            "symbol": "ETH"
        },
        "polygon": {
            "chain_id": 137,
            "rpc": "https://polygon-rpc.com",
            "symbol": "MATIC"
        },
        "base": {
            "chain_id": 8453,
            "rpc": "https://mainnet.base.org",
            "symbol": "ETH"
        }
    }

    def __init__(
        self,
        wallet_dir: Path,
        approval_required: bool = True,
        max_single_transaction: float = 1000.0,
        daily_limit: float = 5000.0
    ):
        self.wallet_dir = wallet_dir
        self.approval_required = approval_required
        self.max_single_transaction = max_single_transaction
        self.daily_limit = daily_limit

        self.address: Optional[str] = None
        self.web3_clients: Dict[str, Any] = {}
        self.pending_transactions: Dict[str, Transaction] = {}
        self.transaction_history: List[Transaction] = []

        self.daily_spent = 0.0
        self.last_reset = datetime.now().date()

        self.initialized = False
        logger.info("VAULT wallet created")

    async def initialize(self) -> bool:
        """Initialize wallet"""
        if self.initialized:
            return True

        try:
            from web3 import Web3

            # Initialize Web3 clients for each chain
            for chain_name, chain_config in self.SUPPORTED_CHAINS.items():
                try:
                    w3 = Web3(Web3.HTTPProvider(chain_config["rpc"]))
                    if w3.is_connected():
                        self.web3_clients[chain_name] = w3
                        logger.info(f"  [+] Connected to {chain_name}")
                    else:
                        logger.warning(f"  [!] Failed to connect to {chain_name}")
                except Exception as e:
                    logger.error(f"  [!] {chain_name} error: {e}")

            # Load or create wallet
            await self._load_or_create_wallet()

            self.initialized = True
            return True

        except ImportError:
            logger.error("web3 not installed")
            return False
        except Exception as e:
            logger.error(f"Failed to initialize wallet: {e}")
            return False

    async def _load_or_create_wallet(self) -> None:
        """Load existing wallet or create new one"""
        from .security import WalletSecurity

        self.security = WalletSecurity(self.wallet_dir)

        # Check for existing wallet
        wallet_file = self.wallet_dir / "wallet.enc"
        if wallet_file.exists():
            # Load existing - requires password
            logger.info("Existing wallet found - load on demand")
        else:
            # Create new wallet
            self.wallet_dir.mkdir(parents=True, exist_ok=True)
            logger.info("No wallet found - create with 'create_wallet' command")

    async def create_wallet(self, password: str) -> str:
        """
        Create a new wallet.

        Args:
            password: Password to encrypt wallet

        Returns:
            Wallet address
        """
        from eth_account import Account

        # Generate new account
        account = Account.create()
        self.address = account.address

        # Encrypt and save private key
        await self.security.save_key(account.key.hex(), password)

        logger.info(f"Created new wallet: {self.address}")
        return self.address

    async def unlock(self, password: str) -> bool:
        """Unlock wallet with password"""
        try:
            private_key = await self.security.load_key(password)
            if private_key:
                from eth_account import Account
                account = Account.from_key(private_key)
                self.address = account.address
                logger.info(f"Wallet unlocked: {self.address}")
                return True
            return False
        except Exception as e:
            logger.error(f"Failed to unlock wallet: {e}")
            return False

    async def get_balance(self, chain: str = "ethereum") -> float:
        """Get wallet balance on chain"""
        if not self.address or chain not in self.web3_clients:
            return 0.0

        try:
            w3 = self.web3_clients[chain]
            balance_wei = w3.eth.get_balance(self.address)
            return float(w3.from_wei(balance_wei, "ether"))
        except Exception as e:
            logger.error(f"Failed to get balance: {e}")
            return 0.0

    async def get_all_balances(self) -> Dict[str, float]:
        """Get balances across all chains"""
        balances = {}
        for chain in self.web3_clients.keys():
            balances[chain] = await self.get_balance(chain)
        return balances

    async def prepare_transaction(
        self,
        to_address: str,
        amount: float,
        chain: str = "ethereum",
        token: str = "ETH"
    ) -> Optional[Transaction]:
        """
        Prepare a transaction (does not submit).

        Args:
            to_address: Recipient address
            amount: Amount to send
            chain: Blockchain to use
            token: Token symbol

        Returns:
            Transaction object awaiting approval
        """
        if not self.address:
            logger.error("Wallet not initialized")
            return None

        # Check limits
        if amount > self.max_single_transaction:
            logger.error(f"Amount exceeds single transaction limit: {self.max_single_transaction}")
            return None

        # Reset daily limit if needed
        if datetime.now().date() > self.last_reset:
            self.daily_spent = 0.0
            self.last_reset = datetime.now().date()

        if self.daily_spent + amount > self.daily_limit:
            logger.error(f"Amount exceeds daily limit: {self.daily_limit}")
            return None

        # Create transaction
        tx_id = f"tx_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        tx = Transaction(
            id=tx_id,
            chain=chain,
            from_address=self.address,
            to_address=to_address,
            amount=amount,
            token=token,
            status=TransactionStatus.AWAITING_APPROVAL if self.approval_required else TransactionStatus.APPROVED
        )

        self.pending_transactions[tx_id] = tx
        logger.info(f"Transaction prepared: {tx_id} - {amount} {token} to {to_address}")

        return tx

    async def approve_transaction(self, tx_id: str) -> bool:
        """Approve a pending transaction"""
        tx = self.pending_transactions.get(tx_id)
        if not tx:
            return False

        tx.status = TransactionStatus.APPROVED
        logger.info(f"Transaction approved: {tx_id}")
        return True

    async def reject_transaction(self, tx_id: str) -> bool:
        """Reject a pending transaction"""
        tx = self.pending_transactions.get(tx_id)
        if not tx:
            return False

        tx.status = TransactionStatus.REJECTED
        del self.pending_transactions[tx_id]
        logger.info(f"Transaction rejected: {tx_id}")
        return True

    async def submit_transaction(
        self,
        tx_id: str,
        password: str
    ) -> Optional[str]:
        """
        Submit an approved transaction.

        Args:
            tx_id: Transaction ID
            password: Wallet password

        Returns:
            Transaction hash if successful
        """
        tx = self.pending_transactions.get(tx_id)
        if not tx or tx.status != TransactionStatus.APPROVED:
            logger.error("Transaction not found or not approved")
            return None

        if tx.chain not in self.web3_clients:
            logger.error(f"Chain not connected: {tx.chain}")
            return None

        try:
            # Load private key
            private_key = await self.security.load_key(password)
            if not private_key:
                return None

            w3 = self.web3_clients[tx.chain]

            # Build transaction
            nonce = w3.eth.get_transaction_count(self.address)
            gas_price = w3.eth.gas_price

            tx_dict = {
                "nonce": nonce,
                "to": tx.to_address,
                "value": w3.to_wei(tx.amount, "ether"),
                "gas": tx.gas_limit,
                "gasPrice": gas_price,
                "chainId": self.SUPPORTED_CHAINS[tx.chain]["chain_id"]
            }

            # Sign and send
            from eth_account import Account
            signed = Account.sign_transaction(tx_dict, private_key)
            tx_hash = w3.eth.send_raw_transaction(signed.rawTransaction)

            tx.tx_hash = tx_hash.hex()
            tx.status = TransactionStatus.SUBMITTED
            tx.gas_price = float(w3.from_wei(gas_price, "gwei"))

            # Update daily limit
            self.daily_spent += tx.amount

            # Move to history
            del self.pending_transactions[tx_id]
            self.transaction_history.append(tx)

            logger.info(f"Transaction submitted: {tx.tx_hash}")
            return tx.tx_hash

        except Exception as e:
            tx.status = TransactionStatus.FAILED
            tx.error = str(e)
            logger.error(f"Transaction failed: {e}")
            return None

    async def wait_for_confirmation(
        self,
        tx_hash: str,
        chain: str = "ethereum",
        timeout: int = 300
    ) -> bool:
        """Wait for transaction confirmation"""
        if chain not in self.web3_clients:
            return False

        w3 = self.web3_clients[chain]

        try:
            receipt = w3.eth.wait_for_transaction_receipt(
                tx_hash,
                timeout=timeout
            )
            return receipt.status == 1
        except Exception as e:
            logger.error(f"Confirmation wait failed: {e}")
            return False

    def get_pending_transactions(self) -> List[Transaction]:
        """Get all pending transactions"""
        return list(self.pending_transactions.values())

    def get_transaction_history(self, limit: int = 50) -> List[Transaction]:
        """Get transaction history"""
        return self.transaction_history[-limit:]

    def get_status(self) -> Dict[str, Any]:
        """Get wallet status"""
        return {
            "initialized": self.initialized,
            "address": self.address,
            "connected_chains": list(self.web3_clients.keys()),
            "pending_count": len(self.pending_transactions),
            "daily_spent": self.daily_spent,
            "daily_limit": self.daily_limit,
            "max_single": self.max_single_transaction
        }

    async def shutdown(self) -> None:
        """Shutdown wallet"""
        # Clear sensitive data
        self.address = None
        self.web3_clients.clear()
        self.initialized = False
        logger.info("VAULT shutdown complete")
