"""
VAULT Security

Secure key storage and encryption for the crypto wallet.
"""

from pathlib import Path
from typing import Optional
import logging
import asyncio
import os
import json

logger = logging.getLogger("specter.vault.security")


class WalletSecurity:
    """
    Secure storage for wallet private keys.

    Uses AES-256-GCM encryption with PBKDF2 key derivation.
    """

    def __init__(self, wallet_dir: Path):
        self.wallet_dir = wallet_dir
        self.key_file = wallet_dir / "wallet.enc"
        self.salt_file = wallet_dir / "wallet.salt"

    async def save_key(self, private_key: str, password: str) -> bool:
        """
        Encrypt and save private key.

        Args:
            private_key: Hex private key
            password: Encryption password

        Returns:
            True if successful
        """
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
            from cryptography.hazmat.primitives import hashes
            from cryptography.hazmat.backends import default_backend

            # Generate salt
            salt = os.urandom(32)

            # Derive key from password
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=480000,
                backend=default_backend()
            )
            key = kdf.derive(password.encode())

            # Generate nonce
            nonce = os.urandom(12)

            # Encrypt
            aesgcm = AESGCM(key)
            ciphertext = aesgcm.encrypt(nonce, private_key.encode(), None)

            # Save
            self.wallet_dir.mkdir(parents=True, exist_ok=True)

            encrypted_data = {
                "nonce": nonce.hex(),
                "ciphertext": ciphertext.hex()
            }

            with open(self.key_file, 'w') as f:
                json.dump(encrypted_data, f)

            with open(self.salt_file, 'wb') as f:
                f.write(salt)

            # Set restrictive permissions
            os.chmod(self.key_file, 0o600)
            os.chmod(self.salt_file, 0o600)

            logger.info("Private key encrypted and saved")
            return True

        except Exception as e:
            logger.error(f"Failed to save key: {e}")
            return False

    async def load_key(self, password: str) -> Optional[str]:
        """
        Load and decrypt private key.

        Args:
            password: Decryption password

        Returns:
            Hex private key or None
        """
        if not self.key_file.exists() or not self.salt_file.exists():
            logger.error("Wallet files not found")
            return None

        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
            from cryptography.hazmat.primitives import hashes
            from cryptography.hazmat.backends import default_backend

            # Load salt
            with open(self.salt_file, 'rb') as f:
                salt = f.read()

            # Derive key
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=480000,
                backend=default_backend()
            )
            key = kdf.derive(password.encode())

            # Load encrypted data
            with open(self.key_file, 'r') as f:
                data = json.load(f)

            nonce = bytes.fromhex(data["nonce"])
            ciphertext = bytes.fromhex(data["ciphertext"])

            # Decrypt
            aesgcm = AESGCM(key)
            private_key = aesgcm.decrypt(nonce, ciphertext, None)

            return private_key.decode()

        except Exception as e:
            logger.error(f"Failed to load key: {e}")
            return None

    async def change_password(
        self,
        old_password: str,
        new_password: str
    ) -> bool:
        """Change wallet password"""
        private_key = await self.load_key(old_password)
        if not private_key:
            return False

        return await self.save_key(private_key, new_password)

    def wallet_exists(self) -> bool:
        """Check if wallet exists"""
        return self.key_file.exists() and self.salt_file.exists()

    async def destroy_wallet(self, password: str) -> bool:
        """
        Securely destroy wallet.

        Requires password confirmation.
        """
        # Verify password
        private_key = await self.load_key(password)
        if not private_key:
            return False

        try:
            # Overwrite files with random data
            if self.key_file.exists():
                size = self.key_file.stat().st_size
                with open(self.key_file, 'wb') as f:
                    f.write(os.urandom(size))
                self.key_file.unlink()

            if self.salt_file.exists():
                size = self.salt_file.stat().st_size
                with open(self.salt_file, 'wb') as f:
                    f.write(os.urandom(size))
                self.salt_file.unlink()

            logger.info("Wallet destroyed securely")
            return True

        except Exception as e:
            logger.error(f"Failed to destroy wallet: {e}")
            return False
