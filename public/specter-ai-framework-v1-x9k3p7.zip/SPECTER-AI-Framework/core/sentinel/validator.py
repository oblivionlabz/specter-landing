"""
SENTINEL Action Validator

Validates and sanitizes actions before execution.
"""

from typing import Optional, Dict, List, Any, Tuple
import logging
import re
from pathlib import Path

logger = logging.getLogger("specter.sentinel.validator")


class ActionValidator:
    """
    Validates actions for safety.

    Checks for:
    - Command injection
    - Path traversal
    - Dangerous patterns
    - Input sanitization
    """

    # Dangerous shell patterns
    SHELL_INJECTION_PATTERNS = [
        r";\s*",           # Command chaining
        r"\|\s*",          # Pipe
        r"&&\s*",          # AND
        r"\|\|\s*",        # OR
        r"`[^`]+`",        # Backticks
        r"\$\([^)]+\)",    # Command substitution
        r"\$\{[^}]+\}",    # Variable expansion
        r">\s*",           # Redirect
        r"<\s*",           # Input redirect
    ]

    # Dangerous file patterns
    DANGEROUS_PATHS = [
        "/etc/passwd",
        "/etc/shadow",
        "/etc/sudoers",
        "/root/.ssh",
        "/home/*/.ssh",
        "~/.ssh",
        "/dev/sda",
        "/dev/null",
    ]

    def __init__(self):
        self.injection_regex = [
            re.compile(p, re.IGNORECASE)
            for p in self.SHELL_INJECTION_PATTERNS
        ]
        logger.info("Action validator initialized")

    def validate_command(self, command: str) -> Tuple[bool, str]:
        """
        Validate a shell command.

        Args:
            command: Command to validate

        Returns:
            (is_safe, reason)
        """
        # Check for injection patterns
        for pattern in self.injection_regex:
            if pattern.search(command):
                return False, f"Potential command injection: {pattern.pattern}"

        # Check for sudo without explicit permission
        if "sudo" in command.lower() and "sudoers" not in command:
            return False, "sudo requires explicit approval"

        # Check for dangerous commands
        dangerous = [
            "rm -rf /",
            "rm -rf /*",
            "dd if=",
            ":(){:|:&};:",
            "chmod -R 777",
            "mkfs",
            "> /dev/sda",
        ]
        for d in dangerous:
            if d in command:
                return False, f"Dangerous command pattern: {d}"

        return True, "Command validated"

    def validate_path(self, path: str) -> Tuple[bool, str]:
        """
        Validate a file path.

        Args:
            path: Path to validate

        Returns:
            (is_safe, reason)
        """
        # Normalize path
        try:
            normalized = str(Path(path).resolve())
        except Exception:
            return False, "Invalid path"

        # Check for path traversal
        if ".." in path:
            return False, "Path traversal detected"

        # Check for dangerous paths
        for dangerous in self.DANGEROUS_PATHS:
            if dangerous.startswith("~"):
                dangerous = str(Path.home() / dangerous[2:])

            if "*" in dangerous:
                # Glob pattern
                pattern = dangerous.replace("*", ".*")
                if re.match(pattern, normalized):
                    return False, f"Access to {dangerous} is restricted"
            elif normalized.startswith(dangerous):
                return False, f"Access to {dangerous} is restricted"

        return True, "Path validated"

    def validate_url(self, url: str) -> Tuple[bool, str]:
        """
        Validate a URL.

        Args:
            url: URL to validate

        Returns:
            (is_safe, reason)
        """
        # Check for valid URL format
        url_pattern = re.compile(
            r'^https?://'
            r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'
            r'localhost|'
            r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
            r'(?::\d+)?'
            r'(?:/?|[/?]\S+)$', re.IGNORECASE
        )

        if not url_pattern.match(url):
            return False, "Invalid URL format"

        # Check for internal addresses
        internal_patterns = [
            r"^https?://localhost",
            r"^https?://127\.",
            r"^https?://192\.168\.",
            r"^https?://10\.",
            r"^https?://172\.(1[6-9]|2[0-9]|3[0-1])\.",
        ]

        for pattern in internal_patterns:
            if re.match(pattern, url, re.IGNORECASE):
                # Allow but flag
                logger.warning(f"Internal URL access: {url}")

        return True, "URL validated"

    def sanitize_input(self, text: str) -> str:
        """
        Sanitize user input.

        Args:
            text: Input text

        Returns:
            Sanitized text
        """
        # Remove null bytes
        text = text.replace("\x00", "")

        # Escape special characters
        special_chars = ["&", ";", "|", "$", "`", "(", ")", "{", "}", "[", "]"]
        for char in special_chars:
            text = text.replace(char, "\\" + char)

        return text

    def validate_json(self, data: Any) -> Tuple[bool, str]:
        """
        Validate JSON data for safety.

        Args:
            data: JSON data to validate

        Returns:
            (is_safe, reason)
        """
        if isinstance(data, str):
            # Check for script injection
            if "<script" in data.lower():
                return False, "Script injection detected"

        if isinstance(data, dict):
            for key, value in data.items():
                is_safe, reason = self.validate_json(value)
                if not is_safe:
                    return False, f"Unsafe value in {key}: {reason}"

        if isinstance(data, list):
            for item in data:
                is_safe, reason = self.validate_json(item)
                if not is_safe:
                    return False, reason

        return True, "JSON validated"

    def validate_code(
        self,
        code: str,
        language: str = "python"
    ) -> Tuple[bool, str]:
        """
        Validate code for dangerous patterns.

        Args:
            code: Code to validate
            language: Programming language

        Returns:
            (is_safe, reason)
        """
        dangerous_patterns = {
            "python": [
                r"import\s+os",
                r"subprocess\.",
                r"exec\s*\(",
                r"eval\s*\(",
                r"__import__",
                r"open\s*\([^)]*['\"]w",  # Write mode
                r"os\.system",
                r"os\.popen",
            ],
            "javascript": [
                r"eval\s*\(",
                r"Function\s*\(",
                r"child_process",
                r"fs\.write",
                r"exec\s*\(",
            ]
        }

        patterns = dangerous_patterns.get(language.lower(), [])
        for pattern in patterns:
            if re.search(pattern, code, re.IGNORECASE):
                logger.warning(f"Dangerous code pattern: {pattern}")
                # Don't block, just warn
                return True, f"Warning: potentially dangerous pattern: {pattern}"

        return True, "Code validated"
