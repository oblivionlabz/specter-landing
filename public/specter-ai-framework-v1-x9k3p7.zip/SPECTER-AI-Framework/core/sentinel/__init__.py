"""
SENTINEL - SPECTER's Security Module

Approval gates, action validation, and security boundaries.
"Protect what matters. Everything else is negotiable." - SPECTER Rule 3
"""

from .guardian import Guardian, ActionResult, ApprovalStatus
from .validator import ActionValidator

__all__ = [
    "Guardian",
    "ActionResult",
    "ApprovalStatus",
    "ActionValidator"
]
