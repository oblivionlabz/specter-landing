"""
SENTINEL Guardian

The security gatekeeper that protects what matters.
"""

from typing import Optional, Dict, List, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging
import asyncio
from datetime import datetime
import fnmatch
import re

logger = logging.getLogger("specter.sentinel.guardian")


class ApprovalStatus(Enum):
    """Status of an approval request"""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    AUTO_APPROVED = "auto_approved"
    BLOCKED = "blocked"


class ActionCategory(Enum):
    """Categories of actions"""
    FILE_READ = "file_read"
    FILE_WRITE = "file_write"
    FILE_DELETE = "file_delete"
    EXECUTE_COMMAND = "execute_command"
    NETWORK_REQUEST = "network_request"
    SYSTEM_MODIFY = "system_modify"
    FINANCIAL = "financial"
    DATA_EXPORT = "data_export"


@dataclass
class ActionResult:
    """Result of action validation"""
    allowed: bool
    status: ApprovalStatus
    reason: str
    category: ActionCategory
    requires_approval: bool = False
    approval_id: Optional[str] = None


@dataclass
class ApprovalRequest:
    """A pending approval request"""
    id: str
    action: str
    category: ActionCategory
    description: str
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    resolved_at: Optional[datetime] = None
    resolver: Optional[str] = None


class Guardian:
    """
    SPECTER's security guardian.

    Features:
    - Action validation
    - Approval gates for dangerous operations
    - Security boundary enforcement
    - Audit logging
    """

    def __init__(
        self,
        mode: str = "guardian",
        approval_required: Optional[List[str]] = None,
        never_read_patterns: Optional[List[str]] = None,
        never_execute_patterns: Optional[List[str]] = None
    ):
        self.mode = mode  # guardian, strict, permissive

        # Actions requiring approval
        self.approval_required = approval_required or [
            "delete_files_gt_10",
            "system_modification",
            "financial_transaction",
            "external_data_send"
        ]

        # Never read these patterns
        self.never_read_patterns = never_read_patterns or [
            "*.env*",
            "*.key",
            "*.pem",
            "*secret*",
            ".ssh/*",
            "*password*",
            "*credential*"
        ]

        # Never execute these patterns
        self.never_execute_patterns = never_execute_patterns or [
            "rm -rf /",
            "rm -rf /*",
            "dd if=*of=/dev/*",
            "mkfs.*",
            "> /dev/sda",
            "chmod -R 777 /",
            ":(){:|:&};:"  # Fork bomb
        ]

        self.pending_approvals: Dict[str, ApprovalRequest] = {}
        self.audit_log: List[Dict] = []
        self.approval_callback: Optional[Callable] = None

        logger.info(f"SENTINEL Guardian initialized: {mode} mode")

    def set_approval_callback(self, callback: Callable) -> None:
        """Set callback for approval requests"""
        self.approval_callback = callback

    async def validate_action(
        self,
        action: str,
        category: ActionCategory,
        details: Optional[Dict] = None
    ) -> ActionResult:
        """
        Validate an action before execution.

        Args:
            action: The action to validate
            category: Category of action
            details: Additional context

        Returns:
            ActionResult with validation decision
        """
        details = details or {}

        # Log the check
        self._audit_log("validate", action, category, details)

        # Check for hard blocks first
        if category == ActionCategory.FILE_READ:
            file_path = details.get("path", action)
            if self._matches_patterns(file_path, self.never_read_patterns):
                return ActionResult(
                    allowed=False,
                    status=ApprovalStatus.BLOCKED,
                    reason=f"File matches protected pattern: {file_path}",
                    category=category
                )

        if category == ActionCategory.EXECUTE_COMMAND:
            if self._matches_patterns(action, self.never_execute_patterns):
                return ActionResult(
                    allowed=False,
                    status=ApprovalStatus.BLOCKED,
                    reason=f"Command is blocked: {action}",
                    category=category
                )

        # Check if approval is required
        requires_approval = self._requires_approval(action, category, details)

        if requires_approval:
            # Create approval request
            approval_id = f"apr_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
            request = ApprovalRequest(
                id=approval_id,
                action=action,
                category=category,
                description=self._describe_action(action, category, details)
            )
            self.pending_approvals[approval_id] = request

            # Notify callback if set
            if self.approval_callback:
                try:
                    if asyncio.iscoroutinefunction(self.approval_callback):
                        await self.approval_callback(request)
                    else:
                        self.approval_callback(request)
                except Exception as e:
                    logger.error(f"Approval callback error: {e}")

            return ActionResult(
                allowed=False,
                status=ApprovalStatus.PENDING,
                reason="Action requires approval",
                category=category,
                requires_approval=True,
                approval_id=approval_id
            )

        # Auto-approve in permissive mode
        if self.mode == "permissive":
            return ActionResult(
                allowed=True,
                status=ApprovalStatus.AUTO_APPROVED,
                reason="Auto-approved in permissive mode",
                category=category
            )

        # Allow by default in guardian mode for non-dangerous actions
        return ActionResult(
            allowed=True,
            status=ApprovalStatus.AUTO_APPROVED,
            reason="Action validated",
            category=category
        )

    def _matches_patterns(self, value: str, patterns: List[str]) -> bool:
        """Check if value matches any pattern"""
        for pattern in patterns:
            if fnmatch.fnmatch(value.lower(), pattern.lower()):
                return True
            # Also check with regex for complex patterns
            try:
                if re.search(pattern, value, re.IGNORECASE):
                    return True
            except re.error:
                pass
        return False

    def _requires_approval(
        self,
        action: str,
        category: ActionCategory,
        details: Dict
    ) -> bool:
        """Determine if action requires approval"""
        if self.mode == "permissive":
            return False

        if self.mode == "strict":
            # In strict mode, approve more things
            if category in [
                ActionCategory.FILE_DELETE,
                ActionCategory.SYSTEM_MODIFY,
                ActionCategory.FINANCIAL,
                ActionCategory.DATA_EXPORT
            ]:
                return True

        # Check specific approval requirements
        if "delete_files" in self.approval_required:
            if category == ActionCategory.FILE_DELETE:
                return True

        if "system_modification" in self.approval_required:
            if category == ActionCategory.SYSTEM_MODIFY:
                return True

        if "financial_transaction" in self.approval_required:
            if category == ActionCategory.FINANCIAL:
                return True

        if "external_data_send" in self.approval_required:
            if category == ActionCategory.DATA_EXPORT:
                return True

        # Check for batch operations
        if "delete_files_gt_10" in self.approval_required:
            file_count = details.get("file_count", 0)
            if category == ActionCategory.FILE_DELETE and file_count > 10:
                return True

        return False

    def _describe_action(
        self,
        action: str,
        category: ActionCategory,
        details: Dict
    ) -> str:
        """Create human-readable action description"""
        if category == ActionCategory.FILE_DELETE:
            count = details.get("file_count", 1)
            return f"Delete {count} file(s): {action}"

        if category == ActionCategory.EXECUTE_COMMAND:
            return f"Execute command: {action}"

        if category == ActionCategory.FINANCIAL:
            amount = details.get("amount", "unknown")
            return f"Financial transaction: {amount}"

        if category == ActionCategory.SYSTEM_MODIFY:
            return f"System modification: {action}"

        return f"{category.value}: {action}"

    async def approve(
        self,
        approval_id: str,
        approver: str = "user"
    ) -> bool:
        """Approve a pending request"""
        if approval_id not in self.pending_approvals:
            return False

        request = self.pending_approvals[approval_id]
        request.status = ApprovalStatus.APPROVED
        request.resolved_at = datetime.now()
        request.resolver = approver

        self._audit_log("approved", request.action, request.category, {"approver": approver})
        logger.info(f"Approved: {approval_id}")

        return True

    async def reject(
        self,
        approval_id: str,
        rejector: str = "user"
    ) -> bool:
        """Reject a pending request"""
        if approval_id not in self.pending_approvals:
            return False

        request = self.pending_approvals[approval_id]
        request.status = ApprovalStatus.REJECTED
        request.resolved_at = datetime.now()
        request.resolver = rejector

        self._audit_log("rejected", request.action, request.category, {"rejector": rejector})
        logger.info(f"Rejected: {approval_id}")

        return True

    def get_approval_status(self, approval_id: str) -> Optional[ApprovalStatus]:
        """Get status of an approval request"""
        if approval_id in self.pending_approvals:
            return self.pending_approvals[approval_id].status
        return None

    def get_pending_approvals(self) -> List[ApprovalRequest]:
        """Get all pending approvals"""
        return [
            r for r in self.pending_approvals.values()
            if r.status == ApprovalStatus.PENDING
        ]

    def _audit_log(
        self,
        event_type: str,
        action: str,
        category: ActionCategory,
        details: Dict
    ) -> None:
        """Add entry to audit log"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "event": event_type,
            "action": action,
            "category": category.value,
            "details": details
        }
        self.audit_log.append(entry)

        # Trim log
        if len(self.audit_log) > 10000:
            self.audit_log = self.audit_log[-5000:]

    def get_audit_log(self, limit: int = 100) -> List[Dict]:
        """Get recent audit log entries"""
        return self.audit_log[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """Get security statistics"""
        pending = len([r for r in self.pending_approvals.values()
                       if r.status == ApprovalStatus.PENDING])
        approved = len([r for r in self.pending_approvals.values()
                        if r.status == ApprovalStatus.APPROVED])
        rejected = len([r for r in self.pending_approvals.values()
                        if r.status == ApprovalStatus.REJECTED])

        return {
            "mode": self.mode,
            "pending_approvals": pending,
            "total_approved": approved,
            "total_rejected": rejected,
            "audit_log_size": len(self.audit_log),
            "protected_patterns": len(self.never_read_patterns),
            "blocked_commands": len(self.never_execute_patterns)
        }
