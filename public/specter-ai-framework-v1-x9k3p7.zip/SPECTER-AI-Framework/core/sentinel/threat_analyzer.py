"""
SENTINEL Threat Analyzer

Advanced threat classification and response recommendation system.
Analyzes detected threats and recommends/executes defensive actions.
"""

from typing import List, Optional, Dict, Any, Callable, Awaitable
from dataclasses import dataclass, field
from enum import Enum, auto
from datetime import datetime, timedelta
import asyncio
import logging

from .network_monitor import Threat, ThreatSeverity, ThreatType

logger = logging.getLogger(__name__)


class ResponseAction(Enum):
    """Defensive response actions"""
    # Immediate actions (auto-execute for critical)
    BLOCK_DEVICE = "block_device"
    ISOLATE_DEVICE = "isolate_device"
    RATE_LIMIT = "rate_limit"

    # Alert actions
    ALERT_USER = "alert_user"
    ALERT_ADMIN = "alert_admin"
    LOG_EVENT = "log_event"

    # Investigation actions
    DEEP_SCAN = "deep_scan"
    CAPTURE_TRAFFIC = "capture_traffic"
    FINGERPRINT_DEVICE = "fingerprint_device"

    # Recovery actions
    QUARANTINE = "quarantine"
    RESTORE_BASELINE = "restore_baseline"

    # Approval-required actions
    FIREWALL_RULE = "firewall_rule"
    NETWORK_SEGMENT = "network_segment"
    DISABLE_PORT = "disable_port"

    # No action
    MONITOR_ONLY = "monitor_only"
    IGNORE = "ignore"


class ResponseOutcome(Enum):
    """Outcome of response execution"""
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"
    PENDING_APPROVAL = "pending_approval"
    SKIPPED = "skipped"


@dataclass
class ResponseRecommendation:
    """Recommended response to a threat"""
    threat_id: str
    action: ResponseAction
    priority: int  # 1-10, higher = more urgent
    requires_approval: bool
    estimated_impact: str  # Description of what this action does
    alternatives: List[ResponseAction] = field(default_factory=list)
    parameters: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "threat_id": self.threat_id,
            "action": self.action.value,
            "priority": self.priority,
            "requires_approval": self.requires_approval,
            "estimated_impact": self.estimated_impact,
            "alternatives": [a.value for a in self.alternatives],
            "parameters": self.parameters
        }


@dataclass
class ResponseResult:
    """Result of executing a response"""
    threat_id: str
    action: ResponseAction
    outcome: ResponseOutcome
    executed_at: datetime
    message: str
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "threat_id": self.threat_id,
            "action": self.action.value,
            "outcome": self.outcome.value,
            "executed_at": self.executed_at.isoformat(),
            "message": self.message,
            "details": self.details
        }


# Response action handlers type
ResponseHandler = Callable[[Threat, Dict[str, Any]], Awaitable[ResponseResult]]


class ThreatAnalyzer:
    """
    Threat classification and response recommendation.

    Severity levels and autonomy:
    - CRITICAL: Immediate auto-response (e.g., rogue device isolation)
    - HIGH: Auto-response + alert (e.g., unauthorized port open)
    - MEDIUM: Alert only, ask before action
    - LOW: Log only
    - INFO: Informational (e.g., new trusted device)
    """

    # Default auto-response actions by severity
    AUTO_RESPONSE_ACTIONS: Dict[ThreatSeverity, List[ResponseAction]] = {
        ThreatSeverity.CRITICAL: [
            ResponseAction.BLOCK_DEVICE,
            ResponseAction.ALERT_ADMIN,
            ResponseAction.LOG_EVENT
        ],
        ThreatSeverity.HIGH: [
            ResponseAction.RATE_LIMIT,
            ResponseAction.ALERT_USER,
            ResponseAction.DEEP_SCAN,
            ResponseAction.LOG_EVENT
        ],
        ThreatSeverity.MEDIUM: [
            ResponseAction.ALERT_USER,
            ResponseAction.LOG_EVENT
        ],
        ThreatSeverity.LOW: [
            ResponseAction.LOG_EVENT
        ],
        ThreatSeverity.INFO: [
            ResponseAction.LOG_EVENT
        ]
    }

    # Threat type specific responses
    THREAT_TYPE_RESPONSES: Dict[ThreatType, ResponseAction] = {
        ThreatType.NEW_DEVICE: ResponseAction.FINGERPRINT_DEVICE,
        ThreatType.ROGUE_DEVICE: ResponseAction.ISOLATE_DEVICE,
        ThreatType.PORT_CHANGE: ResponseAction.DEEP_SCAN,
        ThreatType.ANOMALY: ResponseAction.CAPTURE_TRAFFIC,
        ThreatType.VULNERABILITY: ResponseAction.ALERT_ADMIN,
        ThreatType.SPOOFING: ResponseAction.BLOCK_DEVICE,
        ThreatType.BRUTE_FORCE: ResponseAction.RATE_LIMIT,
        ThreatType.SCAN_DETECTED: ResponseAction.LOG_EVENT,
        ThreatType.POLICY_VIOLATION: ResponseAction.ALERT_USER,
        ThreatType.MALWARE_INDICATOR: ResponseAction.QUARANTINE,
    }

    def __init__(
        self,
        auto_respond_enabled: bool = True,
        max_auto_severity: ThreatSeverity = ThreatSeverity.HIGH,
        approval_callback: Optional[Callable[[ResponseRecommendation], Awaitable[bool]]] = None
    ):
        """
        Initialize threat analyzer.

        Args:
            auto_respond_enabled: Whether to auto-execute responses
            max_auto_severity: Maximum severity for auto-response without approval
            approval_callback: Async function to request user approval
        """
        self.auto_respond_enabled = auto_respond_enabled
        self.max_auto_severity = max_auto_severity
        self.approval_callback = approval_callback

        # Response handlers registry
        self._handlers: Dict[ResponseAction, ResponseHandler] = {}

        # Response history
        self._history: List[ResponseResult] = []

        # Threat pattern learning
        self._threat_patterns: Dict[str, List[Threat]] = {}

        # Register default handlers
        self._register_default_handlers()

    def _register_default_handlers(self) -> None:
        """Register default response action handlers"""
        self.register_handler(ResponseAction.LOG_EVENT, self._handle_log_event)
        self.register_handler(ResponseAction.ALERT_USER, self._handle_alert_user)
        self.register_handler(ResponseAction.ALERT_ADMIN, self._handle_alert_admin)
        self.register_handler(ResponseAction.MONITOR_ONLY, self._handle_monitor_only)

    def register_handler(
        self,
        action: ResponseAction,
        handler: ResponseHandler
    ) -> None:
        """Register a handler for a response action"""
        self._handlers[action] = handler
        logger.debug(f"Registered handler for {action.value}")

    async def classify(self, threat: Threat) -> ThreatSeverity:
        """
        Classify threat severity with contextual analysis.

        Considers:
        - Base threat type severity
        - Device trust level
        - Historical patterns
        - Time of occurrence
        - Network context
        """
        base_severity = threat.severity

        # Adjust based on context
        severity_score = self._severity_to_score(base_severity)

        # Increase severity for untrusted devices
        if not threat.details.get("is_trusted", False):
            severity_score += 1

        # Increase severity for repeat offenders
        device_id = threat.device_id
        if device_id and device_id in self._threat_patterns:
            recent_threats = [
                t for t in self._threat_patterns[device_id]
                if (datetime.now() - t.detected_at).total_seconds() < 3600
            ]
            if len(recent_threats) >= 3:
                severity_score += 1

        # Increase severity during off-hours (potential indicator of attack)
        hour = datetime.now().hour
        if hour < 6 or hour > 22:  # Late night/early morning
            if threat.threat_type in [
                ThreatType.BRUTE_FORCE,
                ThreatType.SCAN_DETECTED,
                ThreatType.SPOOFING
            ]:
                severity_score += 1

        # Convert back to severity enum
        return self._score_to_severity(severity_score)

    def _severity_to_score(self, severity: ThreatSeverity) -> int:
        """Convert severity enum to numeric score"""
        mapping = {
            ThreatSeverity.INFO: 0,
            ThreatSeverity.LOW: 1,
            ThreatSeverity.MEDIUM: 2,
            ThreatSeverity.HIGH: 3,
            ThreatSeverity.CRITICAL: 4
        }
        return mapping.get(severity, 2)

    def _score_to_severity(self, score: int) -> ThreatSeverity:
        """Convert numeric score to severity enum"""
        if score <= 0:
            return ThreatSeverity.INFO
        elif score == 1:
            return ThreatSeverity.LOW
        elif score == 2:
            return ThreatSeverity.MEDIUM
        elif score == 3:
            return ThreatSeverity.HIGH
        else:
            return ThreatSeverity.CRITICAL

    async def recommend_response(
        self,
        threat: Threat
    ) -> ResponseRecommendation:
        """
        Recommend defensive action for a threat.

        Returns prioritized recommendation with alternatives.
        """
        # Classify severity (may adjust from initial)
        severity = await self.classify(threat)

        # Get primary action based on threat type
        primary_action = self.THREAT_TYPE_RESPONSES.get(
            threat.threat_type,
            ResponseAction.MONITOR_ONLY
        )

        # Get additional actions based on severity
        severity_actions = self.AUTO_RESPONSE_ACTIONS.get(severity, [])

        # Determine if approval is required
        requires_approval = self._requires_approval(threat, primary_action)

        # Calculate priority (1-10)
        priority = self._calculate_priority(threat, severity)

        # Generate impact description
        impact = self._describe_impact(primary_action, threat)

        # Get alternative actions
        alternatives = [
            a for a in severity_actions
            if a != primary_action
        ][:3]  # Max 3 alternatives

        # Build parameters based on action type
        parameters = self._build_action_parameters(primary_action, threat)

        recommendation = ResponseRecommendation(
            threat_id=threat.id,
            action=primary_action,
            priority=priority,
            requires_approval=requires_approval,
            estimated_impact=impact,
            alternatives=alternatives,
            parameters=parameters
        )

        logger.info(
            f"Recommended {primary_action.value} for threat {threat.id} "
            f"(severity: {severity.value}, priority: {priority})"
        )

        return recommendation

    def _requires_approval(
        self,
        threat: Threat,
        action: ResponseAction
    ) -> bool:
        """Determine if action requires user approval"""
        # Actions that always require approval
        approval_required_actions = {
            ResponseAction.FIREWALL_RULE,
            ResponseAction.NETWORK_SEGMENT,
            ResponseAction.DISABLE_PORT,
            ResponseAction.QUARANTINE,
        }

        if action in approval_required_actions:
            return True

        # Check if auto-response is enabled
        if not self.auto_respond_enabled:
            return True

        # Check severity threshold
        if self._severity_to_score(threat.severity) <= self._severity_to_score(self.max_auto_severity):
            return False

        return True

    def _calculate_priority(
        self,
        threat: Threat,
        severity: ThreatSeverity
    ) -> int:
        """Calculate response priority (1-10)"""
        base_priority = {
            ThreatSeverity.CRITICAL: 10,
            ThreatSeverity.HIGH: 7,
            ThreatSeverity.MEDIUM: 5,
            ThreatSeverity.LOW: 3,
            ThreatSeverity.INFO: 1
        }.get(severity, 5)

        # Adjust for threat type
        high_priority_types = {
            ThreatType.ROGUE_DEVICE,
            ThreatType.SPOOFING,
            ThreatType.MALWARE_INDICATOR,
            ThreatType.BRUTE_FORCE
        }
        if threat.threat_type in high_priority_types:
            base_priority = min(10, base_priority + 1)

        return base_priority

    def _describe_impact(
        self,
        action: ResponseAction,
        threat: Threat
    ) -> str:
        """Generate human-readable impact description"""
        device_desc = threat.details.get("device_name", threat.device_id or "unknown device")

        descriptions = {
            ResponseAction.BLOCK_DEVICE: f"Block all traffic from {device_desc}",
            ResponseAction.ISOLATE_DEVICE: f"Isolate {device_desc} from network",
            ResponseAction.RATE_LIMIT: f"Limit connection rate for {device_desc}",
            ResponseAction.ALERT_USER: "Send notification to user",
            ResponseAction.ALERT_ADMIN: "Send alert to administrator",
            ResponseAction.LOG_EVENT: "Record event in security log",
            ResponseAction.DEEP_SCAN: f"Perform detailed scan of {device_desc}",
            ResponseAction.CAPTURE_TRAFFIC: f"Capture traffic from {device_desc} for analysis",
            ResponseAction.FINGERPRINT_DEVICE: f"Identify and classify {device_desc}",
            ResponseAction.QUARANTINE: f"Move {device_desc} to quarantine network",
            ResponseAction.RESTORE_BASELINE: f"Reset {device_desc} to known-good state",
            ResponseAction.FIREWALL_RULE: "Add firewall rule (requires approval)",
            ResponseAction.NETWORK_SEGMENT: "Modify network segmentation (requires approval)",
            ResponseAction.DISABLE_PORT: "Disable network port (requires approval)",
            ResponseAction.MONITOR_ONLY: "Continue monitoring without action",
            ResponseAction.IGNORE: "Mark as false positive and ignore"
        }

        return descriptions.get(action, f"Execute {action.value}")

    def _build_action_parameters(
        self,
        action: ResponseAction,
        threat: Threat
    ) -> Dict[str, Any]:
        """Build action-specific parameters"""
        params: Dict[str, Any] = {
            "device_id": threat.device_id,
            "threat_id": threat.id,
            "threat_type": threat.threat_type.value,
            "timestamp": datetime.now().isoformat()
        }

        # Add action-specific parameters
        if action in [ResponseAction.BLOCK_DEVICE, ResponseAction.ISOLATE_DEVICE]:
            params["duration_seconds"] = 3600  # Default 1 hour
            params["reason"] = threat.description

        elif action == ResponseAction.RATE_LIMIT:
            params["max_requests_per_minute"] = 10
            params["burst_size"] = 5

        elif action == ResponseAction.DEEP_SCAN:
            params["scan_ports"] = True
            params["scan_services"] = True
            params["os_detection"] = True

        elif action == ResponseAction.CAPTURE_TRAFFIC:
            params["duration_seconds"] = 300  # 5 minutes
            params["max_packets"] = 10000

        return params

    async def auto_respond(self, threat: Threat) -> Optional[ResponseResult]:
        """
        Execute auto-response for threats that don't require approval.

        Returns ResponseResult if action was taken, None if approval required.
        """
        recommendation = await self.recommend_response(threat)

        # Track threat pattern
        self._record_threat_pattern(threat)

        if recommendation.requires_approval:
            # Try to get approval if callback is set
            if self.approval_callback:
                approved = await self.approval_callback(recommendation)
                if not approved:
                    return ResponseResult(
                        threat_id=threat.id,
                        action=recommendation.action,
                        outcome=ResponseOutcome.PENDING_APPROVAL,
                        executed_at=datetime.now(),
                        message="Action requires approval",
                        details={"recommendation": recommendation.to_dict()}
                    )
            else:
                return ResponseResult(
                    threat_id=threat.id,
                    action=recommendation.action,
                    outcome=ResponseOutcome.PENDING_APPROVAL,
                    executed_at=datetime.now(),
                    message="Action requires manual approval",
                    details={"recommendation": recommendation.to_dict()}
                )

        # Execute the response
        return await self.execute_response(threat, recommendation)

    async def execute_response(
        self,
        threat: Threat,
        recommendation: ResponseRecommendation
    ) -> ResponseResult:
        """Execute a response action"""
        action = recommendation.action

        # Get handler for action
        handler = self._handlers.get(action)

        if not handler:
            logger.warning(f"No handler registered for {action.value}")
            return ResponseResult(
                threat_id=threat.id,
                action=action,
                outcome=ResponseOutcome.FAILED,
                executed_at=datetime.now(),
                message=f"No handler registered for {action.value}",
                details={}
            )

        try:
            result = await handler(threat, recommendation.parameters)
            self._history.append(result)
            return result

        except Exception as e:
            logger.error(f"Error executing {action.value}: {e}")
            result = ResponseResult(
                threat_id=threat.id,
                action=action,
                outcome=ResponseOutcome.FAILED,
                executed_at=datetime.now(),
                message=str(e),
                details={"error": str(e)}
            )
            self._history.append(result)
            return result

    def _record_threat_pattern(self, threat: Threat) -> None:
        """Record threat for pattern analysis"""
        device_id = threat.device_id
        if device_id:
            if device_id not in self._threat_patterns:
                self._threat_patterns[device_id] = []

            self._threat_patterns[device_id].append(threat)

            # Keep only last 100 threats per device
            if len(self._threat_patterns[device_id]) > 100:
                self._threat_patterns[device_id] = \
                    self._threat_patterns[device_id][-100:]

    async def get_threat_history(
        self,
        device_id: Optional[str] = None,
        limit: int = 50
    ) -> List[Threat]:
        """Get threat history for analysis"""
        if device_id:
            threats = self._threat_patterns.get(device_id, [])
        else:
            threats = []
            for device_threats in self._threat_patterns.values():
                threats.extend(device_threats)

        # Sort by time, most recent first
        threats.sort(key=lambda t: t.detected_at, reverse=True)
        return threats[:limit]

    async def get_response_history(
        self,
        limit: int = 50
    ) -> List[ResponseResult]:
        """Get response execution history"""
        return self._history[-limit:]

    async def analyze_patterns(
        self,
        device_id: str,
        time_window_hours: int = 24
    ) -> Dict[str, Any]:
        """
        Analyze threat patterns for a device.

        Returns pattern analysis including:
        - Threat frequency
        - Common threat types
        - Time distribution
        - Escalation indicators
        """
        threats = self._threat_patterns.get(device_id, [])

        if not threats:
            return {
                "device_id": device_id,
                "total_threats": 0,
                "analysis": "No threat history"
            }

        cutoff = datetime.now() - timedelta(hours=time_window_hours)
        recent_threats = [t for t in threats if t.detected_at >= cutoff]

        if not recent_threats:
            return {
                "device_id": device_id,
                "total_threats": len(threats),
                "recent_threats": 0,
                "analysis": "No recent threats"
            }

        # Analyze threat types
        type_counts: Dict[str, int] = {}
        severity_counts: Dict[str, int] = {}

        for threat in recent_threats:
            type_name = threat.threat_type.value
            type_counts[type_name] = type_counts.get(type_name, 0) + 1

            sev_name = threat.severity.value
            severity_counts[sev_name] = severity_counts.get(sev_name, 0) + 1

        # Check for escalation (increasing severity over time)
        escalating = self._detect_escalation(recent_threats)

        # Analyze time distribution
        hour_distribution = self._analyze_time_distribution(recent_threats)

        return {
            "device_id": device_id,
            "total_threats": len(threats),
            "recent_threats": len(recent_threats),
            "time_window_hours": time_window_hours,
            "threat_types": type_counts,
            "severity_distribution": severity_counts,
            "is_escalating": escalating,
            "peak_hours": hour_distribution.get("peak_hours", []),
            "analysis": self._generate_analysis_summary(
                recent_threats, escalating, type_counts
            )
        }

    def _detect_escalation(self, threats: List[Threat]) -> bool:
        """Detect if threat severity is escalating over time"""
        if len(threats) < 3:
            return False

        # Sort by time
        sorted_threats = sorted(threats, key=lambda t: t.detected_at)

        # Calculate average severity for first and last third
        n = len(sorted_threats)
        third = n // 3

        if third == 0:
            return False

        first_avg = sum(
            self._severity_to_score(t.severity)
            for t in sorted_threats[:third]
        ) / third

        last_avg = sum(
            self._severity_to_score(t.severity)
            for t in sorted_threats[-third:]
        ) / third

        return last_avg > first_avg + 0.5

    def _analyze_time_distribution(
        self,
        threats: List[Threat]
    ) -> Dict[str, Any]:
        """Analyze when threats occur"""
        hour_counts: Dict[int, int] = {}

        for threat in threats:
            hour = threat.detected_at.hour
            hour_counts[hour] = hour_counts.get(hour, 0) + 1

        if not hour_counts:
            return {}

        max_count = max(hour_counts.values())
        peak_hours = [h for h, c in hour_counts.items() if c == max_count]

        return {
            "hour_distribution": hour_counts,
            "peak_hours": peak_hours
        }

    def _generate_analysis_summary(
        self,
        threats: List[Threat],
        escalating: bool,
        type_counts: Dict[str, int]
    ) -> str:
        """Generate human-readable analysis summary"""
        parts = []

        parts.append(f"{len(threats)} threats in analysis window")

        if escalating:
            parts.append("ESCALATING severity trend detected")

        if type_counts:
            most_common = max(type_counts.items(), key=lambda x: x[1])
            parts.append(f"Most common: {most_common[0]} ({most_common[1]}x)")

        return "; ".join(parts)

    # Default handlers

    async def _handle_log_event(
        self,
        threat: Threat,
        params: Dict[str, Any]
    ) -> ResponseResult:
        """Default handler for LOG_EVENT"""
        logger.info(
            f"SECURITY EVENT: {threat.threat_type.value} - "
            f"{threat.description} (severity: {threat.severity.value})"
        )

        return ResponseResult(
            threat_id=threat.id,
            action=ResponseAction.LOG_EVENT,
            outcome=ResponseOutcome.SUCCESS,
            executed_at=datetime.now(),
            message="Event logged successfully",
            details={"logged": True}
        )

    async def _handle_alert_user(
        self,
        threat: Threat,
        params: Dict[str, Any]
    ) -> ResponseResult:
        """Default handler for ALERT_USER"""
        logger.warning(
            f"USER ALERT: {threat.threat_type.value} detected - "
            f"{threat.description}"
        )

        return ResponseResult(
            threat_id=threat.id,
            action=ResponseAction.ALERT_USER,
            outcome=ResponseOutcome.SUCCESS,
            executed_at=datetime.now(),
            message="User alert sent",
            details={"alert_type": "user"}
        )

    async def _handle_alert_admin(
        self,
        threat: Threat,
        params: Dict[str, Any]
    ) -> ResponseResult:
        """Default handler for ALERT_ADMIN"""
        logger.critical(
            f"ADMIN ALERT: {threat.threat_type.value} - "
            f"SEVERITY: {threat.severity.value} - {threat.description}"
        )

        return ResponseResult(
            threat_id=threat.id,
            action=ResponseAction.ALERT_ADMIN,
            outcome=ResponseOutcome.SUCCESS,
            executed_at=datetime.now(),
            message="Admin alert sent",
            details={"alert_type": "admin", "severity": threat.severity.value}
        )

    async def _handle_monitor_only(
        self,
        threat: Threat,
        params: Dict[str, Any]
    ) -> ResponseResult:
        """Default handler for MONITOR_ONLY"""
        return ResponseResult(
            threat_id=threat.id,
            action=ResponseAction.MONITOR_ONLY,
            outcome=ResponseOutcome.SUCCESS,
            executed_at=datetime.now(),
            message="Monitoring without action",
            details={"monitoring": True}
        )
