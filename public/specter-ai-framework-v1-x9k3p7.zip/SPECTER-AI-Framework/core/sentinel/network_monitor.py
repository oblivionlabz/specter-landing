"""
SENTINEL Network Monitor

Real-time network threat detection and monitoring.
"""

import asyncio
import logging
from typing import List, Optional, Dict, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import uuid

from core.nucleus.bus import EventBus, get_bus
from core.nucleus.events import Event, EventType

logger = logging.getLogger("specter.sentinel.network_monitor")


class ThreatSeverity(Enum):
    """Threat severity levels"""
    CRITICAL = "critical"  # Immediate auto-response
    HIGH = "high"          # Auto-response + alert
    MEDIUM = "medium"      # Alert only, ask before action
    LOW = "low"            # Log only
    INFO = "info"          # Informational


class ThreatType(Enum):
    """Types of security threats"""
    NEW_DEVICE = "new_device"           # Unknown device detected
    ROGUE_DEVICE = "rogue_device"       # Suspicious unknown device
    PORT_CHANGE = "port_change"         # Open ports changed
    SERVICE_CHANGE = "service_change"   # Services changed
    ANOMALY = "anomaly"                 # Behavioral anomaly
    VULNERABILITY = "vulnerability"     # Known vulnerability
    ROGUE_AP = "rogue_ap"               # Rogue access point
    OFFLINE = "offline"                 # Device went offline
    UNAUTHORIZED = "unauthorized"       # Unauthorized access attempt
    SCAN_DETECTED = "scan_detected"     # Port scan detected
    SPOOFING = "spoofing"               # MAC/IP spoofing
    BRUTE_FORCE = "brute_force"         # Brute force attack detected
    POLICY_VIOLATION = "policy_violation"  # Security policy violation
    MALWARE_INDICATOR = "malware_indicator"  # Malware indicator detected


@dataclass
class Threat:
    """A detected security threat"""
    id: str
    threat_type: ThreatType
    severity: ThreatSeverity
    device_id: Optional[str]
    device_ip: Optional[str]
    device_mac: Optional[str]
    description: str
    details: Dict[str, Any] = field(default_factory=dict)
    detected_at: datetime = field(default_factory=datetime.now)
    resolved_at: Optional[datetime] = None
    auto_response: Optional[str] = None
    requires_approval: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "threat_type": self.threat_type.value,
            "severity": self.severity.value,
            "device_id": self.device_id,
            "device_ip": self.device_ip,
            "device_mac": self.device_mac,
            "description": self.description,
            "details": self.details,
            "detected_at": self.detected_at.isoformat(),
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "auto_response": self.auto_response,
            "requires_approval": self.requires_approval
        }


@dataclass
class DeviceBaseline:
    """Normal behavioral baseline for a device"""
    device_id: str
    mac_address: str
    normal_ports: List[int] = field(default_factory=list)
    normal_services: Dict[int, str] = field(default_factory=dict)
    typical_online_hours: List[int] = field(default_factory=list)  # 0-23
    avg_bandwidth: float = 0.0
    last_updated: datetime = field(default_factory=datetime.now)
    observation_count: int = 0

    def update_from_observation(
        self,
        ports: List[int],
        services: Dict[int, str]
    ) -> None:
        """Update baseline from new observation"""
        # Merge ports (union over time)
        self.normal_ports = list(set(self.normal_ports + ports))

        # Merge services
        self.normal_services.update(services)

        # Update observation count and timestamp
        self.observation_count += 1
        self.last_updated = datetime.now()

        # Track online hours
        current_hour = datetime.now().hour
        if current_hour not in self.typical_online_hours:
            self.typical_online_hours.append(current_hour)


class NetworkMonitor:
    """
    Real-time network threat detection.

    Detects:
    - New/unknown devices
    - Port changes on known devices
    - Unusual traffic patterns
    - Known vulnerability signatures
    - Rogue access points
    - MAC/IP spoofing
    """

    # Ports that raise security concerns
    DANGEROUS_PORTS = {
        21,    # FTP
        23,    # Telnet
        135,   # MSRPC
        137,   # NetBIOS
        138,   # NetBIOS
        139,   # NetBIOS
        445,   # SMB
        3389,  # RDP
        5900,  # VNC
    }

    # Ports that suggest scanning
    SCAN_INDICATOR_PORTS = {1, 7, 9, 13, 17, 19, 21, 22, 23, 25}

    def __init__(
        self,
        event_bus: Optional[EventBus] = None,
        new_device_severity: ThreatSeverity = ThreatSeverity.MEDIUM,
        auto_respond_critical: bool = True
    ):
        self.event_bus = event_bus or get_bus()
        self.new_device_severity = new_device_severity
        self.auto_respond_critical = auto_respond_critical

        # Device baselines
        self.baselines: Dict[str, DeviceBaseline] = {}

        # Active threats
        self.active_threats: Dict[str, Threat] = {}

        # Threat history
        self.threat_history: List[Threat] = []

        # Callbacks
        self._on_threat_detected: List[Callable] = []
        self._on_threat_resolved: List[Callable] = []

        # Known trusted MACs
        self.trusted_macs: set = set()

        # Known trusted subnets
        self.trusted_subnets: List[str] = []

        logger.info("NetworkMonitor initialized")

    def on_threat_detected(self, callback: Callable[[Threat], None]) -> None:
        """Register callback for threat detection"""
        self._on_threat_detected.append(callback)

    def on_threat_resolved(self, callback: Callable[[Threat], None]) -> None:
        """Register callback for threat resolution"""
        self._on_threat_resolved.append(callback)

    async def _notify_threat(self, threat: Threat) -> None:
        """Notify callbacks and event bus of threat"""
        # Notify callbacks
        for callback in self._on_threat_detected:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(threat)
                else:
                    callback(threat)
            except Exception as e:
                logger.error(f"Threat callback error: {e}")

        # Publish to event bus
        try:
            await self.event_bus.publish(Event(
                type=EventType.APPROVAL_REQUIRED if threat.requires_approval else EventType.MEMORY_STORE,
                source="sentinel.network_monitor",
                data={
                    "event_type": "threat_detected",
                    "threat": threat.to_dict()
                }
            ))
        except Exception as e:
            logger.warning(f"Failed to publish threat event: {e}")

    async def _notify_resolved(self, threat: Threat) -> None:
        """Notify callbacks of threat resolution"""
        for callback in self._on_threat_resolved:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(threat)
                else:
                    callback(threat)
            except Exception as e:
                logger.error(f"Resolution callback error: {e}")

    # ==================== Device Analysis ====================

    async def analyze_device(
        self,
        device_id: str,
        mac_address: str,
        ip_address: Optional[str],
        open_ports: List[int],
        services: Dict[int, str],
        is_new: bool = False
    ) -> List[Threat]:
        """
        Analyze a device for potential threats.

        Args:
            device_id: Device identifier
            mac_address: MAC address
            ip_address: IP address
            open_ports: List of open ports
            services: Port to service mapping
            is_new: Whether this is a newly discovered device

        Returns:
            List of detected threats
        """
        threats = []

        # Check for new device
        if is_new and mac_address not in self.trusted_macs:
            threat = await self._check_new_device(
                device_id, mac_address, ip_address, open_ports
            )
            if threat:
                threats.append(threat)

        # Check for port changes
        if mac_address in self.baselines:
            port_threats = await self._check_port_changes(
                device_id, mac_address, ip_address, open_ports
            )
            threats.extend(port_threats)

        # Check for dangerous ports
        dangerous_threats = await self._check_dangerous_ports(
            device_id, mac_address, ip_address, open_ports
        )
        threats.extend(dangerous_threats)

        # Check for spoofing
        spoof_threat = await self._check_spoofing(
            device_id, mac_address, ip_address
        )
        if spoof_threat:
            threats.append(spoof_threat)

        # Update baseline
        self._update_baseline(device_id, mac_address, open_ports, services)

        # Process and store threats
        for threat in threats:
            self.active_threats[threat.id] = threat
            self.threat_history.append(threat)
            await self._notify_threat(threat)

        return threats

    async def _check_new_device(
        self,
        device_id: str,
        mac_address: str,
        ip_address: Optional[str],
        open_ports: List[int]
    ) -> Optional[Threat]:
        """Check if new device is a threat"""
        # Determine severity based on characteristics
        severity = self.new_device_severity

        # Elevate if device has dangerous ports
        if self.DANGEROUS_PORTS.intersection(set(open_ports)):
            severity = ThreatSeverity.HIGH

        # Elevate if device looks like a scanner
        if len(self.SCAN_INDICATOR_PORTS.intersection(set(open_ports))) >= 3:
            severity = ThreatSeverity.HIGH

        threat = Threat(
            id=f"threat_{uuid.uuid4().hex[:8]}",
            threat_type=ThreatType.NEW_DEVICE,
            severity=severity,
            device_id=device_id,
            device_ip=ip_address,
            device_mac=mac_address,
            description=f"New device detected: {mac_address} ({ip_address})",
            details={
                "open_ports": open_ports,
                "port_count": len(open_ports)
            },
            requires_approval=severity in [ThreatSeverity.MEDIUM, ThreatSeverity.LOW]
        )

        logger.warning(f"New device threat: {threat.description}")
        return threat

    async def _check_port_changes(
        self,
        device_id: str,
        mac_address: str,
        ip_address: Optional[str],
        open_ports: List[int]
    ) -> List[Threat]:
        """Check for unexpected port changes"""
        threats = []
        baseline = self.baselines.get(mac_address)

        if not baseline:
            return threats

        current_ports = set(open_ports)
        baseline_ports = set(baseline.normal_ports)

        # New ports opened
        new_ports = current_ports - baseline_ports
        if new_ports:
            # Check if dangerous ports were opened
            dangerous_new = self.DANGEROUS_PORTS.intersection(new_ports)

            if dangerous_new:
                threat = Threat(
                    id=f"threat_{uuid.uuid4().hex[:8]}",
                    threat_type=ThreatType.PORT_CHANGE,
                    severity=ThreatSeverity.HIGH,
                    device_id=device_id,
                    device_ip=ip_address,
                    device_mac=mac_address,
                    description=f"Dangerous ports opened on {ip_address}: {list(dangerous_new)}",
                    details={
                        "new_ports": list(new_ports),
                        "dangerous_ports": list(dangerous_new),
                        "baseline_ports": list(baseline_ports)
                    },
                    requires_approval=True
                )
                threats.append(threat)
                logger.warning(f"Dangerous port change: {threat.description}")

            elif len(new_ports) >= 5:
                threat = Threat(
                    id=f"threat_{uuid.uuid4().hex[:8]}",
                    threat_type=ThreatType.PORT_CHANGE,
                    severity=ThreatSeverity.MEDIUM,
                    device_id=device_id,
                    device_ip=ip_address,
                    device_mac=mac_address,
                    description=f"Multiple new ports opened on {ip_address}: {len(new_ports)} ports",
                    details={
                        "new_ports": list(new_ports),
                        "baseline_ports": list(baseline_ports)
                    },
                    requires_approval=True
                )
                threats.append(threat)
                logger.info(f"Port change detected: {threat.description}")

        return threats

    async def _check_dangerous_ports(
        self,
        device_id: str,
        mac_address: str,
        ip_address: Optional[str],
        open_ports: List[int]
    ) -> List[Threat]:
        """Check for dangerous open ports"""
        threats = []

        # Skip if device is trusted
        if mac_address in self.trusted_macs:
            return threats

        dangerous = self.DANGEROUS_PORTS.intersection(set(open_ports))

        # Telnet is always bad
        if 23 in dangerous:
            threat = Threat(
                id=f"threat_{uuid.uuid4().hex[:8]}",
                threat_type=ThreatType.VULNERABILITY,
                severity=ThreatSeverity.HIGH,
                device_id=device_id,
                device_ip=ip_address,
                device_mac=mac_address,
                description=f"Telnet (port 23) is open on {ip_address} - insecure protocol",
                details={
                    "port": 23,
                    "recommendation": "Disable Telnet and use SSH instead"
                },
                requires_approval=True
            )
            threats.append(threat)

        # FTP without TLS
        if 21 in dangerous:
            threat = Threat(
                id=f"threat_{uuid.uuid4().hex[:8]}",
                threat_type=ThreatType.VULNERABILITY,
                severity=ThreatSeverity.MEDIUM,
                device_id=device_id,
                device_ip=ip_address,
                device_mac=mac_address,
                description=f"FTP (port 21) is open on {ip_address} - consider SFTP",
                details={
                    "port": 21,
                    "recommendation": "Use SFTP or FTPS instead of plain FTP"
                }
            )
            threats.append(threat)

        return threats

    async def _check_spoofing(
        self,
        device_id: str,
        mac_address: str,
        ip_address: Optional[str]
    ) -> Optional[Threat]:
        """Check for MAC/IP spoofing"""
        # Look for IP collision with different MAC
        for other_mac, baseline in self.baselines.items():
            if other_mac != mac_address:
                # Check if this MAC is using same IP as another known device
                # This would require IP tracking in baseline
                pass

        # For now, basic check - will be enhanced
        return None

    def _update_baseline(
        self,
        device_id: str,
        mac_address: str,
        open_ports: List[int],
        services: Dict[int, str]
    ) -> None:
        """Update device behavioral baseline"""
        if mac_address not in self.baselines:
            self.baselines[mac_address] = DeviceBaseline(
                device_id=device_id,
                mac_address=mac_address,
                normal_ports=open_ports,
                normal_services=services
            )
        else:
            self.baselines[mac_address].update_from_observation(open_ports, services)

    # ==================== Anomaly Detection ====================

    async def detect_anomaly(
        self,
        device_id: str,
        mac_address: str,
        ip_address: Optional[str],
        current_state: Dict[str, Any]
    ) -> Optional[Threat]:
        """
        Detect behavioral anomalies.

        Args:
            device_id: Device identifier
            mac_address: MAC address
            ip_address: IP address
            current_state: Current device state

        Returns:
            Threat if anomaly detected
        """
        baseline = self.baselines.get(mac_address)

        if not baseline or baseline.observation_count < 5:
            # Not enough data for anomaly detection
            return None

        current_hour = datetime.now().hour

        # Check if device is online at unusual time
        if (baseline.typical_online_hours and
                current_hour not in baseline.typical_online_hours and
                len(baseline.typical_online_hours) >= 3):

            threat = Threat(
                id=f"threat_{uuid.uuid4().hex[:8]}",
                threat_type=ThreatType.ANOMALY,
                severity=ThreatSeverity.LOW,
                device_id=device_id,
                device_ip=ip_address,
                device_mac=mac_address,
                description=f"Device {ip_address} online at unusual hour ({current_hour}:00)",
                details={
                    "current_hour": current_hour,
                    "typical_hours": baseline.typical_online_hours
                }
            )

            self.active_threats[threat.id] = threat
            self.threat_history.append(threat)
            await self._notify_threat(threat)

            return threat

        return None

    # ==================== Threat Management ====================

    def add_trusted_mac(self, mac_address: str) -> None:
        """Add a MAC address to trusted list"""
        self.trusted_macs.add(mac_address.lower())
        logger.info(f"Added trusted MAC: {mac_address}")

    def remove_trusted_mac(self, mac_address: str) -> None:
        """Remove a MAC address from trusted list"""
        self.trusted_macs.discard(mac_address.lower())

    async def resolve_threat(
        self,
        threat_id: str,
        response: Optional[str] = None
    ) -> bool:
        """Resolve an active threat"""
        if threat_id not in self.active_threats:
            return False

        threat = self.active_threats[threat_id]
        threat.resolved_at = datetime.now()
        threat.auto_response = response

        del self.active_threats[threat_id]

        await self._notify_resolved(threat)
        logger.info(f"Resolved threat {threat_id}: {response}")

        return True

    def get_active_threats(
        self,
        severity: Optional[ThreatSeverity] = None
    ) -> List[Threat]:
        """Get active threats, optionally filtered by severity"""
        threats = list(self.active_threats.values())

        if severity:
            threats = [t for t in threats if t.severity == severity]

        return sorted(threats, key=lambda t: t.detected_at, reverse=True)

    def get_threat_history(
        self,
        hours: int = 24,
        severity: Optional[ThreatSeverity] = None
    ) -> List[Threat]:
        """Get threat history"""
        cutoff = datetime.now() - timedelta(hours=hours)
        threats = [t for t in self.threat_history if t.detected_at >= cutoff]

        if severity:
            threats = [t for t in threats if t.severity == severity]

        return sorted(threats, key=lambda t: t.detected_at, reverse=True)

    def get_threat_count_by_severity(self) -> Dict[str, int]:
        """Get count of active threats by severity"""
        counts = {s.value: 0 for s in ThreatSeverity}
        for threat in self.active_threats.values():
            counts[threat.severity.value] += 1
        return counts

    # ==================== Status ====================

    def get_status(self) -> Dict[str, Any]:
        """Get monitor status"""
        return {
            "active_threats": len(self.active_threats),
            "threat_breakdown": self.get_threat_count_by_severity(),
            "devices_baselined": len(self.baselines),
            "trusted_macs": len(self.trusted_macs),
            "history_size": len(self.threat_history)
        }
