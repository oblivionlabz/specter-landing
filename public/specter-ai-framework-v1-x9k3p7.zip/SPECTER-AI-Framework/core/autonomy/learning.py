"""
SPECTER Learning Manager

Extracts and stores patterns from successful interactions.
Enables SPECTER to learn and improve over time.

"I learn from everything." - SPECTER
"Stand up and walk. Move forward." - Edward Elric
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum, auto

logger = logging.getLogger("specter.autonomy.learning")


class PatternType(Enum):
    """Types of learnable patterns"""
    SUCCESS = auto()        # Successful approach
    FAILURE = auto()        # Failed approach (what not to do)
    USER_PREFERENCE = auto() # User preference
    CODE_PATTERN = auto()   # Code pattern
    ERROR_SOLUTION = auto() # Error -> solution mapping
    OPTIMIZATION = auto()   # Performance optimization


class InsightType(Enum):
    """Types of insights"""
    BEHAVIOR = auto()       # Behavioral insight
    TECHNICAL = auto()      # Technical insight
    USER = auto()           # User-related insight
    SYSTEM = auto()         # System insight


@dataclass
class Pattern:
    """A learned pattern"""
    id: str
    type: PatternType
    description: str
    content: Any
    confidence: float  # 0.0 to 1.0
    applications: int = 0
    success_rate: float = 1.0
    created_at: datetime = field(default_factory=datetime.now)
    last_applied: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Insight:
    """An extracted insight"""
    id: str
    type: InsightType
    title: str
    content: str
    source: str
    confidence: float
    created_at: datetime = field(default_factory=datetime.now)


class LearningManager:
    """
    Manages SPECTER's learning and pattern extraction.

    Key capabilities:
    1. Extract patterns from successful interactions
    2. Learn from errors and failures (Zenkai boost)
    3. Track user preferences
    4. Store and retrieve code patterns
    5. Map errors to solutions

    Learning cycle:
    1. Observe interaction outcome
    2. Analyze for patterns
    3. Extract insights
    4. Store in knowledge base
    5. Apply in future interactions
    """

    def __init__(
        self,
        memory_manager: Optional[Any] = None,
        persistence_path: Optional[Path] = None
    ):
        self.memory = memory_manager
        self.persistence_path = persistence_path

        # Pattern storage
        self.patterns: Dict[str, Pattern] = {}

        # Insights
        self.insights: List[Insight] = []

        # Learning queue
        self._learning_queue: asyncio.Queue = asyncio.Queue()

        # Stats
        self.patterns_learned = 0
        self.patterns_applied = 0
        self.insights_extracted = 0

        logger.info("Learning Manager initialized")

    async def learn_from_interaction(
        self,
        interaction: str,
        outcome: str,
        successful: bool,
        context: Optional[Dict[str, Any]] = None
    ) -> Optional[Pattern]:
        """
        Learn from an interaction outcome.

        Args:
            interaction: What happened
            outcome: The result
            successful: Whether it was successful
            context: Additional context

        Returns:
            Extracted pattern if any
        """
        pattern_type = PatternType.SUCCESS if successful else PatternType.FAILURE

        # Extract pattern
        pattern = await self._extract_pattern(
            interaction,
            outcome,
            pattern_type,
            context
        )

        if pattern:
            self.patterns[pattern.id] = pattern
            self.patterns_learned += 1

            # Store in memory
            if self.memory:
                await self.memory.remember(
                    content=f"Pattern: {pattern.description}\n{pattern.content}",
                    collection="verified-patterns" if successful else "regression-memory",
                    metadata={
                        "pattern_id": pattern.id,
                        "type": pattern.type.name,
                        "confidence": pattern.confidence
                    }
                )

            # Persist
            await self._persist_pattern(pattern)

            logger.info(f"Learned pattern: {pattern.description}")

        return pattern

    async def learn_from_error(
        self,
        error: str,
        context: str,
        solution: str
    ) -> Pattern:
        """
        Learn from an error and its solution.

        This is the "Zenkai boost" - learning from failures.

        Args:
            error: Error message
            context: What was happening
            solution: How it was fixed

        Returns:
            Error->solution pattern
        """
        pattern_id = f"error-{datetime.now().timestamp()}"

        pattern = Pattern(
            id=pattern_id,
            type=PatternType.ERROR_SOLUTION,
            description=f"Solution for: {error[:50]}...",
            content={
                "error": error,
                "context": context,
                "solution": solution
            },
            confidence=0.8
        )

        self.patterns[pattern_id] = pattern
        self.patterns_learned += 1

        # Store in memory
        if self.memory:
            await self.memory.remember_error(error, context, solution)

        # Persist
        await self._persist_pattern(pattern)

        logger.info(f"Learned from error: {error[:50]}...")
        return pattern

    async def learn_user_preference(
        self,
        preference: str,
        value: Any,
        context: Optional[str] = None
    ) -> Pattern:
        """
        Learn a user preference.

        Args:
            preference: What the preference is about
            value: The preferred value
            context: Context when preference was expressed

        Returns:
            Preference pattern
        """
        pattern_id = f"pref-{datetime.now().timestamp()}"

        pattern = Pattern(
            id=pattern_id,
            type=PatternType.USER_PREFERENCE,
            description=f"User prefers: {preference}",
            content={
                "preference": preference,
                "value": value,
                "context": context
            },
            confidence=0.9
        )

        self.patterns[pattern_id] = pattern
        self.patterns_learned += 1

        # Store in memory
        if self.memory:
            await self.memory.remember_user_preference(preference, value)

        # Persist
        await self._persist_pattern(pattern)

        logger.info(f"Learned preference: {preference} = {value}")
        return pattern

    async def learn_code_pattern(
        self,
        pattern_name: str,
        code: str,
        description: str,
        language: str = "python"
    ) -> Pattern:
        """
        Learn a code pattern.

        Args:
            pattern_name: Name of the pattern
            code: The code pattern
            description: Description of what it does
            language: Programming language

        Returns:
            Code pattern
        """
        pattern_id = f"code-{datetime.now().timestamp()}"

        pattern = Pattern(
            id=pattern_id,
            type=PatternType.CODE_PATTERN,
            description=f"{pattern_name}: {description}",
            content={
                "name": pattern_name,
                "code": code,
                "description": description,
                "language": language
            },
            confidence=0.85
        )

        self.patterns[pattern_id] = pattern
        self.patterns_learned += 1

        # Store in memory
        if self.memory:
            await self.memory.remember_code_pattern(code, description, language)

        # Persist
        await self._persist_pattern(pattern)

        logger.info(f"Learned code pattern: {pattern_name}")
        return pattern

    async def find_relevant_patterns(
        self,
        query: str,
        pattern_types: Optional[List[PatternType]] = None,
        limit: int = 5
    ) -> List[Pattern]:
        """
        Find patterns relevant to a query.

        Args:
            query: Search query
            pattern_types: Filter by pattern types
            limit: Max results

        Returns:
            List of relevant patterns
        """
        # For now, simple keyword matching
        # Full implementation would use semantic search

        query_lower = query.lower()
        relevant = []

        for pattern in self.patterns.values():
            # Filter by type
            if pattern_types and pattern.type not in pattern_types:
                continue

            # Check relevance
            description_lower = pattern.description.lower()
            content_str = str(pattern.content).lower()

            score = 0
            for word in query_lower.split():
                if word in description_lower:
                    score += 2
                if word in content_str:
                    score += 1

            if score > 0:
                relevant.append((score, pattern))

        # Sort by score and return top results
        relevant.sort(key=lambda x: -x[0])
        return [p for _, p in relevant[:limit]]

    async def find_error_solution(self, error: str) -> Optional[str]:
        """
        Find a solution for an error.

        Args:
            error: Error message

        Returns:
            Solution if found
        """
        # Search error patterns
        patterns = await self.find_relevant_patterns(
            error,
            pattern_types=[PatternType.ERROR_SOLUTION],
            limit=3
        )

        if patterns:
            best = patterns[0]
            best.applications += 1
            best.last_applied = datetime.now()
            return best.content.get("solution")

        # Search memory
        if self.memory:
            similar = await self.memory.find_similar_error(error, limit=1)
            if similar:
                return similar[0].content

        return None

    async def apply_pattern(
        self,
        pattern_id: str,
        success: bool = True
    ) -> None:
        """
        Record that a pattern was applied.

        Args:
            pattern_id: ID of pattern applied
            success: Whether application was successful
        """
        if pattern_id not in self.patterns:
            return

        pattern = self.patterns[pattern_id]
        pattern.applications += 1
        pattern.last_applied = datetime.now()
        self.patterns_applied += 1

        # Update success rate
        old_rate = pattern.success_rate
        total = pattern.applications
        successes = int(old_rate * (total - 1)) + (1 if success else 0)
        pattern.success_rate = successes / total

        # Adjust confidence based on success rate
        if total >= 5:
            pattern.confidence = min(1.0, pattern.success_rate * 1.1)

        logger.debug(f"Pattern {pattern_id} applied, success rate: {pattern.success_rate:.2f}")

    async def extract_insights(
        self,
        content: str,
        source: str
    ) -> List[Insight]:
        """
        Extract insights from content.

        Args:
            content: Content to analyze
            source: Where the content came from

        Returns:
            List of extracted insights
        """
        insights = []

        # Simple rule-based extraction
        # Full implementation would use LLM

        content_lower = content.lower()

        # Look for patterns
        if "always" in content_lower or "never" in content_lower:
            insights.append(Insight(
                id=f"insight-{datetime.now().timestamp()}",
                type=InsightType.BEHAVIOR,
                title="Behavioral pattern detected",
                content=content[:200],
                source=source,
                confidence=0.7
            ))

        if "error" in content_lower and "fix" in content_lower:
            insights.append(Insight(
                id=f"insight-{datetime.now().timestamp()}",
                type=InsightType.TECHNICAL,
                title="Error solution pattern",
                content=content[:200],
                source=source,
                confidence=0.8
            ))

        if "prefer" in content_lower or "like" in content_lower:
            insights.append(Insight(
                id=f"insight-{datetime.now().timestamp()}",
                type=InsightType.USER,
                title="User preference detected",
                content=content[:200],
                source=source,
                confidence=0.6
            ))

        for insight in insights:
            self.insights.append(insight)
            self.insights_extracted += 1

        return insights

    async def _extract_pattern(
        self,
        interaction: str,
        outcome: str,
        pattern_type: PatternType,
        context: Optional[Dict[str, Any]]
    ) -> Optional[Pattern]:
        """Extract a pattern from an interaction"""

        # Simple extraction logic
        # Full implementation would use LLM

        if len(interaction) < 50:
            return None

        pattern_id = f"pattern-{datetime.now().timestamp()}"

        return Pattern(
            id=pattern_id,
            type=pattern_type,
            description=f"Pattern from: {interaction[:50]}...",
            content={
                "interaction": interaction,
                "outcome": outcome,
                "context": context
            },
            confidence=0.7 if pattern_type == PatternType.SUCCESS else 0.6
        )

    async def _persist_pattern(self, pattern: Pattern) -> None:
        """Persist pattern to disk"""
        if not self.persistence_path:
            return

        self.persistence_path.mkdir(parents=True, exist_ok=True)
        pattern_path = self.persistence_path / f"{pattern.id}.json"

        try:
            with open(pattern_path, 'w') as f:
                json.dump({
                    "id": pattern.id,
                    "type": pattern.type.name,
                    "description": pattern.description,
                    "content": pattern.content,
                    "confidence": pattern.confidence,
                    "applications": pattern.applications,
                    "success_rate": pattern.success_rate,
                    "created_at": pattern.created_at.isoformat(),
                    "last_applied": pattern.last_applied.isoformat() if pattern.last_applied else None,
                    "metadata": pattern.metadata
                }, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to persist pattern: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Get learning statistics"""
        return {
            "patterns_learned": self.patterns_learned,
            "patterns_applied": self.patterns_applied,
            "patterns_stored": len(self.patterns),
            "insights_extracted": self.insights_extracted,
            "avg_pattern_success_rate": (
                sum(p.success_rate for p in self.patterns.values()) / len(self.patterns)
                if self.patterns else 0
            )
        }
