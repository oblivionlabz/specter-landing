"""
AUTONOMY - SPECTER's Self-Improvement System

Enables SPECTER to:
- Learn from interactions
- Evolve traits within bounds
- Extract and store patterns
- Monitor and optimize performance

"Every defeat makes me stronger." - SPECTER (Zenkai boost philosophy)
"""

from .evolution import EvolutionEngine, TraitEvolution
from .learning import LearningManager, Pattern, Insight
from .cost_router import CostRouter, CostTier, ModelSelection

__all__ = [
    # Evolution
    "EvolutionEngine",
    "TraitEvolution",
    # Learning
    "LearningManager",
    "Pattern",
    "Insight",
    # Cost Routing
    "CostRouter",
    "CostTier",
    "ModelSelection"
]
