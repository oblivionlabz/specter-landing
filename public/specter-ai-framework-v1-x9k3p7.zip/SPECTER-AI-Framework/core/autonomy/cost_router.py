"""
SPECTER Cost Router (FrugalGPT Implementation)

Implements economic routing to minimize costs while maintaining quality.
Uses a tiered approach: local first, escalate when needed.

"Nothing is free. Every action has a cost." - Edward Elric (Equivalent Exchange)
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("specter.autonomy.cost_router")


class ModelTier(Enum):
    """Model tiers by cost"""
    LOCAL_FAST = 1      # LocalAI qwen2.5-coder-7b ($0)
    LOCAL_MEDIUM = 2    # LocalAI deepseek-coder-33b ($0)
    LOCAL_FULL = 3      # SPECTER Qwen2.5-32B ($0)
    CLOUD_HAIKU = 4     # Claude Haiku ($0.25/1M)
    CLOUD_SONNET = 5    # Claude Sonnet ($3/1M)
    CLOUD_OPUS = 6      # Claude Opus ($15/1M)


@dataclass
class CostTier:
    """Configuration for a cost tier"""
    tier: ModelTier
    model_name: str
    cost_per_1m_tokens: float
    quality_score: float  # 0.0 to 1.0
    avg_latency_ms: int
    endpoint: Optional[str] = None


@dataclass
class ModelSelection:
    """Result of model selection"""
    tier: CostTier
    reason: str
    estimated_cost: float
    quality_requirement: float


@dataclass
class CostTracker:
    """Tracks costs over time"""
    session_cost: float = 0.0
    daily_cost: float = 0.0
    monthly_cost: float = 0.0
    requests_today: int = 0
    tokens_today: int = 0
    last_reset: datetime = field(default_factory=datetime.now)


class CostRouter:
    """
    Economic routing for LLM requests.

    FrugalGPT principles:
    1. Try local first (free)
    2. Escalate only when quality insufficient
    3. Track and limit costs
    4. Cache responses where possible
    5. Quality-gated escalation

    Cost tiers (cheapest first):
    1. LocalAI qwen2.5-coder-7b: $0, 70% quality
    2. LocalAI deepseek-coder-33b: $0, 80% quality
    3. SPECTER Qwen2.5-32B: $0, 90% quality
    4. Claude Haiku: $0.25/1M, 85% quality
    5. Claude Sonnet: $3/1M, 95% quality
    6. Claude Opus: $15/1M, 99% quality

    Limits:
    - $0.50 per task
    - $5.00 per session
    - $25.00 per day
    """

    # Default cost tiers
    TIERS = [
        CostTier(
            tier=ModelTier.LOCAL_FAST,
            model_name="qwen2.5-coder-7b",
            cost_per_1m_tokens=0.0,
            quality_score=0.70,
            avg_latency_ms=500,
            endpoint="http://localhost:8080"
        ),
        CostTier(
            tier=ModelTier.LOCAL_MEDIUM,
            model_name="deepseek-coder-33b",
            cost_per_1m_tokens=0.0,
            quality_score=0.80,
            avg_latency_ms=1500,
            endpoint="http://localhost:8080"
        ),
        CostTier(
            tier=ModelTier.LOCAL_FULL,
            model_name="qwen2.5-coder-32b",
            cost_per_1m_tokens=0.0,
            quality_score=0.90,
            avg_latency_ms=3000,
            endpoint="local"  # llama-cpp direct
        ),
        CostTier(
            tier=ModelTier.CLOUD_HAIKU,
            model_name="claude-3-haiku",
            cost_per_1m_tokens=0.25,
            quality_score=0.85,
            avg_latency_ms=800
        ),
        CostTier(
            tier=ModelTier.CLOUD_SONNET,
            model_name="claude-3-5-sonnet",
            cost_per_1m_tokens=3.0,
            quality_score=0.95,
            avg_latency_ms=1200
        ),
        CostTier(
            tier=ModelTier.CLOUD_OPUS,
            model_name="claude-opus-4-5",
            cost_per_1m_tokens=15.0,
            quality_score=0.99,
            avg_latency_ms=2000
        )
    ]

    # Cost limits
    TASK_LIMIT = 0.50
    SESSION_LIMIT = 5.00
    DAILY_LIMIT = 25.00

    def __init__(self):
        self.tiers = {t.tier: t for t in self.TIERS}
        self.tracker = CostTracker()

        # Response cache
        self._cache: Dict[str, Tuple[str, float]] = {}  # query -> (response, timestamp)
        self._cache_ttl = 3600  # 1 hour

        # Quality tracking per tier
        self._tier_quality_history: Dict[ModelTier, List[float]] = {
            t: [] for t in ModelTier
        }

        logger.info("Cost Router initialized")

    def select_model(
        self,
        query: str,
        min_quality: float = 0.7,
        max_cost: Optional[float] = None,
        prefer_local: bool = True
    ) -> ModelSelection:
        """
        Select the optimal model for a query.

        Args:
            query: The query to process
            min_quality: Minimum required quality (0.0 to 1.0)
            max_cost: Maximum cost for this request
            prefer_local: Prefer local models even if slower

        Returns:
            ModelSelection with chosen tier and reasoning
        """
        self._reset_daily_if_needed()

        # Check cache
        if self._check_cache(query):
            return ModelSelection(
                tier=self.tiers[ModelTier.LOCAL_FAST],  # Cache hit
                reason="Cached response available",
                estimated_cost=0.0,
                quality_requirement=min_quality
            )

        # Estimate token count (rough: 4 chars per token)
        estimated_tokens = len(query) / 4 + 500  # Add response estimate

        # Check cost limits
        max_cost = max_cost or self.TASK_LIMIT
        remaining_daily = self.DAILY_LIMIT - self.tracker.daily_cost
        remaining_session = self.SESSION_LIMIT - self.tracker.session_cost

        effective_max = min(max_cost, remaining_daily, remaining_session)

        # Find suitable tier
        selected_tier = None
        reason = ""

        # Sort tiers by cost (cheapest first) or quality (if not prefer_local)
        sorted_tiers = sorted(
            self.TIERS,
            key=lambda t: (t.cost_per_1m_tokens if prefer_local else -t.quality_score)
        )

        for tier in sorted_tiers:
            # Check quality requirement
            if tier.quality_score < min_quality:
                continue

            # Check cost limit
            estimated_cost = (estimated_tokens / 1_000_000) * tier.cost_per_1m_tokens
            if estimated_cost > effective_max:
                continue

            # Check if tier is available
            if tier.endpoint and not self._is_endpoint_available(tier.endpoint):
                continue

            selected_tier = tier
            reason = f"Selected {tier.model_name}: quality {tier.quality_score:.0%}, cost ${estimated_cost:.4f}"
            break

        if not selected_tier:
            # Fallback to best local if all fail
            selected_tier = self.tiers[ModelTier.LOCAL_FAST]
            reason = "Fallback to local model (cost/quality constraints)"

        estimated_cost = (estimated_tokens / 1_000_000) * selected_tier.cost_per_1m_tokens

        return ModelSelection(
            tier=selected_tier,
            reason=reason,
            estimated_cost=estimated_cost,
            quality_requirement=min_quality
        )

    def escalate(
        self,
        current_tier: ModelTier,
        quality_score: float,
        required_quality: float
    ) -> Optional[CostTier]:
        """
        Escalate to a higher tier if quality insufficient.

        Args:
            current_tier: Current model tier
            quality_score: Achieved quality
            required_quality: Required quality

        Returns:
            Next tier if escalation needed, None if already at max
        """
        if quality_score >= required_quality:
            return None  # No escalation needed

        # Find next higher tier
        current_value = current_tier.value
        for tier_enum in ModelTier:
            if tier_enum.value > current_value:
                tier = self.tiers[tier_enum]
                if tier.quality_score >= required_quality:
                    logger.info(f"Escalating from {current_tier.name} to {tier_enum.name}")
                    return tier

        return None  # At maximum tier

    def record_usage(
        self,
        tier: ModelTier,
        tokens_used: int,
        quality_achieved: Optional[float] = None
    ) -> float:
        """
        Record usage for cost tracking.

        Args:
            tier: Tier used
            tokens_used: Number of tokens used
            quality_achieved: Achieved quality (optional)

        Returns:
            Cost incurred
        """
        tier_config = self.tiers[tier]
        cost = (tokens_used / 1_000_000) * tier_config.cost_per_1m_tokens

        self.tracker.session_cost += cost
        self.tracker.daily_cost += cost
        self.tracker.monthly_cost += cost
        self.tracker.requests_today += 1
        self.tracker.tokens_today += tokens_used

        if quality_achieved is not None:
            self._tier_quality_history[tier].append(quality_achieved)
            # Keep last 100 samples
            if len(self._tier_quality_history[tier]) > 100:
                self._tier_quality_history[tier].pop(0)

        return cost

    def check_limits(self) -> Dict[str, bool]:
        """Check if cost limits are exceeded"""
        return {
            "session_exceeded": self.tracker.session_cost >= self.SESSION_LIMIT,
            "daily_exceeded": self.tracker.daily_cost >= self.DAILY_LIMIT,
            "warning_level": self.tracker.daily_cost >= self.DAILY_LIMIT * 0.8
        }

    def get_tier_quality(self, tier: ModelTier) -> float:
        """Get observed quality for a tier"""
        history = self._tier_quality_history.get(tier, [])
        if not history:
            return self.tiers[tier].quality_score
        return sum(history) / len(history)

    def _check_cache(self, query: str) -> bool:
        """Check if query is in cache"""
        if query in self._cache:
            _, timestamp = self._cache[query]
            if datetime.now().timestamp() - timestamp < self._cache_ttl:
                return True
        return False

    def cache_response(self, query: str, response: str) -> None:
        """Cache a response"""
        self._cache[query] = (response, datetime.now().timestamp())

        # Cleanup old entries
        now = datetime.now().timestamp()
        expired = [k for k, (_, t) in self._cache.items() if now - t > self._cache_ttl]
        for k in expired:
            del self._cache[k]

    def get_cached_response(self, query: str) -> Optional[str]:
        """Get cached response if available"""
        if self._check_cache(query):
            return self._cache[query][0]
        return None

    def _is_endpoint_available(self, endpoint: str) -> bool:
        """Check if an endpoint is available"""
        # For now, assume local endpoints are always available
        if endpoint == "local" or endpoint.startswith("http://localhost"):
            return True
        return True  # Optimistic for cloud

    def _reset_daily_if_needed(self) -> None:
        """Reset daily tracking if new day"""
        now = datetime.now()
        if (now - self.tracker.last_reset).days >= 1:
            logger.info(
                f"Daily reset: spent ${self.tracker.daily_cost:.2f}, "
                f"{self.tracker.requests_today} requests, "
                f"{self.tracker.tokens_today} tokens"
            )
            self.tracker.daily_cost = 0.0
            self.tracker.requests_today = 0
            self.tracker.tokens_today = 0
            self.tracker.last_reset = now

    def get_stats(self) -> Dict[str, Any]:
        """Get router statistics"""
        return {
            "session_cost": self.tracker.session_cost,
            "daily_cost": self.tracker.daily_cost,
            "monthly_cost": self.tracker.monthly_cost,
            "requests_today": self.tracker.requests_today,
            "tokens_today": self.tracker.tokens_today,
            "cache_size": len(self._cache),
            "limits": self.check_limits(),
            "tier_quality": {
                t.name: self.get_tier_quality(t)
                for t in ModelTier
            }
        }

    def reset_session(self) -> None:
        """Reset session cost tracking"""
        self.tracker.session_cost = 0.0
