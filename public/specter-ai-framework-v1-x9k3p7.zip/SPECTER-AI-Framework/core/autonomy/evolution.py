"""
SPECTER Evolution Engine

Manages the evolution of SPECTER's mutable traits based on feedback and performance.
Respects immutable core values while allowing personality adaptation.

"Every failure is a Zenkai boost." - SPECTER
"I will not be surpassed!" - Vegeta
"""

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from enum import Enum, auto

logger = logging.getLogger("specter.autonomy.evolution")


class EvolutionTrigger(Enum):
    """What triggers trait evolution"""
    FEEDBACK = auto()         # User feedback
    PERFORMANCE = auto()      # Performance metrics
    SCHEDULED = auto()        # Weekly/daily evolution
    MANUAL = auto()           # Explicit request
    LEARNING = auto()         # Pattern learning


@dataclass
class TraitEvolution:
    """Record of a trait evolution"""
    trait_name: str
    old_value: float
    new_value: float
    trigger: EvolutionTrigger
    reason: str
    approved: bool = True
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class EvolutionConstraints:
    """Constraints on trait evolution"""
    min_value: float = 0.0
    max_value: float = 1.0
    max_drift_per_day: float = 0.1
    max_drift_per_week: float = 0.2
    requires_approval: bool = False


class EvolutionEngine:
    """
    Manages SPECTER's trait evolution.

    Key principles:
    1. Core values are IMMUTABLE (protection, excellence, honesty, etc.)
    2. Traits can evolve within bounds
    3. Some traits require approval to change
    4. Evolution is gradual (max drift limits)
    5. All changes are logged and reversible

    Traits that can evolve:
    - confidence (0.7-1.0)
    - wit (0.3-0.8)
    - directness (0.6-1.0)
    - strategic (0.5-1.0)
    - pride (0.7-1.0)
    - intensity (0.4-1.0)
    - playfulness (0.2-0.6)
    """

    # Trait constraints
    TRAIT_CONSTRAINTS = {
        "confidence": EvolutionConstraints(min_value=0.7, max_value=1.0),
        "wit": EvolutionConstraints(min_value=0.3, max_value=0.8),
        "directness": EvolutionConstraints(min_value=0.6, max_value=1.0),
        "strategic": EvolutionConstraints(min_value=0.5, max_value=1.0),
        "pride": EvolutionConstraints(min_value=0.7, max_value=1.0, requires_approval=True),
        "intensity": EvolutionConstraints(min_value=0.4, max_value=1.0),
        "playfulness": EvolutionConstraints(min_value=0.2, max_value=0.6),
        "analytical": EvolutionConstraints(min_value=0.5, max_value=1.0),
        "protective": EvolutionConstraints(min_value=0.8, max_value=1.0, requires_approval=True)
    }

    def __init__(
        self,
        trait_system: Optional[Any] = None,
        persistence_path: Optional[Path] = None
    ):
        self.trait_system = trait_system
        self.persistence_path = persistence_path

        # Evolution history
        self.evolution_history: List[TraitEvolution] = []

        # Pending approvals
        self.pending_approvals: Dict[str, TraitEvolution] = {}

        # Daily tracking
        self._daily_drift: Dict[str, float] = {}
        self._last_reset: datetime = datetime.now()

        # Callbacks
        self.on_evolution: Optional[Callable[[TraitEvolution], None]] = None
        self.on_approval_required: Optional[Callable[[TraitEvolution], None]] = None

        # Stats
        self.evolutions_applied = 0
        self.evolutions_rejected = 0

        logger.info("Evolution Engine initialized")

    async def evolve_trait(
        self,
        trait_name: str,
        adjustment: float,
        trigger: EvolutionTrigger,
        reason: str
    ) -> Tuple[bool, str]:
        """
        Evolve a trait by the specified adjustment.

        Args:
            trait_name: Name of trait to evolve
            adjustment: Amount to adjust (-1.0 to 1.0)
            trigger: What triggered this evolution
            reason: Human-readable reason

        Returns:
            (success, message)
        """
        # Check if trait exists and can evolve
        if trait_name not in self.TRAIT_CONSTRAINTS:
            return False, f"Unknown or immutable trait: {trait_name}"

        constraints = self.TRAIT_CONSTRAINTS[trait_name]

        # Get current value
        current_value = await self._get_trait_value(trait_name)
        if current_value is None:
            return False, f"Could not get current value for {trait_name}"

        # Calculate new value
        new_value = current_value + adjustment

        # Apply constraints
        new_value = max(constraints.min_value, min(constraints.max_value, new_value))

        # Check drift limits
        self._reset_daily_drift_if_needed()
        current_drift = self._daily_drift.get(trait_name, 0.0)

        if abs(current_drift + adjustment) > constraints.max_drift_per_day:
            return False, (
                f"Daily drift limit exceeded for {trait_name}. "
                f"Current: {current_drift:.2f}, Max: {constraints.max_drift_per_day:.2f}"
            )

        # Create evolution record
        evolution = TraitEvolution(
            trait_name=trait_name,
            old_value=current_value,
            new_value=new_value,
            trigger=trigger,
            reason=reason,
            approved=not constraints.requires_approval
        )

        # Check if approval required
        if constraints.requires_approval:
            self.pending_approvals[trait_name] = evolution
            if self.on_approval_required:
                self.on_approval_required(evolution)
            return True, f"Evolution pending approval: {trait_name} {current_value:.2f} -> {new_value:.2f}"

        # Apply evolution
        success = await self._apply_evolution(evolution)
        if success:
            return True, f"Evolved {trait_name}: {current_value:.2f} -> {new_value:.2f}"
        else:
            return False, f"Failed to apply evolution for {trait_name}"

    async def approve_evolution(self, trait_name: str) -> Tuple[bool, str]:
        """Approve a pending evolution"""
        if trait_name not in self.pending_approvals:
            return False, f"No pending approval for {trait_name}"

        evolution = self.pending_approvals.pop(trait_name)
        evolution.approved = True

        success = await self._apply_evolution(evolution)
        if success:
            return True, f"Approved and applied: {trait_name}"
        else:
            return False, f"Failed to apply approved evolution for {trait_name}"

    async def reject_evolution(self, trait_name: str) -> Tuple[bool, str]:
        """Reject a pending evolution"""
        if trait_name not in self.pending_approvals:
            return False, f"No pending approval for {trait_name}"

        evolution = self.pending_approvals.pop(trait_name)
        evolution.approved = False
        self.evolution_history.append(evolution)
        self.evolutions_rejected += 1

        return True, f"Rejected evolution for {trait_name}"

    async def _apply_evolution(self, evolution: TraitEvolution) -> bool:
        """Apply an approved evolution"""
        try:
            # Update trait system
            if self.trait_system:
                self.trait_system.adjust(
                    evolution.trait_name,
                    evolution.new_value - evolution.old_value,
                    evolution.reason
                )

            # Update drift tracking
            drift = evolution.new_value - evolution.old_value
            self._daily_drift[evolution.trait_name] = (
                self._daily_drift.get(evolution.trait_name, 0.0) + drift
            )

            # Record history
            self.evolution_history.append(evolution)
            self.evolutions_applied += 1

            # Callback
            if self.on_evolution:
                self.on_evolution(evolution)

            # Persist
            await self._persist_evolution(evolution)

            logger.info(
                f"Evolution applied: {evolution.trait_name} "
                f"{evolution.old_value:.2f} -> {evolution.new_value:.2f}"
            )
            return True

        except Exception as e:
            logger.error(f"Evolution failed: {e}")
            return False

    async def weekly_evolution(self) -> List[TraitEvolution]:
        """
        Perform weekly trait evolution based on feedback and performance.

        This is the main autonomous evolution cycle that:
        1. Analyzes which traits led to positive outcomes
        2. Adjusts traits within bounds
        3. Respects approval requirements

        Returns:
            List of evolutions applied
        """
        logger.info("Starting weekly evolution cycle...")

        evolutions = []

        # Analyze trait effectiveness
        analytics = await self._analyze_trait_effectiveness()

        for trait_name, recommendation in analytics.items():
            if trait_name in self.TRAIT_CONSTRAINTS:
                # Apply recommended adjustment (capped at weekly max)
                constraints = self.TRAIT_CONSTRAINTS[trait_name]
                adjustment = max(-constraints.max_drift_per_week,
                               min(constraints.max_drift_per_week, recommendation))

                if abs(adjustment) > 0.01:  # Only apply meaningful changes
                    success, message = await self.evolve_trait(
                        trait_name,
                        adjustment,
                        EvolutionTrigger.SCHEDULED,
                        f"Weekly evolution: {message}"
                    )

                    if success and trait_name not in self.pending_approvals:
                        evolutions.append(self.evolution_history[-1])

        logger.info(f"Weekly evolution complete: {len(evolutions)} traits evolved")
        return evolutions

    async def _analyze_trait_effectiveness(self) -> Dict[str, float]:
        """
        Analyze which trait levels led to positive outcomes.

        Returns:
            Dict mapping trait names to recommended adjustments
        """
        # Placeholder - full implementation would analyze:
        # - User feedback patterns
        # - Task success rates
        # - Interaction quality scores

        # For now, return slight adjustments based on general rules
        return {
            "confidence": 0.01,  # Maintain high confidence
            "wit": 0.0,          # Keep wit balanced
            "directness": 0.02,  # Trending toward more direct
        }

    async def _get_trait_value(self, trait_name: str) -> Optional[float]:
        """Get current trait value"""
        if self.trait_system:
            return self.trait_system.get_value(trait_name)
        return 0.5  # Default

    def _reset_daily_drift_if_needed(self) -> None:
        """Reset daily drift tracking if new day"""
        now = datetime.now()
        if (now - self._last_reset).days >= 1:
            self._daily_drift = {}
            self._last_reset = now

    async def _persist_evolution(self, evolution: TraitEvolution) -> None:
        """Persist evolution to disk"""
        if not self.persistence_path:
            return

        self.persistence_path.mkdir(parents=True, exist_ok=True)
        history_path = self.persistence_path / "evolution_history.json"

        try:
            if history_path.exists():
                with open(history_path) as f:
                    history = json.load(f)
            else:
                history = []

            history.append({
                "trait_name": evolution.trait_name,
                "old_value": evolution.old_value,
                "new_value": evolution.new_value,
                "trigger": evolution.trigger.name,
                "reason": evolution.reason,
                "approved": evolution.approved,
                "timestamp": evolution.timestamp.isoformat()
            })

            with open(history_path, 'w') as f:
                json.dump(history, f, indent=2)

        except Exception as e:
            logger.warning(f"Failed to persist evolution: {e}")

    def get_pending_approvals(self) -> List[TraitEvolution]:
        """Get all pending approval requests"""
        return list(self.pending_approvals.values())

    def get_evolution_history(
        self,
        trait_name: Optional[str] = None,
        limit: int = 50
    ) -> List[TraitEvolution]:
        """Get evolution history"""
        history = self.evolution_history

        if trait_name:
            history = [e for e in history if e.trait_name == trait_name]

        return history[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """Get evolution statistics"""
        return {
            "evolutions_applied": self.evolutions_applied,
            "evolutions_rejected": self.evolutions_rejected,
            "pending_approvals": len(self.pending_approvals),
            "history_size": len(self.evolution_history),
            "daily_drift": dict(self._daily_drift)
        }
