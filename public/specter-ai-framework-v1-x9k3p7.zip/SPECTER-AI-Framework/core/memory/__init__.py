"""
MEMORY - SPECTER's Long-term Memory

Vector storage and retrieval using Qdrant.
Includes Agentic RAG for intelligent context retrieval.

"I remember everything. I learn from everything." - SPECTER
"""

from .vector_store import VectorStore, MemoryEntry
from .embeddings import EmbeddingEngine
from .memory_manager import MemoryManager
from .rag_manager import (
    AgenticRAGManager,
    RAGStrategy,
    RAGContext,
    RetrievalResult,
    GradedContext,
    create_rag_manager
)

__all__ = [
    # Core Memory
    "VectorStore",
    "MemoryEntry",
    "EmbeddingEngine",
    "MemoryManager",
    # Agentic RAG
    "AgenticRAGManager",
    "RAGStrategy",
    "RAGContext",
    "RetrievalResult",
    "GradedContext",
    "create_rag_manager"
]
