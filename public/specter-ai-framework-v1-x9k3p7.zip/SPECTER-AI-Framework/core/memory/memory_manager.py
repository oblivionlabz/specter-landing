"""
MEMORY Manager

Unified memory management combining embeddings and vector storage.
"""

from pathlib import Path
from typing import List, Optional, Dict, Any
import logging
import asyncio
from datetime import datetime
import json

from .embeddings import EmbeddingEngine
from .vector_store import VectorStore, MemoryEntry, SearchResult

logger = logging.getLogger("specter.memory.manager")


class MemoryManager:
    """
    Unified memory management for SPECTER.

    Provides:
    - Semantic memory storage and retrieval
    - Conversation history
    - Knowledge base
    - Episode memory (significant events)
    - Learning from interactions
    """

    def __init__(
        self,
        qdrant_host: str = "localhost",
        qdrant_port: int = 6333,
        storage_path: Optional[Path] = None,
        embedding_model: str = "all-MiniLM-L6-v2"
    ):
        self.embeddings = EmbeddingEngine(model_name=embedding_model)
        self.vector_store = VectorStore(
            host=qdrant_host,
            port=qdrant_port,
            path=storage_path
        )

        self.initialized = False

        # Conversation buffer (recent context)
        self.conversation_buffer: List[Dict] = []
        self.buffer_max_size = 50

        # Stats
        self.memories_stored = 0
        self.memories_retrieved = 0

        logger.info("Memory manager created")

    async def initialize(self) -> bool:
        """Initialize memory components"""
        if self.initialized:
            return True

        logger.info("Initializing memory system...")

        embed_ok = await self.embeddings.initialize()
        if embed_ok:
            # Update vector store with correct dimension
            self.vector_store.embedding_dim = self.embeddings.get_dimension()
            logger.info(f"  [+] Embeddings initialized (dim={self.embeddings.embedding_dim})")
        else:
            logger.warning("  [!] Embeddings failed")

        store_ok = await self.vector_store.initialize()
        if store_ok:
            logger.info("  [+] Vector store initialized")
        else:
            logger.warning("  [!] Vector store failed")

        self.initialized = embed_ok and store_ok
        return self.initialized

    async def remember(
        self,
        content: str,
        collection: str = "knowledge",
        metadata: Optional[Dict] = None
    ) -> bool:
        """
        Store a memory.

        Args:
            content: Text content to remember
            collection: Which collection to store in
            metadata: Optional metadata

        Returns:
            True if successful
        """
        if not self.initialized:
            await self.initialize()

        # Generate embedding
        embedding = await self.embeddings.embed(content)
        if embedding is None:
            return False

        # Create entry
        entry = MemoryEntry(
            content=content,
            embedding=embedding,
            collection=collection,
            metadata=metadata or {}
        )

        # Store
        success = await self.vector_store.store(entry)
        if success:
            self.memories_stored += 1

        return success

    async def recall(
        self,
        query: str,
        collection: str = "knowledge",
        limit: int = 5,
        min_score: float = 0.5
    ) -> List[MemoryEntry]:
        """
        Recall relevant memories.

        Args:
            query: Search query
            collection: Collection to search
            limit: Max results
            min_score: Minimum similarity score

        Returns:
            List of matching memories
        """
        if not self.initialized:
            await self.initialize()

        # Generate query embedding
        embedding = await self.embeddings.embed(query)
        if embedding is None:
            return []

        # Search
        result = await self.vector_store.search(
            query_embedding=embedding,
            collection=collection,
            limit=limit,
            score_threshold=min_score
        )

        self.memories_retrieved += len(result.entries)
        return result.entries

    async def recall_all(
        self,
        query: str,
        limit_per_collection: int = 3,
        min_score: float = 0.5
    ) -> Dict[str, List[MemoryEntry]]:
        """
        Recall from all collections.

        Returns:
            Dict mapping collection names to entries
        """
        results = {}

        collections = await self.vector_store.get_collections()
        for collection in collections:
            entries = await self.recall(
                query=query,
                collection=collection,
                limit=limit_per_collection,
                min_score=min_score
            )
            if entries:
                results[collection] = entries

        return results

    async def add_conversation(
        self,
        role: str,
        content: str,
        metadata: Optional[Dict] = None
    ) -> None:
        """
        Add to conversation history.

        Args:
            role: "user" or "assistant"
            content: Message content
            metadata: Optional metadata
        """
        entry = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }

        self.conversation_buffer.append(entry)

        # Trim buffer
        if len(self.conversation_buffer) > self.buffer_max_size:
            # Store overflow to long-term memory
            overflow = self.conversation_buffer[:10]
            self.conversation_buffer = self.conversation_buffer[10:]

            # Combine and store
            combined = "\n".join([
                f"{e['role']}: {e['content']}" for e in overflow
            ])
            await self.remember(
                content=combined,
                collection="conversations",
                metadata={"type": "conversation_chunk"}
            )

    def get_recent_context(self, count: int = 10) -> str:
        """Get recent conversation context as text"""
        recent = self.conversation_buffer[-count:]
        return "\n".join([
            f"{e['role'].upper()}: {e['content']}"
            for e in recent
        ])

    async def learn_from_interaction(
        self,
        interaction: str,
        outcome: str,
        category: str = "general"
    ) -> None:
        """
        Learn from an interaction outcome.

        Args:
            interaction: What happened
            outcome: Whether it was successful/positive
            category: Type of interaction
        """
        await self.remember(
            content=f"Interaction: {interaction}\nOutcome: {outcome}",
            collection="episodes",
            metadata={
                "category": category,
                "outcome": outcome
            }
        )

    async def remember_error(
        self,
        error: str,
        context: str,
        solution: Optional[str] = None
    ) -> None:
        """
        Remember an error for future reference.

        Args:
            error: Error message
            context: What was happening
            solution: How it was fixed (if known)
        """
        content = f"Error: {error}\nContext: {context}"
        if solution:
            content += f"\nSolution: {solution}"

        await self.remember(
            content=content,
            collection="errors",
            metadata={
                "has_solution": solution is not None
            }
        )

    async def remember_code_pattern(
        self,
        pattern: str,
        description: str,
        language: str = "python"
    ) -> None:
        """Remember a code pattern"""
        await self.remember(
            content=f"Pattern: {description}\n```{language}\n{pattern}\n```",
            collection="code_patterns",
            metadata={"language": language}
        )

    async def remember_user_preference(
        self,
        preference: str,
        value: Any
    ) -> None:
        """Remember a user preference"""
        await self.remember(
            content=f"User preference: {preference} = {value}",
            collection="user_preferences",
            metadata={"preference": preference, "value": str(value)}
        )

    async def find_similar_error(
        self,
        error: str,
        limit: int = 3
    ) -> List[MemoryEntry]:
        """Find similar errors from memory"""
        return await self.recall(
            query=error,
            collection="errors",
            limit=limit
        )

    async def get_context_for_query(
        self,
        query: str,
        include_conversation: bool = True,
        include_knowledge: bool = True
    ) -> str:
        """
        Build context for a query from memory.

        Returns:
            Combined context string
        """
        context_parts = []

        # Recent conversation
        if include_conversation:
            recent = self.get_recent_context(5)
            if recent:
                context_parts.append(f"RECENT CONVERSATION:\n{recent}")

        # Relevant knowledge
        if include_knowledge:
            memories = await self.recall_all(query, limit_per_collection=2)
            if memories:
                for collection, entries in memories.items():
                    if entries:
                        context_parts.append(
                            f"RELEVANT {collection.upper()}:\n" +
                            "\n".join(e.content[:200] for e in entries[:2])
                        )

        return "\n\n".join(context_parts)

    async def consolidate(self) -> None:
        """
        Consolidate memories (daily maintenance).

        - Deduplicate similar entries
        - Summarize old conversations
        - Archive rarely accessed memories
        """
        logger.info("Running memory consolidation...")
        # TODO: Implement consolidation logic
        logger.info("Memory consolidation complete")

    def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics"""
        return {
            "initialized": self.initialized,
            "memories_stored": self.memories_stored,
            "memories_retrieved": self.memories_retrieved,
            "conversation_buffer_size": len(self.conversation_buffer),
            "embedding_dim": self.embeddings.embedding_dim if self.embeddings else 0
        }

    async def export_collection(
        self,
        collection: str,
        path: Path
    ) -> bool:
        """Export a collection to JSON"""
        # TODO: Implement export
        return False

    async def import_collection(
        self,
        path: Path,
        collection: str
    ) -> bool:
        """Import a collection from JSON"""
        # TODO: Implement import
        return False

    async def shutdown(self) -> None:
        """Shutdown memory system"""
        logger.info("Shutting down memory system...")

        # Flush conversation buffer to storage
        if self.conversation_buffer:
            combined = "\n".join([
                f"{e['role']}: {e['content']}"
                for e in self.conversation_buffer
            ])
            await self.remember(
                content=combined,
                collection="conversations",
                metadata={"type": "session_end"}
            )

        await self.embeddings.shutdown()
        await self.vector_store.shutdown()

        self.initialized = False
        logger.info("Memory system shutdown complete")
