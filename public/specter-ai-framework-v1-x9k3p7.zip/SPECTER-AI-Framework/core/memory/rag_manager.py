"""
SPECTER Agentic RAG Manager

Implements intelligent retrieval-augmented generation with multiple strategies:
- Simple RAG (basic retrieval + generation)
- Corrective RAG (grade → supplement if low confidence)
- Self-RAG (identify gaps during generation)
- Agentic RAG (document agents for complex queries)

Based on Antonio Gulli's "Agentic Design Patterns" (Springer 2025).

"Humankind cannot gain anything without first giving something in return.
That is the Law of Equivalent Exchange." - Edward Elric
"""

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Tuple
import json

logger = logging.getLogger("specter.memory.rag")


class RAGStrategy(Enum):
    """Available RAG strategies"""
    SIMPLE = auto()           # Basic retrieve + generate
    SIMPLE_MEMORY = auto()    # Simple + conversation memory
    BRANCHED = auto()         # Route to specific sources
    HYDE = auto()             # Hypothetical document embedding
    ADAPTIVE = auto()         # Dynamic strategy selection
    CORRECTIVE = auto()       # Grade and supplement
    SELF_RAG = auto()         # Gap identification
    AGENTIC = auto()          # Document agents


@dataclass
class RetrievalResult:
    """Result from a retrieval operation"""
    content: str
    source: str
    score: float
    collection: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GradedContext:
    """Context with relevance grading"""
    results: List[RetrievalResult]
    confidence: float  # 0.0 to 1.0
    gaps: List[str] = field(default_factory=list)
    needs_supplement: bool = False


@dataclass
class RAGContext:
    """Packaged context for LLM consumption"""
    text: str
    sources: List[str]
    token_count: int
    strategy_used: RAGStrategy
    retrieval_time: float


class AgenticRAGManager:
    """
    Intelligent RAG system for SPECTER.

    Features:
    - Multi-source retrieval (LocalRecall, kb-manager, Context7)
    - Relevance grading with confidence thresholds
    - Corrective retrieval when confidence is low
    - Context engineering for optimal LLM consumption
    - Multiple RAG strategies

    The system implements the "Agentic RAG" pattern where:
    1. Query analysis determines retrieval needs
    2. Parallel retrieval from relevant sources
    3. Relevance grading filters results
    4. Low confidence triggers supplemental retrieval
    5. Context is engineered for LLM consumption
    """

    # Confidence thresholds
    MIN_CONFIDENCE = 0.7
    HIGH_CONFIDENCE = 0.85

    # Token limits for context
    MAX_CONTEXT_TOKENS = 4000
    TOKENS_PER_CHAR = 0.25  # Rough estimate

    # LocalRecall collections
    KNOWLEDGE_COLLECTIONS = [
        "patterns",
        "regression-memory",
        "verified-patterns"
    ]

    def __init__(
        self,
        local_recall_url: str = "http://localhost:9090",
        memory_manager: Optional[Any] = None
    ):
        self.local_recall_url = local_recall_url
        self.memory = memory_manager

        # MCP clients (initialized lazily)
        self._kb_client = None
        self._context7_client = None

        # Stats
        self.queries_processed = 0
        self.supplements_triggered = 0
        self.avg_confidence = 0.0

        logger.info("Agentic RAG Manager initialized")

    async def retrieve(
        self,
        query: str,
        strategy: RAGStrategy = RAGStrategy.CORRECTIVE,
        collections: Optional[List[str]] = None
    ) -> RAGContext:
        """
        Retrieve relevant context for a query.

        Args:
            query: The query to retrieve context for
            strategy: RAG strategy to use
            collections: Specific collections to search (optional)

        Returns:
            RAGContext with packaged context for LLM
        """
        start_time = datetime.now()
        self.queries_processed += 1

        # Select strategy
        if strategy == RAGStrategy.SIMPLE:
            context = await self._simple_rag(query, collections)
        elif strategy == RAGStrategy.CORRECTIVE:
            context = await self._corrective_rag(query, collections)
        elif strategy == RAGStrategy.ADAPTIVE:
            context = await self._adaptive_rag(query, collections)
        elif strategy == RAGStrategy.AGENTIC:
            context = await self._agentic_rag(query, collections)
        else:
            context = await self._corrective_rag(query, collections)

        retrieval_time = (datetime.now() - start_time).total_seconds()
        context.retrieval_time = retrieval_time
        context.strategy_used = strategy

        logger.info(
            f"RAG completed: {len(context.sources)} sources, "
            f"{context.token_count} tokens, {retrieval_time:.2f}s"
        )

        return context

    async def _simple_rag(
        self,
        query: str,
        collections: Optional[List[str]] = None
    ) -> RAGContext:
        """Simple retrieve + package"""

        results = await self._parallel_retrieve(query, collections)
        return self._package_context(results)

    async def _corrective_rag(
        self,
        query: str,
        collections: Optional[List[str]] = None
    ) -> RAGContext:
        """
        Corrective RAG: Grade results and supplement if needed.

        Steps:
        1. Retrieve from primary sources
        2. Grade relevance
        3. If confidence < threshold, supplement with web search
        4. Re-grade and package
        """

        # Primary retrieval
        results = await self._parallel_retrieve(query, collections)

        # Grade results
        graded = self._grade_relevance(results, query)

        # Supplement if needed
        if graded.needs_supplement:
            self.supplements_triggered += 1
            logger.info(f"Low confidence ({graded.confidence:.2f}), supplementing...")

            supplemental = await self._supplement_retrieval(query, graded.gaps)
            results.extend(supplemental)

            # Re-grade
            graded = self._grade_relevance(results, query)

        # Update running average
        self._update_avg_confidence(graded.confidence)

        # Package top results
        top_results = [r for r in results if r.score >= self.MIN_CONFIDENCE]
        return self._package_context(top_results)

    async def _adaptive_rag(
        self,
        query: str,
        collections: Optional[List[str]] = None
    ) -> RAGContext:
        """
        Adaptive RAG: Select strategy based on query type.

        Analyzes query to determine:
        - Code query -> prioritize code patterns
        - Error query -> prioritize regression memory
        - General -> balanced retrieval
        """

        query_lower = query.lower()

        # Detect query type
        if any(kw in query_lower for kw in ["error", "exception", "failed", "bug"]):
            collections = ["errors", "regression-memory"]
        elif any(kw in query_lower for kw in ["pattern", "how to", "best practice"]):
            collections = ["patterns", "verified-patterns", "code_patterns"]
        elif any(kw in query_lower for kw in ["remember", "you said", "earlier"]):
            collections = ["conversations", "episodes"]

        return await self._corrective_rag(query, collections)

    async def _agentic_rag(
        self,
        query: str,
        collections: Optional[List[str]] = None
    ) -> RAGContext:
        """
        Agentic RAG: Use document agents for complex queries.

        Creates specialized agents for different document types:
        - Code agent: Understands code patterns
        - Error agent: Understands error contexts
        - Knowledge agent: General knowledge retrieval

        Agents collaborate to provide comprehensive context.
        """

        # For now, implement as enhanced parallel retrieval
        # Full agent delegation will come with Hive-Mind integration

        # Parallel retrieval with specialized processing
        results = []

        # Code patterns
        code_results = await self._retrieve_from_collection(
            query, "code_patterns", limit=3
        )
        results.extend(code_results)

        # Error patterns
        error_results = await self._retrieve_from_collection(
            query, "errors", limit=3
        )
        results.extend(error_results)

        # Knowledge base
        kb_results = await self._retrieve_from_kb_manager(query)
        results.extend(kb_results)

        # Grade and filter
        graded = self._grade_relevance(results, query)

        if graded.needs_supplement:
            # Use Context7 for external documentation
            external = await self._retrieve_from_context7(query)
            results.extend(external)

        return self._package_context(results)

    async def _parallel_retrieve(
        self,
        query: str,
        collections: Optional[List[str]] = None
    ) -> List[RetrievalResult]:
        """Retrieve from all sources in parallel"""

        collections = collections or self.KNOWLEDGE_COLLECTIONS

        # Create retrieval tasks
        tasks = []

        # LocalRecall / Qdrant via memory manager
        if self.memory:
            for collection in collections:
                tasks.append(
                    self._retrieve_from_collection(query, collection)
                )

        # kb-manager MCP
        tasks.append(self._retrieve_from_kb_manager(query))

        # Execute in parallel
        results_lists = await asyncio.gather(*tasks, return_exceptions=True)

        # Flatten and filter errors
        results = []
        for result_list in results_lists:
            if isinstance(result_list, Exception):
                logger.warning(f"Retrieval task failed: {result_list}")
            elif isinstance(result_list, list):
                results.extend(result_list)

        return results

    async def _retrieve_from_collection(
        self,
        query: str,
        collection: str,
        limit: int = 5
    ) -> List[RetrievalResult]:
        """Retrieve from a specific memory collection"""

        if not self.memory:
            return []

        try:
            entries = await self.memory.recall(
                query=query,
                collection=collection,
                limit=limit,
                min_score=0.5
            )

            return [
                RetrievalResult(
                    content=entry.content,
                    source=f"memory:{collection}",
                    score=getattr(entry, 'score', 0.7),
                    collection=collection,
                    metadata=entry.metadata if hasattr(entry, 'metadata') else {}
                )
                for entry in entries
            ]
        except Exception as e:
            logger.warning(f"Collection {collection} retrieval failed: {e}")
            return []

    async def _retrieve_from_kb_manager(
        self,
        query: str,
        min_confidence: float = 0.7
    ) -> List[RetrievalResult]:
        """Retrieve from kb-manager MCP server"""

        # TODO: Implement actual MCP client call
        # For now, return empty list
        # Will be connected when MCP integration is complete

        return []

    async def _retrieve_from_context7(
        self,
        query: str
    ) -> List[RetrievalResult]:
        """Retrieve from Context7 for external documentation"""

        # TODO: Implement Context7 MCP client call
        # Will provide access to library documentation

        return []

    async def _supplement_retrieval(
        self,
        query: str,
        gaps: List[str]
    ) -> List[RetrievalResult]:
        """Supplement low-confidence results with additional retrieval"""

        supplemental = []

        # Try different collections
        for gap in gaps:
            results = await self._retrieve_from_collection(
                f"{query} {gap}",
                "knowledge",
                limit=2
            )
            supplemental.extend(results)

        # Try web search via LocalRecall if available
        # (Will be implemented with web search integration)

        return supplemental

    def _grade_relevance(
        self,
        results: List[RetrievalResult],
        query: str
    ) -> GradedContext:
        """
        Grade relevance of retrieved results.

        Scoring based on:
        - Vector similarity score
        - Query term overlap
        - Source reliability
        """

        if not results:
            return GradedContext(
                results=[],
                confidence=0.0,
                gaps=["No results found"],
                needs_supplement=True
            )

        # Calculate average confidence
        avg_score = sum(r.score for r in results) / len(results)

        # Identify gaps
        gaps = []
        query_terms = set(query.lower().split())

        covered_terms = set()
        for result in results:
            result_terms = set(result.content.lower().split())
            covered_terms.update(query_terms & result_terms)

        missing_terms = query_terms - covered_terms
        if missing_terms:
            gaps.append(f"Missing context for: {', '.join(list(missing_terms)[:5])}")

        # Determine if supplement needed
        needs_supplement = (
            avg_score < self.MIN_CONFIDENCE or
            len(results) < 2 or
            len(gaps) > 0
        )

        return GradedContext(
            results=results,
            confidence=avg_score,
            gaps=gaps,
            needs_supplement=needs_supplement
        )

    def _package_context(
        self,
        results: List[RetrievalResult]
    ) -> RAGContext:
        """
        Package results into context for LLM consumption.

        Implements context engineering:
        - Sort by relevance
        - Truncate to token limit
        - Format for readability
        - Include source citations
        """

        if not results:
            return RAGContext(
                text="No relevant context found.",
                sources=[],
                token_count=5,
                strategy_used=RAGStrategy.SIMPLE,
                retrieval_time=0.0
            )

        # Sort by score (highest first)
        sorted_results = sorted(results, key=lambda r: r.score, reverse=True)

        # Build context text with token budget
        context_parts = []
        sources = []
        total_chars = 0
        max_chars = int(self.MAX_CONTEXT_TOKENS / self.TOKENS_PER_CHAR)

        for result in sorted_results:
            # Check budget
            content_len = len(result.content)
            if total_chars + content_len > max_chars:
                # Truncate this result
                remaining = max_chars - total_chars
                if remaining > 100:  # Worth including truncated
                    truncated = result.content[:remaining] + "..."
                    context_parts.append(
                        f"[{result.source}] (score: {result.score:.2f})\n{truncated}"
                    )
                    sources.append(result.source)
                break

            context_parts.append(
                f"[{result.source}] (score: {result.score:.2f})\n{result.content}"
            )
            sources.append(result.source)
            total_chars += content_len

        context_text = "\n\n---\n\n".join(context_parts)
        token_count = int(len(context_text) * self.TOKENS_PER_CHAR)

        return RAGContext(
            text=context_text,
            sources=list(set(sources)),
            token_count=token_count,
            strategy_used=RAGStrategy.SIMPLE,
            retrieval_time=0.0
        )

    def _update_avg_confidence(self, new_confidence: float) -> None:
        """Update running average confidence"""
        if self.queries_processed == 1:
            self.avg_confidence = new_confidence
        else:
            # Exponential moving average
            alpha = 0.1
            self.avg_confidence = (
                alpha * new_confidence +
                (1 - alpha) * self.avg_confidence
            )

    def get_stats(self) -> Dict[str, Any]:
        """Get RAG statistics"""
        return {
            "queries_processed": self.queries_processed,
            "supplements_triggered": self.supplements_triggered,
            "supplement_rate": (
                self.supplements_triggered / self.queries_processed
                if self.queries_processed > 0 else 0
            ),
            "avg_confidence": self.avg_confidence,
            "has_memory": self.memory is not None
        }


# Convenience function
def create_rag_manager(memory_manager: Optional[Any] = None) -> AgenticRAGManager:
    """Create a RAG manager with default configuration"""
    return AgenticRAGManager(memory_manager=memory_manager)
