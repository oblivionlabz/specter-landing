"""
MEMORY Vector Store

Qdrant-based vector storage for long-term memory.
"""

from pathlib import Path
from typing import List, Optional, Dict, Any, Union
from dataclasses import dataclass, field
import logging
import asyncio
from datetime import datetime
import uuid
import numpy as np

logger = logging.getLogger("specter.memory.vector_store")


@dataclass
class MemoryEntry:
    """A memory entry to store"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    content: str = ""
    embedding: Optional[np.ndarray] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    collection: str = "default"
    timestamp: datetime = field(default_factory=datetime.now)
    score: float = 0.0  # Relevance score when retrieved


@dataclass
class SearchResult:
    """Result of a memory search"""
    entries: List[MemoryEntry]
    query: str
    collection: str
    search_time: float


class VectorStore:
    """
    Vector storage using Qdrant.

    Features:
    - Multiple collections (conversations, knowledge, etc.)
    - Semantic search
    - Metadata filtering
    - Persistence
    """

    DEFAULT_COLLECTIONS = [
        "conversations",
        "knowledge",
        "episodes",
        "code_patterns",
        "user_preferences",
        "errors"
    ]

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6333,
        path: Optional[Path] = None,
        embedding_dim: int = 384
    ):
        self.host = host
        self.port = port
        self.path = path
        self.embedding_dim = embedding_dim

        self.client = None
        self.initialized = False
        self.collections: List[str] = []

        logger.info(f"Vector store created: {host}:{port}")

    async def initialize(self) -> bool:
        """Initialize connection to Qdrant"""
        if self.initialized:
            return True

        try:
            from qdrant_client import QdrantClient
            from qdrant_client.models import Distance, VectorParams

            loop = asyncio.get_event_loop()

            # Connect to Qdrant
            if self.path:
                # Local storage
                self.client = await loop.run_in_executor(
                    None,
                    lambda: QdrantClient(path=str(self.path))
                )
                logger.info(f"Connected to local Qdrant: {self.path}")
            else:
                # Remote server
                self.client = await loop.run_in_executor(
                    None,
                    lambda: QdrantClient(host=self.host, port=self.port)
                )
                logger.info(f"Connected to Qdrant: {self.host}:{self.port}")

            # Create default collections
            for collection_name in self.DEFAULT_COLLECTIONS:
                await self._ensure_collection(collection_name)

            self.initialized = True
            return True

        except Exception as e:
            logger.error(f"Failed to initialize vector store: {e}")
            return False

    async def _ensure_collection(self, name: str) -> bool:
        """Ensure a collection exists"""
        try:
            from qdrant_client.models import Distance, VectorParams

            loop = asyncio.get_event_loop()

            # Check if exists
            collections = await loop.run_in_executor(
                None,
                lambda: self.client.get_collections()
            )

            existing = [c.name for c in collections.collections]

            if name not in existing:
                await loop.run_in_executor(
                    None,
                    lambda: self.client.create_collection(
                        collection_name=name,
                        vectors_config=VectorParams(
                            size=self.embedding_dim,
                            distance=Distance.COSINE
                        )
                    )
                )
                logger.info(f"Created collection: {name}")

            if name not in self.collections:
                self.collections.append(name)

            return True

        except Exception as e:
            logger.error(f"Failed to ensure collection {name}: {e}")
            return False

    async def store(
        self,
        entry: MemoryEntry
    ) -> bool:
        """
        Store a memory entry.

        Args:
            entry: MemoryEntry to store

        Returns:
            True if successful
        """
        if not self.initialized:
            await self.initialize()

        if entry.embedding is None:
            logger.error("Entry must have embedding")
            return False

        try:
            from qdrant_client.models import PointStruct

            # Ensure collection exists
            await self._ensure_collection(entry.collection)

            # Prepare metadata
            payload = {
                "content": entry.content,
                "timestamp": entry.timestamp.isoformat(),
                **entry.metadata
            }

            point = PointStruct(
                id=entry.id,
                vector=entry.embedding.tolist(),
                payload=payload
            )

            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: self.client.upsert(
                    collection_name=entry.collection,
                    points=[point]
                )
            )

            logger.debug(f"Stored entry: {entry.id} in {entry.collection}")
            return True

        except Exception as e:
            logger.error(f"Failed to store entry: {e}")
            return False

    async def search(
        self,
        query_embedding: np.ndarray,
        collection: str = "default",
        limit: int = 10,
        score_threshold: float = 0.5,
        filters: Optional[Dict] = None
    ) -> SearchResult:
        """
        Search for similar memories.

        Args:
            query_embedding: Query vector
            collection: Collection to search
            limit: Max results
            score_threshold: Min similarity score
            filters: Optional metadata filters

        Returns:
            SearchResult with matching entries
        """
        if not self.initialized:
            await self.initialize()

        start_time = datetime.now()

        try:
            from qdrant_client.models import Filter, FieldCondition, MatchValue

            # Build filter if provided
            query_filter = None
            if filters:
                conditions = []
                for key, value in filters.items():
                    conditions.append(
                        FieldCondition(
                            key=key,
                            match=MatchValue(value=value)
                        )
                    )
                query_filter = Filter(must=conditions)

            loop = asyncio.get_event_loop()
            results = await loop.run_in_executor(
                None,
                lambda: self.client.search(
                    collection_name=collection,
                    query_vector=query_embedding.tolist(),
                    limit=limit,
                    score_threshold=score_threshold,
                    query_filter=query_filter
                )
            )

            # Convert to MemoryEntry
            entries = []
            for result in results:
                entry = MemoryEntry(
                    id=str(result.id),
                    content=result.payload.get("content", ""),
                    metadata={
                        k: v for k, v in result.payload.items()
                        if k not in ["content", "timestamp"]
                    },
                    collection=collection,
                    timestamp=datetime.fromisoformat(
                        result.payload.get("timestamp", datetime.now().isoformat())
                    ),
                    score=result.score
                )
                entries.append(entry)

            search_time = (datetime.now() - start_time).total_seconds()

            return SearchResult(
                entries=entries,
                query="",
                collection=collection,
                search_time=search_time
            )

        except Exception as e:
            logger.error(f"Search failed: {e}")
            return SearchResult(
                entries=[],
                query="",
                collection=collection,
                search_time=0.0
            )

    async def delete(
        self,
        entry_id: str,
        collection: str = "default"
    ) -> bool:
        """Delete a memory entry"""
        if not self.initialized:
            return False

        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: self.client.delete(
                    collection_name=collection,
                    points_selector=[entry_id]
                )
            )
            return True

        except Exception as e:
            logger.error(f"Delete failed: {e}")
            return False

    async def count(self, collection: str = "default") -> int:
        """Get count of entries in collection"""
        if not self.initialized:
            return 0

        try:
            loop = asyncio.get_event_loop()
            info = await loop.run_in_executor(
                None,
                lambda: self.client.get_collection(collection)
            )
            return info.points_count

        except Exception as e:
            logger.error(f"Count failed: {e}")
            return 0

    async def get_collections(self) -> List[str]:
        """Get list of collections"""
        if not self.initialized:
            return []

        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                lambda: self.client.get_collections()
            )
            return [c.name for c in result.collections]

        except Exception as e:
            logger.error(f"Get collections failed: {e}")
            return []

    async def shutdown(self) -> None:
        """Shutdown vector store"""
        if self.client:
            self.client.close()
            self.client = None
        self.initialized = False
        logger.info("Vector store shutdown")
