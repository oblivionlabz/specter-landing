"""
MEMORY Embedding Engine

Generates embeddings for text using sentence-transformers.
"""

from typing import List, Optional, Union
import logging
import asyncio
import numpy as np

logger = logging.getLogger("specter.memory.embeddings")


class EmbeddingEngine:
    """
    Generates text embeddings for vector storage.

    Uses sentence-transformers for high-quality embeddings.
    """

    def __init__(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        device: str = "cuda",
        batch_size: int = 32
    ):
        self.model_name = model_name
        self.device = device
        self.batch_size = batch_size

        self.model = None
        self.initialized = False
        self.embedding_dim = 384  # Default for MiniLM

        logger.info(f"Embedding engine created: {model_name}")

    async def initialize(self) -> bool:
        """Initialize the embedding model"""
        if self.initialized:
            return True

        try:
            from sentence_transformers import SentenceTransformer

            loop = asyncio.get_event_loop()
            self.model = await loop.run_in_executor(
                None,
                lambda: SentenceTransformer(self.model_name, device=self.device)
            )

            # Get embedding dimension
            self.embedding_dim = self.model.get_sentence_embedding_dimension()

            self.initialized = True
            logger.info(f"Embedding model loaded: dim={self.embedding_dim}")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize embeddings: {e}")
            return False

    async def embed(
        self,
        text: Union[str, List[str]],
        normalize: bool = True
    ) -> Optional[np.ndarray]:
        """
        Generate embeddings for text.

        Args:
            text: Single text or list of texts
            normalize: Whether to L2 normalize embeddings

        Returns:
            Numpy array of embeddings
        """
        if not self.initialized:
            await self.initialize()

        if not self.model:
            logger.error("Model not initialized")
            return None

        try:
            texts = [text] if isinstance(text, str) else text

            loop = asyncio.get_event_loop()
            embeddings = await loop.run_in_executor(
                None,
                lambda: self.model.encode(
                    texts,
                    batch_size=self.batch_size,
                    normalize_embeddings=normalize,
                    show_progress_bar=False
                )
            )

            # Return single embedding for single input
            if isinstance(text, str):
                return embeddings[0]

            return embeddings

        except Exception as e:
            logger.error(f"Embedding failed: {e}")
            return None

    async def embed_batch(
        self,
        texts: List[str],
        normalize: bool = True
    ) -> Optional[np.ndarray]:
        """Embed a batch of texts"""
        return await self.embed(texts, normalize)

    def get_dimension(self) -> int:
        """Get embedding dimension"""
        return self.embedding_dim

    async def similarity(
        self,
        embedding1: np.ndarray,
        embedding2: np.ndarray
    ) -> float:
        """
        Calculate cosine similarity between embeddings.

        Args:
            embedding1: First embedding
            embedding2: Second embedding

        Returns:
            Similarity score (0-1)
        """
        # Cosine similarity
        dot = np.dot(embedding1, embedding2)
        norm1 = np.linalg.norm(embedding1)
        norm2 = np.linalg.norm(embedding2)

        if norm1 == 0 or norm2 == 0:
            return 0.0

        return float(dot / (norm1 * norm2))

    async def shutdown(self) -> None:
        """Shutdown embedding engine"""
        if self.model:
            del self.model
            self.model = None
        self.initialized = False
        logger.info("Embedding engine shutdown")
