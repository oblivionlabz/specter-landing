"""
NEXUS WebSocket Manager

Real-time bidirectional communication.
"""

from typing import List, Dict, Any, Optional, Callable
import logging
import asyncio
import json
from datetime import datetime

from fastapi import WebSocket, WebSocketDisconnect

logger = logging.getLogger("specter.nexus.websocket")


class WebSocketManager:
    """
    Manages WebSocket connections for real-time communication.

    Features:
    - Multiple client support
    - Event broadcasting
    - Message routing
    - Heartbeat monitoring
    """

    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.authenticated: Dict[WebSocket, str] = {}
        self.message_handlers: Dict[str, Callable] = {}
        self._heartbeat_task = None

        logger.info("WebSocket manager created")

    async def connect(self, websocket: WebSocket) -> None:
        """Accept a new WebSocket connection"""
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket connected: {len(self.active_connections)} active")

    def disconnect(self, websocket: WebSocket) -> None:
        """Handle WebSocket disconnection"""
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        if websocket in self.authenticated:
            del self.authenticated[websocket]
        logger.info(f"WebSocket disconnected: {len(self.active_connections)} active")

    async def authenticate(self, websocket: WebSocket, token: str) -> bool:
        """Authenticate a WebSocket connection"""
        try:
            import jwt
            JWT_SECRET = "specter_jwt_secret_change_in_production"
            payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
            self.authenticated[websocket] = payload["sub"]
            await self.send_personal(websocket, {
                "type": "auth",
                "status": "ok",
                "user": payload["sub"]
            })
            return True
        except Exception as e:
            await self.send_personal(websocket, {
                "type": "auth",
                "status": "error",
                "message": str(e)
            })
            return False

    async def send_personal(self, websocket: WebSocket, message: Dict) -> None:
        """Send message to specific client"""
        try:
            await websocket.send_json(message)
        except Exception as e:
            logger.error(f"Failed to send message: {e}")
            self.disconnect(websocket)

    async def broadcast(self, message: Dict, authenticated_only: bool = True) -> None:
        """Broadcast message to all connected clients"""
        disconnected = []

        for websocket in self.active_connections:
            if authenticated_only and websocket not in self.authenticated:
                continue

            try:
                await websocket.send_json(message)
            except Exception as e:
                logger.error(f"Broadcast failed: {e}")
                disconnected.append(websocket)

        # Clean up disconnected
        for ws in disconnected:
            self.disconnect(ws)

    async def broadcast_event(
        self,
        event_type: str,
        data: Any = None
    ) -> None:
        """Broadcast a typed event"""
        await self.broadcast({
            "type": "event",
            "event": event_type,
            "data": data,
            "timestamp": datetime.now().isoformat()
        })

    def register_handler(
        self,
        message_type: str,
        handler: Callable
    ) -> None:
        """Register a handler for a message type"""
        self.message_handlers[message_type] = handler
        logger.debug(f"Registered handler for: {message_type}")

    async def handle_message(
        self,
        websocket: WebSocket,
        message: Dict
    ) -> Optional[Dict]:
        """Handle incoming WebSocket message"""
        msg_type = message.get("type")

        if msg_type == "auth":
            token = message.get("token")
            if token:
                await self.authenticate(websocket, token)
            return None

        if msg_type == "ping":
            return {"type": "pong", "timestamp": datetime.now().isoformat()}

        # Check authentication for other messages
        if websocket not in self.authenticated:
            return {
                "type": "error",
                "message": "Not authenticated"
            }

        # Route to handler
        if msg_type in self.message_handlers:
            try:
                handler = self.message_handlers[msg_type]
                if asyncio.iscoroutinefunction(handler):
                    return await handler(websocket, message)
                else:
                    return handler(websocket, message)
            except Exception as e:
                logger.error(f"Handler error: {e}")
                return {"type": "error", "message": str(e)}

        return {"type": "error", "message": f"Unknown message type: {msg_type}"}

    async def handle_connection(self, websocket: WebSocket) -> None:
        """Main WebSocket connection handler"""
        await self.connect(websocket)

        try:
            while True:
                data = await websocket.receive_text()
                message = json.loads(data)

                response = await self.handle_message(websocket, message)
                if response:
                    await self.send_personal(websocket, response)

        except WebSocketDisconnect:
            self.disconnect(websocket)
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
            self.disconnect(websocket)

    async def start_heartbeat(self, interval: int = 30) -> None:
        """Start heartbeat monitoring"""
        self._heartbeat_task = asyncio.create_task(
            self._heartbeat_loop(interval)
        )

    async def stop_heartbeat(self) -> None:
        """Stop heartbeat monitoring"""
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass

    async def _heartbeat_loop(self, interval: int) -> None:
        """Heartbeat loop"""
        while True:
            try:
                await asyncio.sleep(interval)
                await self.broadcast({
                    "type": "heartbeat",
                    "timestamp": datetime.now().isoformat()
                })
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Heartbeat error: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Get WebSocket statistics"""
        return {
            "active_connections": len(self.active_connections),
            "authenticated": len(self.authenticated),
            "handlers": list(self.message_handlers.keys())
        }

    async def shutdown(self) -> None:
        """Shutdown WebSocket manager"""
        await self.stop_heartbeat()

        # Close all connections
        for websocket in self.active_connections.copy():
            try:
                await websocket.close()
            except Exception:
                pass
            self.disconnect(websocket)

        logger.info("WebSocket manager shutdown")
