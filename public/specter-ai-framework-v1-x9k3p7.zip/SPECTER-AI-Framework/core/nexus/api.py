"""
NEXUS REST API

FastAPI-based REST API for SPECTER.
"""

from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
import logging
from pathlib import Path

from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import jwt

logger = logging.getLogger("specter.nexus.api")

# JWT Settings
JWT_SECRET = "specter_jwt_secret_change_in_production"  # Should be from config
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_HOURS = 24


# Pydantic Models
class ChatRequest(BaseModel):
    message: str
    context: Optional[str] = None


class ChatResponse(BaseModel):
    response: str
    mood: str
    timestamp: str


class StatusResponse(BaseModel):
    running: bool
    version: str
    uptime_seconds: float
    components: Dict[str, bool]


class MoodRequest(BaseModel):
    mood: str


class DeviceCommand(BaseModel):
    device_id: str
    action: str
    params: Optional[Dict] = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class LoginRequest(BaseModel):
    username: str
    password: str


# Security
security = HTTPBearer()


def create_token(username: str) -> str:
    """Create JWT token"""
    expiry = datetime.utcnow() + timedelta(hours=JWT_EXPIRY_HOURS)
    payload = {
        "sub": username,
        "exp": expiry,
        "iat": datetime.utcnow()
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> str:
    """Verify JWT token"""
    try:
        payload = jwt.decode(
            credentials.credentials,
            JWT_SECRET,
            algorithms=[JWT_ALGORITHM]
        )
        return payload["sub"]
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expired"
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )


class APIRouter:
    """
    API route definitions.

    Routes are defined here and added to the FastAPI app.
    """

    def __init__(self, daemon=None):
        self.daemon = daemon

    def register_routes(self, app: FastAPI):
        """Register all API routes"""

        @app.post("/api/auth/login", response_model=TokenResponse)
        async def login(request: LoginRequest):
            """Login and get JWT token"""
            # TODO: Implement proper authentication
            if request.username == "specter" and request.password == "specter":
                token = create_token(request.username)
                return TokenResponse(access_token=token)
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials"
            )

        @app.get("/api/status", response_model=StatusResponse)
        async def get_status(user: str = Depends(verify_token)):
            """Get SPECTER status"""
            if self.daemon:
                status_data = self.daemon.get_status()
                return StatusResponse(
                    running=status_data["running"],
                    version=status_data["version"],
                    uptime_seconds=status_data["uptime_seconds"],
                    components=status_data["components"]
                )
            return StatusResponse(
                running=False,
                version="0.1.0",
                uptime_seconds=0,
                components={}
            )

        @app.post("/api/chat", response_model=ChatResponse)
        async def chat(request: ChatRequest, user: str = Depends(verify_token)):
            """Chat with SPECTER"""
            if not self.daemon or not self.daemon.running:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="SPECTER is not running"
                )

            try:
                response = await self.daemon.process_input(request.message)
                mood = self.daemon.personality.moods.get_mood().name if self.daemon.personality else "Unknown"

                return ChatResponse(
                    response=response,
                    mood=mood,
                    timestamp=datetime.now().isoformat()
                )
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=str(e)
                )

        @app.get("/api/mood")
        async def get_mood(user: str = Depends(verify_token)):
            """Get current mood"""
            if self.daemon and self.daemon.personality:
                mood = self.daemon.personality.moods.get_mood()
                return {
                    "name": mood.name,
                    "description": mood.description,
                    "primary_influence": mood.primary_influence,
                    "energy": self.daemon.personality.moods.get_energy()
                }
            return {"name": "Unknown", "description": "", "primary_influence": "", "energy": 1.0}

        @app.post("/api/mood")
        async def set_mood(request: MoodRequest, user: str = Depends(verify_token)):
            """Set mood"""
            if not self.daemon or not self.daemon.personality:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="Personality not initialized"
                )

            try:
                from core.animus.moods import MoodType
                mood_type = MoodType(request.mood)
                self.daemon.personality.moods.set_mood(mood_type)
                return {"status": "ok", "mood": request.mood}
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid mood: {request.mood}"
                )

        @app.get("/api/personality")
        async def get_personality(user: str = Depends(verify_token)):
            """Get personality state"""
            if self.daemon and self.daemon.personality:
                return self.daemon.personality.get_state()
            return {}

        @app.get("/api/rules")
        async def get_rules():
            """Get SPECTER rules (no auth required)"""
            from core.animus import Identity
            return Identity.RULES

        @app.get("/api/quote")
        async def get_quote():
            """Get a random quote (no auth required)"""
            from core.animus import Identity
            return {"quote": Identity.get_quote()}

        @app.get("/api/devices")
        async def get_devices(user: str = Depends(verify_token)):
            """Get smart devices"""
            if self.daemon and hasattr(self.daemon, 'lumina') and self.daemon.lumina:
                return self.daemon.lumina.get_status()
            return {"devices": [], "device_count": 0}

        @app.post("/api/devices/command")
        async def device_command(cmd: DeviceCommand, user: str = Depends(verify_token)):
            """Control a device"""
            if not self.daemon or not hasattr(self.daemon, 'lumina') or not self.daemon.lumina:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="LUMINA not initialized"
                )

            try:
                if cmd.action == "on":
                    success = await self.daemon.lumina.turn_on(cmd.device_id)
                elif cmd.action == "off":
                    success = await self.daemon.lumina.turn_off(cmd.device_id)
                elif cmd.action == "toggle":
                    success = await self.daemon.lumina.toggle(cmd.device_id)
                else:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Unknown action: {cmd.action}"
                    )

                return {"status": "ok" if success else "failed"}
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=str(e)
                )

        @app.get("/api/wallet/status")
        async def wallet_status(user: str = Depends(verify_token)):
            """Get wallet status"""
            if self.daemon and hasattr(self.daemon, 'vault') and self.daemon.vault:
                return self.daemon.vault.get_status()
            return {"initialized": False}

        @app.get("/api/trader/status")
        async def trader_status(user: str = Depends(verify_token)):
            """Get trader status"""
            if self.daemon and hasattr(self.daemon, 'trader') and self.daemon.trader:
                return self.daemon.trader.get_status()
            return {"initialized": False}

        @app.get("/api/health")
        async def health_check():
            """Health check (no auth)"""
            return {"status": "ok", "timestamp": datetime.now().isoformat()}


def create_app(daemon=None) -> FastAPI:
    """
    Create and configure the FastAPI application.

    Args:
        daemon: Optional SpecterDaemon instance

    Returns:
        Configured FastAPI app
    """
    app = FastAPI(
        title="SPECTER API",
        description="Sovereign Persistent Executive Core for Total Environment Reign",
        version="0.1.0",
        docs_url="/api/docs",
        redoc_url="/api/redoc"
    )

    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure properly in production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"]
    )

    # Register routes
    router = APIRouter(daemon)
    router.register_routes(app)

    logger.info("NEXUS API created")
    return app
