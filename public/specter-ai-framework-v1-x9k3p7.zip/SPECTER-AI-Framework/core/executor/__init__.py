"""
EXECUTOR Module

Task execution engine with tool orchestration.
This is how SPECTER interacts with the world.

"Get it done. Get it done right." - Harvey Specter
"""

from .tools import Tool, ToolResult, ToolRegistry, get_registry, ToolCategory
from .browser_tool import BrowserTool, BrowserConfig
from .desktop_tool import DesktopTool
from .queue import TaskQueue, Task, TaskStatus, TaskPriority
from .executor import Executor

__all__ = [
    "Tool",
    "ToolResult",
    "ToolRegistry",
    "ToolCategory",
    "get_registry",
    "BrowserTool",
    "BrowserConfig",
    "DesktopTool",
    "TaskQueue",
    "Task",
    "TaskStatus",
    "TaskPriority",
    "Executor"
]
