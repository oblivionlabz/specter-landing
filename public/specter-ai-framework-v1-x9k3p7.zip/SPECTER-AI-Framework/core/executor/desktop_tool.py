"""
Desktop Automation Tool

Native Ubuntu desktop automation using xdotool, wmctrl, and pyautogui.
Handles window management, keyboard/mouse input, and app launching.
"""

import asyncio
import subprocess
import logging
import shutil
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass

from .tools import Tool, ToolResult, ToolCategory

logger = logging.getLogger("specter.executor.desktop")


@dataclass
class WindowInfo:
    """Information about a window"""
    window_id: str
    title: str
    class_name: str
    desktop: int
    x: int
    y: int
    width: int
    height: int


class DesktopTool(Tool):
    """
    Desktop automation tool for Ubuntu.

    Uses:
    - xdotool: Keyboard/mouse simulation, window focus
    - wmctrl: Window management
    - xclip: Clipboard operations
    - xdg-open: Application launching

    Capabilities:
    - Launch applications
    - Switch windows
    - Keyboard input
    - Mouse control
    - Screenshot regions
    - Clipboard access
    """

    name = "desktop"
    description = "Control Ubuntu desktop - launch apps, manage windows, keyboard/mouse input"
    category = ToolCategory.SYSTEM
    requires_approval = False

    def __init__(self):
        super().__init__()
        self.has_xdotool = False
        self.has_wmctrl = False
        self.has_xclip = False

    async def initialize(self) -> bool:
        """Check for required tools"""
        self.has_xdotool = shutil.which("xdotool") is not None
        self.has_wmctrl = shutil.which("wmctrl") is not None
        self.has_xclip = shutil.which("xclip") is not None

        if not self.has_xdotool:
            logger.warning("xdotool not found. Install: sudo apt install xdotool")
        if not self.has_wmctrl:
            logger.warning("wmctrl not found. Install: sudo apt install wmctrl")
        if not self.has_xclip:
            logger.warning("xclip not found. Install: sudo apt install xclip")

        self.initialized = self.has_xdotool
        return self.initialized

    async def execute(self, action: str, **kwargs) -> ToolResult:
        """
        Execute desktop action.

        Actions:
        - launch_app: Open application
        - list_windows: Get all open windows
        - focus_window: Bring window to front
        - close_window: Close a window
        - minimize_window: Minimize window
        - maximize_window: Maximize window
        - move_window: Move/resize window
        - type_text: Type text via keyboard
        - press_key: Press key combination
        - click: Mouse click at position
        - move_mouse: Move mouse cursor
        - get_clipboard: Get clipboard content
        - set_clipboard: Set clipboard content
        - get_active_window: Get currently focused window
        - take_screenshot: Screenshot region
        - run_command: Execute shell command
        """
        if not self.initialized:
            return ToolResult.fail("Desktop tools not available")

        self.execution_count += 1

        try:
            if action == "launch_app":
                return await self._launch_app(kwargs.get("app"))

            elif action == "list_windows":
                return await self._list_windows()

            elif action == "focus_window":
                return await self._focus_window(
                    kwargs.get("title"),
                    kwargs.get("window_id")
                )

            elif action == "close_window":
                return await self._close_window(
                    kwargs.get("title"),
                    kwargs.get("window_id")
                )

            elif action == "minimize_window":
                return await self._minimize_window(kwargs.get("window_id"))

            elif action == "maximize_window":
                return await self._maximize_window(kwargs.get("window_id"))

            elif action == "type_text":
                return await self._type_text(
                    kwargs.get("text"),
                    kwargs.get("delay", 50)
                )

            elif action == "press_key":
                return await self._press_key(kwargs.get("key"))

            elif action == "click":
                return await self._click(
                    kwargs.get("x"),
                    kwargs.get("y"),
                    kwargs.get("button", 1)
                )

            elif action == "move_mouse":
                return await self._move_mouse(
                    kwargs.get("x"),
                    kwargs.get("y")
                )

            elif action == "get_clipboard":
                return await self._get_clipboard()

            elif action == "set_clipboard":
                return await self._set_clipboard(kwargs.get("text"))

            elif action == "get_active_window":
                return await self._get_active_window()

            elif action == "take_screenshot":
                return await self._take_screenshot(
                    kwargs.get("path"),
                    kwargs.get("region")
                )

            elif action == "run_command":
                return await self._run_command(
                    kwargs.get("command"),
                    kwargs.get("timeout", 30)
                )

            elif action == "search_and_click":
                return await self._search_and_click(kwargs.get("text"))

            else:
                return ToolResult.fail(f"Unknown action: {action}")

        except Exception as e:
            self.last_error = str(e)
            logger.error(f"Desktop action {action} failed: {e}")
            return ToolResult.fail(str(e))

    async def _run_cmd(self, cmd: List[str], timeout: int = 10) -> Tuple[str, str, int]:
        """Run shell command and return stdout, stderr, returncode"""
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout
            )
            return (
                stdout.decode().strip(),
                stderr.decode().strip(),
                proc.returncode
            )
        except asyncio.TimeoutError:
            proc.kill()
            raise

    async def _launch_app(self, app: str) -> ToolResult:
        """Launch an application"""
        if not app:
            return ToolResult.fail("App name required")

        # Common app mappings
        app_commands = {
            "firefox": ["firefox", "--new-window"],
            "chrome": ["google-chrome"],
            "terminal": ["gnome-terminal"],
            "files": ["nautilus"],
            "code": ["code"],
            "vscode": ["code"],
            "settings": ["gnome-control-center"],
            "calculator": ["gnome-calculator"],
            "text-editor": ["gedit"],
            "spotify": ["spotify"],
            "discord": ["discord"],
            "slack": ["slack"],
        }

        cmd = app_commands.get(app.lower(), [app])

        try:
            # Launch detached
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
                start_new_session=True
            )
            await asyncio.sleep(0.5)  # Give app time to start
            return ToolResult.ok({"launched": app, "pid": proc.pid}, action="launch_app")
        except FileNotFoundError:
            # Try xdg-open as fallback
            try:
                proc = await asyncio.create_subprocess_exec(
                    "xdg-open", app,
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL,
                    start_new_session=True
                )
                return ToolResult.ok({"launched": app, "via": "xdg-open"}, action="launch_app")
            except:
                return ToolResult.fail(f"Could not launch: {app}")

    async def _list_windows(self) -> ToolResult:
        """List all open windows"""
        if not self.has_wmctrl:
            return ToolResult.fail("wmctrl not available")

        stdout, _, rc = await self._run_cmd(["wmctrl", "-l", "-G", "-p"])
        if rc != 0:
            return ToolResult.fail("Failed to list windows")

        windows = []
        for line in stdout.split("\n"):
            if not line.strip():
                continue
            parts = line.split(None, 8)
            if len(parts) >= 9:
                windows.append({
                    "window_id": parts[0],
                    "desktop": parts[1],
                    "pid": parts[2],
                    "x": int(parts[3]),
                    "y": int(parts[4]),
                    "width": int(parts[5]),
                    "height": int(parts[6]),
                    "class": parts[7],
                    "title": parts[8] if len(parts) > 8 else ""
                })

        return ToolResult.ok({"windows": windows}, action="list_windows")

    async def _focus_window(
        self,
        title: Optional[str] = None,
        window_id: Optional[str] = None
    ) -> ToolResult:
        """Focus a window by title or ID"""
        if window_id:
            _, _, rc = await self._run_cmd(["wmctrl", "-i", "-a", window_id])
        elif title:
            _, _, rc = await self._run_cmd(["wmctrl", "-a", title])
        else:
            return ToolResult.fail("Title or window_id required")

        if rc == 0:
            return ToolResult.ok({"focused": title or window_id}, action="focus_window")
        return ToolResult.fail("Window not found")

    async def _close_window(
        self,
        title: Optional[str] = None,
        window_id: Optional[str] = None
    ) -> ToolResult:
        """Close a window"""
        if window_id:
            _, _, rc = await self._run_cmd(["wmctrl", "-i", "-c", window_id])
        elif title:
            _, _, rc = await self._run_cmd(["wmctrl", "-c", title])
        else:
            return ToolResult.fail("Title or window_id required")

        return ToolResult.ok({"closed": title or window_id}, action="close_window")

    async def _minimize_window(self, window_id: Optional[str] = None) -> ToolResult:
        """Minimize a window"""
        cmd = ["xdotool", "windowminimize"]
        if window_id:
            cmd.append(window_id)
        else:
            cmd.append("--active")

        _, _, rc = await self._run_cmd(cmd)
        return ToolResult.ok({"minimized": True}, action="minimize_window")

    async def _maximize_window(self, window_id: Optional[str] = None) -> ToolResult:
        """Maximize a window"""
        if window_id:
            await self._run_cmd([
                "wmctrl", "-i", "-r", window_id,
                "-b", "add,maximized_vert,maximized_horz"
            ])
        else:
            await self._run_cmd([
                "wmctrl", "-r", ":ACTIVE:",
                "-b", "add,maximized_vert,maximized_horz"
            ])

        return ToolResult.ok({"maximized": True}, action="maximize_window")

    async def _type_text(self, text: str, delay: int = 50) -> ToolResult:
        """Type text using xdotool"""
        if not text:
            return ToolResult.fail("Text required")

        await self._run_cmd([
            "xdotool", "type",
            "--delay", str(delay),
            text
        ])

        return ToolResult.ok({"typed": len(text)}, action="type_text")

    async def _press_key(self, key: str) -> ToolResult:
        """Press key combination (e.g., 'ctrl+s', 'Return', 'alt+F4')"""
        if not key:
            return ToolResult.fail("Key required")

        # Convert common key names
        key_map = {
            "enter": "Return",
            "esc": "Escape",
            "tab": "Tab",
            "space": "space",
            "backspace": "BackSpace",
            "delete": "Delete",
            "up": "Up",
            "down": "Down",
            "left": "Left",
            "right": "Right",
            "home": "Home",
            "end": "End",
            "pageup": "Page_Up",
            "pagedown": "Page_Down",
        }

        key = key_map.get(key.lower(), key)

        await self._run_cmd(["xdotool", "key", key])
        return ToolResult.ok({"pressed": key}, action="press_key")

    async def _click(
        self,
        x: Optional[int] = None,
        y: Optional[int] = None,
        button: int = 1
    ) -> ToolResult:
        """Click at position (or current position if not specified)"""
        if x is not None and y is not None:
            await self._run_cmd([
                "xdotool", "mousemove", str(x), str(y),
                "click", str(button)
            ])
            return ToolResult.ok({"clicked": [x, y]}, action="click")

        await self._run_cmd(["xdotool", "click", str(button)])
        return ToolResult.ok({"clicked": "current"}, action="click")

    async def _move_mouse(self, x: int, y: int) -> ToolResult:
        """Move mouse cursor"""
        await self._run_cmd(["xdotool", "mousemove", str(x), str(y)])
        return ToolResult.ok({"moved": [x, y]}, action="move_mouse")

    async def _get_clipboard(self) -> ToolResult:
        """Get clipboard content"""
        if not self.has_xclip:
            return ToolResult.fail("xclip not available")

        stdout, _, rc = await self._run_cmd([
            "xclip", "-selection", "clipboard", "-o"
        ])

        return ToolResult.ok({"content": stdout}, action="get_clipboard")

    async def _set_clipboard(self, text: str) -> ToolResult:
        """Set clipboard content"""
        if not self.has_xclip:
            return ToolResult.fail("xclip not available")

        proc = await asyncio.create_subprocess_exec(
            "xclip", "-selection", "clipboard",
            stdin=asyncio.subprocess.PIPE
        )
        await proc.communicate(text.encode())

        return ToolResult.ok({"set": len(text)}, action="set_clipboard")

    async def _get_active_window(self) -> ToolResult:
        """Get the currently active window"""
        stdout, _, _ = await self._run_cmd(["xdotool", "getactivewindow"])
        window_id = stdout.strip()

        if window_id:
            name_out, _, _ = await self._run_cmd([
                "xdotool", "getwindowname", window_id
            ])
            return ToolResult.ok({
                "window_id": window_id,
                "title": name_out
            }, action="get_active_window")

        return ToolResult.fail("No active window")

    async def _take_screenshot(
        self,
        path: Optional[str] = None,
        region: Optional[List[int]] = None
    ) -> ToolResult:
        """Take screenshot"""
        path = path or "/tmp/specter_desktop_screenshot.png"

        if region and len(region) == 4:
            # Region: [x, y, width, height]
            await self._run_cmd([
                "import", "-window", "root",
                "-crop", f"{region[2]}x{region[3]}+{region[0]}+{region[1]}",
                path
            ])
        else:
            # Full screen
            await self._run_cmd(["import", "-window", "root", path])

        return ToolResult.ok({"path": path}, action="take_screenshot")

    async def _run_command(self, command: str, timeout: int = 30) -> ToolResult:
        """Run shell command"""
        if not command:
            return ToolResult.fail("Command required")

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout
            )

            return ToolResult.ok({
                "stdout": stdout.decode()[:5000],
                "stderr": stderr.decode()[:1000],
                "returncode": proc.returncode
            }, action="run_command")

        except asyncio.TimeoutError:
            return ToolResult.fail(f"Command timed out after {timeout}s")

    async def _search_and_click(self, text: str) -> ToolResult:
        """
        Search for text on screen and click it.
        Uses xdotool's window search + OCR position estimation.
        """
        # This would integrate with IRIS for visual search
        # For now, use xdotool search
        stdout, _, _ = await self._run_cmd([
            "xdotool", "search", "--name", text
        ])

        if stdout:
            window_id = stdout.split("\n")[0]
            await self._run_cmd(["xdotool", "windowactivate", window_id])
            return ToolResult.ok({"found": text, "window_id": window_id})

        return ToolResult.fail(f"Could not find: {text}")

    def get_schema(self) -> Dict[str, Any]:
        """Get tool schema for LLM"""
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "requires_approval": self.requires_approval,
            "actions": {
                "launch_app": {"params": ["app"]},
                "list_windows": {"params": []},
                "focus_window": {"params": ["title", "window_id"]},
                "close_window": {"params": ["title", "window_id"]},
                "minimize_window": {"params": ["window_id"]},
                "maximize_window": {"params": ["window_id"]},
                "type_text": {"params": ["text", "delay"]},
                "press_key": {"params": ["key"]},
                "click": {"params": ["x", "y", "button"]},
                "move_mouse": {"params": ["x", "y"]},
                "get_clipboard": {"params": []},
                "set_clipboard": {"params": ["text"]},
                "get_active_window": {"params": []},
                "take_screenshot": {"params": ["path", "region"]},
                "run_command": {"params": ["command", "timeout"]}
            },
            "tools_available": {
                "xdotool": self.has_xdotool,
                "wmctrl": self.has_wmctrl,
                "xclip": self.has_xclip
            }
        }

    async def shutdown(self) -> None:
        """Cleanup"""
        self.initialized = False
        logger.info("Desktop tool shutdown")
