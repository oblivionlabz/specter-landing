"""
EXECUTOR - Task Execution Engine

The hands of SPECTER. Orchestrates tool execution to interact with the world.

"Get it done. Get it done right." - Harvey Specter
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from pathlib import Path

from .tools import Tool, ToolResult, ToolRegistry, get_registry, ToolCategory
from .browser_tool import BrowserTool, BrowserConfig
from .desktop_tool import DesktopTool
from .queue import TaskQueue, Task, TaskStatus, TaskPriority

logger = logging.getLogger("specter.executor")


class Executor:
    """
    SPECTER's execution engine.

    Orchestrates:
    - Tool initialization and management
    - Task queue processing
    - Browser automation
    - Desktop automation
    - Command execution

    This is how SPECTER interacts with the world.
    """

    def __init__(
        self,
        task_db_path: Optional[Path] = None,
        max_concurrent_tasks: int = 4,
        browser_config: Optional[BrowserConfig] = None
    ):
        self.registry = get_registry()
        self.queue = TaskQueue(
            db_path=task_db_path,
            max_concurrent=max_concurrent_tasks
        )

        # Tool configurations
        self.browser_config = browser_config or BrowserConfig()

        # State
        self.initialized = False
        self.running = False
        self._task_loop: Optional[asyncio.Task] = None

        # Stats
        self.tasks_executed = 0
        self.tasks_failed = 0
        self.started_at: Optional[datetime] = None

        logger.info("Executor created")

    async def initialize(self) -> bool:
        """Initialize the executor and all tools"""
        if self.initialized:
            return True

        logger.info("Initializing EXECUTOR...")

        # Initialize queue
        queue_ok = await self.queue.initialize()
        if not queue_ok:
            logger.error("Failed to initialize task queue")
            return False
        logger.info("  [+] Task queue initialized")

        # Register and initialize tools
        await self._register_tools()

        # Initialize all tools
        results = await self.registry.initialize_all()
        for name, success in results.items():
            if success:
                logger.info(f"  [+] Tool '{name}' initialized")
            else:
                logger.warning(f"  [!] Tool '{name}' failed to initialize")

        # Set up queue callbacks
        self.queue.on_task_complete = self._on_task_complete
        self.queue.on_task_failed = self._on_task_failed

        self.initialized = True
        self.started_at = datetime.now()
        logger.info("EXECUTOR initialized successfully")
        return True

    async def _register_tools(self) -> None:
        """Register all available tools"""
        # Browser tool
        browser = BrowserTool(self.browser_config)
        self.registry.register(browser)

        # Desktop tool
        desktop = DesktopTool()
        self.registry.register(desktop)

        logger.info(f"Registered {len(self.registry)} tools")

    async def start(self) -> None:
        """Start the task processing loop"""
        if self.running:
            return

        if not self.initialized:
            await self.initialize()

        self.running = True
        self._task_loop = asyncio.create_task(self._process_loop())
        logger.info("Executor task loop started")

    async def stop(self) -> None:
        """Stop the task processing loop"""
        self.running = False
        if self._task_loop:
            self._task_loop.cancel()
            try:
                await self._task_loop
            except asyncio.CancelledError:
                pass
        logger.info("Executor task loop stopped")

    async def _process_loop(self) -> None:
        """Main task processing loop"""
        while self.running:
            try:
                # Get next task
                task = await self.queue.dequeue()
                if task:
                    # Execute in background
                    asyncio.create_task(self._execute_task(task))
                else:
                    # No task available, wait a bit
                    await asyncio.sleep(0.1)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Task loop error: {e}")
                await asyncio.sleep(1)

    async def _execute_task(self, task: Task) -> None:
        """Execute a single task"""
        logger.info(f"Executing task {task.id}: {task.name}")

        try:
            # Get the tool
            tool = self.registry.get(task.tool)
            if not tool:
                await self.queue.complete(
                    task.id,
                    error=f"Tool not found: {task.tool}"
                )
                return

            # Execute with timeout
            try:
                result = await asyncio.wait_for(
                    tool.execute(task.action, **task.params),
                    timeout=task.timeout
                )
            except asyncio.TimeoutError:
                await self.queue.complete(
                    task.id,
                    error=f"Task timed out after {task.timeout}s"
                )
                return

            # Handle result
            if result.success:
                await self.queue.complete(task.id, result=result.data)
                self.tasks_executed += 1
            else:
                await self.queue.complete(task.id, error=result.error)
                self.tasks_failed += 1

        except Exception as e:
            logger.error(f"Task {task.id} execution error: {e}")
            await self.queue.complete(task.id, error=str(e))
            self.tasks_failed += 1

    async def _on_task_complete(self, task: Task) -> None:
        """Called when a task completes successfully"""
        logger.info(f"Task {task.id} completed: {task.name}")

    async def _on_task_failed(self, task: Task) -> None:
        """Called when a task fails permanently"""
        logger.error(f"Task {task.id} failed: {task.error}")

    # =========================================================================
    # High-Level Action Methods
    # =========================================================================

    async def do(
        self,
        tool: str,
        action: str,
        name: str = "",
        priority: TaskPriority = TaskPriority.NORMAL,
        wait: bool = False,
        **params
    ) -> Optional[Any]:
        """
        Execute a tool action.

        Args:
            tool: Tool name (browser, desktop, etc.)
            action: Action to perform
            name: Human-readable task name
            priority: Task priority
            wait: Whether to wait for completion
            **params: Action parameters

        Returns:
            Task result if wait=True, else task ID
        """
        task = Task(
            name=name or f"{tool}.{action}",
            tool=tool,
            action=action,
            params=params,
            priority=priority
        )

        task_id = await self.queue.enqueue(task)

        if wait:
            return await self._wait_for_task(task_id)

        return task_id

    async def _wait_for_task(
        self,
        task_id: str,
        timeout: int = 300
    ) -> Optional[Any]:
        """Wait for a task to complete"""
        start = datetime.now()

        while (datetime.now() - start).total_seconds() < timeout:
            task = self.queue.get_task(task_id)
            if not task:
                return None

            if task.status == TaskStatus.COMPLETED:
                return task.result

            if task.status == TaskStatus.FAILED:
                raise Exception(task.error)

            await asyncio.sleep(0.1)

        raise TimeoutError(f"Task {task_id} timed out")

    # =========================================================================
    # Convenience Methods for Common Operations
    # =========================================================================

    async def browser_navigate(self, url: str, wait: bool = True) -> Any:
        """Navigate browser to URL"""
        return await self.do(
            "browser", "navigate",
            name=f"Navigate to {url}",
            url=url,
            wait=wait
        )

    async def browser_click(
        self,
        selector: Optional[str] = None,
        text: Optional[str] = None,
        wait: bool = True
    ) -> Any:
        """Click element in browser"""
        return await self.do(
            "browser", "click",
            name=f"Click {selector or text}",
            selector=selector,
            text=text,
            wait=wait
        )

    async def browser_fill(
        self,
        selector: Optional[str] = None,
        value: str = "",
        label: Optional[str] = None,
        wait: bool = True
    ) -> Any:
        """Fill form field"""
        return await self.do(
            "browser", "fill",
            name=f"Fill {selector or label}",
            selector=selector,
            value=value,
            label=label,
            wait=wait
        )

    async def browser_get_content(self, wait: bool = True) -> Any:
        """Get page content"""
        return await self.do(
            "browser", "get_page_content",
            name="Get page content",
            wait=wait
        )

    async def browser_new_tab(self, tab_id: str = "new", wait: bool = True) -> Any:
        """Open new browser tab"""
        return await self.do(
            "browser", "new_tab",
            name=f"New tab: {tab_id}",
            tab_id=tab_id,
            wait=wait
        )

    async def desktop_launch(self, app: str, wait: bool = True) -> Any:
        """Launch desktop application"""
        return await self.do(
            "desktop", "launch_app",
            name=f"Launch {app}",
            app=app,
            wait=wait
        )

    async def desktop_focus(self, title: str, wait: bool = True) -> Any:
        """Focus window by title"""
        return await self.do(
            "desktop", "focus_window",
            name=f"Focus {title}",
            title=title,
            wait=wait
        )

    async def desktop_type(self, text: str, wait: bool = True) -> Any:
        """Type text"""
        return await self.do(
            "desktop", "type_text",
            name="Type text",
            text=text,
            wait=wait
        )

    async def desktop_press(self, key: str, wait: bool = True) -> Any:
        """Press key"""
        return await self.do(
            "desktop", "press_key",
            name=f"Press {key}",
            key=key,
            wait=wait
        )

    async def desktop_run(self, command: str, wait: bool = True) -> Any:
        """Run shell command"""
        return await self.do(
            "desktop", "run_command",
            name=f"Run: {command[:30]}...",
            command=command,
            wait=wait
        )

    async def desktop_windows(self, wait: bool = True) -> Any:
        """List all windows"""
        return await self.do(
            "desktop", "list_windows",
            name="List windows",
            wait=wait
        )

    # =========================================================================
    # Complex Task Sequences
    # =========================================================================

    async def open_url_in_firefox(self, url: str) -> Any:
        """Open URL in Firefox (launches if not running)"""
        # Check if Firefox is running
        windows = await self.desktop_windows()

        firefox_running = False
        if windows and "windows" in windows:
            for win in windows["windows"]:
                if "firefox" in win.get("class", "").lower():
                    firefox_running = True
                    break

        if not firefox_running:
            # Launch Firefox
            await self.desktop_launch("firefox")
            await asyncio.sleep(2)  # Wait for launch

        # Navigate in browser
        return await self.browser_navigate(url)

    async def gmail_login(self, email: str) -> Dict[str, Any]:
        """
        Navigate to Gmail and start login process.

        Note: For security, password should be entered manually
        or stored securely, not passed as parameter.
        """
        results = {}

        # Navigate to Gmail
        results["navigate"] = await self.browser_navigate("https://mail.google.com")
        await asyncio.sleep(2)

        # Enter email
        results["email"] = await self.browser_fill(
            selector='input[type="email"]',
            value=email
        )

        # Click Next
        results["next"] = await self.browser_click(text="Next")
        await asyncio.sleep(2)

        return results

    async def get_gmail_emails(self) -> List[Dict[str, Any]]:
        """Get emails from Gmail inbox"""
        result = await self.do(
            "browser", "get_emails",
            name="Get Gmail emails",
            wait=True
        )
        return result.get("emails", []) if result else []

    # =========================================================================
    # Status and Management
    # =========================================================================

    def get_stats(self) -> Dict[str, Any]:
        """Get executor statistics"""
        return {
            "initialized": self.initialized,
            "running": self.running,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "tasks_executed": self.tasks_executed,
            "tasks_failed": self.tasks_failed,
            "queue": self.queue.get_stats(),
            "tools": self.registry.list_tools()
        }

    def get_tool_schemas(self) -> List[Dict[str, Any]]:
        """Get schemas for all tools (for LLM context)"""
        return self.registry.get_schemas()

    async def shutdown(self) -> None:
        """Shutdown the executor"""
        logger.info("Shutting down EXECUTOR...")

        await self.stop()
        await self.queue.shutdown()
        await self.registry.shutdown_all()

        self.initialized = False
        logger.info("EXECUTOR shutdown complete")
