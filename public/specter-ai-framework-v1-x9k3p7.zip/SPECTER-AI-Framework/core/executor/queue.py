"""
Task Queue

Manages task scheduling, prioritization, and execution tracking.
"""

import asyncio
import uuid
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import json
import aiosqlite
from pathlib import Path

logger = logging.getLogger("specter.executor.queue")


class TaskStatus(Enum):
    """Task execution status"""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    WAITING_APPROVAL = "waiting_approval"


class TaskPriority(Enum):
    """Task priority levels"""
    CRITICAL = 100
    HIGH = 75
    NORMAL = 50
    LOW = 25
    BACKGROUND = 10


@dataclass
class Task:
    """A task to be executed"""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str = ""
    description: str = ""
    tool: str = ""
    action: str = ""
    params: Dict[str, Any] = field(default_factory=dict)
    priority: TaskPriority = TaskPriority.NORMAL
    status: TaskStatus = TaskStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    result: Optional[Any] = None
    error: Optional[str] = None
    retries: int = 0
    max_retries: int = 3
    timeout: int = 300  # seconds
    requires_approval: bool = False
    approved: bool = False
    parent_id: Optional[str] = None  # For sub-tasks

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "tool": self.tool,
            "action": self.action,
            "params": self.params,
            "priority": self.priority.value,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "result": self.result,
            "error": self.error,
            "retries": self.retries,
            "requires_approval": self.requires_approval,
            "approved": self.approved
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Task":
        task = cls(
            id=data.get("id", str(uuid.uuid4())[:8]),
            name=data.get("name", ""),
            description=data.get("description", ""),
            tool=data.get("tool", ""),
            action=data.get("action", ""),
            params=data.get("params", {}),
            priority=TaskPriority(data.get("priority", 50)),
            status=TaskStatus(data.get("status", "pending")),
            result=data.get("result"),
            error=data.get("error"),
            retries=data.get("retries", 0),
            requires_approval=data.get("requires_approval", False),
            approved=data.get("approved", False),
            parent_id=data.get("parent_id")
        )
        if data.get("created_at"):
            task.created_at = datetime.fromisoformat(data["created_at"])
        return task


class TaskQueue:
    """
    Priority-based task queue with persistence.

    Features:
    - Priority ordering
    - SQLite persistence
    - Async execution
    - Retry handling
    - Task history
    """

    def __init__(
        self,
        db_path: Optional[Path] = None,
        max_concurrent: int = 4
    ):
        self.db_path = db_path or Path("/tmp/specter_tasks.db")
        self.max_concurrent = max_concurrent

        # In-memory queue (sorted by priority)
        self._queue: List[Task] = []
        self._running: Dict[str, Task] = {}
        self._history: List[Task] = []

        # Callbacks
        self.on_task_complete: Optional[Callable] = None
        self.on_task_failed: Optional[Callable] = None

        # Stats
        self.total_tasks = 0
        self.completed_tasks = 0
        self.failed_tasks = 0

        self._initialized = False
        self._lock = asyncio.Lock()

    async def initialize(self) -> bool:
        """Initialize the queue and database"""
        try:
            # Create database and table
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute("""
                    CREATE TABLE IF NOT EXISTS tasks (
                        id TEXT PRIMARY KEY,
                        data TEXT NOT NULL,
                        status TEXT NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                await db.execute("""
                    CREATE INDEX IF NOT EXISTS idx_status ON tasks(status)
                """)
                await db.commit()

                # Load pending tasks
                async with db.execute(
                    "SELECT data FROM tasks WHERE status IN (?, ?)",
                    (TaskStatus.PENDING.value, TaskStatus.QUEUED.value)
                ) as cursor:
                    rows = await cursor.fetchall()
                    for row in rows:
                        task = Task.from_dict(json.loads(row[0]))
                        self._queue.append(task)

            self._sort_queue()
            self._initialized = True
            logger.info(f"Task queue initialized with {len(self._queue)} pending tasks")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize task queue: {e}")
            return False

    async def enqueue(self, task: Task) -> str:
        """Add a task to the queue"""
        async with self._lock:
            task.status = TaskStatus.QUEUED
            self._queue.append(task)
            self._sort_queue()
            self.total_tasks += 1

            # Persist
            await self._save_task(task)

            logger.info(f"Enqueued task {task.id}: {task.name}")
            return task.id

    async def dequeue(self) -> Optional[Task]:
        """Get the next task to execute"""
        async with self._lock:
            # Check if we can run more tasks
            if len(self._running) >= self.max_concurrent:
                return None

            # Find first non-blocked task
            for i, task in enumerate(self._queue):
                if task.requires_approval and not task.approved:
                    task.status = TaskStatus.WAITING_APPROVAL
                    continue

                # Remove from queue and mark as running
                self._queue.pop(i)
                task.status = TaskStatus.RUNNING
                task.started_at = datetime.now()
                self._running[task.id] = task

                await self._save_task(task)
                return task

            return None

    async def complete(
        self,
        task_id: str,
        result: Any = None,
        error: Optional[str] = None
    ) -> None:
        """Mark a task as complete or failed"""
        async with self._lock:
            if task_id not in self._running:
                logger.warning(f"Task {task_id} not in running set")
                return

            task = self._running.pop(task_id)
            task.completed_at = datetime.now()

            if error:
                task.status = TaskStatus.FAILED
                task.error = error
                self.failed_tasks += 1

                # Retry logic
                if task.retries < task.max_retries:
                    task.retries += 1
                    task.status = TaskStatus.QUEUED
                    task.error = None
                    self._queue.append(task)
                    self._sort_queue()
                    logger.info(f"Retrying task {task_id} ({task.retries}/{task.max_retries})")
                elif self.on_task_failed:
                    await self._call_callback(self.on_task_failed, task)
            else:
                task.status = TaskStatus.COMPLETED
                task.result = result
                self.completed_tasks += 1
                if self.on_task_complete:
                    await self._call_callback(self.on_task_complete, task)

            self._history.append(task)
            await self._save_task(task)

    async def cancel(self, task_id: str) -> bool:
        """Cancel a task"""
        async with self._lock:
            # Check queue
            for i, task in enumerate(self._queue):
                if task.id == task_id:
                    task = self._queue.pop(i)
                    task.status = TaskStatus.CANCELLED
                    self._history.append(task)
                    await self._save_task(task)
                    return True

            return False

    async def approve(self, task_id: str) -> bool:
        """Approve a task waiting for approval"""
        async with self._lock:
            for task in self._queue:
                if task.id == task_id and task.status == TaskStatus.WAITING_APPROVAL:
                    task.approved = True
                    task.status = TaskStatus.QUEUED
                    await self._save_task(task)
                    return True
            return False

    def get_task(self, task_id: str) -> Optional[Task]:
        """Get task by ID"""
        # Check running
        if task_id in self._running:
            return self._running[task_id]

        # Check queue
        for task in self._queue:
            if task.id == task_id:
                return task

        # Check history
        for task in self._history:
            if task.id == task_id:
                return task

        return None

    def get_pending(self) -> List[Task]:
        """Get all pending/queued tasks"""
        return [t for t in self._queue if t.status in (
            TaskStatus.PENDING, TaskStatus.QUEUED
        )]

    def get_running(self) -> List[Task]:
        """Get all running tasks"""
        return list(self._running.values())

    def get_waiting_approval(self) -> List[Task]:
        """Get tasks waiting for approval"""
        return [t for t in self._queue if t.status == TaskStatus.WAITING_APPROVAL]

    def get_history(self, limit: int = 50) -> List[Task]:
        """Get recent task history"""
        return self._history[-limit:]

    def get_stats(self) -> Dict[str, Any]:
        """Get queue statistics"""
        return {
            "pending": len(self._queue),
            "running": len(self._running),
            "completed": self.completed_tasks,
            "failed": self.failed_tasks,
            "total": self.total_tasks,
            "waiting_approval": len(self.get_waiting_approval())
        }

    def _sort_queue(self) -> None:
        """Sort queue by priority (highest first)"""
        self._queue.sort(key=lambda t: -t.priority.value)

    async def _save_task(self, task: Task) -> None:
        """Persist task to database"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                await db.execute(
                    """
                    INSERT OR REPLACE INTO tasks (id, data, status)
                    VALUES (?, ?, ?)
                    """,
                    (task.id, json.dumps(task.to_dict()), task.status.value)
                )
                await db.commit()
        except Exception as e:
            logger.error(f"Failed to save task {task.id}: {e}")

    async def _call_callback(self, callback: Callable, task: Task) -> None:
        """Call a callback safely"""
        try:
            if asyncio.iscoroutinefunction(callback):
                await callback(task)
            else:
                callback(task)
        except Exception as e:
            logger.error(f"Callback error: {e}")

    async def shutdown(self) -> None:
        """Shutdown the queue"""
        # Save all running tasks as pending for restart
        for task in self._running.values():
            task.status = TaskStatus.PENDING
            await self._save_task(task)

        logger.info("Task queue shutdown complete")
