"""
Browser Automation Tool

Web browser automation using Playwright.
Handles navigation, form filling, clicking, and content extraction.
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path
from dataclasses import dataclass

from .tools import Tool, ToolResult, ToolCategory

logger = logging.getLogger("specter.executor.browser")


@dataclass
class BrowserConfig:
    """Browser configuration"""
    browser_type: str = "firefox"  # firefox, chromium, webkit
    headless: bool = False  # SPECTER should see what it's doing
    slow_mo: int = 100  # Slow down for visibility
    viewport_width: int = 1920
    viewport_height: int = 1080
    user_data_dir: Optional[str] = None  # Persist sessions


class BrowserTool(Tool):
    """
    Browser automation tool using Playwright.

    Capabilities:
    - Navigate to URLs
    - Click elements
    - Fill forms
    - Extract content
    - Take screenshots
    - Handle multiple tabs
    - Login to sites
    """

    name = "browser"
    description = "Control web browsers - navigate, click, fill forms, extract content"
    category = ToolCategory.BROWSER
    requires_approval = False

    def __init__(self, config: Optional[BrowserConfig] = None):
        super().__init__()
        self.config = config or BrowserConfig()
        self.playwright = None
        self.browser = None
        self.context = None
        self.pages: Dict[str, Any] = {}  # tab_id -> page
        self.active_page = None

    async def initialize(self) -> bool:
        """
        Mark browser tool as ready (lazy initialization).

        The actual browser launch is deferred until first use
        to avoid opening Firefox on every SPECTER startup.
        """
        try:
            # Just verify playwright is available
            from playwright.async_api import async_playwright
            self.initialized = True
            logger.info(f"Browser tool ready (lazy init, will use {self.config.browser_type})")
            return True

        except ImportError:
            logger.error("Playwright not installed. Run: pip install playwright && playwright install")
            return False

    async def _ensure_browser(self) -> bool:
        """Launch browser if not already running (lazy initialization)"""
        if self.browser is not None:
            return True

        try:
            from playwright.async_api import async_playwright

            logger.info(f"Launching {self.config.browser_type} browser...")
            self.playwright = await async_playwright().start()

            # Launch browser based on config
            browser_launcher = getattr(
                self.playwright,
                self.config.browser_type,
                self.playwright.firefox
            )

            launch_options = {
                "headless": self.config.headless,
                "slow_mo": self.config.slow_mo
            }

            self.browser = await browser_launcher.launch(**launch_options)

            # Create context (can persist cookies/storage)
            context_options = {
                "viewport": {
                    "width": self.config.viewport_width,
                    "height": self.config.viewport_height
                }
            }

            if self.config.user_data_dir:
                # Persistent context for login sessions
                self.context = await browser_launcher.launch_persistent_context(
                    self.config.user_data_dir,
                    **launch_options,
                    **context_options
                )
            else:
                self.context = await self.browser.new_context(**context_options)

            # Create initial page
            page = await self.context.new_page()
            self.pages["main"] = page
            self.active_page = page

            logger.info(f"Browser launched: {self.config.browser_type}")
            return True

        except Exception as e:
            logger.error(f"Browser launch failed: {e}")
            return False

    async def execute(self, action: str, **kwargs) -> ToolResult:
        """
        Execute browser action.

        Actions:
        - navigate: Go to URL
        - click: Click element by selector
        - fill: Fill form field
        - type: Type text
        - get_text: Extract text from selector
        - get_page_content: Get full page text
        - screenshot: Take screenshot
        - new_tab: Open new tab
        - switch_tab: Switch to tab
        - close_tab: Close tab
        - wait: Wait for selector/time
        - scroll: Scroll page
        - get_links: Extract all links
        - find_elements: Find elements by text/selector
        """
        if not self.initialized:
            return ToolResult.fail("Browser tool not initialized")

        # Lazy launch browser on first use
        if not await self._ensure_browser():
            return ToolResult.fail("Failed to launch browser")

        self.execution_count += 1

        try:
            if action == "navigate":
                return await self._navigate(kwargs.get("url"))

            elif action == "click":
                return await self._click(
                    kwargs.get("selector"),
                    kwargs.get("text")
                )

            elif action == "fill":
                return await self._fill(
                    kwargs.get("selector"),
                    kwargs.get("value"),
                    kwargs.get("label")
                )

            elif action == "type":
                return await self._type(kwargs.get("text"))

            elif action == "get_text":
                return await self._get_text(kwargs.get("selector"))

            elif action == "get_page_content":
                return await self._get_page_content()

            elif action == "screenshot":
                return await self._screenshot(kwargs.get("path"))

            elif action == "new_tab":
                return await self._new_tab(kwargs.get("tab_id", "new"))

            elif action == "switch_tab":
                return await self._switch_tab(kwargs.get("tab_id"))

            elif action == "close_tab":
                return await self._close_tab(kwargs.get("tab_id"))

            elif action == "wait":
                return await self._wait(
                    kwargs.get("selector"),
                    kwargs.get("timeout", 5000)
                )

            elif action == "scroll":
                return await self._scroll(kwargs.get("direction", "down"))

            elif action == "get_links":
                return await self._get_links()

            elif action == "find_elements":
                return await self._find_elements(
                    kwargs.get("text"),
                    kwargs.get("selector")
                )

            elif action == "get_emails":
                return await self._get_emails()

            elif action == "press_key":
                return await self._press_key(kwargs.get("key"))

            else:
                return ToolResult.fail(f"Unknown action: {action}")

        except Exception as e:
            self.last_error = str(e)
            logger.error(f"Browser action {action} failed: {e}")
            return ToolResult.fail(str(e))

    async def _navigate(self, url: str) -> ToolResult:
        """Navigate to URL"""
        if not url:
            return ToolResult.fail("URL required")

        await self.active_page.goto(url, wait_until="domcontentloaded")
        title = await self.active_page.title()

        return ToolResult.ok(
            {"title": title, "url": self.active_page.url},
            action="navigate"
        )

    async def _click(
        self,
        selector: Optional[str] = None,
        text: Optional[str] = None
    ) -> ToolResult:
        """Click element by selector or text"""
        if text:
            # Find by text content
            element = self.active_page.get_by_text(text, exact=False)
            await element.first.click()
            return ToolResult.ok({"clicked": text}, action="click")

        if selector:
            await self.active_page.click(selector)
            return ToolResult.ok({"clicked": selector}, action="click")

        return ToolResult.fail("Selector or text required")

    async def _fill(
        self,
        selector: Optional[str] = None,
        value: str = "",
        label: Optional[str] = None
    ) -> ToolResult:
        """Fill form field"""
        if label:
            # Find by label text
            field = self.active_page.get_by_label(label)
            await field.fill(value)
            return ToolResult.ok({"filled": label}, action="fill")

        if selector:
            await self.active_page.fill(selector, value)
            return ToolResult.ok({"filled": selector}, action="fill")

        return ToolResult.fail("Selector or label required")

    async def _type(self, text: str) -> ToolResult:
        """Type text (simulates keyboard)"""
        await self.active_page.keyboard.type(text)
        return ToolResult.ok({"typed": len(text)}, action="type")

    async def _get_text(self, selector: str) -> ToolResult:
        """Extract text from element"""
        element = await self.active_page.query_selector(selector)
        if element:
            text = await element.inner_text()
            return ToolResult.ok({"text": text}, action="get_text")
        return ToolResult.fail(f"Element not found: {selector}")

    async def _get_page_content(self) -> ToolResult:
        """Get full page text content"""
        content = await self.active_page.inner_text("body")
        title = await self.active_page.title()
        url = self.active_page.url

        return ToolResult.ok({
            "title": title,
            "url": url,
            "content": content[:10000]  # Limit for context
        }, action="get_page_content")

    async def _screenshot(self, path: Optional[str] = None) -> ToolResult:
        """Take screenshot"""
        if not path:
            path = "/tmp/specter_screenshot.png"

        await self.active_page.screenshot(path=path, full_page=True)
        return ToolResult.ok({"path": path}, action="screenshot")

    async def _new_tab(self, tab_id: str) -> ToolResult:
        """Open new tab"""
        page = await self.context.new_page()
        self.pages[tab_id] = page
        self.active_page = page
        return ToolResult.ok({"tab_id": tab_id}, action="new_tab")

    async def _switch_tab(self, tab_id: str) -> ToolResult:
        """Switch to tab"""
        if tab_id in self.pages:
            self.active_page = self.pages[tab_id]
            await self.active_page.bring_to_front()
            return ToolResult.ok({"tab_id": tab_id}, action="switch_tab")
        return ToolResult.fail(f"Tab not found: {tab_id}")

    async def _close_tab(self, tab_id: Optional[str] = None) -> ToolResult:
        """Close tab"""
        if tab_id and tab_id in self.pages:
            await self.pages[tab_id].close()
            del self.pages[tab_id]
            # Switch to another tab if available
            if self.pages:
                self.active_page = list(self.pages.values())[0]
            return ToolResult.ok({"closed": tab_id}, action="close_tab")
        return ToolResult.fail("Tab not found")

    async def _wait(self, selector: Optional[str], timeout: int) -> ToolResult:
        """Wait for selector or time"""
        if selector:
            await self.active_page.wait_for_selector(selector, timeout=timeout)
            return ToolResult.ok({"waited_for": selector}, action="wait")

        await asyncio.sleep(timeout / 1000)
        return ToolResult.ok({"waited_ms": timeout}, action="wait")

    async def _scroll(self, direction: str) -> ToolResult:
        """Scroll page"""
        if direction == "down":
            await self.active_page.keyboard.press("PageDown")
        elif direction == "up":
            await self.active_page.keyboard.press("PageUp")
        elif direction == "top":
            await self.active_page.keyboard.press("Home")
        elif direction == "bottom":
            await self.active_page.keyboard.press("End")

        return ToolResult.ok({"scrolled": direction}, action="scroll")

    async def _get_links(self) -> ToolResult:
        """Extract all links from page"""
        links = await self.active_page.eval_on_selector_all(
            "a[href]",
            """elements => elements.map(el => ({
                text: el.innerText.trim().substring(0, 100),
                href: el.href
            }))"""
        )
        return ToolResult.ok({"links": links[:50]}, action="get_links")

    async def _find_elements(
        self,
        text: Optional[str] = None,
        selector: Optional[str] = None
    ) -> ToolResult:
        """Find elements matching criteria"""
        elements = []

        if text:
            locator = self.active_page.get_by_text(text, exact=False)
            count = await locator.count()
            for i in range(min(count, 10)):
                try:
                    el = locator.nth(i)
                    box = await el.bounding_box()
                    inner = await el.inner_text()
                    elements.append({
                        "index": i,
                        "text": inner[:100],
                        "visible": box is not None
                    })
                except:
                    pass

        if selector:
            els = await self.active_page.query_selector_all(selector)
            for i, el in enumerate(els[:10]):
                try:
                    inner = await el.inner_text()
                    elements.append({
                        "index": i,
                        "selector": selector,
                        "text": inner[:100]
                    })
                except:
                    pass

        return ToolResult.ok({"elements": elements}, action="find_elements")

    async def _get_emails(self) -> ToolResult:
        """Extract email-like content from Gmail inbox"""
        # Wait for inbox to load
        try:
            await self.active_page.wait_for_selector('[role="main"]', timeout=5000)
        except:
            pass

        # Get email rows
        emails = await self.active_page.eval_on_selector_all(
            'tr[jsaction*="click"]',
            """rows => rows.slice(0, 20).map(row => {
                const cells = row.querySelectorAll('td');
                return {
                    sender: cells[2]?.innerText?.trim() || '',
                    subject: cells[3]?.innerText?.trim() || '',
                    snippet: cells[4]?.innerText?.trim() || '',
                    date: cells[cells.length - 1]?.innerText?.trim() || ''
                };
            }).filter(e => e.sender || e.subject)"""
        )

        return ToolResult.ok({"emails": emails}, action="get_emails")

    async def _press_key(self, key: str) -> ToolResult:
        """Press keyboard key"""
        await self.active_page.keyboard.press(key)
        return ToolResult.ok({"pressed": key}, action="press_key")

    def get_schema(self) -> Dict[str, Any]:
        """Get tool schema for LLM"""
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "requires_approval": self.requires_approval,
            "actions": {
                "navigate": {"params": ["url"]},
                "click": {"params": ["selector", "text"]},
                "fill": {"params": ["selector", "value", "label"]},
                "type": {"params": ["text"]},
                "get_text": {"params": ["selector"]},
                "get_page_content": {"params": []},
                "screenshot": {"params": ["path"]},
                "new_tab": {"params": ["tab_id"]},
                "switch_tab": {"params": ["tab_id"]},
                "close_tab": {"params": ["tab_id"]},
                "wait": {"params": ["selector", "timeout"]},
                "scroll": {"params": ["direction"]},
                "get_links": {"params": []},
                "find_elements": {"params": ["text", "selector"]},
                "get_emails": {"params": []},
                "press_key": {"params": ["key"]}
            }
        }

    async def shutdown(self) -> None:
        """Close browser"""
        if self.context:
            await self.context.close()
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()

        self.initialized = False
        logger.info("Browser shutdown complete")
