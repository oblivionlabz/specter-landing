"""
EXECUTOR Tool System

Base classes for executable tools and the tool registry.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Type
from enum import Enum
import logging

logger = logging.getLogger("specter.executor.tools")


class ToolCategory(Enum):
    """Categories of tools"""
    BROWSER = "browser"
    FILESYSTEM = "filesystem"
    CODE = "code"
    SYSTEM = "system"
    SMART_HOME = "smart_home"
    COMMUNICATION = "communication"


@dataclass
class ToolResult:
    """Result from tool execution"""
    success: bool
    data: Any = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def ok(cls, data: Any = None, **metadata) -> "ToolResult":
        return cls(success=True, data=data, metadata=metadata)

    @classmethod
    def fail(cls, error: str, **metadata) -> "ToolResult":
        return cls(success=False, error=error, metadata=metadata)


class Tool(ABC):
    """
    Base class for all SPECTER tools.

    Tools are how SPECTER interacts with the world.
    Each tool has:
    - name: Unique identifier
    - description: What it does (for LLM context)
    - category: Type of tool
    - requires_approval: Whether SENTINEL must approve
    """

    name: str = "base_tool"
    description: str = "Base tool"
    category: ToolCategory = ToolCategory.SYSTEM
    requires_approval: bool = False

    def __init__(self):
        self.initialized = False
        self.execution_count = 0
        self.last_error: Optional[str] = None

    async def initialize(self) -> bool:
        """Initialize the tool. Override in subclasses."""
        self.initialized = True
        return True

    @abstractmethod
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute the tool with given parameters.

        Args:
            **kwargs: Tool-specific parameters

        Returns:
            ToolResult with success/failure and data
        """
        pass

    async def shutdown(self) -> None:
        """Cleanup resources. Override in subclasses."""
        self.initialized = False

    def get_schema(self) -> Dict[str, Any]:
        """
        Get the parameter schema for this tool.

        Override to provide parameter documentation for LLM.
        """
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "requires_approval": self.requires_approval,
            "parameters": {}
        }

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self.name}, initialized={self.initialized})"


class ToolRegistry:
    """
    Registry of all available tools.

    Provides tool discovery and lookup for the Executor.
    """

    def __init__(self):
        self._tools: Dict[str, Tool] = {}
        self._by_category: Dict[ToolCategory, List[str]] = {
            cat: [] for cat in ToolCategory
        }
        logger.info("Tool registry created")

    def register(self, tool: Tool) -> None:
        """Register a tool"""
        if tool.name in self._tools:
            logger.warning(f"Tool {tool.name} already registered, overwriting")

        self._tools[tool.name] = tool
        if tool.name not in self._by_category[tool.category]:
            self._by_category[tool.category].append(tool.name)

        logger.info(f"Registered tool: {tool.name} ({tool.category.value})")

    def unregister(self, name: str) -> bool:
        """Unregister a tool"""
        if name not in self._tools:
            return False

        tool = self._tools.pop(name)
        self._by_category[tool.category].remove(name)
        return True

    def get(self, name: str) -> Optional[Tool]:
        """Get a tool by name"""
        return self._tools.get(name)

    def list_tools(self, category: Optional[ToolCategory] = None) -> List[str]:
        """List all tool names, optionally filtered by category"""
        if category:
            return self._by_category.get(category, [])
        return list(self._tools.keys())

    def get_schemas(self) -> List[Dict[str, Any]]:
        """Get schemas for all tools (for LLM context)"""
        return [tool.get_schema() for tool in self._tools.values()]

    async def initialize_all(self) -> Dict[str, bool]:
        """Initialize all registered tools"""
        results = {}
        for name, tool in self._tools.items():
            try:
                results[name] = await tool.initialize()
            except Exception as e:
                logger.error(f"Failed to initialize {name}: {e}")
                results[name] = False
        return results

    async def shutdown_all(self) -> None:
        """Shutdown all tools"""
        for tool in self._tools.values():
            try:
                await tool.shutdown()
            except Exception as e:
                logger.error(f"Failed to shutdown {tool.name}: {e}")

    def __len__(self) -> int:
        return len(self._tools)


# Global registry instance
_global_registry: Optional[ToolRegistry] = None


def get_registry() -> ToolRegistry:
    """Get the global tool registry"""
    global _global_registry
    if _global_registry is None:
        _global_registry = ToolRegistry()
    return _global_registry


def reset_registry() -> None:
    """Reset the global registry (for testing)"""
    global _global_registry
    _global_registry = None
