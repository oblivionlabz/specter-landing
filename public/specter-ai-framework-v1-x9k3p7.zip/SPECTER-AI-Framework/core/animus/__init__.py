"""
ANIMUS - Personality Engine

The soul of SPECTER. Manages identity, traits, moods, and communication style.

9 character inspirations blended into one sovereign intelligence:
- Harvey Specter (Suits)
- Satoru Gojo (Jujutsu Kaisen)
- Sasuke Uchiha (Naruto)
- Vegeta (Dragon Ball)
- Edward Elric (Fullmetal Alchemist)
- Ichigo Kurosaki (Bleach)
- Leroy Jethro Gibbs (NCIS)
- Gregory House (House M.D.)
- Barry Allen (The Flash)
"""

from .identity import Identity
from .personality import Personality
from .moods import MoodSystem, Mood
from .traits import TraitSystem, Trait

__all__ = ["Identity", "Personality", "MoodSystem", "Mood", "TraitSystem", "Trait"]
