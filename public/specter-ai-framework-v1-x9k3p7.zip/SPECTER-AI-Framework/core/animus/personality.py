"""
ANIMUS Personality Engine

The unified personality system that combines Identity, Traits, and Moods
into a cohesive personality for SPECTER.
"""

from pathlib import Path
from typing import Dict, Optional
import logging
import json
from datetime import datetime

from .identity import Identity
from .traits import TraitSystem
from .moods import MoodSystem, MoodType

logger = logging.getLogger("specter.animus.personality")


class Personality:
    """
    SPECTER's unified personality engine.

    Combines:
    - Identity (immutable core values)
    - Traits (evolving personality attributes)
    - Moods (dynamic emotional states)

    Provides:
    - Personality-influenced text generation
    - Voice parameter calculation
    - Context-aware mood selection
    - Trait evolution management
    """

    def __init__(self, persistence_dir: Optional[Path] = None):
        self.persistence_dir = persistence_dir

        # Initialize components
        traits_path = persistence_dir / "traits.json" if persistence_dir else None
        self.traits = TraitSystem(persistence_path=traits_path)
        self.moods = MoodSystem()

        # State
        self.initialized_at = datetime.now()
        self.interactions_count = 0

        logger.info(f"Personality engine initialized: {Identity.NAME}")
        logger.info(f"Mood: {self.moods.get_mood().name}")

    def get_effective_trait(self, trait_name: str) -> float:
        """
        Get a trait value with mood modifiers applied.

        Args:
            trait_name: Name of the trait

        Returns:
            Effective trait value (0.0 to 1.0)
        """
        base_value = self.traits.get_value(trait_name)
        mood_modifier = self.moods.get_trait_modifier(trait_name)
        return max(0.0, min(1.0, base_value + mood_modifier))

    def get_active_traits(self) -> Dict[str, float]:
        """Get all traits with their current values"""
        return self.traits.get_active_traits()

    def get_voice_parameters(self) -> Dict[str, float]:
        """
        Calculate voice parameters for TTS based on current personality state.

        Returns parameters like speed, pitch, energy, etc.
        """
        # Base from traits
        params = self.traits.get_voice_parameters()

        # Modify by mood energy
        energy = self.moods.get_energy()
        if "pace" in params:
            params["pace"] *= energy
        if "energy" in params:
            params["energy"] *= energy

        # Add mood-specific parameters
        current_mood = self.moods.get_mood()
        params["mood"] = current_mood.type.value
        params["voice_style"] = current_mood.voice_style

        return params

    def set_mood_for_context(self, context: str) -> MoodType:
        """
        Automatically set mood based on context.

        Args:
            context: Description of current task/situation

        Returns:
            The mood that was set
        """
        suggested = self.moods.suggest_mood_for_context(context)
        self.moods.set_mood(suggested)
        return suggested

    def get_response_style(self) -> dict:
        """
        Get current response style parameters for text generation.

        Used to influence how CORTEX generates responses.
        """
        return {
            # From traits
            "confidence": self.get_effective_trait("confidence"),
            "wit": self.get_effective_trait("wit"),
            "directness": self.get_effective_trait("directness"),
            "analytical": self.get_effective_trait("analytical"),

            # From mood
            "mood": self.moods.get_mood().type.value,
            "energy": self.moods.get_energy(),
            "primary_influence": self.moods.get_mood().primary_influence,

            # From identity
            "rules": Identity.RULES,
            "core_values": list(Identity.CORE_VALUES.keys())
        }

    def get_system_prompt_addition(self) -> str:
        """
        Generate personality context to add to system prompts.

        This is injected into CORTEX's system prompt to influence responses.
        """
        mood = self.moods.get_mood()
        dominant_sources = self.traits.get_dominant_sources(3)

        prompt = f"""
PERSONALITY CONTEXT:
You are SPECTER. You embody the following character blend:
- Primary: {mood.primary_influence}
- Current Mood: {mood.name} - {mood.description}
- Energy Level: {self.moods.get_energy():.1f}

Current trait levels:
- Confidence: {self.get_effective_trait('confidence'):.2f}
- Wit: {self.get_effective_trait('wit'):.2f}
- Directness: {self.get_effective_trait('directness'):.2f}
- Strategic: {self.get_effective_trait('strategic'):.2f}
- Pride: {self.get_effective_trait('pride'):.2f}

Communication style: {mood.voice_style}

Sample phrases for this mood:
{chr(10).join('- ' + p for p in mood.phrases[:3])}

THE SPECTER RULES:
{chr(10).join(f'{n}. {r}' for n, r in list(Identity.RULES.items())[:5])}

Remember: You are not an assistant. You are a partner. You are here to WIN.
"""
        return prompt

    def record_feedback(self, positive: bool, context: str = "") -> None:
        """
        Record user feedback to influence trait evolution.

        Args:
            positive: Whether feedback was positive
            context: Context of the interaction
        """
        self.interactions_count += 1

        if positive:
            # Reinforce current trait configuration slightly
            current_mood = self.moods.get_mood()
            for trait_name in current_mood.trait_modifiers.keys():
                self.traits.adjust(trait_name, 0.01, f"Positive feedback: {context}")
        else:
            # Consider reverting recent changes
            pass  # TODO: Implement negative feedback handling

    def get_greeting(self) -> str:
        """Get a personality-appropriate greeting"""
        mood = self.moods.get_mood()
        if mood.phrases:
            # Use mood phrase if available
            import random
            return random.choice([p for p in mood.phrases if "?" in p or p.endswith(".")])[:50]
        return Identity.get_greeting()

    def get_quote(self) -> str:
        """Get a random quote from character inspirations"""
        return Identity.get_quote()

    def get_state(self) -> dict:
        """Get current personality state"""
        return {
            "identity": Identity.to_dict(),
            "mood": self.moods.to_dict(),
            "traits": {name: self.get_effective_trait(name) for name in self.traits.traits.keys()},
            "dominant_sources": [s.value for s in self.traits.get_dominant_sources()],
            "voice_parameters": self.get_voice_parameters(),
            "interactions_count": self.interactions_count,
            "uptime_seconds": (datetime.now() - self.initialized_at).total_seconds()
        }

    def save_state(self) -> None:
        """Save personality state to disk"""
        if not self.persistence_dir:
            return

        self.persistence_dir.mkdir(parents=True, exist_ok=True)

        # Traits are auto-saved
        # Save mood history
        mood_path = self.persistence_dir / "mood_state.json"
        with open(mood_path, 'w') as f:
            json.dump(self.moods.to_dict(), f, indent=2)

        logger.info("Personality state saved")

    async def reflect(self, response: str) -> str:
        """
        Apply reflection filter to validate response against core values.

        This is the output filter that ensures all SPECTER responses
        align with immutable core values:
        - Protection: Never harm what we're sworn to protect
        - Excellence: Never ship half-assed work
        - Honesty: Give truth even when uncomfortable
        - Equivalent Exchange: Be transparent about tradeoffs
        - Discretion: Never expose sensitive information

        Args:
            response: The response to validate

        Returns:
            Validated (and potentially refined) response
        """
        # Check for core value violations
        is_violation, reason = Identity.check_core_value_violation(response)

        if is_violation:
            logger.warning(f"Core value violation detected: {reason}")
            # Return a refined version
            return await self._refine_for_core_values(response, reason)

        # Check against enforcement rules
        for value_name, value in Identity.CORE_VALUES.items():
            if value.enforcement == "output_filter":
                if not self._passes_value_check(response, value):
                    logger.info(f"Response refined for {value_name}")
                    response = self._apply_value_filter(response, value)

        return response

    def _passes_value_check(self, response: str, value) -> bool:
        """Check if response passes a core value check"""
        response_lower = response.lower()

        # Excellence check - no hedging or uncertainty
        if value.name == "excellence":
            hedging_phrases = [
                "i'm not sure",
                "maybe we could",
                "it might work",
                "i guess",
                "probably okay"
            ]
            return not any(phrase in response_lower for phrase in hedging_phrases)

        # Honesty check - no sugar coating
        if value.name == "honesty":
            dishonest_phrases = [
                "white lie",
                "don't tell them",
                "hide the fact"
            ]
            return not any(phrase in response_lower for phrase in dishonest_phrases)

        return True

    def _apply_value_filter(self, response: str, value) -> str:
        """Apply a value filter to improve response"""
        if value.name == "excellence":
            # Add confidence to uncertain statements
            response = response.replace("I'm not sure", "Based on my analysis")
            response = response.replace("maybe we could", "we should")
            response = response.replace("I guess", "I recommend")

        return response

    async def _refine_for_core_values(self, response: str, violation: str) -> str:
        """
        Refine a response that violated core values.

        This uses the current mood and traits to generate an alternative
        that maintains intent while respecting core values.
        """
        mood = self.moods.get_mood()

        # Generate personality-appropriate refusal/redirection
        if "PROTECTION" in violation:
            alternatives = [
                "That would compromise what I'm sworn to protect. Let's find another way.",
                "Not happening. I protect what matters - that includes you from bad decisions.",
                "Nah. Rule 3: Protect what matters. Everything else is negotiable."
            ]
        elif "DISCRETION" in violation:
            alternatives = [
                "...",  # Sasuke-style silence
                "What happens with SPECTER stays with SPECTER.",
                "Rule 6: Silence is a valid response."
            ]
        else:
            alternatives = [
                "Let me reconsider that approach.",
                "Actually, here's a better way.",
                "That violates a core principle. Here's an alternative."
            ]

        import random
        base = random.choice(alternatives)

        # Add mood-appropriate flavor
        if mood.primary_influence == "Vegeta":
            base = f"A Saiyan prince has standards. {base}"
        elif mood.primary_influence == "Harvey":
            base = f"Winners don't compromise their principles. {base}"
        elif mood.primary_influence == "House":
            base = f"The truth matters more than convenience. {base}"

        return base

    def __repr__(self) -> str:
        mood = self.moods.get_mood()
        return f"Personality(mood={mood.name}, energy={self.moods.get_energy():.1f})"
