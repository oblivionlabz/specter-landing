"""
IRIS OCR Engine

Extracts text from screenshots using Surya or Tesseract.
"""

from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass, field
import logging
import asyncio
from datetime import datetime
from PIL import Image
import numpy as np

logger = logging.getLogger("specter.iris.ocr")


@dataclass
class TextBlock:
    """A detected text block"""
    text: str
    confidence: float
    bbox: Tuple[int, int, int, int]  # x, y, width, height
    line_num: int


@dataclass
class OCRResult:
    """Result of OCR processing"""
    full_text: str
    blocks: List[TextBlock]
    confidence: float
    processing_time: float
    timestamp: datetime
    language: str = "en"


class OCREngine:
    """
    OCR engine for text extraction.

    Supports:
    - Surya OCR (GPU accelerated, multilingual)
    - Tesseract (fallback)
    - Confidence scoring
    - Bounding box detection
    """

    def __init__(
        self,
        engine: str = "surya",
        confidence_threshold: float = 0.8,
        language: str = "en"
    ):
        self.engine_name = engine
        self.confidence_threshold = confidence_threshold
        self.language = language

        self.model = None
        self.initialized = False

        logger.info(f"OCR engine created: {engine}")

    async def initialize(self) -> bool:
        """Initialize the OCR engine"""
        if self.initialized:
            return True

        try:
            if self.engine_name == "surya":
                try:
                    from surya.ocr import run_ocr
                    from surya.model.detection import segformer
                    from surya.model.recognition import model as rec_model

                    loop = asyncio.get_event_loop()

                    # Load models
                    self.det_model = await loop.run_in_executor(
                        None, segformer.load_model
                    )
                    self.det_processor = await loop.run_in_executor(
                        None, segformer.load_processor
                    )
                    self.rec_model = await loop.run_in_executor(
                        None, rec_model.load_model
                    )
                    self.rec_processor = await loop.run_in_executor(
                        None, rec_model.load_processor
                    )

                    self.engine = "surya"
                    logger.info("Surya OCR loaded")

                except ImportError:
                    logger.warning("Surya not available, falling back to Tesseract")
                    self.engine_name = "tesseract"

            if self.engine_name == "tesseract":
                try:
                    import pytesseract
                    pytesseract.get_tesseract_version()
                    self.engine = "tesseract"
                    logger.info("Tesseract OCR loaded")

                except Exception as e:
                    logger.error(f"Tesseract not available: {e}")
                    return False

            self.initialized = True
            return True

        except Exception as e:
            logger.error(f"Failed to initialize OCR: {e}")
            return False

    async def extract_text(
        self,
        image: Image.Image,
        detect_layout: bool = True
    ) -> Optional[OCRResult]:
        """
        Extract text from image.

        Args:
            image: PIL Image to process
            detect_layout: Whether to detect text layout/blocks

        Returns:
            OCRResult with extracted text
        """
        if not self.initialized:
            await self.initialize()

        start_time = datetime.now()

        try:
            if self.engine == "surya":
                result = await self._extract_surya(image, detect_layout)
            else:
                result = await self._extract_tesseract(image, detect_layout)

            if result:
                result.processing_time = (
                    datetime.now() - start_time
                ).total_seconds()

            return result

        except Exception as e:
            logger.error(f"OCR extraction failed: {e}")
            return None

    async def _extract_surya(
        self,
        image: Image.Image,
        detect_layout: bool
    ) -> Optional[OCRResult]:
        """Extract using Surya OCR"""
        from surya.ocr import run_ocr

        loop = asyncio.get_event_loop()

        # Run OCR
        results = await loop.run_in_executor(
            None,
            lambda: run_ocr(
                [image],
                [self.det_model, self.det_processor],
                self.rec_model,
                self.rec_processor,
                langs=[[self.language]]
            )
        )

        if not results or not results[0].text_lines:
            return OCRResult(
                full_text="",
                blocks=[],
                confidence=0.0,
                processing_time=0.0,
                timestamp=datetime.now()
            )

        # Process results
        blocks = []
        confidences = []

        for i, line in enumerate(results[0].text_lines):
            if line.confidence >= self.confidence_threshold:
                bbox = line.bbox
                blocks.append(TextBlock(
                    text=line.text,
                    confidence=line.confidence,
                    bbox=(
                        int(bbox[0]), int(bbox[1]),
                        int(bbox[2] - bbox[0]), int(bbox[3] - bbox[1])
                    ),
                    line_num=i
                ))
                confidences.append(line.confidence)

        full_text = "\n".join(b.text for b in blocks)
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0

        return OCRResult(
            full_text=full_text,
            blocks=blocks,
            confidence=avg_confidence,
            processing_time=0.0,
            timestamp=datetime.now(),
            language=self.language
        )

    async def _extract_tesseract(
        self,
        image: Image.Image,
        detect_layout: bool
    ) -> Optional[OCRResult]:
        """Extract using Tesseract"""
        import pytesseract

        loop = asyncio.get_event_loop()

        if detect_layout:
            # Get detailed data
            data = await loop.run_in_executor(
                None,
                lambda: pytesseract.image_to_data(
                    image,
                    lang=self.language,
                    output_type=pytesseract.Output.DICT
                )
            )

            blocks = []
            confidences = []

            n_boxes = len(data['text'])
            for i in range(n_boxes):
                conf = float(data['conf'][i])
                text = data['text'][i].strip()

                if conf >= self.confidence_threshold * 100 and text:
                    blocks.append(TextBlock(
                        text=text,
                        confidence=conf / 100.0,
                        bbox=(
                            data['left'][i],
                            data['top'][i],
                            data['width'][i],
                            data['height'][i]
                        ),
                        line_num=data['line_num'][i]
                    ))
                    confidences.append(conf / 100.0)

            full_text = " ".join(b.text for b in blocks)
            avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0

        else:
            # Simple extraction
            text = await loop.run_in_executor(
                None,
                lambda: pytesseract.image_to_string(image, lang=self.language)
            )

            full_text = text.strip()
            blocks = [TextBlock(
                text=full_text,
                confidence=1.0,
                bbox=(0, 0, image.width, image.height),
                line_num=0
            )] if full_text else []
            avg_confidence = 1.0 if full_text else 0.0

        return OCRResult(
            full_text=full_text,
            blocks=blocks,
            confidence=avg_confidence,
            processing_time=0.0,
            timestamp=datetime.now(),
            language=self.language
        )

    async def extract_from_file(self, path: Path) -> Optional[OCRResult]:
        """Extract text from image file"""
        try:
            image = Image.open(path)
            return await self.extract_text(image)
        except Exception as e:
            logger.error(f"Failed to load image: {e}")
            return None

    async def extract_from_numpy(self, array: np.ndarray) -> Optional[OCRResult]:
        """Extract text from numpy array"""
        try:
            image = Image.fromarray(array)
            return await self.extract_text(image)
        except Exception as e:
            logger.error(f"Failed to convert array: {e}")
            return None

    async def shutdown(self) -> None:
        """Shutdown OCR engine"""
        if self.engine == "surya":
            if hasattr(self, 'det_model'):
                del self.det_model
            if hasattr(self, 'rec_model'):
                del self.rec_model

        self.initialized = False
        logger.info("OCR engine shutdown")
