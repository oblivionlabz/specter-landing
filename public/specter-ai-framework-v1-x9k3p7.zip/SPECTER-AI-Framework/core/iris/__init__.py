"""
IRIS - SPECTER's Vision System

Screen capture, OCR, and visual understanding.
"I see what others miss." - Diagnostic mode
"""

from .capture import ScreenCapture, Screenshot
from .ocr import OCREngine, OCRResult
from .vision_manager import VisionManager

__all__ = [
    "ScreenCapture",
    "Screenshot",
    "OCREngine",
    "OCRResult",
    "VisionManager"
]
