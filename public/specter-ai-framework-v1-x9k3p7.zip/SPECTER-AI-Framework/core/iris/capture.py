"""
IRIS Screen Capture

Captures screenshots for visual analysis.
"""

from pathlib import Path
from typing import Optional, List, Tuple, Dict, Any
from dataclasses import dataclass
import logging
import asyncio
from datetime import datetime
import numpy as np
from PIL import Image
import io

logger = logging.getLogger("specter.iris.capture")


@dataclass
class Screenshot:
    """A captured screenshot"""
    image: Image.Image
    timestamp: datetime
    monitor: int
    region: Optional[Tuple[int, int, int, int]]  # x, y, width, height
    hash_value: str


class ScreenCapture:
    """
    Screen capture system using mss.

    Features:
    - Multi-monitor support
    - Region capture
    - Change detection
    - Continuous capture mode
    """

    def __init__(
        self,
        interval_ms: int = 1000,
        change_threshold: float = 0.15
    ):
        self.interval_ms = interval_ms
        self.change_threshold = change_threshold

        self.sct = None
        self.monitors: List[Dict] = []
        self.last_screenshot: Optional[Screenshot] = None
        self.capturing = False

        self._capture_task = None
        self._change_callbacks: List = []

        logger.info("Screen capture initialized")

    async def initialize(self) -> bool:
        """Initialize screen capture"""
        try:
            import mss

            self.sct = mss.mss()
            self.monitors = self.sct.monitors

            logger.info(f"Screen capture ready: {len(self.monitors) - 1} monitors")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize screen capture: {e}")
            return False

    def get_monitors(self) -> List[Dict]:
        """Get list of available monitors"""
        return self.monitors[1:]  # Skip combined monitor

    async def capture(
        self,
        monitor: int = 1,
        region: Optional[Tuple[int, int, int, int]] = None
    ) -> Optional[Screenshot]:
        """
        Capture a screenshot.

        Args:
            monitor: Monitor index (1-based)
            region: Optional region (x, y, width, height)

        Returns:
            Screenshot object
        """
        if not self.sct:
            await self.initialize()

        try:
            if region:
                capture_area = {
                    "left": region[0],
                    "top": region[1],
                    "width": region[2],
                    "height": region[3]
                }
            else:
                if monitor < len(self.monitors):
                    capture_area = self.monitors[monitor]
                else:
                    capture_area = self.monitors[1]

            # Capture
            loop = asyncio.get_event_loop()
            sct_img = await loop.run_in_executor(
                None,
                lambda: self.sct.grab(capture_area)
            )

            # Convert to PIL Image
            img = Image.frombytes(
                "RGB",
                (sct_img.width, sct_img.height),
                sct_img.rgb
            )

            # Calculate hash for change detection
            img_hash = self._calculate_hash(img)

            screenshot = Screenshot(
                image=img,
                timestamp=datetime.now(),
                monitor=monitor,
                region=region,
                hash_value=img_hash
            )

            self.last_screenshot = screenshot
            return screenshot

        except Exception as e:
            logger.error(f"Capture failed: {e}")
            return None

    def _calculate_hash(self, img: Image.Image) -> str:
        """Calculate perceptual hash for image comparison"""
        # Resize to small image for fast comparison
        small = img.resize((16, 16), Image.Resampling.LANCZOS)
        gray = small.convert("L")

        # Calculate average
        pixels = list(gray.getdata())
        avg = sum(pixels) / len(pixels)

        # Generate hash
        hash_bits = "".join("1" if p > avg else "0" for p in pixels)
        return hex(int(hash_bits, 2))[2:]

    def detect_change(
        self,
        current: Screenshot,
        previous: Optional[Screenshot] = None
    ) -> Tuple[bool, float]:
        """
        Detect if significant change occurred.

        Returns:
            (changed, difference_ratio)
        """
        if previous is None:
            previous = self.last_screenshot

        if previous is None:
            return True, 1.0

        # Compare hashes
        if current.hash_value == previous.hash_value:
            return False, 0.0

        # Calculate hamming distance
        h1 = int(current.hash_value, 16)
        h2 = int(previous.hash_value, 16)
        xor = h1 ^ h2
        diff = bin(xor).count("1") / 256.0

        return diff > self.change_threshold, diff

    def on_change(self, callback) -> None:
        """Register callback for screen changes"""
        self._change_callbacks.append(callback)

    async def start_continuous(
        self,
        monitor: int = 1,
        on_change_only: bool = True
    ) -> None:
        """Start continuous screen capture"""
        if self.capturing:
            return

        self.capturing = True
        self._capture_task = asyncio.create_task(
            self._continuous_loop(monitor, on_change_only)
        )
        logger.info("Continuous capture started")

    async def stop_continuous(self) -> None:
        """Stop continuous capture"""
        self.capturing = False
        if self._capture_task:
            self._capture_task.cancel()
            try:
                await self._capture_task
            except asyncio.CancelledError:
                pass
        logger.info("Continuous capture stopped")

    async def _continuous_loop(
        self,
        monitor: int,
        on_change_only: bool
    ) -> None:
        """Continuous capture loop"""
        previous = None

        while self.capturing:
            try:
                screenshot = await self.capture(monitor)

                if screenshot:
                    if on_change_only:
                        changed, diff = self.detect_change(screenshot, previous)
                        if changed:
                            await self._notify_change(screenshot, diff)
                    else:
                        await self._notify_change(screenshot, 1.0)

                    previous = screenshot

                await asyncio.sleep(self.interval_ms / 1000.0)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Capture loop error: {e}")
                await asyncio.sleep(1.0)

    async def _notify_change(
        self,
        screenshot: Screenshot,
        diff: float
    ) -> None:
        """Notify callbacks of screen change"""
        for callback in self._change_callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(screenshot, diff)
                else:
                    callback(screenshot, diff)
            except Exception as e:
                logger.error(f"Change callback error: {e}")

    async def save_screenshot(
        self,
        screenshot: Screenshot,
        path: Path,
        format: str = "PNG"
    ) -> bool:
        """Save screenshot to file"""
        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: screenshot.image.save(str(path), format)
            )
            return True
        except Exception as e:
            logger.error(f"Failed to save screenshot: {e}")
            return False

    def to_numpy(self, screenshot: Screenshot) -> np.ndarray:
        """Convert screenshot to numpy array"""
        return np.array(screenshot.image)

    def to_base64(self, screenshot: Screenshot) -> str:
        """Convert screenshot to base64 string"""
        import base64
        buffer = io.BytesIO()
        screenshot.image.save(buffer, format="PNG")
        return base64.b64encode(buffer.getvalue()).decode()

    async def shutdown(self) -> None:
        """Shutdown screen capture"""
        await self.stop_continuous()
        if self.sct:
            self.sct.close()
            self.sct = None
        logger.info("Screen capture shutdown")
