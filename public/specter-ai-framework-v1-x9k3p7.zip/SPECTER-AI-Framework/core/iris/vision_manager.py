"""
IRIS Vision Manager

Orchestrates screen capture and OCR for visual understanding.
"""

from pathlib import Path
from typing import Optional, List, Dict, Any, Callable
import logging
import asyncio
from datetime import datetime
from PIL import Image

from .capture import ScreenCapture, Screenshot
from .ocr import OCREngine, OCRResult

logger = logging.getLogger("specter.iris.vision_manager")


class VisionManager:
    """
    Unified vision system manager.

    Coordinates:
    - Screen capture
    - OCR text extraction
    - Change detection
    - Visual context for CORTEX
    """

    def __init__(
        self,
        capture_interval_ms: int = 1000,
        change_threshold: float = 0.15,
        ocr_engine: str = "surya",
        ocr_confidence: float = 0.8
    ):
        self.capture = ScreenCapture(
            interval_ms=capture_interval_ms,
            change_threshold=change_threshold
        )
        self.ocr = OCREngine(
            engine=ocr_engine,
            confidence_threshold=ocr_confidence
        )

        self.initialized = False
        self.monitoring = False

        # Current state
        self.last_screenshot: Optional[Screenshot] = None
        self.last_ocr: Optional[OCRResult] = None
        self.current_context: str = ""

        # Callbacks
        self.on_screen_change: Optional[Callable] = None
        self.on_text_detected: Optional[Callable] = None

        # Stats
        self.captures_count = 0
        self.ocr_count = 0

        logger.info("Vision manager created")

    async def initialize(self) -> bool:
        """Initialize vision components"""
        if self.initialized:
            return True

        logger.info("Initializing vision system...")

        capture_ok = await self.capture.initialize()
        if capture_ok:
            logger.info("  [+] Screen capture initialized")
        else:
            logger.warning("  [!] Screen capture failed")

        ocr_ok = await self.ocr.initialize()
        if ocr_ok:
            logger.info("  [+] OCR engine initialized")
        else:
            logger.warning("  [!] OCR engine failed")

        # Register change callback
        self.capture.on_change(self._on_screen_change)

        self.initialized = capture_ok
        return self.initialized

    async def capture_screen(
        self,
        monitor: int = 1,
        extract_text: bool = True
    ) -> Dict[str, Any]:
        """
        Capture current screen and optionally extract text.

        Args:
            monitor: Monitor index
            extract_text: Whether to run OCR

        Returns:
            Dict with screenshot and optional OCR result
        """
        result = {
            "screenshot": None,
            "ocr": None,
            "text": "",
            "timestamp": datetime.now()
        }

        # Capture screen
        screenshot = await self.capture.capture(monitor)
        if screenshot:
            self.last_screenshot = screenshot
            self.captures_count += 1
            result["screenshot"] = screenshot

            # Extract text if requested
            if extract_text:
                ocr_result = await self.ocr.extract_text(screenshot.image)
                if ocr_result:
                    self.last_ocr = ocr_result
                    self.ocr_count += 1
                    result["ocr"] = ocr_result
                    result["text"] = ocr_result.full_text
                    self.current_context = ocr_result.full_text

        return result

    async def get_screen_context(self) -> str:
        """
        Get current screen context as text.

        Returns:
            Text content visible on screen
        """
        result = await self.capture_screen(extract_text=True)
        return result.get("text", "")

    async def start_monitoring(
        self,
        monitor: int = 1,
        on_change_only: bool = True
    ) -> None:
        """Start continuous screen monitoring"""
        if self.monitoring:
            return

        if not self.initialized:
            await self.initialize()

        self.monitoring = True
        await self.capture.start_continuous(monitor, on_change_only)
        logger.info("Screen monitoring started")

    async def stop_monitoring(self) -> None:
        """Stop screen monitoring"""
        self.monitoring = False
        await self.capture.stop_continuous()
        logger.info("Screen monitoring stopped")

    async def _on_screen_change(
        self,
        screenshot: Screenshot,
        diff: float
    ) -> None:
        """Handle screen change detection"""
        self.last_screenshot = screenshot
        self.captures_count += 1

        # Extract text from changed screen
        ocr_result = await self.ocr.extract_text(screenshot.image)
        if ocr_result:
            self.last_ocr = ocr_result
            self.ocr_count += 1
            self.current_context = ocr_result.full_text

            if self.on_text_detected:
                try:
                    if asyncio.iscoroutinefunction(self.on_text_detected):
                        await self.on_text_detected(ocr_result)
                    else:
                        self.on_text_detected(ocr_result)
                except Exception as e:
                    logger.error(f"Text callback error: {e}")

        if self.on_screen_change:
            try:
                if asyncio.iscoroutinefunction(self.on_screen_change):
                    await self.on_screen_change(screenshot, diff)
                else:
                    self.on_screen_change(screenshot, diff)
            except Exception as e:
                logger.error(f"Screen change callback error: {e}")

    async def find_text_on_screen(
        self,
        search_text: str,
        case_sensitive: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Find occurrences of text on screen.

        Args:
            search_text: Text to find
            case_sensitive: Case sensitive search

        Returns:
            List of matches with locations
        """
        # Capture and OCR if needed
        if not self.last_ocr:
            await self.capture_screen(extract_text=True)

        if not self.last_ocr:
            return []

        matches = []
        search = search_text if case_sensitive else search_text.lower()

        for block in self.last_ocr.blocks:
            text = block.text if case_sensitive else block.text.lower()
            if search in text:
                matches.append({
                    "text": block.text,
                    "bbox": block.bbox,
                    "confidence": block.confidence,
                    "line": block.line_num
                })

        return matches

    async def describe_screen(self) -> str:
        """
        Generate a text description of current screen content.

        Returns:
            Human-readable description
        """
        result = await self.capture_screen(extract_text=True)

        if not result["text"]:
            return "Screen appears to be empty or unable to extract text."

        # Summarize content
        text = result["text"]
        lines = text.split("\n")
        non_empty_lines = [l.strip() for l in lines if l.strip()]

        description = f"Screen contains {len(non_empty_lines)} lines of text.\n"

        if len(non_empty_lines) <= 10:
            description += "Content:\n" + "\n".join(non_empty_lines)
        else:
            description += "First 5 lines:\n" + "\n".join(non_empty_lines[:5])
            description += f"\n... and {len(non_empty_lines) - 5} more lines."

        return description

    async def save_screenshot(
        self,
        path: Path,
        include_ocr: bool = True
    ) -> bool:
        """Save current screenshot and optional OCR data"""
        if not self.last_screenshot:
            await self.capture_screen()

        if not self.last_screenshot:
            return False

        success = await self.capture.save_screenshot(self.last_screenshot, path)

        if success and include_ocr and self.last_ocr:
            ocr_path = path.with_suffix(".txt")
            ocr_path.write_text(self.last_ocr.full_text)

        return success

    def get_stats(self) -> Dict[str, Any]:
        """Get vision system statistics"""
        return {
            "initialized": self.initialized,
            "monitoring": self.monitoring,
            "captures": self.captures_count,
            "ocr_runs": self.ocr_count,
            "monitors": len(self.capture.monitors) - 1 if self.capture.monitors else 0,
            "current_context_length": len(self.current_context),
            "last_capture": self.last_screenshot.timestamp if self.last_screenshot else None
        }

    async def shutdown(self) -> None:
        """Shutdown vision system"""
        logger.info("Shutting down vision system...")

        await self.stop_monitoring()
        await self.capture.shutdown()
        await self.ocr.shutdown()

        self.initialized = False
        logger.info("Vision system shutdown complete")
