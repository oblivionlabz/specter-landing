"""
CORTEX ReAct Engine

Implements the Reason + Act pattern for SPECTER's intelligence loop.
Based on Antonio Gulli's "Agentic Design Patterns" (Springer 2025).

The ReAct loop:
1. THOUGHT - Reason about what to do
2. ACTION - Execute tool or generate response
3. OBSERVATION - Process result
4. REFLECTION - Validate against core values
5. MEMORY - Store observation
6. REPEAT or OUTPUT

"I don't have dreams. I have goals." - Harvey Specter
"""

import asyncio
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Callable, Tuple

from .engine import CortexEngine, InferenceRequest, InferenceResponse

logger = logging.getLogger("specter.cortex.react")


class ActionType(Enum):
    """Types of actions the agent can take"""
    RESPOND = auto()  # Generate a response
    TOOL_USE = auto()  # Execute a tool
    SEARCH = auto()    # Search memory
    REFLECT = auto()   # Self-reflection
    DELEGATE = auto()  # Delegate to sub-agent


@dataclass
class Thought:
    """A reasoning step"""
    content: str
    action_type: ActionType
    confidence: float = 0.0
    tool_name: Optional[str] = None
    tool_params: Optional[Dict[str, Any]] = None
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class Action:
    """An action to execute"""
    type: ActionType
    tool_name: Optional[str] = None
    tool_params: Dict[str, Any] = field(default_factory=dict)
    requires_approval: bool = False


@dataclass
class Observation:
    """Result of an action"""
    content: str
    success: bool
    source: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ReActStep:
    """A single step in the ReAct loop"""
    thought: Thought
    action: Optional[Action]
    observation: Optional[Observation]
    reflection: Optional[str]
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class ReActContext:
    """Context for a ReAct session"""
    input: str
    steps: List[ReActStep] = field(default_factory=list)
    final_response: Optional[str] = None
    total_tokens: int = 0
    start_time: datetime = field(default_factory=datetime.now)


class ReActEngine:
    """
    SPECTER's ReAct (Reason + Act) intelligence engine.

    This wraps CortexEngine and adds:
    - Iterative reasoning loop
    - Tool use planning and execution
    - Memory retrieval and storage
    - Reflection against core values
    - Multi-step task completion

    The ReAct pattern enables SPECTER to:
    - Break down complex tasks
    - Use tools strategically
    - Learn from observations
    - Self-correct mistakes
    """

    REACT_SYSTEM_PROMPT = """You are SPECTER's reasoning engine. For each user input, think step by step:

1. THOUGHT: Analyze what needs to be done. Consider:
   - What is the user asking?
   - Do I need to use a tool?
   - What information do I need?

2. ACTION: Decide on an action:
   - RESPOND: If you can answer directly
   - TOOL: If you need to execute a tool (specify which one)
   - SEARCH: If you need to retrieve from memory
   - REFLECT: If you need to reconsider

3. Format your response as:
THOUGHT: <your reasoning>
ACTION: <action_type>
[TOOL: <tool_name>]
[PARAMS: <json params>]

Or if ready to respond:
THOUGHT: <your reasoning>
ACTION: RESPOND
RESPONSE: <your final response>
"""

    MAX_ITERATIONS = 10  # Prevent infinite loops

    def __init__(
        self,
        cortex: CortexEngine,
        executor: Optional[Any] = None,
        memory: Optional[Any] = None,
        personality: Optional[Any] = None,
        tool_schemas: Optional[List[Dict]] = None
    ):
        self.cortex = cortex
        self.executor = executor
        self.memory = memory
        self.personality = personality
        self.tool_schemas = tool_schemas or []

        # Callbacks
        self.on_thought: Optional[Callable[[Thought], None]] = None
        self.on_action: Optional[Callable[[Action], None]] = None
        self.on_observation: Optional[Callable[[Observation], None]] = None

        # State
        self.current_context: Optional[ReActContext] = None
        self.total_sessions = 0
        self.total_steps = 0

        logger.info("ReAct Engine initialized")

    async def process(self, input: str, context: Optional[str] = None) -> str:
        """
        Process an input through the ReAct loop.

        Args:
            input: User input to process
            context: Optional additional context

        Returns:
            Final response after reasoning and actions
        """
        self.current_context = ReActContext(input=input)
        self.total_sessions += 1

        # Build initial prompt with context
        full_input = input
        if context:
            full_input = f"{context}\n\nUser: {input}"

        # Add memory context if available
        if self.memory:
            memory_context = await self._get_memory_context(input)
            if memory_context:
                full_input = f"{memory_context}\n\n{full_input}"

        # Add personality context
        personality_context = ""
        if self.personality:
            personality_context = self.personality.get_system_prompt_addition()

        # ReAct loop
        iteration = 0
        while iteration < self.MAX_ITERATIONS:
            iteration += 1
            self.total_steps += 1

            # Generate thought and action
            step = await self._react_step(full_input, personality_context)
            self.current_context.steps.append(step)

            # Callback
            if self.on_thought:
                self.on_thought(step.thought)

            # Check if we have a final response
            if step.thought.action_type == ActionType.RESPOND:
                response = await self._extract_response(step)

                # Apply reflection
                validated = await self._reflect(response)
                self.current_context.final_response = validated

                # Store in memory
                await self._store_observation(input, validated)

                return validated

            # Execute action
            if step.action:
                if self.on_action:
                    self.on_action(step.action)

                observation = await self._execute_action(step.action)
                step.observation = observation

                if self.on_observation:
                    self.on_observation(observation)

                # Add observation to context for next iteration
                full_input = self._build_continuation_prompt(
                    input, step.thought, observation
                )

        # Max iterations reached
        logger.warning(f"ReAct loop reached max iterations ({self.MAX_ITERATIONS})")
        return await self._generate_fallback_response(input)

    async def _react_step(
        self,
        input: str,
        personality_context: str
    ) -> ReActStep:
        """Execute one step of the ReAct loop"""

        # Build system prompt with tool schemas
        system_prompt = self.REACT_SYSTEM_PROMPT
        if self.tool_schemas:
            tool_list = "\n".join([
                f"- {t['name']}: {t.get('description', '')}"
                for t in self.tool_schemas
            ])
            system_prompt += f"\n\nAvailable tools:\n{tool_list}"

        system_prompt = f"{personality_context}\n\n{system_prompt}"

        # Generate reasoning
        request = InferenceRequest(
            prompt=input,
            system_prompt=system_prompt,
            max_tokens=2048,
            temperature=0.7
        )

        response = await self.cortex.generate(request)
        self.current_context.total_tokens += response.tokens_used

        # Parse response into thought and action
        thought, action = self._parse_react_response(response.text)

        return ReActStep(
            thought=thought,
            action=action,
            observation=None,
            reflection=None
        )

    def _parse_react_response(self, text: str) -> Tuple[Thought, Optional[Action]]:
        """Parse LLM output into Thought and Action"""

        # Extract THOUGHT
        thought_match = re.search(r'THOUGHT:\s*(.+?)(?=ACTION:|$)', text, re.DOTALL)
        thought_content = thought_match.group(1).strip() if thought_match else text

        # Extract ACTION
        action_match = re.search(r'ACTION:\s*(\w+)', text)
        action_type_str = action_match.group(1).upper() if action_match else "RESPOND"

        # Map to ActionType
        action_type_map = {
            "RESPOND": ActionType.RESPOND,
            "TOOL": ActionType.TOOL_USE,
            "SEARCH": ActionType.SEARCH,
            "REFLECT": ActionType.REFLECT,
            "DELEGATE": ActionType.DELEGATE
        }
        action_type = action_type_map.get(action_type_str, ActionType.RESPOND)

        # Extract tool info if applicable
        tool_name = None
        tool_params = {}

        if action_type == ActionType.TOOL_USE:
            tool_match = re.search(r'TOOL:\s*(\w+)', text)
            tool_name = tool_match.group(1) if tool_match else None

            params_match = re.search(r'PARAMS:\s*(\{.+?\})', text, re.DOTALL)
            if params_match:
                try:
                    import json
                    tool_params = json.loads(params_match.group(1))
                except json.JSONDecodeError:
                    pass

        thought = Thought(
            content=thought_content,
            action_type=action_type,
            tool_name=tool_name,
            tool_params=tool_params
        )

        action = None
        if action_type != ActionType.RESPOND:
            action = Action(
                type=action_type,
                tool_name=tool_name,
                tool_params=tool_params,
                requires_approval=self._requires_approval(tool_name)
            )

        return thought, action

    async def _execute_action(self, action: Action) -> Observation:
        """Execute an action and return observation"""

        if action.type == ActionType.TOOL_USE:
            return await self._execute_tool(action)
        elif action.type == ActionType.SEARCH:
            return await self._search_memory(action)
        elif action.type == ActionType.REFLECT:
            return await self._self_reflect(action)
        elif action.type == ActionType.DELEGATE:
            return await self._delegate(action)
        else:
            return Observation(
                content="Unknown action type",
                success=False,
                source="react_engine"
            )

    async def _execute_tool(self, action: Action) -> Observation:
        """Execute a tool via EXECUTOR"""

        if not self.executor:
            return Observation(
                content="Executor not available",
                success=False,
                source="react_engine"
            )

        if not action.tool_name:
            return Observation(
                content="No tool specified",
                success=False,
                source="react_engine"
            )

        try:
            # Map tool names to executor methods
            tool_mapping = {
                "browser_navigate": ("browser", "navigate"),
                "browser_click": ("browser", "click"),
                "browser_fill": ("browser", "fill"),
                "desktop_launch": ("desktop", "launch_app"),
                "desktop_type": ("desktop", "type_text"),
                "desktop_press": ("desktop", "press_key"),
            }

            if action.tool_name in tool_mapping:
                tool, action_name = tool_mapping[action.tool_name]
                result = await self.executor.do(
                    tool=tool,
                    action=action_name,
                    wait=True,
                    **action.tool_params
                )
                return Observation(
                    content=str(result),
                    success=True,
                    source=action.tool_name,
                    metadata={"result": result}
                )
            else:
                # Try generic tool execution
                result = await self.executor.do(
                    tool=action.tool_name.split("_")[0],
                    action="_".join(action.tool_name.split("_")[1:]),
                    wait=True,
                    **action.tool_params
                )
                return Observation(
                    content=str(result),
                    success=True,
                    source=action.tool_name,
                    metadata={"result": result}
                )

        except Exception as e:
            logger.error(f"Tool execution failed: {e}")
            return Observation(
                content=f"Tool execution failed: {str(e)}",
                success=False,
                source=action.tool_name or "unknown"
            )

    async def _search_memory(self, action: Action) -> Observation:
        """Search memory for relevant information"""

        if not self.memory:
            return Observation(
                content="Memory not available",
                success=False,
                source="memory"
            )

        query = action.tool_params.get("query", "")
        if not query:
            return Observation(
                content="No search query provided",
                success=False,
                source="memory"
            )

        try:
            results = await self.memory.recall_all(query, limit_per_collection=3)
            if results:
                content = "\n".join([
                    f"[{collection}]: {entry.content[:200]}"
                    for collection, entries in results.items()
                    for entry in entries
                ])
                return Observation(
                    content=content,
                    success=True,
                    source="memory",
                    metadata={"results_count": sum(len(e) for e in results.values())}
                )
            else:
                return Observation(
                    content="No relevant memories found",
                    success=True,
                    source="memory"
                )
        except Exception as e:
            return Observation(
                content=f"Memory search failed: {str(e)}",
                success=False,
                source="memory"
            )

    async def _self_reflect(self, action: Action) -> Observation:
        """Self-reflection step"""

        reflection_prompt = action.tool_params.get(
            "prompt",
            "Reflect on the current approach and consider alternatives."
        )

        request = InferenceRequest(
            prompt=reflection_prompt,
            system_prompt="You are reflecting on your reasoning process. Be critical and thorough.",
            max_tokens=512,
            temperature=0.5
        )

        response = await self.cortex.generate(request)

        return Observation(
            content=response.text,
            success=True,
            source="self_reflection"
        )

    async def _delegate(self, action: Action) -> Observation:
        """Delegate to sub-agent (placeholder for Hive-Mind integration)"""
        return Observation(
            content="Delegation not yet implemented",
            success=False,
            source="delegation"
        )

    async def _reflect(self, response: str) -> str:
        """
        Apply reflection filter using ANIMUS core values.

        This validates the response against SPECTER's immutable values:
        - Protection
        - Excellence
        - Honesty
        - Equivalent Exchange
        - Discretion
        """

        if not self.personality:
            return response

        # Check for core value violations
        from core.animus.identity import Identity

        is_violation, reason = Identity.check_core_value_violation(response)
        if is_violation:
            logger.warning(f"Core value violation detected: {reason}")
            # Generate refined response
            refined = await self._refine_response(response, reason)
            return refined

        return response

    async def _refine_response(self, response: str, violation: str) -> str:
        """Refine a response that violated core values"""

        refine_prompt = f"""The following response violated a core value:

Original response: {response}

Violation: {violation}

Generate a refined response that maintains the same intent but respects the core value.
Do not mention the refinement process in your response."""

        request = InferenceRequest(
            prompt=refine_prompt,
            system_prompt="You are refining a response to align with core values.",
            max_tokens=1024,
            temperature=0.5
        )

        result = await self.cortex.generate(request)
        return result.text

    async def _extract_response(self, step: ReActStep) -> str:
        """Extract final response from a RESPOND action step"""

        text = step.thought.content

        # Look for explicit RESPONSE marker
        response_match = re.search(r'RESPONSE:\s*(.+)$', text, re.DOTALL)
        if response_match:
            return response_match.group(1).strip()

        # Otherwise use the thought content
        return text

    async def _get_memory_context(self, query: str) -> str:
        """Get relevant context from memory"""

        if not self.memory:
            return ""

        try:
            context = await self.memory.get_context_for_query(
                query,
                include_conversation=True,
                include_knowledge=True
            )
            return context
        except Exception as e:
            logger.error(f"Failed to get memory context: {e}")
            return ""

    async def _store_observation(self, input: str, response: str) -> None:
        """Store the interaction in memory"""

        if not self.memory:
            return

        try:
            # Store conversation
            await self.memory.add_conversation("user", input)
            await self.memory.add_conversation("assistant", response)

            # Learn from interaction
            await self.memory.learn_from_interaction(
                interaction=f"User: {input}\nAssistant: {response}",
                outcome="completed",
                category="general"
            )
        except Exception as e:
            logger.error(f"Failed to store observation: {e}")

    def _build_continuation_prompt(
        self,
        original_input: str,
        thought: Thought,
        observation: Observation
    ) -> str:
        """Build prompt for next iteration"""

        return f"""Original request: {original_input}

Previous thought: {thought.content}

Action taken: {thought.action_type.name}
{f'Tool: {thought.tool_name}' if thought.tool_name else ''}

Observation: {observation.content}

Based on this observation, continue reasoning and determine the next step or provide a final response."""

    async def _generate_fallback_response(self, input: str) -> str:
        """Generate a fallback when max iterations reached"""

        fallback_prompt = f"""The reasoning process took too many steps for: {input}

Provide a direct response based on available information. Be concise."""

        request = InferenceRequest(
            prompt=fallback_prompt,
            system_prompt="Provide a helpful response.",
            max_tokens=512,
            temperature=0.7
        )

        response = await self.cortex.generate(request)
        return response.text

    def _requires_approval(self, tool_name: Optional[str]) -> bool:
        """Check if a tool requires user approval"""

        high_risk_tools = [
            "wallet",
            "transaction",
            "delete",
            "transfer",
            "execute",
            "shell",
            "sudo"
        ]

        if not tool_name:
            return False

        return any(risk in tool_name.lower() for risk in high_risk_tools)

    def get_context(self) -> Optional[ReActContext]:
        """Get current ReAct context"""
        return self.current_context

    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics"""
        return {
            "total_sessions": self.total_sessions,
            "total_steps": self.total_steps,
            "avg_steps_per_session": (
                self.total_steps / self.total_sessions
                if self.total_sessions > 0 else 0
            ),
            "has_executor": self.executor is not None,
            "has_memory": self.memory is not None,
            "has_personality": self.personality is not None,
            "tool_count": len(self.tool_schemas)
        }
