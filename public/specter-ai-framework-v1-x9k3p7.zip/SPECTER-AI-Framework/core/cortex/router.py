"""
CORTEX Model Router

Routes requests to appropriate models based on complexity analysis.
Uses the fast model for simple queries, primary model for complex ones.
"""

from enum import Enum
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import logging
import re

logger = logging.getLogger("specter.cortex.router")


class ComplexityLevel(Enum):
    """Complexity levels for routing decisions"""
    SIMPLE = "simple"      # Quick questions, greetings, confirmations
    MEDIUM = "medium"      # Standard coding, explanations
    COMPLEX = "complex"    # Architecture, debugging, multi-step reasoning
    CRITICAL = "critical"  # Security decisions, financial operations


@dataclass
class RoutingDecision:
    """Result of routing analysis"""
    model: str  # "fast" or "primary"
    complexity: ComplexityLevel
    confidence: float
    reasoning: str
    estimated_tokens: int


class ModelRouter:
    """
    Routes inference requests to the appropriate model.

    Analyzes:
    - Token count / length
    - Keywords indicating complexity
    - Task type
    - Historical patterns
    """

    def __init__(
        self,
        simple_threshold: int = 100,
        complex_threshold: int = 500
    ):
        self.simple_threshold = simple_threshold
        self.complex_threshold = complex_threshold

        # Keywords that indicate complexity
        self.complex_keywords = [
            # Architecture
            "architect", "design", "system", "infrastructure",
            "scalable", "distributed", "microservice",
            # Debugging
            "debug", "diagnose", "investigate", "trace", "error",
            "exception", "crash", "memory leak", "race condition",
            # Security
            "security", "vulnerability", "exploit", "authentication",
            "authorization", "encrypt", "decrypt", "hash",
            # Analysis
            "analyze", "optimize", "refactor", "review", "audit",
            # Multi-step
            "step by step", "explain", "how does", "why does",
            "compare", "contrast", "evaluate", "assess"
        ]

        self.simple_keywords = [
            # Greetings
            "hello", "hi", "hey", "yo", "sup",
            # Confirmations
            "yes", "no", "ok", "okay", "sure", "fine",
            # Simple queries
            "what is", "define", "status", "time", "date",
            # Quick actions
            "run", "execute", "start", "stop", "restart"
        ]

        self.critical_keywords = [
            # Financial
            "transaction", "transfer", "payment", "wallet", "crypto",
            "trade", "buy", "sell", "invest",
            # Security
            "password", "credential", "secret", "key", "token",
            "delete", "remove", "wipe", "destroy",
            # System
            "sudo", "root", "admin", "permission", "production"
        ]

        self.routing_history: List[RoutingDecision] = []
        logger.info("Model router initialized")

    def estimate_tokens(self, text: str) -> int:
        """Rough token estimation (avg 4 chars per token)"""
        return len(text) // 4

    def analyze_complexity(self, prompt: str) -> Tuple[ComplexityLevel, float, str]:
        """
        Analyze the complexity of a prompt.

        Returns:
            (complexity_level, confidence, reasoning)
        """
        prompt_lower = prompt.lower()
        token_estimate = self.estimate_tokens(prompt)

        # Check for critical keywords first
        critical_matches = [
            kw for kw in self.critical_keywords
            if kw in prompt_lower
        ]
        if critical_matches:
            return (
                ComplexityLevel.CRITICAL,
                0.95,
                f"Critical keywords detected: {', '.join(critical_matches[:3])}"
            )

        # Check for complex keywords
        complex_matches = [
            kw for kw in self.complex_keywords
            if kw in prompt_lower
        ]

        # Check for simple keywords
        simple_matches = [
            kw for kw in self.simple_keywords
            if kw in prompt_lower
        ]

        # Code detection
        has_code = bool(re.search(r'```|\bdef\b|\bclass\b|\bfunction\b', prompt))

        # Multi-line detection
        line_count = prompt.count('\n') + 1

        # Scoring
        complexity_score = 0.0
        reasons = []

        # Token-based scoring
        if token_estimate < self.simple_threshold:
            complexity_score -= 0.3
            reasons.append(f"Short prompt ({token_estimate} tokens)")
        elif token_estimate > self.complex_threshold:
            complexity_score += 0.3
            reasons.append(f"Long prompt ({token_estimate} tokens)")

        # Keyword-based scoring
        if complex_matches:
            complexity_score += 0.1 * min(len(complex_matches), 5)
            reasons.append(f"Complex keywords: {', '.join(complex_matches[:2])}")

        if simple_matches:
            complexity_score -= 0.2 * min(len(simple_matches), 3)
            reasons.append(f"Simple keywords: {', '.join(simple_matches[:2])}")

        # Code-based scoring
        if has_code:
            complexity_score += 0.2
            reasons.append("Contains code")

        # Multi-line scoring
        if line_count > 10:
            complexity_score += 0.15
            reasons.append(f"Multi-line ({line_count} lines)")

        # Determine level
        if complexity_score < -0.2:
            level = ComplexityLevel.SIMPLE
            confidence = min(0.9, 0.6 + abs(complexity_score))
        elif complexity_score > 0.3:
            level = ComplexityLevel.COMPLEX
            confidence = min(0.9, 0.5 + complexity_score)
        else:
            level = ComplexityLevel.MEDIUM
            confidence = 0.6

        return (level, confidence, "; ".join(reasons) if reasons else "Standard analysis")

    def route(self, prompt: str, context: Optional[str] = None) -> RoutingDecision:
        """
        Determine which model to route a request to.

        Args:
            prompt: The user's prompt
            context: Optional conversation context

        Returns:
            RoutingDecision with model selection
        """
        # Combine prompt and context for analysis
        full_text = f"{context or ''}\n{prompt}".strip()
        token_estimate = self.estimate_tokens(full_text)

        # Analyze complexity
        complexity, confidence, reasoning = self.analyze_complexity(full_text)

        # Determine model
        if complexity == ComplexityLevel.SIMPLE:
            model = "fast"
        elif complexity == ComplexityLevel.CRITICAL:
            model = "primary"  # Always use best model for critical
        elif complexity == ComplexityLevel.COMPLEX:
            model = "primary"
        else:  # MEDIUM
            # Use heuristics for medium complexity
            if token_estimate > 200:
                model = "primary"
            else:
                model = "fast"

        decision = RoutingDecision(
            model=model,
            complexity=complexity,
            confidence=confidence,
            reasoning=reasoning,
            estimated_tokens=token_estimate
        )

        # Store in history
        self.routing_history.append(decision)
        if len(self.routing_history) > 1000:
            self.routing_history = self.routing_history[-500:]

        logger.debug(
            f"Routed to {model} ({complexity.value}): {reasoning}"
        )

        return decision

    def get_stats(self) -> Dict[str, any]:
        """Get routing statistics"""
        if not self.routing_history:
            return {"total_routes": 0}

        total = len(self.routing_history)
        fast_count = sum(1 for d in self.routing_history if d.model == "fast")
        primary_count = total - fast_count

        complexity_counts = {}
        for level in ComplexityLevel:
            complexity_counts[level.value] = sum(
                1 for d in self.routing_history if d.complexity == level
            )

        return {
            "total_routes": total,
            "fast_model_percent": fast_count / total * 100,
            "primary_model_percent": primary_count / total * 100,
            "complexity_distribution": complexity_counts,
            "avg_confidence": sum(d.confidence for d in self.routing_history) / total
        }

    def __repr__(self) -> str:
        return f"ModelRouter(routes={len(self.routing_history)})"
