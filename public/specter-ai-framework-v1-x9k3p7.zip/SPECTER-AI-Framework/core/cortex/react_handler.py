"""
CORTEX ReAct Handler

Integrates the ReActEngine with NUCLEUS event bus for event-driven processing.

"When I speak, you listen." - Gibbs mode
"""

import asyncio
import logging
from typing import Any, Dict, Optional
from datetime import datetime

from core.nucleus import get_bus, Event, EventType
from .react_engine import ReActEngine, ReActContext, Thought, Action, Observation

logger = logging.getLogger("specter.cortex.react_handler")


class ReActHandler:
    """
    Event-driven wrapper for ReActEngine.

    Subscribes to NUCLEUS events and coordinates:
    - INFERENCE_REQUEST -> Process via ReAct loop
    - REASONING_START -> Begin reasoning trace
    - REASONING_COMPLETE -> Publish results

    Also publishes events for:
    - Each thought step
    - Each action taken
    - Each observation received
    - Final response

    This enables other modules to observe and react to
    SPECTER's reasoning process.
    """

    def __init__(self, react_engine: ReActEngine):
        self.react = react_engine
        self.bus = get_bus()
        self.initialized = False

        # Connect callbacks
        self.react.on_thought = self._on_thought
        self.react.on_action = self._on_action
        self.react.on_observation = self._on_observation

        # Active sessions
        self.active_sessions: Dict[str, ReActContext] = {}

        logger.info("ReAct Handler created")

    async def initialize(self) -> bool:
        """Initialize handler and subscribe to events"""
        if self.initialized:
            return True

        # Subscribe to inference requests
        await self.bus.subscribe(
            EventType.INFERENCE_REQUEST,
            self._handle_inference_request,
            priority=80,
            async_handler=True
        )

        # Subscribe to user input
        await self.bus.subscribe(
            EventType.USER_INPUT,
            self._handle_user_input,
            priority=70,
            async_handler=True
        )

        self.initialized = True
        logger.info("ReAct Handler initialized and subscribed to events")
        return True

    async def _handle_inference_request(self, event: Event) -> None:
        """Handle an inference request via ReAct loop"""

        data = event.data or {}
        prompt = data.get("prompt", "")
        context = data.get("context", "")
        request_id = data.get("request_id", event.id)

        if not prompt:
            logger.warning("Received inference request with no prompt")
            return

        logger.info(f"Processing inference request {request_id}")

        # Publish reasoning start
        await self.bus.publish(Event(
            type=EventType.REASONING_START,
            data={
                "request_id": request_id,
                "prompt": prompt
            },
            source="cortex.react"
        ))

        try:
            # Process through ReAct
            response = await self.react.process(prompt, context)

            # Store session
            if self.react.current_context:
                self.active_sessions[request_id] = self.react.current_context

            # Publish reasoning complete
            await self.bus.publish(Event(
                type=EventType.REASONING_COMPLETE,
                data={
                    "request_id": request_id,
                    "response": response,
                    "steps": len(self.react.current_context.steps) if self.react.current_context else 0,
                    "tokens": self.react.current_context.total_tokens if self.react.current_context else 0
                },
                source="cortex.react"
            ))

            # Publish inference response
            await self.bus.publish(Event(
                type=EventType.INFERENCE_RESPONSE,
                data={
                    "request_id": request_id,
                    "text": response,
                    "model": "react",
                    "tokens_used": self.react.current_context.total_tokens if self.react.current_context else 0
                },
                source="cortex.react"
            ))

        except Exception as e:
            logger.error(f"ReAct processing failed: {e}")
            await self.bus.publish(Event(
                type=EventType.INFERENCE_ERROR,
                data={
                    "request_id": request_id,
                    "error": str(e)
                },
                source="cortex.react"
            ))

    async def _handle_user_input(self, event: Event) -> None:
        """Handle direct user input"""

        data = event.data or {}
        text = data.get("text", "")

        if not text:
            return

        # Convert to inference request
        await self.bus.publish(Event(
            type=EventType.INFERENCE_REQUEST,
            data={
                "prompt": text,
                "context": data.get("context", ""),
                "request_id": event.id
            },
            source="user"
        ))

    def _on_thought(self, thought: Thought) -> None:
        """Callback when ReAct generates a thought"""

        # Fire and forget event publish
        asyncio.create_task(self.bus.publish(Event(
            type=EventType.REASONING_START,  # Reuse for thought steps
            data={
                "step": "thought",
                "content": thought.content,
                "action_type": thought.action_type.name,
                "tool": thought.tool_name
            },
            source="cortex.react",
            priority=30  # Lower priority for intermediate steps
        )))

    def _on_action(self, action: Action) -> None:
        """Callback when ReAct decides on an action"""

        asyncio.create_task(self.bus.publish(Event(
            type=EventType.TASK_SUBMITTED,
            data={
                "action_type": action.type.name,
                "tool": action.tool_name,
                "params": action.tool_params,
                "requires_approval": action.requires_approval
            },
            source="cortex.react"
        )))

        # If action requires approval, emit approval request
        if action.requires_approval:
            asyncio.create_task(self.bus.publish(Event(
                type=EventType.APPROVAL_REQUIRED,
                data={
                    "action_type": action.type.name,
                    "tool": action.tool_name,
                    "params": action.tool_params,
                    "reason": f"Tool '{action.tool_name}' requires approval"
                },
                source="cortex.react",
                priority=90  # High priority for approval requests
            )))

    def _on_observation(self, observation: Observation) -> None:
        """Callback when ReAct receives an observation"""

        asyncio.create_task(self.bus.publish(Event(
            type=EventType.TASK_COMPLETED,
            data={
                "success": observation.success,
                "content": observation.content[:500],  # Truncate for event
                "source": observation.source
            },
            source="cortex.react"
        )))

    async def process_with_events(
        self,
        prompt: str,
        context: Optional[str] = None,
        request_id: Optional[str] = None
    ) -> str:
        """
        Process a prompt and emit events throughout.

        This is the main entry point for event-driven processing.
        """

        event_id = request_id or f"react-{datetime.now().timestamp()}"

        # Emit inference request event
        await self.bus.publish(Event(
            type=EventType.INFERENCE_REQUEST,
            data={
                "prompt": prompt,
                "context": context,
                "request_id": event_id
            },
            source="cortex.react"
        ))

        # The handler will process this and emit response
        # Wait for response via a local callback
        response_received = asyncio.Event()
        response_text = [""]

        async def response_handler(event: Event):
            if event.data and event.data.get("request_id") == event_id:
                response_text[0] = event.data.get("text", "")
                response_received.set()

        await self.bus.subscribe(
            EventType.INFERENCE_RESPONSE,
            response_handler,
            priority=100
        )

        # Wait for response (with timeout)
        try:
            await asyncio.wait_for(response_received.wait(), timeout=300)
        except asyncio.TimeoutError:
            logger.error("ReAct processing timed out")
            response_text[0] = "Processing timed out"
        finally:
            self.bus.unsubscribe(EventType.INFERENCE_RESPONSE, response_handler)

        return response_text[0]

    def get_session(self, request_id: str) -> Optional[ReActContext]:
        """Get a stored ReAct session by ID"""
        return self.active_sessions.get(request_id)

    def get_stats(self) -> Dict[str, Any]:
        """Get handler statistics"""
        return {
            "initialized": self.initialized,
            "active_sessions": len(self.active_sessions),
            "react_stats": self.react.get_stats()
        }

    async def shutdown(self) -> None:
        """Shutdown the handler"""
        logger.info("Shutting down ReAct Handler...")

        # Unsubscribe from events
        self.bus.unsubscribe(EventType.INFERENCE_REQUEST, self._handle_inference_request)
        self.bus.unsubscribe(EventType.USER_INPUT, self._handle_user_input)

        self.active_sessions.clear()
        self.initialized = False

        logger.info("ReAct Handler shutdown complete")
