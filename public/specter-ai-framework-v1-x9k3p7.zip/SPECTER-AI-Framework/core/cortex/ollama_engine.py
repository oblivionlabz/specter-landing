"""
CORTEX Ollama Engine

LLM inference engine using Ollama API.
Supports chat completions with streaming.
"""

import aiohttp
import asyncio
import logging
from typing import Dict, List, Optional, AsyncIterator, Any
from dataclasses import dataclass, field
from datetime import datetime
import json

logger = logging.getLogger("specter.cortex.ollama")


@dataclass
class OllamaConfig:
    """Configuration for Ollama connection"""
    host: str = "http://localhost:11434"
    primary_model: str = "llama3.3:70b"
    fast_model: str = "qwen2.5-coder:32b"
    timeout: int = 300  # 70B models need time


@dataclass
class InferenceRequest:
    """A request for LLM inference"""
    prompt: str
    system_prompt: Optional[str] = None
    max_tokens: int = 4096
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 40
    repeat_penalty: float = 1.1
    stop_sequences: List[str] = field(default_factory=list)
    stream: bool = False
    request_id: Optional[str] = None


@dataclass
class InferenceResponse:
    """Response from LLM inference"""
    text: str
    tokens_used: int
    generation_time: float
    model_name: str
    request_id: Optional[str] = None
    finish_reason: str = "stop"


class OllamaEngine:
    """
    SPECTER's brain - Ollama-based LLM inference engine.

    Features:
    - Multi-model support (primary + fast)
    - Async HTTP API calls
    - Streaming generation
    - Personality injection via system prompts
    """

    def __init__(
        self,
        config: Optional[OllamaConfig] = None,
        personality_context: Optional[str] = None
    ):
        self.config = config or OllamaConfig()
        self.personality_context = personality_context

        self.active_model = self.config.primary_model
        self.active_model_name = "primary"

        self.initialized = False
        self.total_tokens_generated = 0
        self.total_inference_time = 0.0
        self.request_count = 0

        self._session: Optional[aiohttp.ClientSession] = None

        logger.info(f"Ollama Engine created (host: {self.config.host})")

    async def initialize(self) -> bool:
        """
        Initialize the engine and verify Ollama connection.

        Returns:
            True if connection successful and models available
        """
        if self.initialized:
            logger.warning("Ollama Engine already initialized")
            return True

        try:
            # Create session
            timeout = aiohttp.ClientTimeout(total=self.config.timeout)
            self._session = aiohttp.ClientSession(timeout=timeout)

            # Check Ollama is running
            async with self._session.get(f"{self.config.host}/api/tags") as resp:
                if resp.status != 200:
                    logger.error(f"Ollama not responding: {resp.status}")
                    return False

                data = await resp.json()
                available_models = [m["name"] for m in data.get("models", [])]

            # Verify models exist
            primary_available = self.config.primary_model in available_models
            fast_available = self.config.fast_model in available_models

            if primary_available:
                logger.info(f"Primary model available: {self.config.primary_model}")
            else:
                logger.warning(f"Primary model NOT found: {self.config.primary_model}")

            if fast_available:
                logger.info(f"Fast model available: {self.config.fast_model}")
            else:
                logger.warning(f"Fast model NOT found: {self.config.fast_model}")

            if not primary_available and not fast_available:
                logger.error("No configured models available in Ollama")
                return False

            # Use whichever is available
            if primary_available:
                self.active_model = self.config.primary_model
                self.active_model_name = "primary"
            else:
                self.active_model = self.config.fast_model
                self.active_model_name = "fast"

            self.initialized = True
            logger.info(f"Ollama Engine initialized with {self.active_model}")
            return True

        except aiohttp.ClientError as e:
            logger.error(f"Failed to connect to Ollama: {e}")
            return False
        except Exception as e:
            logger.error(f"Ollama initialization failed: {e}")
            return False

    def select_model(self, model_name: str) -> bool:
        """
        Select which model to use for inference.

        Args:
            model_name: "primary" or "fast"

        Returns:
            True if model selection successful
        """
        if model_name == "primary":
            self.active_model = self.config.primary_model
            self.active_model_name = "primary"
            logger.info(f"Switched to primary model: {self.config.primary_model}")
            return True
        elif model_name == "fast":
            self.active_model = self.config.fast_model
            self.active_model_name = "fast"
            logger.info(f"Switched to fast model: {self.config.fast_model}")
            return True
        else:
            logger.warning(f"Unknown model type: {model_name}")
            return False

    def _build_messages(self, request: InferenceRequest) -> List[Dict[str, str]]:
        """Build chat messages from request"""
        messages = []

        # System message with personality
        system_content = ""
        if self.personality_context:
            system_content = self.personality_context
        if request.system_prompt:
            if system_content:
                system_content = f"{system_content}\n\n{request.system_prompt}"
            else:
                system_content = request.system_prompt

        if system_content:
            messages.append({"role": "system", "content": system_content})

        # User message
        messages.append({"role": "user", "content": request.prompt})

        return messages

    async def generate(self, request: InferenceRequest) -> InferenceResponse:
        """
        Generate a response for the given request.

        Args:
            request: The inference request

        Returns:
            InferenceResponse with generated text
        """
        if not self.initialized or not self._session:
            raise RuntimeError("Ollama Engine not initialized")

        start_time = datetime.now()
        messages = self._build_messages(request)

        payload = {
            "model": self.active_model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": request.temperature,
                "top_p": request.top_p,
                "top_k": request.top_k,
                "repeat_penalty": request.repeat_penalty,
                "num_predict": request.max_tokens,
            }
        }

        if request.stop_sequences:
            payload["options"]["stop"] = request.stop_sequences

        try:
            async with self._session.post(
                f"{self.config.host}/api/chat",
                json=payload
            ) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"Ollama error {resp.status}: {error_text}")

                data = await resp.json()

            generated_text = data.get("message", {}).get("content", "")

            # Ollama returns eval_count for tokens
            tokens_used = data.get("eval_count", 0)
            generation_time = (datetime.now() - start_time).total_seconds()

            # Update stats
            self.total_tokens_generated += tokens_used
            self.total_inference_time += generation_time
            self.request_count += 1

            logger.debug(
                f"Generated {tokens_used} tokens in {generation_time:.2f}s "
                f"({tokens_used/generation_time:.1f} tok/s)" if generation_time > 0 else ""
            )

            return InferenceResponse(
                text=generated_text,
                tokens_used=tokens_used,
                generation_time=generation_time,
                model_name=self.active_model_name,
                request_id=request.request_id,
                finish_reason=data.get("done_reason", "stop")
            )

        except aiohttp.ClientError as e:
            logger.error(f"Ollama request failed: {e}")
            raise
        except Exception as e:
            logger.error(f"Inference failed: {e}")
            raise

    async def generate_stream(
        self, request: InferenceRequest
    ) -> AsyncIterator[str]:
        """
        Stream a response token by token.

        Args:
            request: The inference request

        Yields:
            Generated text chunks
        """
        if not self.initialized or not self._session:
            raise RuntimeError("Ollama Engine not initialized")

        messages = self._build_messages(request)

        payload = {
            "model": self.active_model,
            "messages": messages,
            "stream": True,
            "options": {
                "temperature": request.temperature,
                "top_p": request.top_p,
                "top_k": request.top_k,
                "repeat_penalty": request.repeat_penalty,
                "num_predict": request.max_tokens,
            }
        }

        if request.stop_sequences:
            payload["options"]["stop"] = request.stop_sequences

        try:
            async with self._session.post(
                f"{self.config.host}/api/chat",
                json=payload
            ) as resp:
                if resp.status != 200:
                    error_text = await resp.text()
                    raise RuntimeError(f"Ollama error {resp.status}: {error_text}")

                async for line in resp.content:
                    if line:
                        try:
                            data = json.loads(line.decode('utf-8'))
                            content = data.get("message", {}).get("content", "")
                            if content:
                                yield content
                        except json.JSONDecodeError:
                            continue

        except aiohttp.ClientError as e:
            logger.error(f"Streaming request failed: {e}")
            raise
        except Exception as e:
            logger.error(f"Streaming inference failed: {e}")
            raise

    def set_personality_context(self, context: str) -> None:
        """Update the personality context injected into prompts"""
        self.personality_context = context
        logger.info("Personality context updated")

    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics"""
        return {
            "initialized": self.initialized,
            "engine": "ollama",
            "host": self.config.host,
            "active_model": self.active_model,
            "active_model_type": self.active_model_name,
            "models_configured": {
                "primary": self.config.primary_model,
                "fast": self.config.fast_model
            },
            "total_requests": self.request_count,
            "total_tokens_generated": self.total_tokens_generated,
            "total_inference_time": self.total_inference_time,
            "avg_tokens_per_second": (
                self.total_tokens_generated / self.total_inference_time
                if self.total_inference_time > 0 else 0
            )
        }

    async def shutdown(self) -> None:
        """Shutdown the engine and cleanup"""
        logger.info("Shutting down Ollama Engine...")

        if self._session:
            await self._session.close()
            self._session = None

        self.initialized = False
        logger.info("Ollama Engine shutdown complete")

    def __repr__(self) -> str:
        return (
            f"OllamaEngine(model={self.active_model}, "
            f"requests={self.request_count})"
        )
