"""
CORTEX - SPECTER's Brain

The LLM inference engine that provides intelligence to SPECTER.
Handles model loading, inference routing, and personality injection.

Supports multiple backends:
- llama-cpp: Local GGUF models via llama-cpp-python
- ollama: Ollama API for local model serving

Includes:
- ReActEngine: Reason + Act pattern for agentic processing
"""

from .engine import CortexEngine, InferenceRequest, InferenceResponse, ModelConfig
from .ollama_engine import OllamaEngine, OllamaConfig
from .router import ModelRouter, ComplexityLevel
from .prompts import PromptManager
from .react_engine import (
    ReActEngine,
    ReActContext,
    ReActStep,
    Thought,
    Action,
    Observation,
    ActionType
)

__all__ = [
    # Core Engine
    "CortexEngine",
    "InferenceRequest",
    "InferenceResponse",
    "ModelConfig",
    # ReAct Engine
    "ReActEngine",
    "ReActContext",
    "ReActStep",
    "Thought",
    "Action",
    "Observation",
    "ActionType",
    # Ollama
    "OllamaEngine",
    "OllamaConfig",
    # Routing
    "ModelRouter",
    "ComplexityLevel",
    # Prompts
    "PromptManager"
]
