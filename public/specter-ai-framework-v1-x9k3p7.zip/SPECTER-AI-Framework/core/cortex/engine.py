"""
CORTEX Engine

The core LLM inference engine using llama-cpp-python.
Handles model loading, inference, and response generation.
"""

from pathlib import Path
from typing import Dict, List, Optional, AsyncIterator, Any
from dataclasses import dataclass, field
import logging
import asyncio
from datetime import datetime
import json

logger = logging.getLogger("specter.cortex.engine")


@dataclass
class ModelConfig:
    """Configuration for a loaded model"""
    path: Path
    context_length: int = 32768
    gpu_layers: int = 40
    threads: int = 8
    batch_size: int = 512
    rope_freq_base: float = 10000.0
    rope_freq_scale: float = 1.0


@dataclass
class InferenceRequest:
    """A request for LLM inference"""
    prompt: str
    system_prompt: Optional[str] = None
    max_tokens: int = 4096
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 40
    repeat_penalty: float = 1.1
    stop_sequences: List[str] = field(default_factory=list)
    stream: bool = False
    request_id: Optional[str] = None


@dataclass
class InferenceResponse:
    """Response from LLM inference"""
    text: str
    tokens_used: int
    generation_time: float
    model_name: str
    request_id: Optional[str] = None
    finish_reason: str = "stop"


class CortexEngine:
    """
    SPECTER's brain - the LLM inference engine.

    Features:
    - Multi-model support (primary + fast)
    - GPU-accelerated inference via llama-cpp-python
    - Streaming generation
    - Personality injection via system prompts
    - Automatic model routing based on complexity
    """

    def __init__(
        self,
        primary_model_config: Optional[ModelConfig] = None,
        fast_model_config: Optional[ModelConfig] = None,
        personality_context: Optional[str] = None
    ):
        self.primary_config = primary_model_config
        self.fast_config = fast_model_config
        self.personality_context = personality_context

        self.primary_model = None
        self.fast_model = None
        self.active_model = None
        self.active_model_name = None

        self.initialized = False
        self.total_tokens_generated = 0
        self.total_inference_time = 0.0
        self.request_count = 0

        logger.info("CORTEX Engine created")

    async def initialize(self) -> bool:
        """
        Initialize the engine and load models.

        Returns:
            True if at least one model loaded successfully
        """
        if self.initialized:
            logger.warning("CORTEX already initialized")
            return True

        success = False

        # Load primary model
        if self.primary_config:
            try:
                self.primary_model = await self._load_model(
                    self.primary_config, "primary"
                )
                success = True
                logger.info(f"Primary model loaded: {self.primary_config.path.name}")
            except Exception as e:
                logger.error(f"Failed to load primary model: {e}")

        # Load fast model
        if self.fast_config:
            try:
                self.fast_model = await self._load_model(
                    self.fast_config, "fast"
                )
                success = True
                logger.info(f"Fast model loaded: {self.fast_config.path.name}")
            except Exception as e:
                logger.error(f"Failed to load fast model: {e}")

        # Set default active model
        if self.primary_model:
            self.active_model = self.primary_model
            self.active_model_name = "primary"
        elif self.fast_model:
            self.active_model = self.fast_model
            self.active_model_name = "fast"

        self.initialized = success
        return success

    async def _load_model(self, config: ModelConfig, name: str):
        """Load a model using llama-cpp-python"""
        try:
            from llama_cpp import Llama

            logger.info(f"Loading {name} model from {config.path}...")

            model = Llama(
                model_path=str(config.path),
                n_ctx=config.context_length,
                n_gpu_layers=config.gpu_layers,
                n_threads=config.threads,
                n_batch=config.batch_size,
                rope_freq_base=config.rope_freq_base,
                rope_freq_scale=config.rope_freq_scale,
                verbose=False
            )

            logger.info(f"Model {name} loaded successfully")
            return model

        except ImportError:
            logger.error("llama-cpp-python not installed. Install with CUDA support.")
            raise
        except Exception as e:
            logger.error(f"Error loading model {name}: {e}")
            raise

    def select_model(self, model_name: str) -> bool:
        """
        Select which model to use for inference.

        Args:
            model_name: "primary" or "fast"

        Returns:
            True if model selection successful
        """
        if model_name == "primary" and self.primary_model:
            self.active_model = self.primary_model
            self.active_model_name = "primary"
            logger.info("Switched to primary model")
            return True
        elif model_name == "fast" and self.fast_model:
            self.active_model = self.fast_model
            self.active_model_name = "fast"
            logger.info("Switched to fast model")
            return True
        else:
            logger.warning(f"Model {model_name} not available")
            return False

    def _build_prompt(self, request: InferenceRequest) -> str:
        """Build the full prompt with system context and personality"""
        parts = []

        # System prompt with personality
        if request.system_prompt or self.personality_context:
            system_content = request.system_prompt or ""
            if self.personality_context:
                system_content = f"{self.personality_context}\n\n{system_content}"

            parts.append(f"<|im_start|>system\n{system_content.strip()}<|im_end|>")

        # User prompt
        parts.append(f"<|im_start|>user\n{request.prompt}<|im_end|>")
        parts.append("<|im_start|>assistant\n")

        return "\n".join(parts)

    async def generate(self, request: InferenceRequest) -> InferenceResponse:
        """
        Generate a response for the given request.

        Args:
            request: The inference request

        Returns:
            InferenceResponse with generated text
        """
        if not self.initialized or not self.active_model:
            raise RuntimeError("CORTEX not initialized or no model available")

        start_time = datetime.now()
        full_prompt = self._build_prompt(request)

        # Build stop sequences
        stop_sequences = request.stop_sequences or []
        stop_sequences.extend(["<|im_end|>", "<|im_start|>"])

        try:
            # Run inference in thread pool to not block async
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self.active_model(
                    full_prompt,
                    max_tokens=request.max_tokens,
                    temperature=request.temperature,
                    top_p=request.top_p,
                    top_k=request.top_k,
                    repeat_penalty=request.repeat_penalty,
                    stop=stop_sequences,
                    echo=False
                )
            )

            # Extract response
            generated_text = response["choices"][0]["text"].strip()
            tokens_used = response["usage"]["completion_tokens"]
            generation_time = (datetime.now() - start_time).total_seconds()

            # Update stats
            self.total_tokens_generated += tokens_used
            self.total_inference_time += generation_time
            self.request_count += 1

            logger.debug(
                f"Generated {tokens_used} tokens in {generation_time:.2f}s "
                f"({tokens_used/generation_time:.1f} tok/s)"
            )

            return InferenceResponse(
                text=generated_text,
                tokens_used=tokens_used,
                generation_time=generation_time,
                model_name=self.active_model_name,
                request_id=request.request_id,
                finish_reason=response["choices"][0].get("finish_reason", "stop")
            )

        except Exception as e:
            logger.error(f"Inference failed: {e}")
            raise

    async def generate_stream(
        self, request: InferenceRequest
    ) -> AsyncIterator[str]:
        """
        Stream a response token by token.

        Args:
            request: The inference request

        Yields:
            Generated text chunks
        """
        if not self.initialized or not self.active_model:
            raise RuntimeError("CORTEX not initialized or no model available")

        full_prompt = self._build_prompt(request)

        stop_sequences = request.stop_sequences or []
        stop_sequences.extend(["<|im_end|>", "<|im_start|>"])

        try:
            # Stream inference
            stream = self.active_model(
                full_prompt,
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                top_p=request.top_p,
                top_k=request.top_k,
                repeat_penalty=request.repeat_penalty,
                stop=stop_sequences,
                echo=False,
                stream=True
            )

            for chunk in stream:
                text = chunk["choices"][0]["text"]
                if text:
                    yield text

        except Exception as e:
            logger.error(f"Streaming inference failed: {e}")
            raise

    def set_personality_context(self, context: str) -> None:
        """Update the personality context injected into prompts"""
        self.personality_context = context
        logger.info("Personality context updated")

    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics"""
        return {
            "initialized": self.initialized,
            "active_model": self.active_model_name,
            "models_available": {
                "primary": self.primary_model is not None,
                "fast": self.fast_model is not None
            },
            "total_requests": self.request_count,
            "total_tokens_generated": self.total_tokens_generated,
            "total_inference_time": self.total_inference_time,
            "avg_tokens_per_second": (
                self.total_tokens_generated / self.total_inference_time
                if self.total_inference_time > 0 else 0
            )
        }

    async def shutdown(self) -> None:
        """Shutdown the engine and free resources"""
        logger.info("Shutting down CORTEX...")

        # Free models
        if self.primary_model:
            del self.primary_model
            self.primary_model = None

        if self.fast_model:
            del self.fast_model
            self.fast_model = None

        self.active_model = None
        self.initialized = False
        logger.info("CORTEX shutdown complete")

    def __repr__(self) -> str:
        return (
            f"CortexEngine(active={self.active_model_name}, "
            f"requests={self.request_count})"
        )
