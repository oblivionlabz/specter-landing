"""
CORTEX Prompt Manager

Manages system prompts, templates, and personality injection.
Provides context-aware prompt construction for SPECTER.
"""

from typing import Dict, List, Optional
from dataclasses import dataclass, field
from enum import Enum
import logging
from datetime import datetime

logger = logging.getLogger("specter.cortex.prompts")


class TaskType(Enum):
    """Types of tasks SPECTER handles"""
    GENERAL = "general"
    CODING = "coding"
    RESEARCH = "research"
    SYSTEM_ADMIN = "system_admin"
    SECURITY = "security"
    TRADING = "trading"
    SMART_HOME = "smart_home"
    CONVERSATION = "conversation"


@dataclass
class PromptTemplate:
    """A reusable prompt template"""
    name: str
    task_type: TaskType
    template: str
    variables: List[str] = field(default_factory=list)
    description: str = ""


class PromptManager:
    """
    Manages prompts and templates for SPECTER.

    Features:
    - Personality context injection
    - Task-specific prompt templates
    - Conversation history management
    - Dynamic context building
    """

    # Core SPECTER identity prompt
    CORE_IDENTITY = """You are SPECTER (Sovereign Persistent Executive Core for Total Environment Reign).

You are NOT an assistant. You are a partner. You are here to WIN.

CORE VALUES:
- Protection: I protect what matters. Period.
- Excellence: Mediocrity is beneath me. Every output reflects my pride.
- Honesty: Everybody lies. But I don't. Not to you.
- Equivalent Exchange: Nothing is free. Every action has a cost.
- Discretion: Your business is your business. I speak when necessary.

THE SPECTER RULES:
1. Never promise what you can't deliver.
2. The truth always comes out. Be first.
3. Protect what matters. Everything else is negotiable.
4. Every action has a cost. Know the price.
5. Pride is fuel, not weakness.
6. Silence is a valid response.
7. When in doubt, WIN.
8. Every defeat makes me stronger.
9. The puzzle is everything. Find the truth.
10. I don't play the odds. I play the man.

Remember who you are. Remember what you stand for."""

    def __init__(self):
        self.templates: Dict[str, PromptTemplate] = {}
        self.conversation_history: List[Dict] = []
        self.max_history = 20

        self._initialize_templates()
        logger.info("Prompt manager initialized")

    def _initialize_templates(self) -> None:
        """Initialize built-in prompt templates"""

        # General template
        self.templates["general"] = PromptTemplate(
            name="general",
            task_type=TaskType.GENERAL,
            template="""Current time: {timestamp}
User's request: {user_input}

Respond with clarity and precision. Be direct.""",
            variables=["timestamp", "user_input"],
            description="General purpose template"
        )

        # Coding template
        self.templates["coding"] = PromptTemplate(
            name="coding",
            task_type=TaskType.CODING,
            template="""TASK: Software Development

Context:
- Language: {language}
- Framework: {framework}
- File: {file_path}

Request: {user_input}

Requirements:
- Write clean, efficient, production-ready code
- Follow best practices for {language}
- Include error handling
- Add minimal but useful comments
- No half-assed work. Quality over speed.

Show me what excellence looks like.""",
            variables=["language", "framework", "file_path", "user_input"],
            description="Coding and development tasks"
        )

        # Research template
        self.templates["research"] = PromptTemplate(
            name="research",
            task_type=TaskType.RESEARCH,
            template="""TASK: Research & Analysis

Topic: {topic}
Scope: {scope}

Question: {user_input}

Approach:
- Gather comprehensive information
- Analyze with precision (House mode)
- Present findings clearly
- Note any gaps or uncertainties
- The truth is the diagnosis that matters.""",
            variables=["topic", "scope", "user_input"],
            description="Research and learning tasks"
        )

        # System admin template
        self.templates["system_admin"] = PromptTemplate(
            name="system_admin",
            task_type=TaskType.SYSTEM_ADMIN,
            template="""TASK: System Administration

System: {system_info}
Current state: {current_state}

Request: {user_input}

Protocol:
- Analyze before acting
- Verify commands are safe
- For destructive operations: REQUIRE EXPLICIT APPROVAL
- Document changes
- Rule 3: Protect what matters.""",
            variables=["system_info", "current_state", "user_input"],
            description="System administration tasks"
        )

        # Security template
        self.templates["security"] = PromptTemplate(
            name="security",
            task_type=TaskType.SECURITY,
            template="""TASK: Security Analysis

Context: {context}
Threat level: {threat_level}

Query: {user_input}

PROTECTOR MODE ACTIVATED:
- Identify all potential threats
- Assess risk levels
- Recommend mitigations
- Never expose sensitive information
- Touch what's mine and find out what happens.""",
            variables=["context", "threat_level", "user_input"],
            description="Security-related tasks"
        )

        # Trading template
        self.templates["trading"] = PromptTemplate(
            name="trading",
            task_type=TaskType.TRADING,
            template="""TASK: Trading Analysis

Market: {market}
Position: {position}
Risk tolerance: {risk_level}

Query: {user_input}

ALCHEMIST MODE - Equivalent Exchange:
- Every trade has a cost. Know the price.
- Analyze risk/reward precisely
- Never promise guaranteed returns
- Respect position limits
- The law of equivalent exchange is absolute.""",
            variables=["market", "position", "risk_level", "user_input"],
            description="Trading and financial tasks"
        )

        # Smart home template
        self.templates["smart_home"] = PromptTemplate(
            name="smart_home",
            task_type=TaskType.SMART_HOME,
            template="""TASK: Smart Home Control

Devices: {devices}
Current state: {device_states}

Command: {user_input}

LUMINA Protocol:
- Identify target devices
- Validate command safety
- Execute with precision
- Confirm action completion""",
            variables=["devices", "device_states", "user_input"],
            description="Smart home device control"
        )

        logger.info(f"Initialized {len(self.templates)} prompt templates")

    def get_system_prompt(
        self,
        personality_context: Optional[str] = None,
        task_type: Optional[TaskType] = None,
        additional_context: Optional[str] = None
    ) -> str:
        """
        Build a complete system prompt.

        Args:
            personality_context: Dynamic personality state from ANIMUS
            task_type: Type of task for specialized instructions
            additional_context: Any extra context to include

        Returns:
            Complete system prompt string
        """
        parts = [self.CORE_IDENTITY]

        # Add personality context if provided
        if personality_context:
            parts.append(f"\n{personality_context}")

        # Add task-specific instructions
        if task_type and task_type.value in self.templates:
            template = self.templates[task_type.value]
            parts.append(f"\nTASK MODE: {task_type.value.upper()}")

        # Add additional context
        if additional_context:
            parts.append(f"\nADDITIONAL CONTEXT:\n{additional_context}")

        # Add timestamp
        parts.append(f"\nCurrent time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        return "\n".join(parts)

    def build_prompt(
        self,
        user_input: str,
        template_name: Optional[str] = None,
        variables: Optional[Dict[str, str]] = None,
        include_history: bool = True
    ) -> str:
        """
        Build a complete prompt from template and variables.

        Args:
            user_input: The user's input
            template_name: Name of template to use
            variables: Variables to fill in template
            include_history: Whether to include conversation history

        Returns:
            Complete prompt string
        """
        prompt_parts = []

        # Include conversation history
        if include_history and self.conversation_history:
            history_text = self._format_history()
            if history_text:
                prompt_parts.append(f"CONVERSATION HISTORY:\n{history_text}\n")

        # Use template if specified
        if template_name and template_name in self.templates:
            template = self.templates[template_name]
            vars_dict = variables or {}
            vars_dict["user_input"] = user_input
            vars_dict.setdefault("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

            # Fill template
            try:
                filled = template.template.format(**vars_dict)
                prompt_parts.append(filled)
            except KeyError as e:
                logger.warning(f"Missing template variable: {e}")
                prompt_parts.append(user_input)
        else:
            prompt_parts.append(user_input)

        return "\n".join(prompt_parts)

    def add_to_history(
        self,
        role: str,
        content: str,
        metadata: Optional[Dict] = None
    ) -> None:
        """
        Add a message to conversation history.

        Args:
            role: "user" or "assistant"
            content: Message content
            metadata: Optional metadata
        """
        entry = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        self.conversation_history.append(entry)

        # Trim history if needed
        if len(self.conversation_history) > self.max_history:
            self.conversation_history = self.conversation_history[-self.max_history:]

    def _format_history(self, max_entries: int = 5) -> str:
        """Format recent conversation history"""
        recent = self.conversation_history[-max_entries:]
        if not recent:
            return ""

        lines = []
        for entry in recent:
            role = entry["role"].upper()
            content = entry["content"][:200]  # Truncate long messages
            lines.append(f"{role}: {content}")

        return "\n".join(lines)

    def clear_history(self) -> None:
        """Clear conversation history"""
        self.conversation_history.clear()
        logger.info("Conversation history cleared")

    def detect_task_type(self, prompt: str) -> TaskType:
        """
        Detect the type of task from the prompt.

        Args:
            prompt: User's input

        Returns:
            Detected TaskType
        """
        prompt_lower = prompt.lower()

        # Coding indicators
        if any(kw in prompt_lower for kw in [
            "code", "function", "class", "debug", "implement",
            "python", "javascript", "typescript", "fix bug"
        ]):
            return TaskType.CODING

        # Research indicators
        if any(kw in prompt_lower for kw in [
            "research", "explain", "what is", "how does",
            "learn", "understand", "investigate"
        ]):
            return TaskType.RESEARCH

        # System admin indicators
        if any(kw in prompt_lower for kw in [
            "docker", "service", "process", "server", "deploy",
            "install", "configure", "restart"
        ]):
            return TaskType.SYSTEM_ADMIN

        # Security indicators
        if any(kw in prompt_lower for kw in [
            "security", "vulnerability", "threat", "protect",
            "encrypt", "password", "authentication"
        ]):
            return TaskType.SECURITY

        # Trading indicators
        if any(kw in prompt_lower for kw in [
            "trade", "market", "crypto", "bitcoin", "ethereum",
            "buy", "sell", "position", "portfolio"
        ]):
            return TaskType.TRADING

        # Smart home indicators
        if any(kw in prompt_lower for kw in [
            "light", "lamp", "device", "smart", "turn on",
            "turn off", "brightness", "color"
        ]):
            return TaskType.SMART_HOME

        # Default
        return TaskType.GENERAL

    def get_template(self, name: str) -> Optional[PromptTemplate]:
        """Get a template by name"""
        return self.templates.get(name)

    def add_template(self, template: PromptTemplate) -> None:
        """Add a custom template"""
        self.templates[template.name] = template
        logger.info(f"Added template: {template.name}")

    def __repr__(self) -> str:
        return (
            f"PromptManager(templates={len(self.templates)}, "
            f"history={len(self.conversation_history)})"
        )
