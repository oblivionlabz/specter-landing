"""
NUCLEUS Event Definitions

All events that flow through SPECTER's nervous system.
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional
import uuid


class EventType(Enum):
    """All event types in SPECTER"""

    # System Events
    SYSTEM_STARTUP = auto()
    SYSTEM_STARTED = auto()
    SYSTEM_SHUTDOWN = auto()
    SYSTEM_STOPPED = auto()
    SHUTDOWN_REQUESTED = auto()
    SYSTEM_ERROR = auto()
    SYSTEM_HEALTH_CHECK = auto()

    # Personality Events
    MOOD_CHANGE = auto()
    TRAIT_UPDATE = auto()
    PERSONALITY_EVOLUTION = auto()

    # Cortex (Brain) Events
    INFERENCE_REQUEST = auto()
    INFERENCE_RESPONSE = auto()
    INFERENCE_ERROR = auto()
    REASONING_START = auto()
    REASONING_COMPLETE = auto()

    # Echo (Voice) Events
    WAKE_WORD_DETECTED = auto()
    SPEECH_INPUT = auto()
    SPEECH_OUTPUT = auto()
    VOICE_ERROR = auto()

    # Iris (Vision) Events
    SCREEN_CHANGE = auto()
    OCR_RESULT = auto()
    VISUAL_CONTEXT = auto()

    # Memory Events
    MEMORY_STORE = auto()
    MEMORY_RETRIEVE = auto()
    MEMORY_CONSOLIDATE = auto()
    LEARNING_UPDATE = auto()

    # Executor Events
    TASK_SUBMITTED = auto()
    TASK_STARTED = auto()
    TASK_COMPLETED = auto()
    TASK_FAILED = auto()
    AGENT_SPAWNED = auto()
    AGENT_COMPLETED = auto()

    # Sentinel (Security) Events
    APPROVAL_REQUIRED = auto()
    APPROVAL_GRANTED = auto()
    APPROVAL_DENIED = auto()
    SECURITY_ALERT = auto()
    BOUNDARY_VIOLATION = auto()

    # Sentinel Agent (Network Monitoring) Events
    NETWORK_SCAN_STARTED = auto()
    NETWORK_SCAN_COMPLETED = auto()
    DEVICE_ONLINE = auto()
    DEVICE_OFFLINE = auto()
    DEVICE_STATE_CHANGED = auto()
    THREAT_DETECTED = auto()
    THREAT_RESOLVED = auto()
    DEVICE_BLOCKED = auto()
    DEVICE_UNBLOCKED = auto()
    DEVICE_ISOLATED = auto()
    DEVICE_TRUSTED = auto()
    DEVICE_UNTRUSTED = auto()

    # Integration Events
    DEVICE_DISCOVERED = auto()
    DEVICE_COMMAND = auto()
    DEVICE_STATUS = auto()
    WALLET_TRANSACTION = auto()
    TRADER_SIGNAL = auto()

    # User Interaction Events
    USER_INPUT = auto()
    USER_OUTPUT = auto()
    USER_FEEDBACK = auto()


@dataclass
class Event:
    """
    A single event in SPECTER's nervous system.

    Events are immutable once created and flow through the EventBus
    to all subscribed handlers.
    """

    type: EventType
    data: Any = None
    source: str = "unknown"
    target: Optional[str] = None  # None = broadcast
    priority: int = 50  # 0-100, higher = more important

    # Auto-generated fields
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: datetime = field(default_factory=datetime.now)

    def __post_init__(self):
        """Validate event after creation"""
        if not isinstance(self.type, EventType):
            raise ValueError(f"Invalid event type: {self.type}")
        if not 0 <= self.priority <= 100:
            raise ValueError(f"Priority must be 0-100, got {self.priority}")

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization"""
        return {
            "id": self.id,
            "type": self.type.name,
            "data": self.data,
            "source": self.source,
            "target": self.target,
            "priority": self.priority,
            "timestamp": self.timestamp.isoformat()
        }

    def __repr__(self) -> str:
        return f"Event({self.type.name}, id={self.id}, source={self.source})"


# Convenience constructors for common events
def system_event(event_type: EventType, data: Any = None) -> Event:
    """Create a system-level event"""
    return Event(type=event_type, data=data, source="system", priority=90)


def user_event(event_type: EventType, data: Any = None) -> Event:
    """Create a user-initiated event"""
    return Event(type=event_type, data=data, source="user", priority=75)


def internal_event(event_type: EventType, source: str, data: Any = None) -> Event:
    """Create an internal module event"""
    return Event(type=event_type, data=data, source=source, priority=50)


def sentinel_event(event_type: EventType, data: Any = None, priority: int = 60) -> Event:
    """Create a Sentinel Agent network/security event"""
    return Event(type=event_type, data=data, source="sentinel_agent", priority=priority)


def threat_event(data: Any, severity: str = "medium") -> Event:
    """Create a threat detection event with appropriate priority"""
    priority_map = {
        "critical": 95,
        "high": 85,
        "medium": 70,
        "low": 50,
        "info": 30
    }
    priority = priority_map.get(severity.lower(), 70)
    return Event(
        type=EventType.THREAT_DETECTED,
        data=data,
        source="sentinel_agent",
        priority=priority
    )
