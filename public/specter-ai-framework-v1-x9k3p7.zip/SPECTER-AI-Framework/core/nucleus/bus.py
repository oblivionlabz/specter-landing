"""
NUCLEUS Event Bus

The central nervous system of SPECTER. All modules communicate through here.

"When I speak, you listen." - Gibbs mode
"""

import asyncio
import logging
from typing import Any, Callable, Dict, List, Optional, Set
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
import threading

from .events import Event, EventType

logger = logging.getLogger("specter.nucleus")


@dataclass
class Subscription:
    """A subscription to an event type"""
    handler: Callable
    priority: int = 50  # Higher priority handlers run first
    async_handler: bool = False
    filter_source: Optional[str] = None  # Only receive from specific source


class EventBus:
    """
    SPECTER's central message bus.

    All modules register handlers here and communicate via events.
    This is the nervous system that connects CORTEX, ECHO, IRIS,
    MEMORY, EXECUTOR, SENTINEL, and all integrations.

    Features:
    - Sync and async handlers
    - Priority-based handler ordering
    - Source filtering
    - Event history for debugging
    - Thread-safe operation
    """

    def __init__(self, history_size: int = 1000):
        self._subscriptions: Dict[EventType, List[Subscription]] = defaultdict(list)
        self._history: List[Event] = []
        self._history_size = history_size
        self._lock = threading.RLock()
        self._running = False
        self._async_queue: asyncio.Queue = None
        self._stats = {
            "events_published": 0,
            "events_delivered": 0,
            "handlers_called": 0,
            "errors": 0
        }

        logger.info("NUCLEUS EventBus initialized")

    async def subscribe(
        self,
        event_type: EventType,
        handler: Callable,
        priority: int = 50,
        async_handler: bool = True,
        filter_source: Optional[str] = None
    ) -> None:
        """
        Subscribe a handler to an event type.

        Args:
            event_type: The type of event to listen for
            handler: Function to call when event occurs
            priority: Higher priority handlers run first (0-100)
            async_handler: Whether handler is async
            filter_source: Only receive events from this source
        """
        with self._lock:
            sub = Subscription(
                handler=handler,
                priority=priority,
                async_handler=async_handler,
                filter_source=filter_source
            )
            self._subscriptions[event_type].append(sub)
            # Sort by priority (highest first)
            self._subscriptions[event_type].sort(key=lambda s: -s.priority)

        logger.debug(f"Subscribed handler to {event_type.name} (priority={priority})")

    def unsubscribe(self, event_type: EventType, handler: Callable) -> bool:
        """Remove a handler from an event type"""
        with self._lock:
            subs = self._subscriptions[event_type]
            for i, sub in enumerate(subs):
                if sub.handler == handler:
                    subs.pop(i)
                    logger.debug(f"Unsubscribed handler from {event_type.name}")
                    return True
        return False

    async def publish(self, event: Event) -> int:
        """
        Publish an event to all subscribers.

        Returns the number of handlers that received the event.
        """
        with self._lock:
            # Add to history
            self._history.append(event)
            if len(self._history) > self._history_size:
                self._history.pop(0)

            self._stats["events_published"] += 1

        handlers_called = 0
        subs = self._subscriptions.get(event.type, [])

        for sub in subs:
            # Check source filter
            if sub.filter_source and sub.filter_source != event.source:
                continue

            # Check target filter
            if event.target and event.target != self._get_handler_module(sub.handler):
                continue

            try:
                if sub.async_handler:
                    # Queue for async processing
                    if self._async_queue:
                        asyncio.create_task(self._call_async_handler(sub.handler, event))
                else:
                    sub.handler(event)
                handlers_called += 1

            except Exception as e:
                logger.error(f"Handler error for {event.type.name}: {e}")
                self._stats["errors"] += 1

        with self._lock:
            self._stats["events_delivered"] += handlers_called
            self._stats["handlers_called"] += handlers_called

        logger.debug(f"Published {event.type.name} to {handlers_called} handlers")
        return handlers_called

    async def _call_async_handler(self, handler: Callable, event: Event) -> None:
        """Call an async handler"""
        try:
            await handler(event)
        except Exception as e:
            logger.error(f"Async handler error: {e}")
            self._stats["errors"] += 1

    def _get_handler_module(self, handler: Callable) -> str:
        """Get the module name of a handler"""
        module = getattr(handler, "__module__", "unknown")
        if "." in module:
            return module.split(".")[-2]  # e.g., "specter.core.cortex" -> "cortex"
        return module

    def publish_sync(self, event: Event) -> int:
        """Synchronous publish that waits for all handlers"""
        return self.publish(event)

    async def publish_async(self, event: Event) -> int:
        """Async publish for use in async contexts"""
        return self.publish(event)

    def get_history(
        self,
        event_type: Optional[EventType] = None,
        source: Optional[str] = None,
        limit: int = 100
    ) -> List[Event]:
        """Get event history with optional filtering"""
        with self._lock:
            events = self._history.copy()

        if event_type:
            events = [e for e in events if e.type == event_type]
        if source:
            events = [e for e in events if e.source == source]

        return events[-limit:]

    def get_stats(self) -> dict:
        """Get bus statistics"""
        with self._lock:
            stats = self._stats.copy()
            stats["subscriptions"] = sum(len(subs) for subs in self._subscriptions.values())
            stats["history_size"] = len(self._history)
        return stats

    def clear_history(self) -> None:
        """Clear event history"""
        with self._lock:
            self._history.clear()

    # Convenience methods for common event patterns

    def emit(self, event_type: EventType, data: Any = None, source: str = "unknown") -> int:
        """Quick emit without creating Event object"""
        event = Event(type=event_type, data=data, source=source)
        return self.publish(event)

    def request(
        self,
        event_type: EventType,
        data: Any = None,
        source: str = "unknown",
        timeout: float = 5.0
    ) -> Optional[Event]:
        """
        Request-response pattern.
        Publishes an event and waits for a response.
        """
        request_id = Event(type=event_type, data=data, source=source).id
        response_received = threading.Event()
        response_data = [None]

        def response_handler(event: Event):
            if event.data and event.data.get("request_id") == request_id:
                response_data[0] = event
                response_received.set()

        # Subscribe to response
        response_type = self._get_response_type(event_type)
        if response_type:
            self.subscribe(response_type, response_handler, priority=100)

        # Publish request
        self.emit(event_type, {"request_id": request_id, **data} if data else {"request_id": request_id}, source)

        # Wait for response
        response_received.wait(timeout=timeout)

        # Cleanup
        if response_type:
            self.unsubscribe(response_type, response_handler)

        return response_data[0]

    def _get_response_type(self, request_type: EventType) -> Optional[EventType]:
        """Map request types to their response types"""
        mapping = {
            EventType.INFERENCE_REQUEST: EventType.INFERENCE_RESPONSE,
            EventType.MEMORY_RETRIEVE: EventType.MEMORY_STORE,
            EventType.APPROVAL_REQUIRED: EventType.APPROVAL_GRANTED,
        }
        return mapping.get(request_type)


# Global event bus instance
_global_bus: Optional[EventBus] = None


def get_bus() -> EventBus:
    """Get the global event bus instance"""
    global _global_bus
    if _global_bus is None:
        _global_bus = EventBus()
    return _global_bus


def reset_bus() -> None:
    """Reset the global event bus (for testing)"""
    global _global_bus
    _global_bus = None
