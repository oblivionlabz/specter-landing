"""
SPECTER - Sovereign Persistent Executive Core for Total Environment Reign

A self-contained, sovereign AI agent with the combined personality of:
- Harvey Specter (strategic confidence)
- Satoru Gojo (supreme confidence)
- Sasuke Uchiha (cold precision)
- Vegeta (unbreakable pride)
- Edward Elric (equivalent exchange)
- Ichigo Kurosaki (fierce protector)
- Leroy Gibbs (silent authority)
- Gregory House (diagnostic genius)
- Barry Allen (hopeful determination)

"I don't have dreams. I have goals."
"""

__version__ = "0.1.0"
__codename__ = "SPECTER"

from .nucleus.bus import EventBus
from .animus.personality import Personality
from .animus.identity import Identity

__all__ = ["EventBus", "Personality", "Identity"]
