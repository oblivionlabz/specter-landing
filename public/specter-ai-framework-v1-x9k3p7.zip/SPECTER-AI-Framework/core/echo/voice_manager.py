"""
ECHO Voice Manager

Orchestrates all voice components: STT, TTS, and Wake Word.
Provides a unified interface for voice interaction.
"""

from pathlib import Path
from typing import Optional, Callable, Dict, Any
import logging
import asyncio
from dataclasses import dataclass
from datetime import datetime

from .stt import SpeechToText, AudioRecorder, TranscriptionResult
from .tts import TextToSpeech, SynthesisResult
from .wake_word import WakeWordDetector, WakeWordDetection

logger = logging.getLogger("specter.echo.voice_manager")


@dataclass
class VoiceInteraction:
    """A complete voice interaction"""
    user_audio: Any
    transcription: str
    response_text: str
    response_audio: Any
    timestamp: datetime
    duration: float


class VoiceManager:
    """
    Unified voice interaction manager.

    Coordinates:
    - Wake word detection
    - Speech-to-text transcription
    - Response generation (via callback)
    - Text-to-speech synthesis

    Provides seamless hands-free interaction.
    """

    def __init__(
        self,
        stt_model: str = "large-v3",
        tts_voice: str = "en_US-libritts_r-medium",
        wake_phrase: str = "hey specter",
        wake_sensitivity: float = 0.5,
        device: str = "cuda"
    ):
        # Components
        self.stt = SpeechToText(
            model_name=stt_model,
            device=device
        )
        self.tts = TextToSpeech(voice=tts_voice)
        self.wake_word = WakeWordDetector(
            phrase=wake_phrase,
            sensitivity=wake_sensitivity
        )
        self.recorder = AudioRecorder()

        # State
        self.initialized = False
        self.active = False
        self.listening_for_command = False
        self.processing = False

        # Callbacks
        self.response_callback: Optional[Callable[[str], asyncio.Future]] = None
        self.on_wake: Optional[Callable] = None
        self.on_transcription: Optional[Callable[[str], None]] = None
        self.on_response: Optional[Callable[[str], None]] = None

        # Settings
        self.listen_timeout = 10.0  # Max seconds to listen for command
        self.silence_threshold = 2.0  # Seconds of silence to end recording

        # Stats
        self.interactions_count = 0
        self.total_listen_time = 0.0

        logger.info("Voice manager created")

    async def initialize(self) -> bool:
        """Initialize all voice components"""
        if self.initialized:
            return True

        logger.info("Initializing voice system...")

        # Initialize STT
        stt_ok = await self.stt.initialize()
        if stt_ok:
            logger.info("  [+] STT initialized")
        else:
            logger.warning("  [!] STT failed to initialize")

        # Initialize TTS
        tts_ok = await self.tts.initialize()
        if tts_ok:
            logger.info("  [+] TTS initialized")
        else:
            logger.warning("  [!] TTS failed to initialize")

        # Initialize wake word
        wake_ok = await self.wake_word.initialize()
        if wake_ok:
            logger.info("  [+] Wake word initialized")
        else:
            logger.warning("  [!] Wake word failed to initialize")

        # Register wake word callback
        self.wake_word.add_callback(self._on_wake_detected)

        self.initialized = stt_ok or tts_ok  # At least one component
        return self.initialized

    def set_response_callback(
        self,
        callback: Callable[[str], asyncio.Future]
    ) -> None:
        """
        Set the callback for generating responses.

        The callback receives transcribed text and should return
        the response text to speak.
        """
        self.response_callback = callback

    def set_mood_parameters(self, params: Dict[str, float]) -> None:
        """Apply mood parameters to TTS"""
        self.tts.apply_mood_modulation(params)

    async def start(self) -> None:
        """Start voice interaction system"""
        if not self.initialized:
            await self.initialize()

        if self.active:
            return

        self.active = True
        await self.wake_word.start_listening()
        logger.info("Voice system active - listening for wake word")

    async def stop(self) -> None:
        """Stop voice interaction system"""
        self.active = False
        self.listening_for_command = False
        await self.wake_word.stop_listening()
        logger.info("Voice system stopped")

    async def _on_wake_detected(self, detection: WakeWordDetection) -> None:
        """Handle wake word detection"""
        if not self.active or self.processing:
            return

        logger.info(f"Wake word detected! Confidence: {detection.confidence:.2f}")

        if self.on_wake:
            try:
                if asyncio.iscoroutinefunction(self.on_wake):
                    await self.on_wake()
                else:
                    self.on_wake()
            except Exception as e:
                logger.error(f"Wake callback error: {e}")

        # Play acknowledgment
        await self.speak("Yes?")

        # Start listening for command
        await self._listen_for_command()

    async def _listen_for_command(self) -> None:
        """Listen for and process a voice command"""
        if self.listening_for_command:
            return

        self.listening_for_command = True
        self.processing = True

        try:
            # Record audio
            logger.info("Listening for command...")
            await self.recorder.start_recording()

            # Wait for speech with timeout
            start_time = datetime.now()
            audio = None

            while (datetime.now() - start_time).total_seconds() < self.listen_timeout:
                await asyncio.sleep(0.1)

                # Check for silence to end recording
                # In production, use VAD for proper silence detection
                if (datetime.now() - start_time).total_seconds() > 3.0:
                    break

            audio = await self.recorder.stop_recording()

            if audio is None or len(audio) < 1000:
                logger.info("No audio captured")
                await self.speak("I didn't catch that.")
                return

            listen_duration = (datetime.now() - start_time).total_seconds()
            self.total_listen_time += listen_duration

            # Transcribe
            logger.info("Transcribing...")
            result = await self.stt.transcribe(audio)

            if not result or not result.text.strip():
                logger.info("No speech detected")
                await self.speak("I didn't understand.")
                return

            transcription = result.text.strip()
            logger.info(f"Transcribed: {transcription}")

            if self.on_transcription:
                self.on_transcription(transcription)

            # Get response
            if self.response_callback:
                response = await self.response_callback(transcription)
            else:
                response = "I heard you, but I don't know how to respond yet."

            logger.info(f"Response: {response[:100]}...")

            if self.on_response:
                self.on_response(response)

            # Speak response
            await self.speak(response)

            self.interactions_count += 1

        except Exception as e:
            logger.error(f"Command processing error: {e}")
            await self.speak("I encountered an error.")

        finally:
            self.listening_for_command = False
            self.processing = False

    async def speak(self, text: str) -> bool:
        """
        Speak text using TTS.

        Args:
            text: Text to speak

        Returns:
            True if successful
        """
        if not text:
            return False

        if not self.tts.initialized:
            logger.warning("TTS not initialized, cannot speak")
            return False

        return await self.tts.speak(text)

    async def transcribe(self, audio) -> Optional[str]:
        """
        Transcribe audio to text.

        Args:
            audio: Audio data (numpy array or file path)

        Returns:
            Transcribed text or None
        """
        if isinstance(audio, (str, Path)):
            result = await self.stt.transcribe_file(Path(audio))
        else:
            result = await self.stt.transcribe(audio)

        return result.text if result else None

    async def process_text_input(self, text: str) -> Optional[str]:
        """
        Process text input (for non-voice interaction).

        Args:
            text: User input text

        Returns:
            Response text
        """
        if not self.response_callback:
            return None

        return await self.response_callback(text)

    def get_stats(self) -> Dict[str, Any]:
        """Get voice system statistics"""
        return {
            "initialized": self.initialized,
            "active": self.active,
            "processing": self.processing,
            "interactions": self.interactions_count,
            "total_listen_time": self.total_listen_time,
            "stt_initialized": self.stt.initialized if self.stt else False,
            "tts_initialized": self.tts.initialized if self.tts else False,
            "wake_word_listening": self.wake_word.listening if self.wake_word else False
        }

    async def shutdown(self) -> None:
        """Shutdown all voice components"""
        logger.info("Shutting down voice system...")

        await self.stop()
        await self.stt.shutdown()
        await self.tts.shutdown()
        await self.wake_word.shutdown()

        self.initialized = False
        logger.info("Voice system shutdown complete")
