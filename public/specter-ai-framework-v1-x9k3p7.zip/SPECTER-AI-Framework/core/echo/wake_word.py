"""
ECHO Wake Word Detection

Listens for "Hey Specter" to activate voice interaction.
"""

from typing import Optional, Callable, List
import logging
import asyncio
import numpy as np
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger("specter.echo.wake_word")


@dataclass
class WakeWordDetection:
    """A detected wake word event"""
    phrase: str
    confidence: float
    timestamp: datetime


class WakeWordDetector:
    """
    Wake word detector using OpenWakeWord.

    Listens continuously for the wake phrase and triggers callback.
    """

    def __init__(
        self,
        phrase: str = "hey specter",
        sensitivity: float = 0.5,
        sample_rate: int = 16000
    ):
        self.phrase = phrase.lower()
        self.sensitivity = sensitivity
        self.sample_rate = sample_rate

        self.model = None
        self.initialized = False
        self.listening = False
        self.callbacks: List[Callable] = []

        self._audio_stream = None
        self._listen_task = None

        logger.info(f"Wake word detector created: '{phrase}'")

    async def initialize(self) -> bool:
        """Initialize the wake word model"""
        if self.initialized:
            return True

        try:
            # Try to use openwakeword
            try:
                from openwakeword.model import Model

                # OpenWakeWord has pre-trained models
                self.model = Model(
                    wakeword_models=["hey_jarvis"],  # Use similar model
                    inference_framework="onnx"
                )
                self.engine = "openwakeword"
                logger.info("Using OpenWakeWord for detection")

            except ImportError:
                # Fallback to simple voice activity detection
                logger.warning("OpenWakeWord not available, using VAD fallback")
                self.engine = "vad_fallback"

            self.initialized = True
            return True

        except Exception as e:
            logger.error(f"Failed to initialize wake word: {e}")
            return False

    def add_callback(self, callback: Callable[[WakeWordDetection], None]) -> None:
        """Add callback for wake word detection"""
        self.callbacks.append(callback)

    def remove_callback(self, callback: Callable) -> None:
        """Remove a callback"""
        if callback in self.callbacks:
            self.callbacks.remove(callback)

    async def start_listening(self) -> None:
        """Start listening for wake word"""
        if self.listening:
            return

        if not self.initialized:
            await self.initialize()

        self.listening = True
        self._listen_task = asyncio.create_task(self._listen_loop())
        logger.info("Wake word detection started")

    async def stop_listening(self) -> None:
        """Stop listening for wake word"""
        self.listening = False

        if self._listen_task:
            self._listen_task.cancel()
            try:
                await self._listen_task
            except asyncio.CancelledError:
                pass
            self._listen_task = None

        logger.info("Wake word detection stopped")

    async def _listen_loop(self) -> None:
        """Main listening loop"""
        try:
            import sounddevice as sd

            chunk_size = int(self.sample_rate * 0.5)  # 500ms chunks

            def audio_callback(indata, frames, time, status):
                if status:
                    logger.warning(f"Audio status: {status}")
                if self.listening:
                    asyncio.create_task(self._process_audio(indata.copy()))

            with sd.InputStream(
                samplerate=self.sample_rate,
                channels=1,
                callback=audio_callback,
                blocksize=chunk_size
            ):
                while self.listening:
                    await asyncio.sleep(0.1)

        except Exception as e:
            logger.error(f"Listen loop error: {e}")
            self.listening = False

    async def _process_audio(self, audio: np.ndarray) -> None:
        """Process audio chunk for wake word"""
        if not self.listening:
            return

        try:
            if self.engine == "openwakeword":
                # Run OpenWakeWord prediction
                prediction = self.model.predict(audio.flatten())

                # Check if any wake word detected
                for model_name, scores in prediction.items():
                    if any(s > self.sensitivity for s in scores):
                        await self._trigger_detection(
                            confidence=max(scores)
                        )
                        break

            elif self.engine == "vad_fallback":
                # Simple energy-based VAD as fallback
                energy = np.sqrt(np.mean(audio ** 2))
                if energy > 0.02:  # Threshold for voice activity
                    # In fallback mode, we just detect voice activity
                    # A proper implementation would use actual wake word detection
                    pass

        except Exception as e:
            logger.error(f"Audio processing error: {e}")

    async def _trigger_detection(self, confidence: float) -> None:
        """Trigger wake word detection callbacks"""
        detection = WakeWordDetection(
            phrase=self.phrase,
            confidence=confidence,
            timestamp=datetime.now()
        )

        logger.info(f"Wake word detected: {confidence:.2f}")

        for callback in self.callbacks:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(detection)
                else:
                    callback(detection)
            except Exception as e:
                logger.error(f"Callback error: {e}")

    async def check_phrase(self, audio: np.ndarray) -> Optional[WakeWordDetection]:
        """
        Check if audio contains wake phrase.

        Args:
            audio: Audio to check

        Returns:
            WakeWordDetection if detected, None otherwise
        """
        if not self.initialized:
            return None

        try:
            if self.engine == "openwakeword":
                prediction = self.model.predict(audio.flatten())

                for model_name, scores in prediction.items():
                    if any(s > self.sensitivity for s in scores):
                        return WakeWordDetection(
                            phrase=self.phrase,
                            confidence=max(scores),
                            timestamp=datetime.now()
                        )

            return None

        except Exception as e:
            logger.error(f"Check phrase error: {e}")
            return None

    async def shutdown(self) -> None:
        """Shutdown the detector"""
        await self.stop_listening()
        if self.model:
            del self.model
            self.model = None
        self.initialized = False
        logger.info("Wake word detector shutdown complete")
