"""
ECHO Text-to-Speech

Converts text to spoken audio using Piper TTS.
Voice parameters adapt based on SPECTER's mood.
"""

from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass
import logging
import asyncio
import numpy as np
from datetime import datetime
import subprocess
import tempfile
import wave

logger = logging.getLogger("specter.echo.tts")


@dataclass
class SynthesisResult:
    """Result of speech synthesis"""
    audio: np.ndarray
    sample_rate: int
    duration: float
    text: str


class TextToSpeech:
    """
    Text-to-speech engine using Piper.

    Features:
    - Natural sounding voices
    - Speed and pitch control
    - Mood-based voice modulation
    - GPU acceleration
    """

    def __init__(
        self,
        voice: str = "en_US-libritts_r-medium",
        speed: float = 1.05,
        pitch: float = 0.0,
        model_dir: Optional[Path] = None
    ):
        self.voice = voice
        self.base_speed = speed
        self.base_pitch = pitch
        self.model_dir = model_dir or Path("/specter/models/piper")

        self.current_speed = speed
        self.current_pitch = pitch
        self.initialized = False

        logger.info(f"TTS engine created: {voice}")

    async def initialize(self) -> bool:
        """Initialize the TTS engine"""
        if self.initialized:
            return True

        try:
            # Check if piper is available
            result = subprocess.run(
                ["which", "piper"],
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                # Try pip installed piper-tts
                try:
                    import piper
                    self.use_python = True
                    logger.info("Using piper-tts Python library")
                except ImportError:
                    logger.warning("Piper not found, TTS will be disabled")
                    return False
            else:
                self.use_python = False
                self.piper_path = result.stdout.strip()
                logger.info(f"Using piper CLI: {self.piper_path}")

            self.initialized = True
            return True

        except Exception as e:
            logger.error(f"Failed to initialize TTS: {e}")
            return False

    def set_voice_parameters(
        self,
        speed: Optional[float] = None,
        pitch: Optional[float] = None
    ) -> None:
        """Update voice parameters"""
        if speed is not None:
            self.current_speed = speed
        if pitch is not None:
            self.current_pitch = pitch

    def apply_mood_modulation(self, mood_params: Dict[str, float]) -> None:
        """
        Apply mood-based voice modulation.

        Args:
            mood_params: Dict with 'energy', 'pace', etc.
        """
        energy = mood_params.get("energy", 1.0)
        pace = mood_params.get("pace", 1.0)

        # Adjust speed based on energy and pace
        self.current_speed = self.base_speed * pace * (0.9 + energy * 0.2)

        # Clamp to reasonable range
        self.current_speed = max(0.5, min(2.0, self.current_speed))

        logger.debug(f"Voice modulated: speed={self.current_speed:.2f}")

    async def synthesize(self, text: str) -> Optional[SynthesisResult]:
        """
        Synthesize text to speech.

        Args:
            text: Text to synthesize

        Returns:
            SynthesisResult with audio data
        """
        if not self.initialized:
            logger.warning("TTS not initialized")
            return None

        if not text.strip():
            return None

        try:
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                output_path = Path(tmp.name)

            loop = asyncio.get_event_loop()

            if self.use_python:
                await self._synthesize_python(text, output_path)
            else:
                await loop.run_in_executor(
                    None,
                    lambda: self._synthesize_cli(text, output_path)
                )

            # Read the generated audio
            audio, sample_rate = await loop.run_in_executor(
                None,
                lambda: self._read_wav(output_path)
            )

            # Apply speed adjustment (simple resampling)
            if self.current_speed != 1.0:
                import scipy.signal as signal
                new_length = int(len(audio) / self.current_speed)
                audio = signal.resample(audio, new_length)

            # Cleanup
            output_path.unlink(missing_ok=True)

            return SynthesisResult(
                audio=audio,
                sample_rate=sample_rate,
                duration=len(audio) / sample_rate,
                text=text
            )

        except Exception as e:
            logger.error(f"Synthesis failed: {e}")
            return None

    def _synthesize_cli(self, text: str, output_path: Path) -> None:
        """Synthesize using piper CLI"""
        model_path = self.model_dir / f"{self.voice}.onnx"

        cmd = [
            self.piper_path,
            "--model", str(model_path),
            "--output_file", str(output_path)
        ]

        process = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

        process.communicate(input=text.encode())

    async def _synthesize_python(self, text: str, output_path: Path) -> None:
        """Synthesize using piper-tts Python library"""
        try:
            from piper import PiperVoice

            model_path = self.model_dir / f"{self.voice}.onnx"
            config_path = self.model_dir / f"{self.voice}.onnx.json"

            voice = PiperVoice.load(str(model_path), config_path=str(config_path))

            with wave.open(str(output_path), "wb") as wav_file:
                voice.synthesize(text, wav_file)

        except Exception as e:
            logger.error(f"Python synthesis failed: {e}")
            raise

    def _read_wav(self, path: Path) -> tuple:
        """Read WAV file and return audio data"""
        import soundfile as sf
        audio, sample_rate = sf.read(str(path))
        return audio.astype(np.float32), sample_rate

    async def speak(self, text: str) -> bool:
        """
        Synthesize and play audio directly.

        Args:
            text: Text to speak

        Returns:
            True if successful
        """
        result = await self.synthesize(text)
        if not result:
            return False

        try:
            import sounddevice as sd

            sd.play(result.audio, result.sample_rate)
            sd.wait()
            return True

        except Exception as e:
            logger.error(f"Playback failed: {e}")
            return False

    async def shutdown(self) -> None:
        """Shutdown TTS engine"""
        self.initialized = False
        logger.info("TTS shutdown complete")
