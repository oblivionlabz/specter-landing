"""
ECHO - SPECTER's Voice System

Handles speech-to-text, text-to-speech, and wake word detection.
"When I speak, you listen." - Commander mode
"""

from .stt import SpeechToText, TranscriptionResult
from .tts import TextToSpeech
from .wake_word import WakeWordDetector
from .voice_manager import VoiceManager

__all__ = [
    "SpeechToText",
    "TranscriptionResult",
    "TextToSpeech",
    "WakeWordDetector",
    "VoiceManager"
]
