"""
ECHO Speech-to-Text

Converts spoken audio to text using Whisper.
"The puzzle is everything. Find the truth." - Diagnostic mode
"""

from pathlib import Path
from typing import Optional, List, Callable, Any
from dataclasses import dataclass
import logging
import asyncio
import numpy as np
from datetime import datetime

logger = logging.getLogger("specter.echo.stt")


@dataclass
class TranscriptionResult:
    """Result of speech transcription"""
    text: str
    language: str
    confidence: float
    duration: float
    segments: List[dict]
    timestamp: datetime


class SpeechToText:
    """
    Speech-to-text engine using Whisper.

    Supports:
    - Real-time transcription
    - Audio file transcription
    - Language detection
    - Confidence scoring
    """

    def __init__(
        self,
        model_name: str = "large-v3",
        device: str = "cuda",
        language: str = "en",
        compute_type: str = "float16"
    ):
        self.model_name = model_name
        self.device = device
        self.language = language
        self.compute_type = compute_type
        self.model = None
        self.initialized = False

        logger.info(f"STT engine created: {model_name} on {device}")

    async def initialize(self) -> bool:
        """Initialize the Whisper model"""
        if self.initialized:
            return True

        try:
            # Try faster-whisper first (optimized)
            try:
                from faster_whisper import WhisperModel

                logger.info(f"Loading Faster-Whisper model: {self.model_name}")

                loop = asyncio.get_event_loop()
                self.model = await loop.run_in_executor(
                    None,
                    lambda: WhisperModel(
                        self.model_name,
                        device=self.device,
                        compute_type=self.compute_type
                    )
                )
                self.engine = "faster-whisper"

            except ImportError:
                # Fall back to OpenAI whisper
                import whisper

                logger.info(f"Loading OpenAI Whisper model: {self.model_name}")

                loop = asyncio.get_event_loop()
                self.model = await loop.run_in_executor(
                    None,
                    lambda: whisper.load_model(self.model_name, device=self.device)
                )
                self.engine = "openai-whisper"

            self.initialized = True
            logger.info(f"STT initialized with {self.engine}")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize STT: {e}")
            return False

    async def transcribe(
        self,
        audio: np.ndarray,
        sample_rate: int = 16000
    ) -> Optional[TranscriptionResult]:
        """
        Transcribe audio array to text.

        Args:
            audio: Audio data as numpy array
            sample_rate: Sample rate of audio

        Returns:
            TranscriptionResult or None on failure
        """
        if not self.initialized:
            logger.warning("STT not initialized")
            return None

        start_time = datetime.now()

        try:
            loop = asyncio.get_event_loop()

            if self.engine == "faster-whisper":
                segments, info = await loop.run_in_executor(
                    None,
                    lambda: self.model.transcribe(
                        audio,
                        language=self.language,
                        beam_size=5,
                        vad_filter=True
                    )
                )

                segments_list = list(segments)
                text = " ".join(s.text.strip() for s in segments_list)

                return TranscriptionResult(
                    text=text,
                    language=info.language,
                    confidence=info.language_probability,
                    duration=(datetime.now() - start_time).total_seconds(),
                    segments=[{
                        "start": s.start,
                        "end": s.end,
                        "text": s.text
                    } for s in segments_list],
                    timestamp=datetime.now()
                )

            else:  # openai-whisper
                result = await loop.run_in_executor(
                    None,
                    lambda: self.model.transcribe(
                        audio,
                        language=self.language,
                        fp16=self.device == "cuda"
                    )
                )

                return TranscriptionResult(
                    text=result["text"].strip(),
                    language=result.get("language", self.language),
                    confidence=1.0,
                    duration=(datetime.now() - start_time).total_seconds(),
                    segments=result.get("segments", []),
                    timestamp=datetime.now()
                )

        except Exception as e:
            logger.error(f"Transcription failed: {e}")
            return None

    async def transcribe_file(self, audio_path: Path) -> Optional[TranscriptionResult]:
        """Transcribe an audio file"""
        if not self.initialized:
            logger.warning("STT not initialized")
            return None

        if not audio_path.exists():
            logger.error(f"Audio file not found: {audio_path}")
            return None

        try:
            import soundfile as sf

            audio, sample_rate = sf.read(str(audio_path))

            # Convert to mono if stereo
            if len(audio.shape) > 1:
                audio = audio.mean(axis=1)

            # Resample to 16kHz if needed
            if sample_rate != 16000:
                import librosa
                audio = librosa.resample(audio, orig_sr=sample_rate, target_sr=16000)

            return await self.transcribe(audio.astype(np.float32))

        except Exception as e:
            logger.error(f"Failed to transcribe file: {e}")
            return None

    async def shutdown(self) -> None:
        """Shutdown and free resources"""
        if self.model:
            del self.model
            self.model = None
        self.initialized = False
        logger.info("STT shutdown complete")


class AudioRecorder:
    """
    Records audio from microphone for transcription.
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        channels: int = 1,
        chunk_duration: float = 0.5
    ):
        self.sample_rate = sample_rate
        self.channels = channels
        self.chunk_duration = chunk_duration
        self.chunk_size = int(sample_rate * chunk_duration)

        self.recording = False
        self.audio_buffer: List[np.ndarray] = []
        self.stream = None

    async def start_recording(self) -> None:
        """Start recording from microphone"""
        if self.recording:
            return

        try:
            import sounddevice as sd

            self.audio_buffer = []
            self.recording = True

            def callback(indata, frames, time, status):
                if status:
                    logger.warning(f"Audio status: {status}")
                if self.recording:
                    self.audio_buffer.append(indata.copy())

            self.stream = sd.InputStream(
                samplerate=self.sample_rate,
                channels=self.channels,
                callback=callback,
                blocksize=self.chunk_size
            )
            self.stream.start()

            logger.debug("Recording started")

        except Exception as e:
            logger.error(f"Failed to start recording: {e}")
            self.recording = False

    async def stop_recording(self) -> Optional[np.ndarray]:
        """Stop recording and return audio data"""
        if not self.recording:
            return None

        self.recording = False

        if self.stream:
            self.stream.stop()
            self.stream.close()
            self.stream = None

        if not self.audio_buffer:
            return None

        audio = np.concatenate(self.audio_buffer, axis=0)
        self.audio_buffer = []

        logger.debug(f"Recording stopped: {len(audio)} samples")
        return audio.flatten().astype(np.float32)

    async def record_duration(self, duration: float) -> Optional[np.ndarray]:
        """Record for a specific duration"""
        await self.start_recording()
        await asyncio.sleep(duration)
        return await self.stop_recording()
